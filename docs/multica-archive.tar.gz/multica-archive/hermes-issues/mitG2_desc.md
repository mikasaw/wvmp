# WVmp MIT-G2 派活单 — 跳转表残余形态：8B 绝对表 + jmp [mem] 表 + 无防御表实测裁决

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: G 线 W2 | MIT-409 done (MSVC 4B-delta+防御表, 比较链, translator.cpp:834 translate_jump_table) | triage 409 §F 残余登记: 8B 绝对表 / clang `jmp [tbl+idx*8]` / 无防御表 → 照旧 gate
> 前置阅读: 本单 → translator.cpp translate_jump_table 全函数 (:834 起) + 匹配器入口 (:767 附近 case 链) → mit409-ruling §2 → `.multica/mit-D1-triage.md` (跳转表先验格式)

---

## §A 基线实测事实 (项目主 fresh verify @ main 1734829, 2026-08-29 21:5x)

### A.1 现网
- main = `1734829` (411/G1 合入后); build 0 错 / ctest 16/16 / **multiseed 基线 32 样本 × 5 = 160/160** / wvmpTest 14/14 满贯 + 双跑 103/103 + jump-table @0xDD84 entries=8 命中 + ExitNative 17 站点
- 411 刚合入 lifter 折叠, 与 translator 跳转表**零文件重叠** → 本单 translator.cpp 独占无并发风险 (派单时主工作区必须 CLEAN 且 main)

### A.2 409 既有实现锚 (本单扩展基座)
- 匹配器现状 (409 c27a0fc + 放宽 c04ca49): lea-rip 基址 → mov idx 读 u32 表项 → add base → jmp reg 四件套; 表长 = `cmp idx, K-1` 防御常数; 全目标 ∈ 区域块表硬判据; 比较链 `Mov→LeaRva→Cmp→Jcc(E)` ×K + 链尾 Halt; **lifter 死代码保留** (409 配套: build_blocks 不丢"只经表可达"块)
- **本机工具链实测 (项目主 21:5x)**: `where clang` / gcc / MinGW 全部不存在 → clang/GCC 平台形态**无法产真样本** → 本单正样本必须 **MASM 手拼** (`_emit`/`dq` 表体 + 手编基址/索引序列), 411 sse_memop 样本的 MASM 手法 (ml64 在 vcvars64 直接可用) 即模板; 披露"clang 真产物兼容性未验证"为 §F

### A.3 三形态目标定义 (MASM 可构造性项目主已核)
| 形态 | 编码 | 表项语义 | 匹配窗口变化 |
|---|---|---|---|
| **G2-a 8B 绝对表** | 同四件套但 `movabs`/`mov` 读 qword (`48 8B 84 C1 …` 或 `mov reg,[base+idx*8]` 读 8 字节项) | 项 = **完整 VA** (非 delta) → 目标 RVA = 表项 − image_base | 项宽 aux 8; 还原减 image_base (翻译期: PE 已知基) 后过"全 ∈ 区"判据 |
| **G2-b `jmp [tbl+idx*8]`** (mem 源直跳, clang/GCC 风格) | capstone `X86_INS_JMP` op0=**MEM** (base=lea 过的 tbl 或 rip 直接 disp, index=idx*scale) | 项目主实测 GCC 变体项可为 **delta-from-jmp 指令地址** (`t[case]-.L4`)——**表项基址语义两种都要试**, 判据失败如实披露"仅支持可判定的一种" | op0=MEM 分支新挂点 (409 是 REG); 表基址来自 disp 常量或 lea |
| **G2-c 无防御表** | 四件套缺 `cmp K-1; ja` | 表长不可静态推 | **D2 裁决: 保持 gate** (409 拍板"禁扫 int3"纪律不破——0xCCCCCC 填充证据 mit409 §A.2), 本单仅固化负例证据 |

## §B 任务

1. **B.1 匹配器扩 G2-a**: 读表项宽度 u32/u64 双形态 (aux); 8B 项按"绝对 VA − 翻译期 image_base → RVA"还原再过区判据; **两种 8B 语义 (绝对 VA vs delta) 都要实测 MASM 构造** (GCC 绝对/MSVC-style delta 都可能), 至少一种进, 另一种照旧 gate 如实披露
2. **B.2 匹配器扩 G2-b**: `translate_jmp` op0=MEM 的表模式识别 (disp32 rip 表基址 或 lea 基址 + SIB index*scale); 目标 ∈ 区判据 + 表长推导同 D2 (无防御 gate)
3. **B.3 表长纪律** (硬): 一切新形态表长**仅认 `cmp idx,K-1; ja/jae` 防御常数**; 禁"扫填充/扫非法值"推导 (mit409 §A.2 第 9 项 0xCCCCCCCC 证据)。G2-c 交付 = 负例样本断言 gate + 报告写明原因链
4. **B.4 E2E 样本**: 新 `wvmp_jmp_table8_sample` (MASM 手拼 8B 表, switch-like 语义 + 主函数真虚拟化 REQUIRE_REAL) + G2-b 表形态样本 (可同文件多区域) + 负例 (无防御/目标出区/表项指向数据段) 各 ≥1; 影子按需 (flags 面零涉, 比较链 409 影子已覆盖通路, 本单可复用其结论并披露)
5. **B.5 注册+基线**: CMakeLists + multiseed (32→33/34, 预计 **165-170/170**), 注释头对齐 (408 尾巴 411 已清偿, 保持); dump/static 双门 (新形态 handler 零新增预期, 复用比较链)
6. **B.6 零回踩**: 409 r06 命中链 (wvmpTest jump-table @0xDD84 entries=8 note 原样) + 比较链语义不变 + ExitNative 17 + 14/14 满贯 + 160 既有 runs 全绿
7. **B.7 GAPS/文档**: C1 节跳转表行更新 (新支持面 + 残余清单收窄: clang 真产物未验 / 无防御保持 gate / 表含数据段交叉情形)

## §C 决策点 (项目主已拍板)

- **D1 8B 项双语义全试** (✅): 至少一语义进 + 区判据硬底线; 全试失败诚实单形态交付 (负例固化, §F)
- **D2 无防御 = 永久 gate 保持** (✅): 表长不可推是保守哲学非 laziness; **扩区/链尾 halt 兜底** 类方案已审 (mit409 D4 精神), 未来若 GAPS 重新分级再议
- **D3 MASM 手拼样本授权** (✅): 形态支持验证以字节为准; 披露"无真 clang/GCC 样本"局限, 报告留 clang 重验钩子 (未来环境到位复跑)
- **D4 改面约束** (✅): 优先扩既有 translate_jump_table 匹配器参数化 (宽度/基址语义/MEM 源三参数), 禁复制第二套匹配器; 若实测复杂度证明拆分更清晰, 披露后自定

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 (+新单测: 匹配器新形态 lifter/translator 级单测各 ≥2) / **multiseed REQUIRE_REAL=1 全绿** (预计 165-170)
2. 新样本真虚拟化 (protect stub 计数日志 + 语义值手算核对) + 负例 gate 日志逐字节
3. 实汇编对照表 (每形态: MASM 字节 → capstone → 匹配路径 → 比较链 diag) + jump-table note 计数变化报告
4. 零回踩: wvmpTest 14/14 + jump-table@0xDD84 原样 + 双跑 103/103 diff 0 + 160 既有全绿
5. 冻结契约: runtime.hpp/ir::Op/backend.hpp BytecodeCodec/callgate/kExitSlotDepth/lifter 死代码保留(409) 零破坏
6. **硬条款**: tracked 零脏附输出 + 完工切回 main (⚠️ 无并发运行占用时必执行; 被占用则如实披露"留给下一顺位", 412 例外注记条款生效); 单分支 ff-safe
7. ≥30 分钟; 数据主张附复跑命令

## §E 纪律 (407 v2 版全文继承)

worktree 隔离 / wvmpTest 基线禁覆写 / `cmd /c` / capstone 以 vendored 头枚举名为准 (404 分裂枚举教训; 8B 表项 `mov` 读宽度与 X86_OP_MEM scale=8 形态实测) / ml64 模板抄 411 sse_memop 样本 / **#33**: §A.3 表语义先验全部可能被实测推翻, 推翻优先; 匹配窗口与真实编译器风格不符处按实测放宽但**区判据+表长纪律两条硬底线零让步**。

## §F known compromise 预判

1. clang/GCC 真产物兼容性未验证 (本机无工具链, MASM 拼写等价字节形态; 未来环境复跑钩子已留)
2. 无防御表永久 gate (D2)——理论上编译器防御被 /O2 消除的产物会漏保护, 接受 (gate=保守原生执行非坏壳)
3. delta-from-jmp vs delta-from-base 语义若实测歧义无法静态判定 → 取区判据通过者, 双不过 gate
4. 8B 表规模上界未调 (比较链 K≤32 预算继承 409)

时间预算: ~半天。== MIT-G2 派活单完 ==
