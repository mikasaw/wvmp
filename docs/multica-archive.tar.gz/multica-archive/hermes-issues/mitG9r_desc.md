# WVmp MIT-G9r 派活单 — SIMD 尾族频率 + G8-BMI 载体成本 + 跳表扩容前置量化（侦察三合一，阶段收官决策输入）

> 派活单生成: 2026-08-31, 接手人 (项目主)
> 性质: **纯侦察零代码单**（405/D1、412/G7r、416/G5r、424/G6r 五先例同构）——产出=一份 triage 报告落 `.multica/mit-G9r-triage.md` 进命名分支，**指令虚拟化阶段收官波次的三合一决策输入**，项目主按数字拍板后才立实施单
> 交付形态: **main 之外的命名分支 `mit-g9r-tri-recon`**（triage 文档落分支，单 commit，ff-merge 由项目主执行）；零产品代码改动
> 关联: main `0ac661a` (428 合入后, 基线 46 样本 **230/230**, 硬条款七连满分) | GAPS:193-196 残余登记行 = 本单三路对象

---

## §A 基线实测事实 (项目主 fresh verify @ main 0ac661a, 2026-08-31 03:1x)

### A.1 现网
- main = `0ac661a`; build 0 错 / ctest 16/16 / **multiseed 46 样本 × 5 = 230/230** / wvmpTest 14/14；kVmOpMax=**97**（vm_op.hpp:582）
- 424 triage（`.multica/mit-G6r-triage.md`, 207 行）已建立全套方法论：**System32 4354 文件预扫→86 全扫、.pdata 函数域 capstone 全扫、九宫格探针矩阵、E2E 三态确认**——本单三路全部复用其方法与语料（424 语料结论直接引用不重扫）

### A.2 路1 锚（SIMD 尾族——pmovmskb / pcmpeq/pcmpgt / punpck 系）
- lifter 白名单三族 grep = **0**（本单亲验）；GAPS:193-195 登记行现文："与 G1d 通路叠加）；pmovmskb（66 0F D7）/ pcmpeq/pcmpgt 系（SSE 整数比较族）/ punpckldq/punpcklqdq（66 0F 62/6C 交织语义，D4 裁决非纯拷贝"
- 语义复杂度画像（项目主预判，你实测复核）：
  - **pmovmskb**（66 0F D7）: xmm→GPR 位图提取——**427 桥（GpFromXmm 全宽截取）的近亲**，但需 16 位打包提取语义；新 VmOp or native 直执行 handler（419 xadd 模板）？成本≈桥半张单？——**用频率判该不该花**
  - **pcmpeqb/w/d/q + pcmpgt 族**（66 0F 74/75 等）: lane 比较→掩码写回——新 VmOp 群（4 宽度×2 比较=8 值预算）或 GP 域拆 lane 折条（成本爆面预判）
  - **punpcklqdq/hqdq**（66 0F 6C/6D，128-bit 全宽交织）: lqdq/hqdq = 高低 64-bit 重组——**可能 = XmmLoad/XmmStore+桥组合折条零新 op**（q 粒度交织本质是 8B 搬运重组）；lbw/lwd/lqdq 系字节/字粒度交织则需 lane 操作（预判爆面）
- **427/428 频率证据缺口**: 两单实测 intrinsic 伴随面只证 movdqa 高频（428 翻转闭环），punpck 在 cpp_movdqa_neg 残留 gate=**intrinsic 溢出也会产 punpck**（_mm_set_epi64x 类）——该形态真实高频性待语料计数

### A.3 路2 锚（G8-BMI：rorx/mulx/andn/shlx/sarx/shrx/pdep/pext/blsr）
- capstone id 在位亲验（.deps/capstone-src/include/capstone/x86.h）: **ANDN=412（与 ANDNPS=414 id 分裂——lifter 折叠不互染）**、RORX=1024、MULX=890、SHLX=1072；VEX-GP 不经前缀闸直达 switch（424 §2.4 机制实证）
- **424 频率先验**: ClipUp rorx:288、wmp/BioIso mulx:898、smartscreen rorx:1088、ntdll shlx:28+pdep:14、ucrtbase shlx:30——**真实高频已证**，本路只需补"客户态 exe 分档抽测"与三族细分计数，不必全量重扫
- 折叠原料在位亲验: `:2338-2339` ROL/ROR 白名单（**rorx≈ROR 非破坏形**）、Not/And/Sar/Shl/Add 全在——**rorx/shlx/sarx/shrx/blsr 预判零新 VmOp 折条可行**（三地址形态直接复用 426 translate_vex128 折叠器框架！shlx 只是"cnt 在 reg 而非 imm"——shift 载体扩判）；**mulx=三操作数无标志乘法**（:916 双语义槽拼装先例）、**andn=NOT(a)&b**（425 Andnps 整数版，Op::Not+Op::And 折条或复用 Andnps 通路——实测选）、**pdep/pext=位散布压缩**（微程序循环 or native 直执行 handler——成本核心变量）
- 载体域: src2=imm 已占 0..4(string)/5..13(lock)/14..18(sse)/19..21(bridge)——**下一可用域自 22 起**（每次新用全域对账，419 教训铁律：428 亲验 `imul ...,12` 不误拦机制在位）
- **BMI 特有语义面**: mulx 写 CF（唯一）、rorx **不写 flags**（与 ror 关键差异——flags 语义分叉必须实测钉，禁照搬 translate_shift）、shlx 非破坏=不改 dst flags? （SDM 口径逐条核）

### A.4 路3 锚（跳表 128→256 扩容前置量化——G6r-B0）
- 现机制直读（asmgen.cpp:14/:28/:181 注释）: dispatch `T8=[BYTE+PC*8]` → `and T0, kTableEntries-1(=0x7F)`；表项 u64×128 原样追加码尾——**扩容=改 kTableEntries 常量 + mask 位 + 尺寸派生式**（MIT-B2 编译期派生+static_assert 先例，mod-16 纪律）
- 冲击面预判（你逐条量化）: ① 码体 +1KB/壳（128 项→256 项 ×8B——pe_writer 布局/section 尺寸派生是否自动跟随）② build_dispatch 掩码/断言回归 ③ **三债务共享**: 档B ymm 新 op 群 ~20-30（424 §B-2）/ x87 L0 ~80 op（416 估）/ G8-BMI 若走 op 路线——**97+80=177>128 溢出临界=x87 L0 启动的硬前置**（424 §4 B-2 已指认，本路给精确触发点）④ 423 后 stub 侧无感验证（表在 runtime 码体内，宿主 exe 布局无关？实测钉）
- **交付=一张扩容成本卡**（S 级 or M 级、文件清单、风险点、触发条件建议"何 op 计数阈值时启动"）

## §B 任务（三路，全部分节独立可读）

1. **B.1 路1 频率实测**: 复用 424 方法——424 已扫 86 语料直接二次统计三族计数（**零重扫成本**：424 留样/方法内嵌可重建，或重跑其扫法脚本化计数）+ /Od-/O2 intrinsic 探针矩阵（_mm_movemask_epi8/_mm_cmpeq_epi32/_mm_set_epi64x→punpck 溢出）+ 客户态 exe ≥10 抽测（424 49 阳性集外的新面）→ **裁决矩阵: 每族 {频率档, 折叠成本档(零新op/桥近亲/新op群), 建议 立项/文档化gate/永久gate}**
2. **B.2 路2 载体设计成本**: 逐指令折叠可行性表（rorx/shlx/sarx/shrx/blsr/andn/mulx/pdep/pext/bzhi——**flags 语义 SDM 逐条核 + 与既有 Op 白名单映射 + 426 折叠器复用度 + 载体域 22.. 方案 + 三地址形态分布实测**）+ 拆单蓝图（G8a 折条款目 vs G8b pdep/pext 独立档？规模 M 量化）；**E2E 三态**: BMI 形态现状 gate 零逃逸亲验（424 §3 同构，样本可 MASM/C5 编码直写）
3. **B.3 路3 扩容成本卡**: §A.4 四冲击面逐项实测（**可在 worktree 内做 spike 改常量试编译**——不落分支，spike 结论进报告；若改 256 后 230 全绿=成本 S 直接说；触碰 pe_writer 布局则量化到文件级）+ 触发阈值建议（x87 L0/BMI-op/ymm 三债哪条先启动谁付前置）
4. **B.4 路线裁决**: 三路合一给 G 线收官波次**排序建议**（对齐 230/230 基线与 410 M3 优先级——用户既定"先完成指令虚拟化阶段目标再开新内容"，但**阶段边界本身可由你的数字重定义**: 若三族+BMI 全判文档化 gate，阶段即刻收官）
5. **B.5 文档联动草案**: GAPS:193-196 精确化文本草案 + 426 G6a ①行（BMI）+ :153 行现状声明同步（只进报告草案，项目主拍板后实施单落）

## §C 决策点（项目主已拍板）

- **D1 三路全报，不因预判砍路**（✅）: punpcklqdq "可能零新 op"与 pdep/pext "可能爆面"两个预判**都要实测**出数；任何一路想跳过=在报告披露理由+等价证据，不接受无数据跳过
- **D2 语料复用优先**（✅）: 424 方法与已扫集优先复用（二次统计/内嵌留样重建），新增扫测聚焦 424 未覆盖面（BMI 细分、三族计数、客户态新样本）——**别烧钟点重跑 4354 预扫**
- **D3 flags 语义红线**（✅）: A.3 列的 rorx 不写 flags/mulx 仅 CF/shlx 非破坏——**SDM 逐条 + native 行为 probe 双验**，这是 BMI 折叠单未来的验收硬项，侦察期先把语义事实钉死
- **D4 spike 隔离**（✅）: B.3 试编译走 worktree/detached，主仓与 0ac661a 零扰动；spike 补丁以 diff 文本内嵌报告（留样纪律 424/426 同款）

## §D 验收标准

1. triage 报告 `.multica/mit-G9r-triage.md` 落命名分支单 commit，ff-safe；主仓 main 未动、tracked 零脏、切回 main
2. 路1: 三族×{语料计数表(方法+分母+样本清单), 探针矩阵, 折叠成本判据} + 裁决矩阵三行齐；路2: ≥9 指令可行性表（flags SDM 页码引用 + probe 实证列）+ 载体域对账 + 拆单蓝图 + E2E 现状三态；路3: 四冲击面逐项 + spike 试编译结果（256 表 ctest/multiseed 抽跑 ≥10 样本）+ 触发阈值建议
3. 路线裁决节: 收官波次排序含**反方陈述**（"全部文档化 gate 即刻收官"的成本对比侧——用户重定义阶段边界的决策依据）
4. #33 纪律: §A.2/A.3/A.4 项目主预判（lqdq 折条可行、rorx 零新 op、扩容 S 级、四冲击清单）**逐条实测兜底，推翻优先**；424 数字二次引用时注明"引用 424 实测"非自测
5. 硬条款: ≥30 分钟时间对账 + honest disclosure 优先 + 留样内嵌报告（%TEMP% 清理可重建）

## §E 纪律

worktree 隔离 / `cmd /c` bat（查 build log 时间戳防空跑）/ capstone probe 用 vendored `.deps/capstone-src`（Python C:/Python314 + capstone 5.0.7 同核先例）/ MASM/C5 编码直写探针（426/428 手编纪律：pp/vvvv 位双验+probe 反查）/ 424 报告（207 行）与 416 报告动手前通读（方法与反面教训）/ 观察模式纪律（427 披露①：GP 方向观察勿区域外读 callee-saved）。

## §F known compromise 预判

1. 三族语料计数可能"经典 DLL 全零+少数 hash/codec 高频"（424 AVX 分层结论的延续）——分层证据即有效结论，不必强凑均值
2. pdep/pext 若无 CPU 实测条件（本机支持与否先查 `cpuid`）——行为 probe 退化为 SDM 文本+折条可行性双路评估，披露
3. spike 改 256 若牵出连锁编译失败——失败清单本身就是成本卡内容，不算路3失败

时间预算: 侦察三合一 ~2-4 小时量级（超过 4 小时说明在做实施，先停下评论披露）。== MIT-G9r 派活单完 ==
