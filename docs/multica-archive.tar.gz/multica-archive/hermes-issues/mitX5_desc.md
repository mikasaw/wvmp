# WVmp MIT-X5 派活单 — 多目标平台收口波：x86 样本池扩量（3→10±）+ wvmpTest x86 全量 E2E + 参数窗真语义对账 + M2.5-X 阶段宣告

> 派活单生成: 2026-09-02, 接手人 (项目主)
> 关联: 多目标平台 X5 = **最后一棒**（冲线）| main `dc2f21a`（446 X4 合入后, 基线 53 样本 **265/265** 含 x86 池 15, x64 dump 底稿 `ffd47289`, 十七连）| 素材 = GAPS「X4 收口节 + X5 交接注记」（gate 清单全量）+ 446 裁定 §6 | 本单后: X3d(SSE 32)/410(M3) 另立项, x86 战役收档
> 交付形态: **main 之外的命名分支 `mit-x5-closure`**（硬条款十八连, 违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main dc2f21a, 2026-09-02 01:2x)

### A.1 现网
build 0 / ctest 16/16 / multiseed 265/265 / wvmpTest x64 14 stubs 双跑 diff 0 / x86 电池 36 例 / dump 门 60 项；D1 已解禁（446）。

### A.2 双池现状（multiseed_e2e.sh 直读）
x64 `samples=()`（:134 起 50 项）+ x86 `x86_samples=()`（:286 起 3 项: forkface/sse/callgate, 路径约定 `build/x86_samples/`）; seeds×2 池=265。446 批次四 MASM 交叉构建入口=`build_x86_e2e_samples.bat`（ml.exe /MACHINE:X86, CMake 自动跑+native rc=0 哨兵）——**新样本入此链即自动进池**。

### A.3 §A 头号新发现（派单前项目主亲测）: wvmpTest **x86 版产物已存在且 native 可跑**
`wvmpTest/build/x86/test_target.exe`：machine=0x14C 亲验、**native rc=0 SUMMARY passed=94 failed=0**（2026-08-27 旧构建）。⚠️ 双注: ① 比 x64 版（08-31, 103 项）**旧 4 天少 9 个 kernel**——X5 必先在 wvmpTest 仓 rebuild 对齐（禁拿旧产物充数, 405 坐标漂移教训同源）; ② x64 侧 wvmpTest **不进 multiseed 池**（独立打壳双跑 diff 0 面）——x86 对称处理=**独立全量 E2E**（本单 B.2, 16 kernel 域×gate 分布的天然富矿: 94 kernel 的 x86 打壳通过率/分布即真实语料判定数据）。
### A.4 参数窗真语义疑点（446 §遗留 3, 本单 D2 必须拆开讲清）
x86 callgate 固定 4 dword 参数窗（step 2.5 从 guest [v4+4i] 预置）。**项目主要亲验的问题**: ① guest 侧 5+ 参 cdecl call（push 5 dword 后 call）虚拟化后 arg4 去哪了——callgate 预置与 guest 自 push 的**覆盖/互补关系**（读 446 批次二 step 2.5 实现+设计意图）② 该形态在 x86 真语料（X0 域）频率。裁决输出=扩窗 or 维持+gate 化（若 guest push 序列本身就是参数来源、预置只是 ctx 桥, 则 4 dword 窗是"可见参数上限"非"调用上限"——语义定性先于扩量）。
### A.5 gate 面 E2E 验证现状（X4 交接注记全量直读）
x86 gate 清单: SSE 族 32（白名单闸, sse 样本设计性负例已实证）/ Div-Idiv / Movsxd（永久纸面）/ x87 全族（R-SSE-only）/ SEH·段覆盖 / 67 / std / S16 串形 / shld·enter·cwd。**多数 gate 仅在 x64 侧或 lifter 单测有负例证据, x86 真管道 E2E 面=本单 B.3 补**。

## §B 任务

1. **B.1 样本池扩量 3→10±（族级矩阵）**: 新增 x86 MASM 样本（沿 446 纪律: 区域内 eax/ecx/edx+全局内存、无 push、native 全绿先入池）——建议族: ① deepcall（x64 406 E1 对称形, callgate 递归深度）② switch 跳转表（413 面 x86 形）③ 串操作扩展（rep movsd/scasd 多形混合, 442 载体域 x86 真管道）④ 位操作+bmi 折叠（tzcnt/bswap/cmpxchg 混合）⑤ 循环嵌套+lea 复杂形。multiseed 目标 **265→315±**（10×5+265-15 口径自算, 报告给精确数）
2. **B.2 wvmpTest x86 全量 E2E（本单招牌）**: 先 rebuild wvmpTest x86 对齐 x64 源（同 commit, Win32/交叉构建）→ 新 CLI 打壳 → **双跑 94-103 kernel 全绿口径**（native/packed 逐 kernel 对账; gate 命中 kernel 分布表=天然真实语料数据, 顺路回答 432/435 悬置的"客户态 gate 触发率"在 x86 侧的镜像问题）→ 报告含 16 类 gate 命中统计（x87/SSE/std/...各几例）——**这份分布表是 X3d 与未来客户支持的立项数据**。wvmpTest 仓改动不属 WVmp 分支交付——产物+日志入 WVmp worktree 侧报告, 或经项目主确认的隔离位置（**D3: 禁覆写 wvmpTest 现有 x64 产物/kernels.toml**——x86 用独立配置副本）
3. **B.3 gate E2E 负例族（x86 真管道）**: x87 gate（R-SSE-only 定稿面: fld/fdiv 函数整函数原生）+ SEH gate + std/67 gate 各 1 样本——protect→gate note 断言→**双跑 byte-exact 保原生**（x64 侧 418/426 同款纪律的 x86 平移）; 落 `x86_samples` 池 or 独立负例区（agent 按 442 区先例定, 报告披露选择）
4. **B.4 参数窗真语义对账（A.4）**: step 2.5 实现直读+5 参 cdecl 手工样本亲测（guest 自 push 形→虚拟化后 callee 读 arg4 是否可读）→ 裁决: 维持（语义=可见参数桥, 非上限）/扩窗（给最小 diff 方案）/gate 化（调用点判据）——**给证据不给猜**
5. **B.5 收口宣告**: STATUS「多目标平台（M2.5-X）」收口节（定义完成口径+权威基线+gate 边界清单引用 GAPS+X3d/未来触发条件）+ GAPS x86 节终稿（x87 R-SSE-only 入册核对 446 已做面, 缺则补）+ x86 支持矩阵行复核（0x14C 生产可用+覆盖%引用 X0）
6. **B.6 x64 零扰动铁证**: multiseed 全绿（既有 250 部分）+ wvmpTest x64 双跑 diff 0 不变 + x64 dump `ffd47289` 恒等（本单理论上零产品代码 diff——B.1-B.5 全样本/文档/测试面; **若 B.4 裁决触发扩窗实施=独立 commit+解禁披露**, 默认不做）

## §C 决策点（项目主已拍板）

- **D1 收口不等 X3d**（✅）: SSE 32=白名单 gate C1 显式零逃逸（446 实证）, 与"生产可用"不矛盾; B.2 分布表给 X3d 立项数据, 本单不实施 SSE 折叠
- **D2 参数窗先对账后裁决**（✅）: B.4 是唯一可能动产品代码的点, 默认零改; 扩窗实施若必要, 走独立 commit（asmgen+stub 两处同步=445 D2 协议）+ 电池联动
- **D3 wvmpTest 纪律**: x86 构建**禁覆写** x64 产物（build/x64 与 build/x86 天然分目录, kernels.toml 用副本指 x86 input）; wvmpTest 若需源码级改动（极少）→ 报告点名文件行, 不夹带
- **D4 native 全绿先（428）+ ≥1 真可虚拟化函数（407）**: 每个新样本入池前两断言亲跑
- **D5 冻结面全维持**: 除 B.4 裁决触发的最小扩窗（默认不发生）外**产品代码零 diff 是本单期望态**; kVmOpMax=97 / dump `ffd47289` / 载体域 / 协议面全部原样
- **D6 池规模宁精勿滥**: 族级矩阵覆盖优先于数量（10± 个各族互斥族 > 30 个同质变体——x64 50 样本是六天战役逐个挣来的, 不追求对称数字）

## §D 验收标准
1. multiseed **315±/315± 全绿**（REQUIRE_REAL=1, 项目主将亲手复跑）+ x86 池 ≥10 样本逐个 machine=0x14C + byte-exact（项目主抽跑 ≥3 新样本）
2. **wvmpTest x86 全量 E2E 证据链**: rebuild 后 native 全绿基线 + 打壳 stub 数 + 双跑逐 kernel diff 0 口径 + **gate 命中分布表**（B.2 招牌交付）
3. B.4 参数窗对账报告: step 2.5 语义定性 + 5 参实测（改前行为亲测）+ 裁决与依据
4. gate 负例族 3 样本: gate note 断言 + 保原生双跑 byte-exact
5. STATUS/GAPS 收口节实读核对（M2.5-X 完成口径+触发条件清单+矩阵行）
6. 冻结契约（D5）+ x64 六件套不退（B.6）
7. 硬条款: 命名分支 `mit-x5-closure` + main 未动 + tracked 零脏 + 切回 main + worktree 自拆 + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 + 分批 commit（B.1/B.3/B.2/B.4/B.5 各批）/ **#33 主战场**: A.3 wvmpTest x86 旧产物（5 天前, 94 项 vs x64 103——**必 rebuild 对齐禁充数**）、A.4 参数窗语义（读实现+实测, 禁从 446 报告文字推定）、X0 覆盖数字引用核对 / 新样本缺陷实录照贴（446 首通双缺陷=好证据非丢人事）/ 卡壳 ≥3h 评论。

## §F known compromise 预判
1. wvmpTest x86 部分 kernel 可能真踩 gate（如浮点=x87 域）——**双跑 byte-exact 仍须成立**（gate=保原生, 非错误）; 若有 kernel 打壳后行为分叉=挖到底（这是 432/433 式现网缺陷探测器, 全绿反而要怀疑验得浅）
2. 池扩到 315± 后单轮 multiseed 时长 +~20%——可接受, 不引入分层跑法
3. 参数窗若裁决扩窗, 本单范围膨胀风险——D2 默认零改, 扩窗可拆 X5b 独立单

时间预算: ~2-3 天。本单交报+验收后 = **多目标平台里程碑收档**, 下一战役=410(M3 加密) 或 X3d(SSE 32, B.2 数据裁决)。== MIT-X5 派活单完 ==
