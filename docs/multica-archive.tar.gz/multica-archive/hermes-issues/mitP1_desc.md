# WVmp MIT-P1 派活单 — rol/ror flags 语义分叉修复（flags_tail partial-preserve 机制，现网正确性缺口）

> 派活单生成: 2026-08-31, 接手人 (项目主)
> 关联: **432/G9r §6.1 P1 发现（项目主已独立复现认定——406 铁律走完）** | main `624e900`（基线 46 样本 230/230）| 选A 排波第一单；本单产出的 partial-preserve 机制 = G8a（rorx/shlx/sarx/shrx flagless）的硬前置半成品
> 复现认定记录: `.multica/mit432-ruling.md` §1（项目主独立重建样本: native `ror_zdiv=0` vs packed `ror_zdiv=1`，shl 对照一致）
> 交付形态: **main 之外的命名分支 `mit-p1-flags-partial`**（硬条款八连，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main 624e900, 2026-08-31 12:4x)

### A.1 缺口机制链（全部项目主源码直读 + 复现亲验，非转述）
- **根因**: `build_rol/build_ror` 复用 `build_shift`（asmgen.cpp:2492 起注释明言"与 build_sar 同理"）——build_shift 尾部 `zero5()`（:591，清 T3/T4/T6/T7/T9——内部 xor 自身置宿主 ZF=1/PF=1/SF=0）→ native rol/ror（**只写 CF/OF**）→ `setcc5()`（:582，setz/sets/setp/seto/setc 捕**宿主 handler 内部状态**，恒 ZF=1 等）→ `flags_tail()`（:546-556 全量装配五标志写 `[ctx+0x98]`）→ **ZF/SF/PF 被覆写，native 语义应保留原值**
- **注释根因（一并修）**: :2492-2506 断言 "SF=结果 MSB, ZF=结果==0, PF=偶校验 与 Intel SDM Vol.2 ROL/ROR 一一对应"——**SDM 误读**（该组属 SHL/SHR/SAR；ROL/ROR 仅 CF/OF，ZF/SF/PF **unaffected**）
- **既有先例（本单机制的模板）**: `flags_tail(dispatch, cf_preset)` 已有 **Inc/Dec 变体**（:544-545 "T3 已是旧 CF 的 bit1 值（保留语义），不再移位"）——**partial-preserve 不是从零发明，是把 Inc/Dec 的"保留位不经 setcc5、直接从 ctx 旧值搬运合并"手法推广到 ZF/SF/PF 三位**
- 复现样本留样: `%TEMP%\p432\`（asm+main.cpp+build.bat，magic 直嵌 markers.hpp 常量自含桩）——**§B.4 收编进仓**
- 波及面确认: `setcc5` 捕五标志被 shift/rot/adc/sbb/incdec 等共享——**本单只改 rol/ror 通路，其余 handler 字节码零扰动**（对齐 428"零静默变数"审计口径）

### A.2 现网验证锚
- build 0 / ctest 16/16 / multiseed **230/230** / wvmpTest 14/14 + jump-table@0xDD84 + ExitNative 17；kVmOpMax=97；harness crash guard（427 三判据）在位
- SDM 语义事实（G9r §2.1 probe 双验过）: ror 输入 1 → CF=1, ZF/SF/PF 保留；rol/ror count=0 不动值不动 flags（既有 adv_lbl 行为，别碰）；OF 仅 count==1 有定义（现状 seto5 捕法对 OF 本来就正确，**保留**）

## §B 任务

1. **B.1 机制实现**: `build_rol/build_ror` 与 build_shift 解耦出 **partial 装配路径**——CF/OF 照旧 setcc5 捕获装配；**ZF/SF/PF 三位从 ctx+0x98 旧值原样保留**（手法=Inc/Dec cf_preset 先例的三位版：flags_tail 参数化掩码 or 独立 flags_tail_partial，你实测选，**禁扩 VmOp/禁改既有非 rot handler 一字节**）
2. **B.2 注释修正**: :2492-2506 ROL/ROR 段按 SDM 实义重写（仅 CF/OF + OF 定义域 + ZF/SF/PF unaffected 明说 + 引 G9r §6.1 本案）；顺带 :544 附近 flags_tail 文档同步新掩码语义
3. **B.3 单测/样本矩阵（分叉面钉死）**: rol/ror 各 ×{ZF,SF,PF} 消费形态 = **6 组语义断言**（rotate 结果分别为 0/负/PF 奇偶三态构造 × 前态 flags 基线置反）+ shl/shr/sar 对照（语义应不变——写全量 flags 是对的）+ **count=0 不动 flags** + OF 仅 count1。lifter/runtime 单测层 + E2E 双跑层各钉
4. **B.4 复现样本收编**: `%TEMP%\p432\` 样本转正为 multiseed 注册样本 `wvmp_flags_rol_sample`（正例区 ror_case/shl_case + 扩 SF/PF 消费区；MASM 自含桩形保留）→ 基线 46→**47 样本 = 235/235**；该样本**修复前必 FAIL（分叉值可观察）修复后 PASS**——用 main 0ac661a 旧 CLI 跑反证（406 反证模板：项目主会亲验，你自报也要跑）
5. **B.5 G8a 前置接口预留**: partial 路径机制文档化（flags_tail 掩码语义注释即 G8a flagless 变体的接入点声明——**本单不实现 flagless，只留接口文本**；G8a §C D2 依赖本单合入）
6. **B.6 GAPS/STATUS**: §6.1 缺口收口行 + M3 技术债同步 + "rotate 后消费 ZF/SF/PF"盲区教训一句（样本集设计纪律）

## §C 决策点（项目主已拍板）

- **D1 修复=语义正确性优先，非 flagless 泛化**（✅）: 本单只救 rol/ror（现网真缺口）；rorx/shlx 族的 flagless 需求留 G8a——**别顺手把 VEX-GP 加白名单**
- **D2 机制选型两路都实测**（✅）: (i) flags_tail 掩码参数化（复用装配骨架）vs (ii) 独立 partial 装配函数——**选字节码更短/改动面更小者**，报告对照披露；两路均禁新增 handler 集合外的 VmOp
- **D3 既有 230 样本字节码扰动预期**: 修复只动 rol/ror handler 生成——**其余 230 runs 的 packed sha 应逐字节不变**（同 seed 同 CLI 对照：main 旧 vs 分支新，抽样 ≥5 种含 shift-heavy 样本）；rot handler 本体字节码必然变（这就是修复），其所在样本 stdout 应一致（盲区无消费形态）——不一致即新 bug
- **D4 OF 语义现状保留**（✅）: count>1 OF undefined 的"捕 host 值"行为与 SDM 不冲突（G9r §2.1 已注），别顺手改

## §D 验收标准

1. build 0 新警 / ctest 16/16（+B.3 矩阵 ≥6 新用例）/ **multiseed 235/235**（47 样本，含新 flags_rol 样本 5 seed）
2. **反证闭环（硬项）**: 新样本在 main 0ac661a CLI 下 protect+双跑 → **FAIL/分叉值可观察**（如 ror_zdiv=1≠0）→ 分支 CLI 下 PASS 且值=原生——两侧输出都贴报告
3. D3 sha 对照表: ≥5 非 rot 样本修复前后 packed sha256 逐字节一致 + rot 样本 stdout 一致
4. 零回踩: wvmpTest 14/14 + jump-table/ExitNative 17 + 全部 note 面原样 + 双跑 103/103 diff 0
5. 冻结契约: kVmOpMax=97 不动、VmOp enum 零增、ir::Op/backend.hpp/callgate/载体域 0..21 零触、**非 rot handler 字节码零扰动**（asmgen diff 逐 case 对账）
6. dump/static 双门 PASS（handler 数不变；rot handler dump 校验通过）
7. 硬条款: 命名分支 `mit-p1-flags-partial` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律

worktree 隔离 / wvmpTest 禁覆写 / `cmd /c` bat 查 log 时间戳 / MASM 手编纪律（B.4 转正样本时 ModRM 双验——428 pp 位教训）/ **观察纪律**: 新样本 flags 消费值经**区内 Store 通路**读出（427 披露①：禁区域外读 callee-saved 物理寄存器）/ #33: §A.1 机制链与 D3"sha 不变"预期均实测兜底（若发现 flags_tail 结构使掩码化牵动全 handler 共享代码路径——**停手评论披露**，别硬拆）。

## §F known compromise 预判

1. partial 路径字节码比全量装配长（多一次 ctx 旧值 load+掩码 or）——rot handler 性能微降，正确性优先，披露
2. PF 保留语义在 VM 内 = ctx 旧 PF 位原样——与 native"完全不触碰标志寄存器该位"在 VM 抽象层等价（ctx.flags 即 guest 视角 RFLAGS），无残留风险，文本说清即可
3. 新样本收编后 multiseed 分母 +5 runs（235）——harness 时长 +~20 秒，接受

时间预算: ~0.5-1 天。== MIT-P1 派活单完 ==
