# WVmp MIT-X1a 派活单 — marker_scan x86 双段 magic 锚点 + SDK x86 构建形态（多目标平台 X1 波·扫描面单）

> 派活单生成: 2026-09-01, 接手人 (项目主)
> 关联: 多目标平台里程碑 X1a（X0=MIT-436 triage 定版, 动手前通读 `.multica/mit-X0-triage.md` + 412 `mit-G7r-triage.md` §6 构建坑）| main `f7a865c`（基线 48 样本 240/240 不变）| 与 MIT-X1b（cli/translator/GAPS 面）**改面互斥可并行**
> 交付形态: **main 之外的命名分支 `mit-x1a-scan-anchors`**（硬条款十一连，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main f7a865c, 2026-09-01 01:1x)

### A.1 现网
- main = `f7a865c`; build 0 / ctest 16/16 / **multiseed 48×5=240/240** / wvmpTest 14/14；414 硬拒面原样（X0 §B.5 已复验 rc=2）
- **414 已铺路直读**: marker_scan_pass.cpp:180 `fr.arch = (pe->machine==kMachineX86) ? ir::Arch::X86 : X64`——arch 推导已就位，本单消费之
- **断层点位（本单主战场）**: marker_scan_pass.cpp:177 `TODO(P7-x86): x86 目标上 magic 会拆成两条 imm32（不连续），v1 仅 x64`——x64 扫描=单段 8B `movabs rax,imm64` 连续字节锚；x86 世界 `mov eax,imm32`×2（begin 拆 mov magic-lo / mov magic-hi 两条不连续指令）——412 §6 已实测验证锚点构造形态（**坑**: naked+`_emit` 吞 ret、必须 `jmp skip` 跳过 magic、magic 字节被执行毁栈）
- SDK 面: sdk/src/sdk.cpp:26 `volatile unsigned long long m = kBeginMagic`（依赖 64 位常量物化形态）；scan_core.hpp 复制双 magic 模式（markers.hpp:37-38 同步断言先例）

### A.2 设计边界（防越界）
- **X1a 只做到"marker_scan 能正确定位 x86 区域 + fr.arch 正确落位"**——x86 的 lifter 消费/translator/全管道仍在后续单（X2+），硬拒保持（见 X1b 单 D1）
- x86 magic 扫描**不得破坏 x64 单段锚点路径**（42 单史全样本 byte-identical 守护）

## §B 任务

1. **B.1 扫描侧**: scan_core 增 x86 双段 magic 识别（形态=412 §6 实测形：`mov eax,imm32`(lo) + `mov eax,imm32`(hi) 相邻 or 允许 1 条填充——**以你实测 SDK 编译产物字节为准**，禁照抄本文）；begin/end 各二形共 4 组合对账；区域 E8 回溯链 arch 分叉（x86 call rel32 同形? 实测）
2. **B.2 SDK 侧**: sdk.cpp 构造 x86 锚点形态（按 412 §6 "jmp skip + 双段"验证形——**先建 x86 构建探针实测编译器真实产物再定实现**，#33 惯例）+ CMake/构建脚本增 x86 SDK lib 产物位（`/MACHINE:X86`，不破坏现有 x64 产物路径）
3. **B.3 单测/样本**: ① 泳道单测: x86 双段 magic 字节流 fixture（手编/真产物二取）→ 区域定位断言 ② **真 E2E**: ml.exe（14.51 在位亲验）手编 x86 标记样本（412 §6 三坑全规避）→ marker_scan pass 单 pass 跑通断言（后续 pass 不参与，硬拒前 pipeline 可分步——用 `--passes marker_scan` 类局部跑法，实测确认可行性）③ x64 全 48 样本零回踩
4. **B.4 同步纪律**: scan_core.hpp 与 markers.hpp magic 模式**三处同步**（x64 双段变体定义单一来源 + 既有同步断言扩展）
5. **B.5 文档**: GAPS C5 节追加"x86 扫描面已就位（X1a），管道后续单接力"一行（**不改写 414 收口史文本**）+ STATUS 里程碑行

## §C 决策点（项目主已拍板）

- **D1 双段形态以真编译器产物为准**（✅）: 412 §6 形态是先验，SDK x86 编译实测可能不同（编译器插 lea/mov 顺序自由）——扫描判据必须容忍你实测到的真实分布，报告附反汇编对照表
- **D2 容忍窗策略**: 双段 magic 两条指令间允许的最大间隔（0/1/2 条）你实测定，**宁窄勿宽**（幻影 begin 教训：424 §3.2+432 §6.2 两例 P2 在案——任何放宽都要配负例回归）
- **D3 单 pass 跑法不可行则最小 plumbing**（✅）: 若 CLI 无 `--passes` 局部跑，允许加最简 pass 序列截断选项（属本单最小基建，披露）

## §D 验收标准
1. build 0 新警 / ctest 16/16（+x86 扫描单测 ≥4 例：双段正/反序负/间隔超窗负/x64 单段回归）/ **multiseed 240/240 零回踩**
2. ml.exe x86 真产物 E2E: marker_scan 定位区域断言（RVA/尺寸精确）+ fr.arch=X86 落位 + **保护全管道仍 rc=2 硬拒原样**（扫得到≠放行进——边界亲验）
3. x64 零扰动: 48 样本 note 面/坐标面原样（幻影 begin 负例含）；双段改动对 x64 路径=死代码级隔离（diff 可指认）
4. 冻结面: 产品代码 diff 仅 passes/marker_scan/ + sdk/ + CMake/构建 + docs；cli/、lifter/、translator/、asmgen、backend 零触（X1b 面互斥）
5. 硬条款: 命名分支 + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 / wvmpTest 禁覆写 / `cmd /c` 查时间戳 / ml.exe 手编三坑（412 §6：/utf-8、naked 吞 ret、jmp skip magic——**样本注释钉教训**）/ MASM ModRM 双验（423/428）/ #33: 412 §6 先验形态实测兜底 / 幻影 begin 负例必带（432 §6.2 收紧建议本单顺路评估：目标须落 stub 入口±窗口——若与本单 scope 冲突留文档挂账披露）。

== MIT-X1a 派活单完 ==
