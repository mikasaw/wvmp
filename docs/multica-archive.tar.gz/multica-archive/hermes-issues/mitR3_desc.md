# WVmp MIT-G5r-R3 派活单 — x87 永久 gate 文档化收口 + gate 行为回归样本钉死

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: MIT-416/G5r triage §5-R3 (推荐路线, 项目主采纳) | main `fa08d50` 基线 170/170 | 与 MIT-417 (P0 callgate FP, asmgen 改面) **零文件冲突** (本单 = 文档 + 新样本文件 + multiseed 行)
> 前置阅读: 本单 → `.multica/mit-G5r-triage.md` 全文 (频率数字/形态枚举/现状行为链 §0)

---

## §A 基线实测事实 (项目主 fresh verify @ main fa08d50, 2026-08-30)

### A.1 R3 成立前提 (416 实测, 项目主复核采纳)
- **现状已是"半 R3"**: x87 指令 (D8-DF 全族) 入标记区 → lifter `未支持指令 'fld' 已跳过` → C1 gate 整函数保持原生 → 输出 byte-identical, **不产坏壳** (416 E2E 实测行为链)
- 频率数字 (§1): x64 MSVC 世界 x87 ≈ 0 (0.0000–0.0032% 全伪影点检); 真实入口 = mingw/msys runtime (1.02-2.12%)、OS 运行时/CRT、显式 /arch:IA32、手写 asm → R1 全量不排波 (项目主裁定)
- 缺口仅剩**文档面**: GAPS.md x87 仅 :132 一行混列 "AVX/x87/SSE2 整数族", 无独立声明/无频率数据/无行为承诺

### A.2 样本构造先验
- 416 triage 实验目录 %TEMP%\mit416_x87 已被 Temp 清理 (登记在案), 其报告披露的 MASM x87 模块形态 = 你重构起点: `fld qword ptr [x]` / `fadd` / `fstp` 最小闭合 + WVMP 标记宏 (411/413 样本的 sdk include 手法照抄)
- **ml64 直汇编 x87 无障碍** (D8-DF opcode 全支持); 或 C++ 侧 `long double` 强制? 不——MSVC long double=double 不产 x87 (416 §A 裁定①), **MASM 是唯一可靠构造路**, 413 jmp_table8 模板
- 样本预期行为 = **0 stub 真 gate + byte-identical 双跑**: multiseed 的 REQUIRE_REAL 口径是"每样本 ≥1 stub"——**你必实测确认 gate-only 样本与 REQUIRE_REAL=1 兼容性** (若脚本要求逐样本 ≥1, 需把该样本注册进 gate 白名单机制或在样本内加 1 个真虚拟化 helper 区——两种都可行, 实测选型披露; 409 教训③同源)

## §B 任务

1. **B.1 x87 gate 回归样本**: 新 `wvmp_x87_gate_sample` (MASM: fld/fadd/fstp/fcomip/fsin 至少 5 族各 ≥1 条入标记区 + 1 个纯 GP helper 真虚拟化区满足 REQUIRE_REAL; 主函数行为可校验——x87 区结果 printf) → CMakeLists + multiseed 34→35 (A.2 选型后预计 **175/175**)
2. **B.2 gate 断言固化**: 样本 protect 日志断言: ① `未支持指令 'fld'...` note 系列 ② helper 区 stub 计数 ≥1 ③ x87 函数区**无 stub** (gate 证据) ④ native/packed 双跑 byte-exact——四件套进报告
3. **B.3 GAPS.md**: 把 x87 从 :132 混列行**拆出独立小节** "x87 (永久 gate, R3 裁决)": 全族清单 (D8-DF 8 组, 引用 416 §1 表) + 行为承诺 (gate→原生执行 byte-identical, 回归样本名钉死) + 频率数据摘要 + **路线记录** (R1 蓝图留档 `.multica/mit-G5r-triage.md` §4/§5 不排波; R2 随 G7 P1 捆绑评估; 跳表 128→256 扩容=G7/x87 未来前置) + 16-bit 不可行交叉引用 (C5 节)
4. **B.4 STATUS.md / README**: 支持面声明同步 ("目标=x64 PE; 浮点=x87 全族保持原生")
5. **B.5 (可选加餐, 若 A.2 gate 兼容实测发现脚本盲区)**: multiseed 注释头登记 gate-only 样本语义, 防后人误删 helper 区

## §C 决策点 (项目主已拍板)

- **D1 样本形态 = MASM 全族混合 + GP helper 真区** (✅): gate-only 样本对 multiseed 价值有限, 混合样本一箭双雕 (gate 证据 + 同 exe 内虚拟化区回归)
- **D2 gate 语义零代码改动** (✅): 本单**禁碰 lifter/translator/asmgen**——"半 R3"现状即目标行为, 只文档化+钉回归; 若你实测发现 x87 某条**绕过 gate 进了 VM** (如前缀组合漏网产坏壳)——**立即停下评论上报** (那属 P0 级新洞, 不是本单修复面)
- **D3 fsin 等超越指令进样本** (✅): 频率"中"但真实 (msvcrt fsin 归约循环实证); gate 行为与数据传输同路径, 样本多族混合成本低

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 (+lifter x87 gate 单测 ≥2: fld/fadd 白名单外断言, 若已有则引用) / **multiseed 全绿** (35 样本 × 5 = 175 或 A.2 选型后等价口径)
2. B.2 四件套 gate 断言日志原文入报告
3. 零回踩: 170 既有全绿 + wvmpTest 14/14 + 双跑 byte-exact (与 417 并发, 你基于派发时 main 自证即可, 收口链项目主编排)
4. 冻结契约: 全代码文件零触碰 (本单 diff 文件面 = 文档 ×3 + 样本 ×2 + CMakeLists + multiseed 注册, 越界即违规)
5. **新铁律**: 交付 commit 落命名分支 (如 `mit-g5r-r3`) + tracked 零脏 + 完工切回 main (无并发占用时) + ff-safe
6. ≥30 分钟; 时间对账 (412 纪律); 数据主张附复跑命令

## §E 纪律

worktree 隔离 (417 并发运行中, 主工作区随时可能被占用——**412 例外注记纪律生效: 被占用不扰动**) / wvmpTest 基线禁覆写 / `cmd /c` / vendored capstone 对 D8-DF 的 id 报法实测 (x87 系枚举名以 .deps 头为准, 404 教训) / **#33**: A.2 REQUIRE_REAL 兼容性先验可翻, 按实测选型。

## §F known compromise 预判

1. 样本 gate 证据 = 行为面 (日志+双跑), 非单测面 (lifter 级单测 B.1 可选)
2. R3 是"文档化不保护"承诺——若未来 G7 x86 P1 立项, IA32 浮点档口重开 (B.3 路线记录句写明, 防未来考古困惑)
3. x87 全族 gate 性能零影响 (gate=原生) 但受保护函数含 x87 时整函数不保护——用户文档必须明示 (B.4 支持面声明)

时间预算: ~半天内 (S 级)。== MIT-G5r-R3 派活单完 ==
