# WVmp MIT-P0 派活单 — CallGate 浮点参数/返回值传递修复（xmm0..3 入参 + xmm0 返回，静默坏壳首例）

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: MIT-416/G5r triage §6.1 (P0 发现, 项目主已独立复现) | 全项目**第一个 gate 哲学之外的静默坏壳面** — 严重度高于既有全部缺口清单
> 前置阅读: 本单 → `.multica/mit-G5r-triage.md` §6.1 → asmgen.cpp build_callgate (:1189-1266) → 406/403 callgate 纪律链 (shadow/窗口/派生常量)

---

## §A 基线实测事实 (项目主 fresh verify @ main fa08d50, 2026-08-30 00:4x)

### A.1 现网
- main = `fa08d50` (415 直提违规登记在案 — **本单起执行新铁律: 交付 commit 必须落 main 之外命名分支, 违者退回重交**); build 0 错 / ctest 16/16 / **multiseed 基线 34 样本 × 5 = 170/170** / wvmpTest 14/14
- 170 runs 从未抓到本缺陷的原因 (**回归盲区, 修复后必须消灭**): 全部既有 callgate 样本 (bswap/rol/sha256 54 call/deepcall) 恰好全整型参数调用——**新样本是全 FP 参数形态,  multiseed 池第一份**

### A.2 缺陷与复现 (项目主亲手, 非采信 agent)
- 固定复现样本: `%TEMP%\g5r_p0\` (fp_caller.cpp + build.bat + fp.toml, **已固存, 你环境不可用时照 §A.3 自构造**)
- 形态: 区域内 noinline `double fp_add(double,double)` ×2 + `fp_mul` 调用 (3 次 callgate)
- 实测: native `fp_sum=15.00 last=7.00 rc=0` → protect (stub=1 真虚拟化) → packed **`fp_sum=3.00 last=2.00 rc=1` 静默错乱无告警** (416 报 4.5/rc2 是不同构造样本, 同根因同性质)
- 根因 (项目主代码直读证实): `build_callgate` step0 (:1193-1201) 只搬 regs[1/2/8/9]→reserved 0xD0..0xE8, step5 (:1240-1244) 抬 rcx/rdx/r8/r9, step10 (:1263) 只回写 `[ctx+0x10]` RAX — **全程零 xmm 触点**; Win64 FP 参数/返回值槽 xmm0..3/xmm0 断链

### A.3 修复面先验 (你实测复核, #33 推翻优先)
- 挂点 = **step5 之后 / step6 call 之前**加 4 条 `movups xmmN, [ctx + xmm_base + 16*N]` (N=0..3); **step10 位置**加 1 条 `movups [ctx + xmm_base], xmm0`
- 时序安全论证: step4 rsp 切换/push ctx 不触 xmm; **VM 物理 xmm0-3 在指令边界是否恒无活值** = 你必须实测 (408 设计宣称"handler 内临时、指令边界即死"——若 dump/静态扫描证实有跨边界残留, 披露并调整搬运时机)
- 宽度语义: 无条件全 16B movups 对 float/double/packed 全安全——x64 ABI 本就规定 FP 参数高位垃圾 undefined, 全宽搬运与原生行为精确一致 (ctx.xmm 槽由 408 Movss S32/Movsd S64 通路正确维护, 低部有效即可)
- **movaps 禁用红线**: 一律 movups (406 movaps 对齐 #GP 先例; ctx.xmm 区 16B 对齐但物理侧无保证)
- 常量纪律: xmm base 用 `imm(kCtxXmmBase + 16*N)` 编译期派生, **禁字面量第二份拷贝** (B2/E1 一脉); mod-16 断言若涉布局派生同步补
- 返回值: Win64 标量 FP 返回恒 xmm0 单槽, 无需 xmm1 (416 §6.1 同判; __vectorcall 多槽返回不在 v1 面, §F 登记)
- D1 简化授权: **零 aux 方案** (无条件 4+1 条, translator 不传 FP 参数存在性) 优先于 416 预判的 aux 方案——指令体多 ~90B 常数开销换全类型正确, callgate 本就重路径预算宽松 (406 实测); 你实测若发现无条件搬运在某形态引入回归, 再退 aux 方案并披露

## §B 任务

1. **B.1 修复实现**: §A.3 挂点补 4+1 movups (keystone 编码实测——movups xmm↔mem 的 VEX.128/legacy 形态以 keystone 输出为准, 生成码 dumpbin 反汇编对照进报告)
2. **B.2 指令边界无活值实测**: 全 handler dump 审读物理 xmm0-3 生命周期 (A.3 论证的实证); 发现反例→时机调整+披露
3. **B.3 回归盲区样本**: 新 `wvmp_fp_callgate_sample` 入 multiseed (34→35, 预计 **175/175**): double×4 全参槽 callee + float callee + 返回值参与后续 VM 运算 (双跑口径)+ **一个 callee 改 xmm4+ 非易失? 不——callee 只保 ABI, 你出参面验证 caller 侧语义**; REQUIRE_REAL 主函数真虚拟化
4. **B.4 反证 (406 铁律双向)**: ① 修复前: 你 worktree 复跑 %TEMP%\g5r_p0 同构造 (或自构等价) 必现错值 (附你环境输出); ② 修复后: 同输入必正确 + rc 一致; ③ 项目主收口时将用 g5r_p0 固定样本亲手复跑认定, 你的报告不能替代
5. **B.5 GAPS/文档**: C3 节按 416 发现的"pre-M2-9 旧文"一并改写 (现状: callgate 已支持整数+本单起 FP; 残余: __vectorcall 多槽返回/可变参 FP 实测面), 引用 416 triage 编号留档

## §C 决策点 (项目主已拍板)

- **D1 零 aux 无条件搬运** (✅ 先验推荐, A.3 授权实测择优)
- **D2 全宽 16B movups** (✅, ABI 高位 undefined 论证; float/double 低部正确性由 408 既有通路保证)
- **D3 callee 侧不模拟**: 被调函数内部用不用 x87/SSE 不关本单事 (callgate 边界=ABI 契约)
- **D4 可变参 FP (printf 类)**: xmm0=n_unpacked 的 ABI 约定 ( variadic FP 参数须 caller 侧 al 计数——**VM Mov 通路 al 已天然正确? 实测一个 `%f` printf 用例进样本或披露**, 不预设)

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 (+asmgen callgate 单测: 生成码含 4+1 movups 序列断言 + 时机) / **multiseed 175/175** (35 样本)
2. **修复证明双样本**: g5r 等价构造 pre-fix 错值/post-fix 正确 (报告附双输出) + 新 multiseed 样本真虚拟化 byte-exact
3. 零回踩: 170 既有全绿 + wvmpTest 14/14 + jump-table/ExitNative 17 + **sha256 54-call 深栈样本原样** (callgate 高频路径回归=本单最大回踩风险, 双跑逐字节)
4. 冻结契约: kCallgateCalleeWindow/kPushCtxDepth/kWinShadowBytes 派生链零触碰 (只加搬运不改栈布局); runtime.hpp 零改 (xmm base 既有); 跳表容量不动 (零新 VmOp)
5. **新铁律 (415 违规后固化)**: 交付 commit 落**命名分支** (如 `mit-p0-callgate-fp`) + 主工作区 tracked 零脏 + 完工切回 main (无并发占用时; 占用则如实披露——412 例外注记) + ff-safe
6. ≥30 分钟; 时间报告与 run 起止对账 (412 纪律); 数据主张附复跑命令

## §E 纪律

worktree 隔离 (418 并发可能占用主工作区) / wvmpTest 基线禁覆写 / `cmd /c` / **#33**: §A.3 全部先验可推翻 (尤其 B.2 边界无活值论证——推翻则本单复杂度上跳, 立即评论披露而非硬做)。

## §F known compromise 预判

1. 每次 callgate +5 movups ≈90B 指令体 (D1 常数化代价, 体积换正确)
2. __vectorcall 多 xmm 返回/128 位结构返回不在本单 (登记)
3. callee 返回 double 但 VM 侧按 float 读 (调用点类型错配) = 上游翻译缺陷不属本单, 出现即披露

时间预算: ~半天 (挂点小, 实测论证+样本是大头)。== MIT-P0 派活单完 ==
