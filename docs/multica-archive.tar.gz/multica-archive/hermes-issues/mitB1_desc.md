# WVmp MIT-B1 派活单 — multiseed 5 坏样本共享 runtime 崩溃根因定位（裁定型 / verifier self-report + 项目主复核）

> 派活单生成: 2026-08-28 晚, 接手人 (项目主)
> 关联: MIT-376 done (main HEAD `fb66b98`, SSE 五连单收官) + GAPS.md C2/C3 + 计划 `.hermes/plans/2026-08-28_B-preexisting-fail-repair.md` §2
> 模板: MIT-379 裁定型派活单 (verifier 独立复跑 + 报告 + 不改产品代码)
> 性质: **纯侦察定位单** — 唯一交付物是根因结论 + 精确文件行 + 修复方向建议。**不改任何产品代码, 不 commit, 不建分支**

---

## §A Pre-dispatch baseline (项目主 fresh verify, 2026-08-28 21:00 UTC+8, main fb66b98 重建后复验 CONFIRMED)

| 项 | 实测值 |
|---|---|
| main HEAD | `fb66b98` (含 MIT-376) |
| build | rc=0, wvmp_cli.exe 10,188,288 B @ `build/cli/` |
| ctest | 16/16 PASS |
| multiseed REQUIRE_REAL=1 | 100 runs = 75 PASS / 25 FAIL (5 坏样本 × 5 seeds) |
| 坏样本 1 | `wvmp_call_gate_sample.exe` — protect rc=0, **1 stub 真生成**, packed rc=0xC0000005, native rc=0 |
| 坏样本 2 | `wvmp_call_gate_simple_sample.exe` — 1 stub, 同 crash |
| 坏样本 3 | `wvmp_rol_sample.exe` — 2 stubs, 同 crash |
| 坏样本 4 | `wvmp_cl_shift_sample.exe` — **16 stubs**, 同 crash |
| 坏样本 5 | `wvmp_bswap_sample.exe` — 3 stubs, 同 crash |
| 对照组 | wvmp_sse_add_sample packed byte-exact PASS → 非全局 runtime 损坏 |
| 共享 crash 签名 | **5/5 全部** `4c8b7608  mov r14, [rsi+8]`，rsi=0 (`ds:00000000`00000008=????`)，stdout 零字节 |
| 崩溃地址 | bswap/rol/call_gate×2: `0x14000E7C0` (.wvmp@0xB000) / cl_shift: `0x1400107C0` (.wvmp@0xD000) → 归一化 **.wvmp+0x37C0 同一处** |
| 崩溃上下文 | rdi=节基址 0x14000B000；rax/rcx=0x78563412, r11=0x4562…, r12=0x4562, r13=0x140004562 (bswap 样本业务值已在寄存器) → **崩在 VM 执行中途, 非入口** |
| merge 前后不变性 | 694eda0 CLI 与 fb66b98 CLI 崩溃地址完全一致 → MIT-371..376 SSE 演进**未触及**该 bug, 系更早引入 (MIT-349/353 时代 FAIL 集已含 bswap/cl_shift) |

⚠️ 以上 crash 数据用 `cdb.exe -g -G -c ".cxr;q"` 采集 (路径 `C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe`)。verifier 复跑若得不同偏移, 以实测为准并披露 (§D.3)。

## §B 任务 (按序执行, 全部必做)

### B.1 独立复现 (防单环境假象)
用 main 当前 `build/cli/wvmp_cli.exe` 重建 worktree 干净环境, 对 5 样本各 protect(seed=12345) + 双跑, 确认 5/5 复现 `mov r14,[rsi+8] @ .wvmp+0x37C0` 崩溃签名。粘贴实测输出。

### B.2 定位 +0x37C0 是哪个 handler
1. 提取 runtime 镜像: protect 日志或 `scripts/verifier/dump_handler_xmm_check.py` 同源切片法拿到 .wvmp 节内 runtime 代码区 (或直接用 packed.exe + cdb `u 0x14000B000+0x3740 L40` 反汇编崩溃点前后 ±0x80)。
2. 用 capstone (`C:/Python314/python.exe -m pip show capstone` 已装) 反汇编 +0x37C0 前后各 0x80 字节, 结合 `vm/regvm/runtime/src/asmgen.cpp` 的 handler 生成顺序, **确定崩溃指令属于哪个 build_* handler 的哪一步** (rsi 应装什么: ctx? callee 帧? helper 表基址?)。
3. 在 asmgen.cpp 中找到发射该指令的源码行, 引用 `文件:行号`。

### B.3 裁决三假设 (计划 §1 H1/H2/H3)
- **H1 特定 handler 指针装载缺陷**: 崩溃点所在 handler 是否就是 rol/cl_shift/bswap/call_gate 共用的某条通路 (对照 PASS 的 setcc/cmovcc/xchg 走哪条)? "rsi=0 是从未装入" 还是 "被覆写" — 用 cdb 在崩溃前一条断点 (`bp wvmp+0x37B8; g; r`) 看 rsi 前值。
- **H2 ctx 布局漂移 (MIT-371 kCtxSize 0x140→0x1C8)**: grep 崩溃 handler 相关代码里 0x140/0x1C8/+8 字面量, 对照 `vm/regvm/isa` ctx 布局注释; `git log -S` 定位该字面量引入 commit。
- **H3 样本过期**: 仅当 H1/H2 落空才验 (重编样本 exe 前后 crash 是否变化)。
**出口判据: 三选一并给出 文件:行号 + 一句话修复方向。禁止"证据不足"作结 — 若真不足, 列出还差哪个实验并当场补做。**

### B.4 最小复现 (强烈建议, 非强制)
新建临时样本 (放 `%TEMP%`, **不进仓库**): 单条 `rol` 一个区域内联, 走同管道 protect → 若同样崩 → 根因锁定到 handler 粒度; 若不崩 → 披露差异 (帧嵌套? 多函数?)。

## §C 工作目录与纪律

- 仓库 `C:\Users\www\AiCode\WVmp\wvmp` main fb66b98; **先 `scripts\build.bat` 再验** (若 build/ 已有新产物可跳过)
- multiseed 旧路径漂移: `build/vs/cli/Debug/` 缺 CLI 时自行镜像 (不判构建损坏)
- **不改产品代码 / 不 commit / 不 push**; 临时脚本一律 `%TEMP%` 或 `.hermes/triage/`
- TOML 路径必须 `C:/...` Windows 风格; .ps1 全 ASCII; bash 逻辑走文件
- 长跑 exe 用 subprocess/Start-Process, 不用 `& <exe>`
- verifier 必跑 ≥ 30 分钟; honest disclosure 优先于结论好看 (模式 13); **自报的每一条数字必须带实测输出粘贴** (pitfall #29)

## §D 决策点 (项目主已拍板 2026-08-28)

- **D1. 交付形态** (✅ D1.1): 报告发 issue comment + 落盘 `.multica/mit-B1-triage.md` (gitignored 目录, 与 mit375 同口径); status → in_review
- **D2. 修复建议深度** (✅ D2.1): 只给方向一句话 + 影响面清单 (哪些文件/行/样本), **不写 patch 不派 Phase 2** — Phase 2 由项目主据本单结论另立 MIT
- **D3. 若崩点与 §A 实测不符** (✅ D3.1): 以 verifier 实测为准, 在报告 §0 披露差异 (时间线错位假矛盾教训, pitfall #33 亚种), 并继续定位实际根因

## §E 验收标准 (项目主按本单独立复核项)

1. B.1 五样本复现表 (stub 数 / crash 地址 / 归一化偏移) 与 §A 一致或披露差异
2. B.2 给出崩溃 handler 名 + asmgen.cpp 源码行引用
3. B.3 三假设裁决明确 (选定 H + 证据链: cdb 前值快照 + git log -S 定位)
4. B.4 做了则贴结果, 没做则说明为何不需要
5. 全程零产品代码改动 (`git -C … status --short` 前后一致, HEAD 不变)
6. 报告含实测输出粘贴 (非转述)

## §F known compromise

- §A 崩溃数据采自项目主单机 cdb first-chance 现场; verifier 环境若有 AVX/OS 差异导致镜像重排, 归一化偏移可能移动 — D3 已兜底
- call_gate 与 rol/cl_shift/bswap 是否**同一**根因未先验断言 (§A 只见同一崩点); 若 B.2/B.3 拆出两因, 如实拆报

## §G 沉淀 (本单预期产出)

- GAPS C2/C3 真实状态刷新 (handler"已接管"与 multiseed 持续 FAIL 的矛盾定论)
- runtime 镜像偏移定位方法论 (cdb + .cxr + 归一化节偏移) 可入 wvmp-dev skill
- Phase 2 修复单的 §A 假设将由本单结论直接生成 (§A 假设质量 = 本单最大交付)

## §H close-out (项目主侧, verifier 无需执行)

triage 报告 → 项目主复核 → 据此写 Phase 2 修复派活单 (1 张 MIT, 含基线刷新 100/100) → 派发 WVmpCppDev。

== 派活单完 ==
