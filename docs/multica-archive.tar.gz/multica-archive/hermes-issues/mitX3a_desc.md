# WVmp MIT-X3a 派活单 — asmgen x86 核心：KS_MODE_32 双模 + 物理池 14→6/spill 重构 + entry/dispatch + x86 runtime 真执行电池（X 波关键路径首张）

> 派活单生成: 2026-09-01, 接手人 (项目主)
> 关联: 多目标平台 X3 拆单第 1 张（asmgen XL=X0 §6"唯一 XL 无并行替代"，本波关键路径）| main `5ce27c7`（442 合入后, 基线 50 样本 **250/250**, 十三连）| 素材 = `.multica/mit-X0-triage.md` §3（B.3 四子项）+ `.multica/mit442-ruling.md` §3（X3 挂账包六项）| 后续：**X3b**（A 档 ~45 handler 宽度批迁 + B 档 GP 面）→ **X3c**（CallGate reg-target + ExitNative 4B + x87 D1 备忘）——三张同文件全串行禁并行
> 交付形态: **main 之外的命名分支 `mit-x3a-asmgen-core`**（硬条款十四连，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main 5ce27c7, 2026-09-01 13:5x)

### A.1 现网与解锁纪律
- build 0 / ctest 16/16 / **multiseed 50×5=250/250** / wvmpTest 14/14；kVmOpMax=97（跳表 98/128 项, 余量 30）
- **D1 红线本波维持**: 四象限第 4 格项目主亲验——`arch=x86 + x86 目标 → "匹配, 但 x86 通行未解禁 (D1); 不产出保护壳"`；**X3 三张全部不解锁**（解禁=X5 收口单拍板）
- **X3 真验证通道 = x86 runtime 电池（本单元设计）**: 全管道不通≠VM 码体不可真跑——**/MACHINE:X86 的 32 位测试 exe 内嵌 x86 VM 码体真执行**（438/442 runtime 语义电池 + 5 seed 寄存器随机化模式平移；442 已证 `vcvarsamd64_x86` 交叉构建在本机可用——注意其环境注记：VS Installer 目录须入 PATH 供 vswhere）
- multiseed x86 空池架子在位（442 B.7: `x86_samples=()` + `run_one_seed()` 双池共用，:276-284）——本单不填池（X5 面）

### A.2 asmgen 结构锚（本单改造对象，行号=5ce27c7 实测）
- **keystone 单模硬编码**: `:85 ks_open(KS_ARCH_X86, KS_MODE_64)`——codegen 类需 arch 参数化（KS_MODE_32/64 双模；注意 Intel 语法 32 位下 `dword ptr`/短跳转/无 REX 全族差异）
- **物理池分配**: `:369-380`——`array<int,10> pool` + seed 随机 shuffle：pc_/flags_/t_[1..4]/t_[6..9] 从 pool 填、t_[0]/t_[5] 固定；x64 池=15 GPR−rsp−rax? 你实读现状（注释与代码对账）。**x86 池 = 8 GPR − esp −（ecx? 留 rep 串 native 用——X0 §3 注）→ 可分配 ≈5-6 个**：**pc/flags/t0/t5/ctx/base 等持久角色 + t_[1..9] 临时 10→~2 = spill 纪律重构**（X0 §3.2 核心判决："XL 的硬骨头不是编码而是 spill 重构"）
- **zero5**（:591 区域）: 五 temp 清零惯用——x86 池 2 temp 时该函数全重写（哪些 handler 依赖 5 个以上并发 temp 实测点名）
- **entry/dispatch**: :420 起入口块（位置无关取基址 rip-relative 单点——X0: `call next; pop` 出路，或 base-reloc——你 D2 选）；dispatch `T8=[BYTE+PC*8]`+`and T0,kTableEntries-1`（**跳表 8B 表项 x86 保/改 4B=X0 §3.2-C(2) 决策点，本单拍**——保 8B=ModRM 无宽度惩罚零改动优先评估）
- **stub 保存区约束（442 规则化输入）**: `[ns-8 .. ns-0x40]` 保存区 + "guest 栈写恒 ≥ ns"——X3a 的 epilogue/栈基设计要么维持规则（文档化+lifter 侧已有保守 gate），要么重排保存区（asmgen 面）——**给裁决不给暧昧**

### A.3 挂账六项归属（442 裁定 §3 → 三张拆单映射，防漏防叠）
| 项 | 归属 |
|---|---|
| 池 14→6 spill/zero5 重构 + entry/dispatch + KS_MODE_32 | **X3a（本单）** |
| 保存区冲突设计约束（guest≥ns or 重排） | **X3a（本单拍板）** |
| A 档 ~45 handler 宽度断言批迁 + B 档 GP 面（Push/Pop/Jmp/Jcc/RVA 族+pop 宽度+S16 串元素宽） | X3b |
| CallGate reg-target（442 半程：lifter 开口+note 已就位） | X3c |
| ExitNative 4B 槽协议（X0 §3.2-C(4)） | X3c |
| shld/shrd、cwd、S16 push 真支持评估 + **x87 三路线一页备忘** | X3c 交报附 |

## §B 任务

1. **B.1 arch 参数化骨架**: CodeGen 构造吃 arch（默认 X64 **逐字节不变**——48 单史 sha 恒等纪律：x64 面 `git diff` 可证行为零扰动）；KS_MODE_32 双模开关 + 32 位语法辅助函数（rs() 尺寸表复用度实测——X0 §7 注"已就位"需真验）
2. **B.2 池重构**: x86 分配器（持久角色+临时压减+seed 随机化保留）+ spill 纪律（池尽时的 ctx 槽溢出策略：栈位图/ctx 预留槽——**禁改 kCtxSize 冻结面**（438 遗产），若必须扩 ctx=停手披露 D 点上报）+ zero5 x86 形
3. **B.3 entry/dispatch**: x86 entry（callee-saved 5 push 形 + BASE 取址 D2: (i) call/pop idiom (ii) base-reloc——(ii) 牵 pe_writer reloc 面越界，默认 (i)，选 (ii) 必须披露越界影响）；dispatch/跳表决策（8B 表项保留优先——表体积+1024B@256 已在 432 spike 实测过，x86 下重算）
4. **B.4 保存区裁决**: 维持"guest≥ns"规则（零改+依赖 lifter 保守 gate）vs 重排保存区（asmgen 布局改动面）——实测样本（442 区1 反例形）两方案行为，报告给裁决+理由
5. **B.5 x86 runtime 电池（本单核心交付）**: 新 `/MACHINE:X86` 测试目标（CMake 双 arch 测试目录——复用 442 x86 交叉构建链）：① 最小码体真跑: entry→dispatch→[Halt] 空转闭环 ② 6-8 个代表性 handler（Mov/Add/Sub/Load/Store/Cmp+Jcc/Inc/dec 级）x86 码体生成→capstone 32 位反汇编断言→**32 位进程内真执行语义断言**（寄存器/内存/flags 采样）③ 5 seed 随机化同 442 模式 ④ dump 反汇编静态审（新 x86 dump 门脚本 or 扩展 A.3 工具——SSE_HANDLERS 集合 x64 恒等不动）
6. **B.6 x64 零扰动铁证**: 全 48+2 既有样本 multiseed 250/250 绿 + wvmpTest 双跑 diff 0 + **x64 asm_dump 逐 handler 对账**（433 口径: 逐 handler 非 packed sha——池 shuffle 算法若动, 相同 seed 相同分配可证; 动则披露 delta 表）
7. **B.7 文档**: GAPS C5/X0 行翻正（asmgen 核心就位）+ STATUS 里程碑 + X3b/X3c 交接注记（哪些 handler 在 x86 下真可跑/哪些仍纸面）

## §C 决策点（项目主已拍板）

- **D1 不解锁**（✅）: 四象限第 4 格文案维持；真验证=电池层（A.1）；X5 收口拍解禁
- **D2 entry BASE=call/pop idiom 默认**（✅）: base-reloc 路线涉 pe_writer/reloc 面越界，除非实测 (i) 有硬伤
- **D3 跳表保 8B 优先**（✅）: x86 ModRM 全宽寻址无惩罚（X0 §3.2-C(2) 分析），4B 省体积但动 build_dispatch 掩码逻辑——(i) 优先，选 (ii) 给回归证据
- **D4 kCtxSize/runtime.hpp 冻结不破**（✅）: 池 spill 用**栈**不用 ctx 扩容；ctx 布局任何变动想法=停手评论
- **D5 电池优先于花活**（✅）: 本单成功标准=B.5 的 32 位进程真跑通 6-8 handler——X3b/c 才有地基；池重构做不完可以缩 handler 数，**不许缩电池**
- **D6 x64 恒等口径 = 逐 handler dump 对账**（✅）: 433 教训（禁 packed sha 恒等）；seed 算法保持则相同 seed 逐字节恒等是强目标，若池规模改变 x64 分配序被迫扰动=披露 delta+全回归绿即接受

## §D 验收标准
1. build 0 新警（双 arch 目标）/ ctest 16/16（+x86 电池组 ≥8 例含反汇编断言+真执行断言）/ **multiseed 250/250 + wvmpTest 零回踩**（x64 全绿是本单底线）
2. **x86 电池真跑证据**: 32 位测试 exe 在 SysWOW64/wow64 下 rc=0 + 逐 handler 语义输出贴报告；dump 反汇编样例（entry+dispatch+≥3 handler）内嵌
3. 池重构设计文档节（映射表: 角色→x64 15 池/x86 6 池 + spill 策略 + zero5 x86 形影响 handler 清单）
4. 保存区裁决落地（规则化文档+442 反例行为证 或 重排实现+回归）
5. 冻结契约: kCtxSize/runtime.hpp/vm_op(97)/backend/载体域 0..28/markers/SDK **零 diff**（asmgen.cpp **允许大改**——本单就是它的单；但 x64 输出路径恒等按 D6）；cli/lifter/translator/stub_gen 零触（stub_gen=X4）
6. 硬条款: 命名分支 `mit-x3a-asmgen-core` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账
7. dump/static 双门 x64 PASS 恒等（+x86 电池新门或扩展脚本）

## §E 纪律
worktree 隔离（本单大改 asmgen——多轮小步 commit 自证渐进）/ wvmpTest 禁覆写 / `cmd /c` 查时间戳 / **#33 主战场**: A.2 全部锚点（池规模/zero5 依赖面/rs() 复用度/8B 跳表可行性）实测兜底；**池 14→6 的"6"是 X0 粗算，真实可分配数自己数**（含 esp/rax/ecx 隐式占用与 handler 内硬编码寄存器——grep `mov rax` 类直用点）/ 观察纪律 427 / 卡壳 ≥2 小时评论披露别闷头（XL 单允许中途评论，交付节奏>一次成型）。

## §F known compromise 预判
1. 本单 x86 handler 覆盖面=代表性 6-8 个（全 95 个=X3b 批迁面）——电池可扩展设计，X3b 直接加行
2. 32 位测试进程跑在 x64 机=WOW64（与真 32 位 OS 的 VM 行为差异=0 预期，寄存器池同构；若遇 WOW64 特有行为披露）
3. 池 shuffle 的 seed 可复现性在 x86 池 6 下空间缩小（安全性非本单语义——如实注一句）

时间预算: ~3-4 天（X0 §6 XL 定级）。**本单是 x86 战役最长棒，交报后 X3b/X3c 各 ~2 天。** == MIT-X3a 派活单完 ==
