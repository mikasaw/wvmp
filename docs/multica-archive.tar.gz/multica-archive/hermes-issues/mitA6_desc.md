# WVmp MIT-A6 派活单 — MSVC switch 跳转表特化识别（jmp reg 间接跳转 VM 化，wvmpTest 14/14 收官棒）

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: MIT-407/408 done (main `bbc93e6`, ExitNative 17 站点 + SSE mem, 覆盖 13/14) + MIT-405/D1 triage (r06 病灶静态数据) + GAPS C1 保守 gate 哲学
> 前置阅读: 本单 → `.multica/mit-D1-triage.md` §2 (r06 行) → translator.cpp `translate_jump`/`:525` gate 面 → lifter `translate_jmp` (:242-259, **reg 形式已 lift 成 Op::Jmp dst=Reg**)

---

## §A 基线实测事实 (项目主 fresh verify @ main bbc93e6, 2026-08-29 19:2x)

### A.1 环境
- main = `bbc93e6`; build 0 错 / ctest 16/16 / **multiseed 基线 29 样本 × 5 = 145/145** / wvmpTest **13/14** + 双跑 103/103 byte-exact
- wvmpTest `test_target.exe` **sha256 = bdbfff91… 与 triage 时代一致 (本轮亲验 hash)** → triage 全部 RVA 坐标今日直接有效, 无需重测 (若你重建 wvmpTest 则按 405 红线算法重测)

### A.2 唯一病灶 r06 wv_duff_copy (marker@0xCF88, 区域 [0xCF88, 0xDD7E)) 的间接跳转 — 项目主 capstone 实测
经典 **MSVC 编译期跳转表 lowering** 四件套 (区域尾部, 全函数唯一直测间接跳转):
```
dba2: b9 08000000    mov ecx, 8
dba7: f7 f1          div ecx            ; 404 已支持 ✓
dba9: 8b c2          mov eax, edx       ; 余数 idx = count%8
dbab: 89 44 24 2c    mov [rsp+0x2c], eax
dbaf: 83 7c 24 2c 07 cmp dword [rsp+0x2c], 7   ; 上界防御 (MSVC 恒 emit)
dbb4: 0f 87 bc010000 ja 0xdd76          ; 越界出口 = 出区 jcc, ExitNative 已救 (triage r06)
dbba: 8b 44 24 2c    mov eax, [rsp+0x2c]
dbbe: 48 8d 0d 3b24ffff lea rcx, [rip-0xdbc5]      ; 表基址 (rip → RVA)
dbc5: 8b 84 81 84dd0000 mov eax, [rcx+rax*4+0xdd84] ; 读表项 (u32 delta)
dbcc: 48 03 c1       add rax, rcx       ; delta 基址相对 → VA
dbcf: ff e0          jmp rax            ; ★ 唯一拦路虎
```
表体 @0xDD84 (u32 delta×N, 基址=rcx)。源 = `switch(count%8){case 0..7}` 全 8 路, 无 default → 表全覆盖, `ja` 为死防御。
**项目主表体直读实测 (本轮, sha bdbfff91 有效)**: lea 基址 = RVA 0 (MSVC 表 delta 直接是目标 RVA); 8 项 = 0xDBD1/0xDD2F/0xDCFD/0xDCCB/0xDC99/0xDC67/0xDC35/0xDC03, **8/8 全 ∈ [0xCF88,0xDD7E) ✓**; 第 9 项起 0xCCCCCCCC int3 填充 → **表长严禁靠"扫到非法值"推导, 必须取 `cmp idx, K-1` 防御常数** (D1 已锁, 此为其证据)。
- **lifter 现状**: `translate_jmp` 已放行 `X86_OP_REG` → `Op::Jmp dst=Reg` (x86_translate.cpp:242-259); **translator 侧 Jmp(dst=Reg) 无处可去 → skip → C1 gate** (本单挂点)
- **triage §2.2 r06 口径**: 该区 12 条越区跳转 (switch 各 case 汇入 join 的出区 jcc) 已被 407 ExitNative 救回, 站点 17 中占 12 — 与实测吻合

### A.3 关键设计事实
- 目标集**静态可枚举**: 翻译期读表 (PE image 字节, 表 RVA = `lea` 的 rip 目标 + 0xdd84 位移, 项 = u32 delta 基址相对) → 8 个目标 RVA 全部 ∈ [0xCF88,0xDD7E) 区域内 (项目主预验: 表目标 = case 标签, duff 本体; **你必须实测复核**, 任一目标出区 → gate)
- 区域内 block 表已有 `block_of_addr` 反查 (Jcc/Jmp rel 形式同款), 表目标 → 字节码块映射零新机制
- `jmp rax` 的 rax 值域 = 表项值集 (闭集), 运行时 dispatch 用**比较链**即可全静态实现 (D2)

## §B 任务

1. **B.1 translator 挂点**: `Jmp(dst=Reg)` skip 分支 → 跳转表模式匹配 (D1 四件套模板): 前溯 `lea <b>,[rip+T]` → `mov <ix>,[<b>+idx*4+off]` (u32) → `add <t>,<b>` → `jmp <t>`, 三指令窗口内寄存器/基址一致即命中 (匹配失败 → 照旧 gate, **保守底线零让步**)
2. **B.2 翻译期读表**: 从 PeImage 字节读 N 项 (N = 上界防御 `cmp idx, K-1` 的 K; 无防御时表长推导见 D1), delta→目标 RVA; 全部目标 ∈ 区域块表 → 展开; 任一失败 (出区/表越界/非 4B 项) → gate + note 说明原因
3. **B.3 实现**: 目标集展开为**既有 VmOp 组合** (D2 授权: cmp/je 条件链优先, 零新 handler 零新 VmOp = 最小改面; 条件链预算 ≤32 项, 超预算披露后 gate)
4. **B.4 diag**: `jump-table @ <rva> entries=<N> targets∈region` note 级 (站点计数入报告); 被 gate 的间接 jmp 保持原 note
5. **B.5 E2E 样本**: 新 `wvmp_jmp_table_sample`: switch 8 路 + default + 边界 (idx 越界走 default) + **负例**: 计算跳转目标不可枚举形态 (如 `jmp` 读函数指针全局) → 断言照旧 gate 且行为一致; 主正样本含真虚拟化函数 (REQUIRE_REAL 红线)
6. **B.6 注册 + 基线**: CMakeLists + multiseed (29→30 样本, 预计 **150/150**); 顺带修 408 尾巴: multiseed 注释头 "28 samples=140" 与实际数组长度对齐
7. **B.7 wvmpTest 收官实测**: r06 进 VM 后 **14/14**; ExitNative 站点 17→18 (r06 的 `ja 0xdd76` 保持; 若你的表展开实现使部分越区 jcc 语义并入链, 如实报告差异原因); 双跑 103/103 byte-exact + duff_copy 用例输出正确
8. **B.8 GAPS.md**: C1 节补"跳转表特化"一行 + 间接跳转残余形态清单 (jmp [mem] / 不可枚举 reg jmp → 未来单)

## §C 决策点 (项目主已拍板 2026-08-29)

- **D1. 识别模式 = 受限四件套模板匹配** (✅): 仅 MSVC `lea rip 基 + mov idx 读表(u32) + add + jmp reg`; 表长 K 优先取 `cmp idx,K-1` 防御常数, 无防御时**不猜**→gate。clang `jmp [tbl+idx*8]` mem 形态不做 (越界即披露, 留未来)
- **D2. 运行时实现 = 比较链零新 VmOp** (✅): `mov eax,[rsp+0x2c]` 类 dispatch 值已在 VM 槽, 链 = `cmp v, tgt_i; je blk_i` ×N (tgt = 目标块字节码偏移映射); 预算 ≤32; 若你实测认为查表 handler (新 VmOp JmpTable) 更优, **先评论披露再动**, 不阻塞
- **D3. 表内容正确性标准** (✅): 目标 ∈ 区域块表为硬判据; 目标落表体自身/数据段 → gate; 不做"目标在 .text 任意处"的放宽 (ExitNative 管出区, 本单管在区, 分工清楚)
- **D4. 死防御不优化** (✅): `ja 0xdd76` 语义保持原样 (已由 ExitNative 实现), 不因"表全覆盖可证死"而删除——保守镜像原则

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 / **multiseed REQUIRE_REAL=1 全绿** (预计 **150/150**, 30 样本)
2. **wvmpTest 14/14** (r06 经跳转表 VM 化; stub 数 13→14) + packed 双跑 **103/103 byte-exact**; ExitNative 站点账对齐 (17±, 差异有解释)
3. 新正样本真虚拟化 PASS (非 gate) + 负例 gate 行为与 main 逐字节一致
4. 零回踩: 405 triage 其余 16 站点/12 病灶行为不变 (wvmpTest 映射表逐行对账); callgate/ExitNative/SSE mem 全链 145 既有 runs 绿
5. enum: 目标 **零新增 VmOp** (D2 比较链); 若披露后走 JmpTable → append-only #34 自查 + dump/static_scan 双门 PASS
6. 冻结契约: runtime.hpp / ir::Op / framework / callgate step4-8 / kExitSlotDepth 消费点 / 29 既有样本
7. 报告含: 表识别命中证据 (diag 行) + 8 目标 RVA↔表项 delta 实测表 + gate 负例 note 原文 + **硬条款**: 交付前主工作区 `git status --short` tracked 零脏附输出 + 切回 main + 单分支 ff-safe commit 链
8. ≥30 分钟; 反证/数据主张附固定二进制复跑命令 (406 教训)

## §E 纪律 (407 v2 版全文继承)

build/ 占用自开 worktree / wvmpTest `out/base_*.log` 禁覆写 / `cmd /c` 单斜杠 / cdb 路径见 407 / **#33**: §A 四件套模板若与你的反汇编实测不符 (如 MSVC 版本差异 emit `jmp [reg+disp]` 混合形态), honest disclosure 按实测调整识别器, 不硬套。

## §F known compromise 预判

1. 仅 MSVC 4B-delta 表形态; 8B 绝对表/clang/GCC 平台表留钩子 (B.8 清单)
2. 比较链 O(N) 运行时; 32 项预算内性能无忧, 超预算 gate
3. duff_copy 的 join 出区 jcc 与表链共存, ExitNative+表两机制叠加路径是新增互操作面——影子样本须含"表跳转后函数尾部 ExitNative 退出"组合形态 (r06 天然如此, wvmpTest 即活体证明)

时间预算: ~1 天 (参照近单实际 1-2h)。== MIT-A6 派活单完 ==
