# WVmp MIT-G3 派活单 — 串指令族 rep movs/stos/scas/cmps 微程序展开 VM 化

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: G 线 W3 | main `92928e0` (413/414 链式合并后, 基线 165/165) | GAPS 不支持面登记的串指令缺口
> 前置阅读: 本单 → x86_translate.cpp:1494-1497 (前缀拒绝闸) → translator 比较链先例 (translate_jump_table :834+, 409/413 两代) → vm_reg.hpp:22-28 (flags 位布局)

---

## §A 基线实测事实 (项目主 fresh verify @ main 92928e0, 2026-08-29 23:1x)

### A.1 现网
- main = `92928e0`; build 0 错 / ctest 16/16 / **multiseed 基线 33 样本 × 5 = 165/165** / wvmpTest 14/14 满贯 (jump-table 5 形态 + ExitNative 17 + 双跑 103/103)
- 413 刚修复 409 两潜伏缺陷: ① diag note 前缀 = gate 语义一部分 (`jump-table-gate` 不过滤/new note 必须与 backend :136-137 过滤白名单对账——**本单新 note 类型同样受此纪律约束**) ② width 参数化先例

### A.2 本单三锚 (项目主直读)
1. **挂点 = lifter 入口前缀闸**: `x86_translate.cpp:1494-1497` — `if (x.prefix[0] != 0 || x.prefix[1] != 0) return unsupported(...)`。带 rep/F2/F3/66 前缀的指令**全部在 lifter 层被拒** → 409-era gate 哲学一致, 本单从 lifter 开始, 不是 translator 单点 (与 C4b 当年不同路径)
2. **ir::Reg 全齐**: `Reg : u8 { Rax,Rcx,Rdx,Rbx,Rsp,Rbp,Rsi,Rdi,R8..R15,Rip,Flags,Count }` — rep 循环三寄存器 RCX/RSI/RDI 虚拟槽现成
3. **VM flags 无 DF**: vm_reg.hpp:22-28 flags 槽仅低 5 位 ZF/CF/OF/SF/PF — rep 语义的 DF(方向标志) 在 VM 中**不存在** → MSVC/所有主流 Win 编译器产物 DF 恒 0 (cld ABI 惯例) → **D1 裁决路线: DF=0 假定 + 防御 gate** (见 §C)

### A.3 capstone 形态先验 (实施前你必实测, 404 分裂枚举教训)
- vendored capstone (.deps/capstone-src/include/capstone/x86.h): 串指令独立 id 存在 (MOVSQ/MOVSD string/STOSB..Q/CMPSQ/SCASQ 等; **注意 X86_INS_MOVSD 与 SSE movsd 同 id 双形态** — lifter :1590 注释在案, 你需按 detail.repe/repne + detail.op_size 区分, 408 的"双 MEM 拒绝规则"区分法可参照)
- `x.detail.prefix` 对 F3 (rep)/F2 (repne)/66 (操作数宽) 的报法**实测为准**; movsb/movsq 由 op_size 区分 (S8/S64)
- MSVC /O2 memcpy/memset 内联产 rep movsq/stosq 实测频率: wvmpTest kernels 有 memcpy/memcmp 对拍用例 (duff/mem 类) — 项目主已知其 /Od 版不产 rep (走 call), 你的样本用 MASM 直写 (`rep movsq` 单行) + /O2 局部编译双路证形态 (ml64 模板抄 413 jmp_table8)

## §B 任务

1. **B.1 lifter**: 前缀闸放行 `rep/repnz` + {movs,stos,lods?,scas,cmps} 族 (lods 是否入面你按编译器产物频率实测定, 无真实产出可砍面披露); 其余前缀指令 (lock/rep 前缀的非串指令/rep x87 逃逸类) **照旧拒** — 放行判定必须 detail 级 (mnemonic+prefix+op_size 三元组白名单, 禁"prefix[0]!=0 全放")
2. **B.2 微程序展开** (D2 授权选型): translator 展开为既有 VmOp 组合循环 (load [rsi] / store [rdi] / ptr±imm / rcx-1 / jnz) — **优先零新 VmOp**; cmps/scas 的 flags 语义 = 每迭代 cmp 真写 flags (repnz 早退条件读 ZF) 用既有 Cmp+Jcc 通路; 展开后的循环回边与区域块表交互实测 (块边界/回跳 gate 链)
3. **B.3 DF 防御**: 翻译期无法证 DF=0 (静态), **保守边界 = 文档+note**: 微程序按 DF=0 (指针递增) 展开, note 级 `string-op DF=0 assumption @ rva` 披露 (新 note 与 backend 过滤白名单对账, 413 纪律); 若你认为运行时 pushf 探测可行且低扰, 先评论披露方案再动
4. **B.4 语义正确性硬底线**: ① 逐字节/逐 8B 宽度语义与原生一致 (movsb/q/d/w 全宽); ② rep 0 次 (rcx=0) 空转; ③ repnz 早退 (scas/cmps); ④ 重叠区域行为 (rep movs 原生未定义重叠拷贝——样本禁依赖重叠语义, 披露); ⑤ **非对齐 [rsi]/[rdi] 访存** (movups 教训族: 展开用非对齐语义指令)
5. **B.5 E2E 样本**: `wvmp_string_ops_sample` (MASM 直写全族 + C++ /O2 双路, 边界①-⑤全覆盖) + 负例 (rep 前缀非串指令 `rep nop`/`lock rep?` 组合照旧 gate) + REQUIRE_REAL 真虚拟化主函数; 影子按需 (flags 通路 cmps/scas 读回探针)
6. **B.6 注册+基线**: multiseed 33→34 (预计 **170/170**), 注释头对齐; dump/static 双门 (新 handler 预期零, 全复用; 若有新 handler 进注册表)
7. **B.7 GAPS**: 不支持面串指令行收口 (残余: lods 若砍 / 16 位操作数模式 / DF=1 假定边界)

## §C 决策点 (项目主已拍板)

- **D1 DF=0 假定 + note 披露** (✅): 不建 DF 位不进 flags 布局 (kFlagsMask 变更=冻结面破坏); DF=1 输入 (手写 asm) 行为=原生不保证, gate 判据无法静态化 → 文档化边界; 运行时 pushf 探测=可选加餐需披露
- **D2 展开优先禁新 handler** (✅): 微程序 = 既有 VmOp 序列; 若实测发现展开后回边/块表交互复杂度失控, **新 VmOp RepMovs 类专用 handler 方案先评论披露** (对照 408 D1"编码墙"先例, 换路不算失败)
- **D3 族面** (✅): movs/stos/scas/cmps 四族入面; lods 实测无编译器产出则砍面披露; movsd-string vs SSE-movsd 双形态区分是硬判据 (408 :1590 先例反查: 你需保证两形态互不误纳)
- **D4 循环上界**: 展开体固定 (微循环, 非迭代数展开) — **禁按 rcx 值展开代码**; rcx 运行时值语义保留

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 (+lifter/translator 新用例各 ≥3: 族白名单/双形态区分/DF note) / **multiseed 170/170 (34 样本 × 5)**
2. 新样本真虚拟化 stub 计数 + 语义①-⑤逐条证据 (含 rcx=0/repnz 早退/非对齐) + 负例 gate 日志逐字节
3. 实汇编对照表 (每族: MASM 字节 → capstone (prefix 报法) → 微程序 VmOp 序列 dump) 
4. **零回踩**: 165 既有全绿 + wvmpTest 14/14 + jump-table note 原样 + ExitNative 17 + 双跑 103/103 diff 0
5. 冻结契约: kFlagsMask/vm_reg 布局/runtime.hpp/ir::Op/backend.hpp/callgate/kExitSlotDepth 零触碰 (D1 明证: 不建 DF 位)
6. 新 note 类型与 regvm_backend 过滤白名单对账披露 (413 纪律执行证据)
7. **硬条款**: tracked 零脏 + 完工切回 main (无并发占用时; 被占用如实披露) + 单分支 ff-safe
8. ≥30 分钟; 数据主张附复跑命令; 时间报告与 run 起止对账 (412 教训)

## §E 纪律

worktree 隔离 (主工作区 build/ 禁占) / wvmpTest 基线禁覆写 / `cmd /c` / vendored capstone 枚举名为准 (禁 pip capstone 结论, 404 教训) / **#33**: §A.3 先验全可能被实测推翻, 推翻优先; 区判据/双形态互斥两条硬底线零让步。

## §F known compromise 预判

1. DF=1 手写产物不保 (D1); 16 位操作数 (0x66 rep movsb) 若砍面入 §B.7 残余
2. 重叠拷贝未定义语义与原生可能不一致 (原生本身未定义, 样本禁依赖)
3. 微程序展开 = 字节码膨胀 (每串指令 ~8-12 op), 体积换覆盖接受, 性能量级报告 (rep 大计数循环 native 比 VM 快属预期, 非回归)
4. `rep stosq` 大 memset 的缓存行为差异不做性能面

时间预算: ~1 天 (参照 407 复杂度, 微程序+双形态区分是硬点)。== MIT-G3 派活单完 ==
