# WVmp MIT-D1 派活单 — 区域外跳转 8 病灶侦察 + ExitNative(B') 可行性确认书（裁定型 / 纯侦察不改码）

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: 规划 `.hermes/plans/2026-08-29_D-jump-region-plan.md` (B' 方案 = translator 条件 emit VmOp::ExitNative, 复用 HALT 写回链, 区域/stub 布局零改动) + MIT-404 (整数除法族, **并行在跑, 与本单无依赖**)
> 模板: MIT-393 裁定型 (verifier 独立复跑 + 报告落盘 + 不改产品代码)
> 性质: **侦察 + 可行性裁决单** — 唯一交付物 = B' 可行性确认书 + 上界算法建议 + D2 实现单 §A 假设素材。**不改产品代码, 不 commit**

---

## §A 已知事实 (项目主 08-28/08-29 实测, 直接引用可, 复验必做)

wvmpTest kernels.toml 全量 protect (seed=12345, 08-28, CLI≈694eda0): 14 marker, 1 真虚拟化, 13 被 gate。其中 **8 个 marker 唯一根因 = 区域外跳转** (translator.cpp:516 `block_of_addr` miss → skip → C1 gate 整函数回退)。

### 8 病灶清单 (marker@RVA → 越区跳转目标 RVA, 原文日志可复得 `%TEMP%\handover_protect.log`)

| # | marker | 越区目标 | kernels.cpp 推测函数 (待你实证) | 候选病灶形态 |
|---|---|---|---|---|
| 1 | 0xc951 | 0xD55F, 0xD566, 0xD57A (3 连跳) | wv_mul64hi? | 溢出/快路径早返回 ×3 |
| 2 | 0xc9c7 | 0xD5FB, 0xD638 (2) | wv_duff_copy? | Duff 设备 switch 尾 |
| 3 | 0xcac7 | 0xD8A3, 0xD8B3 (2) | wv_bsearch_i32? | not-found 早返回 + mid 回跳? |
| 4 | 0xcdc7 | 0xD9E1, 0xDA14 (2) | wv_insertion_sort? | 早返回 + 循环出口 |
| 5 | 0xce67 | 0xDB1B (1) | wv_ackermann? | 递归底早返回 |
| 6 | 0xd758 | 0xE392 (1) | wv_rc4_ksa? | swap 尾 join |
| 7 | 0xe023 | 0xEC76 (1) | wv_b64_encode? | 余数分支出口 |
| 8 | 0xe153 | 0xEDA6 (1) | wv_b64_decode? | 非法字符早返回 |

(5 个非跳转病灶归 MIT-404: div @0xcf88,0xd898 / cdqe @0xd1c2,0xd9d8 / cdq+cdqe @0xd298 — 本单不管)

### B' 方案一句话 (见规划文件机制修订节)

越区目标 ∈ [END, 保守上界) 且**跳出后不回跳本区** → 译成 `ExitNative(target_rva)`: 复用 HALT/callgate 的"回写易失寄存器 → 恢复 → jmp target"链, VM 单次退出原生接管。目标 < END 或超上界 → 维持 gate (行为与今天逐字节一致)。

## §B 任务 (D1 出口判据四件套, 全部实测)

### B.1 marker→函数 映射实证
用 marker_scan diag / capstone 反汇编 8 个 BEGIN 调用点上下文, 把上表"推测函数"钉死为实测函数名。方法自定, 报告写步骤。

### B.2 逐病灶四问 (8×11 目标 RVA 逐个回答, 不许抽查)
对每个越区目标 RVA:
1. **[END, 上界) 落界内?** 上界候选三种全测: ① 下个 BEGIN 的 marker 函数地址 ② int3-padding + retn 簇扫描 (从本区 END 向后) ③ 函数真边界 (若有别的手段)。给出每候选下 8 病灶的覆盖矩阵 (几种算法各救回几个)。
2. **跳出后有无回跳本区?** 反汇编目标所在块及其后继 (capstone 顺基本图走 ≤3 层), 找目标块内/可达块内是否有 jcc/jmp 回落在 [BEGIN, END)。有 → 该 marker 记"反例", B' 覆盖不了, 维持 gate。
3. **目标点栈自洽?** 目标处反汇编上下文: 若是函数 epilogue (add rsp, imm; pop; ret) 或普通 join 块 — 核查 ExitNative 写回链落点时 rsp 与 VM 入口时 rsp 关系 (VM stub 执行期 rsp 摆位 = stub 帧; 原生续跑需要"恢复后"形态, 即与 callgate step 4-8 后等价)。对照 callgate 现状 (B2 后 asmgen.cpp:1012-1080 注释链) 给一句"可复用/需适配+差在哪"。
4. **目标是否落在共享尾部?** 多 marker 目标相同/相邻 (如 0xD55F/0xD566/0xD57A 三连) — 标注共享关系, 给 D2 防重复覆写提示。

### B.3 反例压力测试 (构造, 临时样本不进仓库)
写 2 个临时靶函数: ① 跳出后又跳回区域 (B' 必须识别并 gate) ② 目标 = 超界 (下一函数中) (必须 gate)。当前管道跑 protect, 确认现有 C1 gate 对二者行为 = 整函数原生 (保守正确底线在 B' 后不能破)。

### B.4 裁决出口 (三选一, 必须给)
- **B' 全行**: 8 病灶 ≥6 救回 + 0 反例风险 → D2 直接按 B' 派
- **B' 部分行**: 列"可救集/维持 gate 集"精确划分 + 每集判据 (D2 按可救集派)
- **B' 不可行**: 证据 + 建议转 C (双向分段) 的入场理由
出口文件 = `.multica/mit-D1-triage.md` + issue 评论, status → in_review。

## §C 工具与环境纪律

- 仓库 main `43b3827` (MIT-404 并行在跑 mit-c-intdiv 分支, **勿动 main 勿 fetch 404 分支**, 你测的是 08-28 日志 + 当前 main CLI; CLI 用 `build/cli/wvmp_cli.exe`, 缺则先 scripts\build.bat — 注意 build/ 可能被他单占用重编, 若 build.bat 报锁/产物新于 43b3827, 用 git worktree 拉 `wvmp-mitD1-verify` 自建)
- wvmpTest 重跑 protect 输出请落 `%TEMP%` 自定义名, **不要覆写 wvmpTest/out/base_*.log 与 build/x64/packed.exe** (那是验收基线产物; 如需 protect, 输出指向临时目录)
- capstone: `C:/Python314/python.exe` (5.x 已装; 枚举以 vendored `.deps/capstone-src` 为准的教训见 MIT-404 §A, 本单分析用 pip 版无碍, 但报告注明版本)
- cdb: `C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe` (B.2.3 栈核查可用)
- TOML `C:/...` 绝对路径; .ps1 全 ASCII; 长跑 subprocess; 禁 `cmd //c`
- 纪律: ≥30 分钟; 每条数字带实测粘贴 (#29); 结论与 §A 冲突以实测为准并披露 (#33); honest disclosure 优先 (模式 13); 完工 `git checkout main` (若用了 worktree 则 remove 自己那个)

## §D 决策点 (项目主已拍板 2026-08-29)

- **D1. 交付形态** (✅): triage 落盘 + in_review, 与 MIT-393 同口径
- **D2. 上界算法若三候选打平** (✅ D2.1): 报"最简稳定"者 (倾向 ② int3+retn 扫描, 无需符号依赖), 注明维护成本
- **D3. 若发现第 9、10 个跳转病灶被 div/cdqe 掩盖** (✅ D3.1): 08-28 日志按 marker 首个 skip 截断过后续原因 (cdqe 先触发 gate, 跳转可能藏在后) — 本单在 404 修复合入前无法复验这些隐性病灶, 如实标"待 404 后复扫", 不算 B' 失败

## §E 验收 (项目主复核项)

1. 8 marker 函数名映射表 (实测方法可复现)
2. 8×11 四问矩阵全表 (无抽查)
3. 上界三候选覆盖对比表 + 选型结论
4. 2 个反例压力样本的 protect 实测输出
5. 裁决三选一 + D2 派单 §A 素材段 (可直接抄进 MIT-D2 描述文件)
6. 零产品代码改动 (git status / HEAD 不变 / 不碰 wvmpTest 基线产物)

## §F known compromise

- 你此刻看不到 404 的 div/cdqe 修复; 隐性跳转病灶 (D3) 是已知盲区, 不算入 B' 否决证据
- kernels 编译自 /O2, 布局随编译器版本漂移 — 病灶 RVA 仅在 08-28 test_target.exe (941056 B, sha 可自取) 下有效; 若你重建 wvmpTest 产物 RVA 会变, 请**以你重建后的实测为准并披露两版差异** (这正是 B' 上界算法必须鲁棒的证明机会)

== 派活单完 ==
