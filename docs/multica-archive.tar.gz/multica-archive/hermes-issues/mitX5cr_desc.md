# WVmp MIT-X5cr 派活单 — 侦察："跳转目标块未找到"17 处根因分型（x86 最大 gate 面）+ exit-native=0 之谜（x64 同构 17 次命中 vs x86 零命中）→ X5c 实施单设计输入

> 派活单生成: 2026-09-02, 接手人 (项目主)
> 性质: **纯侦察零代码**（412/416/424/432/436 五先例同构）| 关联: X5b 裁定 §4.2 点名的 x86 下一最大 gate 面 | main `ae194d3`（451 合入后, 基线 63 样本 **315/315**, x64 dump 底稿 `ffd47289`, 十九连）
> 交付形态: **main 之外的命名分支 `mit-x5cr-jtbn-recon`**（硬条款二十连, 违者退回重交）| 后续: 本单出数 → 项目主拍板 X5c 实施单（或改判维持 gate/归入其他战役）

---

## §A 基线实测事实 (项目主 fresh verify @ main ae194d3, 2026-09-02 18:3x)

### A.1 note 出处与语义
`translator.cpp:1671 return skip(in, "跳转目标块未找到（区域外/未 lift）", nullptr)` —— Jmp/Jcc 目标解析后的**最后兜底**：前置（:1638-1670 区）有完整 **ExitNative 判定链**（目标在区域外 → emit VmOp::ExitNative 单向退出, 407 G1b 面）——**只有前置不命中才落到 skip**。

### A.2 项目主亲测现场（wvmpTest x86, 当前 main CLI@ae194d3, protect log 已存 `%TEMP%\v452\protect.log`）
- **17 处"跳转目标块未找到"分布**: marker@0xaa18 内 3（rva 0xB625/B62B/B63E）+ 0xaa7b×2 + 0xab3b×2 + 0xad5b×2 + 0xaddb×1 + 0xaebb×2 + …（共 12 个 marker 函数, 单函数 1-3 处）
- **⭐ 头号谜题（本单靶心）: x86 `exit-native` 命中 = 0**——wvmpTest **x64 同 toml 同构打壳历来 en=17**（每单验收亲数的"exit-native @"计数）, x86 侧同 kernel 结构却 **0 次命中、17 次全落 skip**。两个"17"数字诡异吻合: 高度怀疑**同一批区域外跳转在 x86 前置链上系统性不命中**（ExitNative 判定条件在 32 位形下有 arch 假设漏洞）——若是, 修一个判据点即 17 处全翻正, 是本侦察单能给出的最高价值结论。
- 候选嫌疑点位（侦察起点非结论）: 目标值宽度链（x86 Jmp in.size=S32 / aux 32 位截断 vs 区域表 RVA u64 比较?）、image_base 相加形（x64 RVA+base 64 位 vs x86 VA 32 位比较域）、区域边界判定（section 末/函数 end 口径）、lifter 区形差异（x86 .text 段内 marker 区域划分）——**全部实测排除或坐实**。
- skip 函数总面 30（含 push-imm 11 / 其他, 对照 450 分布表——本单只管"跳转目标块未找到"这 17 处一类, 别族数对账即可不展开）。

### A.3 x64 零命中基线（对照锚）
wvmpTest x64 = 14 stubs / 0 gate（含本类 0 处——同构 kernel 在 x64 全被 ExitNative/块表消化）；x86 池样本 jmptbl/deepcall 也无本类命中（x64 50 样本 multiseed 同样零命中）——**17 处集中在 wvmpTest 103-kernel 真实混合语料**（MSVC /Od x86 大函数多 switch/异常帧/冷区形态）。

## §B 任务（triage 报告 `.multica/mit-X5cr-triage.md`, 150-250 行, 零产品代码）

1. **B.1 逐处根因分型（招牌表）**: 17 处每处给——函数/触发指令（capstone 反汇编原文）/目标 rva 值/目标在哪（区域外? 区内但未 lift? 函数尾?）/**前置 ExitNative 链为何不命中的精确判据行**（对照 :1638-1670 逐条件走查, 打印现场值）——归类到互斥型（每型: 计数/判据点位/修复难度/是否 arch 特有）。
2. **B.2 exit-native=0 之谜裁决**: x64 en=17 vs x86 en=0 的**机制性解释**（同一 kernel 双 arch protect 对照实验: 挑 0xaa18 函数双 arch 各跑一次, dump 目标值/区域表/判定中间量）；结论三选一并给证据: (a) x86 前置链有 arch 假设 bug（点位+最小修法）/ (b) x86 区域外跳转语义不该走 ExitNative（给设计理由, 现状 skip 正确, "翻正"=别的机制）/ (c) 目标真未 lift（区域划分问题, 归 lifter）。
3. **B.3 修复选项对比（X5c 实施输入）**: 每型给——方案（判据点参数化? 区域扩展? 目标 lift 补挖?）/改动面文件清单/预估（S/M/L）/multiseed+wvmpTest 回归风险/预期翻正数（17 中救回几处, **修完 wvmpTest x86 虚拟化 stub 数预期读数**）；给推荐组合。
4. **B.4 泛化评估**: 此 17 类在真实第三方 x86 客户产物（SysWOW 抽样 or X0 域语料复扫）的预估占比（436 方法学可复用）——"修完 x86 虚拟化率提升"的客户面读数。
5. **B.5 纪律**: 禁改产品代码/样本/harness（只读+新增离线脚本入 scripts/verifier/）; 数字全部自测（报告点名"x64 en=17"是项目主 §A 锚, 你复测兜底——失配即点名 #33）; 每结论必附命令输出证据。

## §C 决策点
- **D1 侦察边界**: 只管"跳转目标块未找到"17 处一类；stack-depth 永久 gate/push-imm/间接 jmp 各族**不重开**（451 已裁, 数对账入报告一句即可）。
- **D2 不预设修复方向**: (a)(b)(c) 裁决开放——**若结论=现状 skip 即正确设计（不该 ExitNative）, 如实说"无 X5c 实施单必要, 建议维持+文档化"同样是满分交付**（424 R2 先例）。
- **D3 实验样本纪律**: 对照实验用临时目录产物（wvmpTest 只读, protect 输出落 %TEMP%）；x64 侧对照用 main CLI 现产物。

## §D 验收标准
1. triage 报告落盘 `.multica/mit-X5cr-triage.md`: 17 处互斥分型表（每处: 指令/目标/判据行现场值）+ 之谜裁决（双 arch 对照实验证据）+ 修复选项对比（含推荐组合与预期翻正读数）+ 泛化占比
2. §A.2 锚复测: en=0 与 17 处亲跑对账（失配即披露）
3. 硬条款: 命名分支 + 纯文档/脚本 diff（零产品代码）+ main 未动 + 零脏 + 切回 main + worktree 自拆 + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 / capstone 用 `C:/Python314/python.exe`（CS_MODE_32）/ dumpbin 路径在 `C:/Program Files/Microsoft Visual Studio/18/Insiders/VC/Tools/MSVC/*/bin/Hostx64/x64/` / **#33**: §A.1/A.2 全部锚（前置链行号会漂, 重钉; 17 处分布在 451 guard 后可能已变——以你实测为准点名）/ 卡壳 ≥2h 评论披露。

## §F known compromise 预判
1. wvmpTest 是自家 kernel 语料（非真第三方客户产物）——B.4 泛化只能给抽样估计, 口径如实注。
2. 目标"未 lift"判定依赖区域表实现细节——读码口径若与运行时中间量矛盾, 以运行时打印为准（433 教训: 机制面以实测为是）。

时间预算: ~2-3 小时。交报后项目主据 B.3 推荐 + B.4 读数拍板 X5c 实施单（或改道）。== MIT-X5cr 派活单完 ==
