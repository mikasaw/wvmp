# WVmp MIT-B2 派活单 — callgate 栈回退常量修复 (0x1A8 → kCtxSize 派生) + multiseed 基线 100/100 刷新

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: MIT-393 (MIT-B1 定位单, **done**, 报告 `.multica/mit-B1-triage.md` 174 行, 项目主已独立复核) + GAPS.md C3 (callgate) + MIT-371 (kCtxSize 0x140→0x1C8, 漂移引入者)
> 本单 §A 假设 = MIT-393 四路互证结论, 置信度高 (cdb 现场内存实测 + git log -S + 最小复现对) — 但仍适用 pitfall #33: 实测若与 §A 不符, 诚实披露 + 改方向

---

## §A 根因 (MIT-393 已裁定, H2 ✓, 项目主复核通过)

MIT-371 (commit 23f0e25) 把 `VmContext`/kCtxSize 从 **0x140 扩到 0x1C8** (stub_gen.cpp:30), 入口 stub 栈帧加深 0x88; 但 callgate handler 的栈回退常量 `sub rsp, 0x1A8` (**vm/regvm/runtime/src/asmgen.cpp:1042**, step 7) 未同步 → push ctx 落槽与 pop ctx 读槽错开 **0x88** → pop 读到 stub VmContext 帧 +0x38 (= 保存的宿主 RBP = 0) → ctx_=0 → 下一条 `mov r14,[rsi+8]` AV (0xC0000005)。

- 崩点 = callgate handler (镜像 +0x3704) 内偏移 0xBC = asmgen.cpp:1046 step 9 发射
- 5 坏样本命中 callgate 的途径各异 (MIT-393 §6 查明): call_gate×2 设计使然; bswap/rol 的 intrinsic 在 VS 18 Insiders /MDd 下**未内联**成 bswap/rol 而落成 CRT call (`ucrtbased!_byteswap_ulong`/`_rotl64`); cl_shift 含本地 helper call
- **C2 算术 handler 本身无恙** (崩时 rax=0x78563412 正是 bswap32 正确结果)

## §B 修复方案 (决策已拍板)

**B.1 主修复** — `vm/regvm/runtime/src/asmgen.cpp:1042`:
- step 7 `sub rsp, 0x1A8` 改为**从 kCtxSize 编译期派生**: `step7 = kCtxSize + 0x40(stub 8 push) + 0x8(call ret) + 0x40(entry 8 push) + 0x8(ctx push) - 0x28(native_sp 摆位)` → kCtxSize=0x1C8 时 = **0x230** (推导核对: 旧 0x140 → 0x1A8 ✓ 与现存常量吻合)
- **禁止裸换魔数**: 必须是 constexpr 表达式或等价派生形式, 让 kCtxSize 再变时自动跟随 (消除隐式耦合 — 这正是本 bug 根因)
- 同步刷新周边注释: asmgen.cpp:231-236 (0x1C8/0x1D0 推演块) 与 :979-980 (栈回退算术注释)

**B.2 fix-the-class 排查 (必做)** — grep 全 runtime/stub 代码面对 kCtxSize 的**其它**隐式硬编码耦合 (候选字面量: 0x1A8 / 0x1D0 / 0x1C8 / 0x140 出现在 rsp 算术/帧偏移语境):
- 逐处判定: 已派生 / 需派生 / 无关; 需派生的一并按 B.1 模式修
- 报告列排查表 (文件:行 + 判定 + 依据), 一处不漏

**B.3 卫生搭车 (本单包含)** — `scripts/multiseed_e2e.sh` L31 CLI 路径改**双探测**: 先 `build/cli/wvmp_cli.exe` (Ninja 现行布局), 缺则 `build/vs/cli/Debug/wvmp_cli.exe` (旧 VS 布局), 都缺则明确报错。消灭"镜像目录 hack"。不改脚本其余逻辑。

## §C 环境基线 (2026-08-29 09:00 项目主 fresh verify, fb66b98)

- build rc=0 / ctest 16/16 / multiseed REQUIRE_REAL=1 = **75 PASS / 25 FAIL** (修复前)
- 5 坏样本 stub 实测数: call_gate **1** / call_gate_simple **1** / rol **2** / cl_shift **16** / bswap **3**
- 崩溃签名 (修复前): 5/5 `4c8b7608 mov r14,[rsi+8]` @ .wvmp+0x37C0
- 注意: bswap/rol 样本内崩在**执行出正确结果之后** — 修复后它们的 stdout 必须与 native byte-exact (0x78563412 等值), 不得只看不崩
- 环境坑沿用: multiseed 旧路径 (B.3 修复前仍需镜像 `mkdir -p build/vs/cli/Debug && cp build/cli/wvmp_cli.exe build/vs/cli/Debug/`); TOML 用 `C:/...`; .ps1 全 ASCII; 长跑用 subprocess/Start-Process; cdb 可用 (`C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe`)

## §D 决策点 (项目主已拍板 2026-08-29)

- **D1. 修复形态** (✅ D1.1): kCtxSize 编译期派生 (constexpr), 拒绝硬编码 0x230 + 注释
- **D2. 样本 intrinsic 问题** (✅ D2.2): bswap/rol 样本**保持现状不改成强制内联** — CRT call 路径恰好是 callgate 的活体回归样本, 价值更高; 在样本文件头注释记录该事实即可
- **D3. §A 若被实测推翻** (✅ D3.1): 沿 pitfall #33 诚实披露 + 改方向 + 完整 fresh 验证链

## §E 验收标准 (12 项, agent 自查 + 项目主独立复验)

1. build: rc=0, 0 error (scripts\build.bat Ninja)
2. ctest: 16/16 PASS 零退化
3. **multiseed REQUIRE_REAL=1: 20 样本 × 5 seeds = 100 runs 全部 PASS (100/100)** ← 本单核心断言, 25 FAIL 清零
4. 5 坏样本 stub 数不减 (1/1/2/16/3) + packed stdout+rc 与 native byte-exact + **不再出现 0xC0000005**
5. SSE 职责集 9 样本 45/45 含于 3, 单独列
6. capstone 回读: callgate handler 修复前后机器码 diff (sub rsp 立即数 0x1A8→0x230 + 派生改动), 贴报告
7. B.2 排查表完整 (每处字面量: 判定+依据)
8. `static_scan_bare_immediates.ps1` → RESULT: PASS (0x230 为 hex 显式, 预期过; 若被扫出, 按 #78 用 imm() 语义处理 runtime 侧则说明理由)
9. `dump_handler_xmm_check.py` → PASS (SSE 写回门不回归)
10. 冻结契约: 改动面 = asmgen.cpp (+ 派生所需的最小头文件改动) + multiseed_e2e.sh + B.2 波及处 + 样本头注释; **不改** common/framework/backend.hpp/runtime.cpp/pe_writer.cpp/stub_link.cpp/18 既有样本主体逻辑
11. commit 到独立分支 `mit-b2-callgate-sp-fix`, 未 push 未 merge, 报告附 hash
12. 报告按 §F 格式, 每条数字带实测输出粘贴

**时间预期**: 主修复本身 <30 行; B.2 排查是大头。**agent 必跑 ≥ 30 分钟; multiseed 100 runs 一轮 ~15 分钟, 若你 5 分钟内报告"完成"即触发 pitfall #38 假完成红线, 直接 REJECT。**

## §F 报告模板

```
# MIT-B2 报告 — callgate 栈回退修复 + 基线刷新
## 一、改动清单 (文件:行 + 前后 diff 摘要)
## 二、B.2 隐式耦合排查表
## 三、验证结果 (12 项逐条, 实测输出粘贴)
  - multiseed TOTAL 行必须原文: [multiseed] TOTAL: 100 pass / 0 fail
## 四、capstone 回读 diff
## 五、关键决策/披露 (含 §A 若被修正处)
## 六、遗留 (如有)
```

## §G known compromise

- kCtxSize 派生若引入 asmgen ↔ stub_gen 头依赖方向问题, 允许在既有共同头取用常量 (沿现状 include 图, 不新建跨层依赖); 报告说明取舍
- 样本 /MDd CRT call 行为依赖工具链版本 (VS 18 Insiders), 换编译器版本可能"意外内联"使 callgate 覆盖静默流失 — D2.2 已在样本头注释留哨兵

## §H close-out (项目主侧)

报告 → 项目主 worktree 独立复验 §E 1-4 → `.multica/mit-b2-ruling.md` → done → ff-merge main → **新基线 100/100 冻结入 wvmp-dev skill + MEMORY** (替换 65/25、75/25 段) → multica 面板清零后, 按 GAPS 顺序评估 C4 rip-relative 派单。

== 派活单完 ==
