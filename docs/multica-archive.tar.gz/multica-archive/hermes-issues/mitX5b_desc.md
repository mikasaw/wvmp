# WVmp MIT-X5b 派活单 — x86 保存区冲突修复：entry guard 垫栈 + 翻译期栈深 gate 兜底（C2→C1 化）+ 顺路两缺口（跳表匹配器 S32 / REG-REG 位测试族）

> 派活单生成: 2026-09-02, 接手人 (项目主)
> 关联: 多目标平台 X5b（450 收口波遗留的 C2 缺陷修复单, **x86 生产态正确性补丁**）| main `df6b751`（M2.5-X 已宣告收档, 基线 56 样本 **305/305**, x64 dump 底稿 `ffd47289`, 十八连）| 素材 = 450 交报 §B.2 崩溃实录 + §遗留 1-2 + GAPS X5 收口终稿节 + 442"guest 栈写≥ns"规则（450 升级为产品正确性边界）
> 交付形态: **main 之外的命名分支 `mit-x5b-stackfix`**（硬条款十九连, 违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main df6b751, 2026-09-02 14:0x)

### A.1 缺陷本体（450 实锤, 我亲手复验过崩溃）
真实 /Od x86 codegen 在虚拟化区域内发 push（prologue `push ebx` 类）→ guest push 从 ns 下探写穿 stub 保存区 [ns−4 .. ns−0x10]（4 callee-saved）+ ctx 区 → VM 退出还原垃圾 → 确定性 AV（cdb: ebp=FFFFFFFF, eax=" WVMP"/ecx=" END1" magic）。442 规则只约束了**自建样本**（D4 纪律"区域内无 push"），真实编译器产物普遍违反——**当前 x86 生产态 = 含区内置 push 的函数不可安全虚拟化, mul64hi 是唯一漏网进虚拟化的样本所以只有它崩**。x64 侧同构风险存在（保存区 [ns−0x208..ns−0x40] 更宽 + 406 E1 kCalleeWindow=0x60B callee 专用栈窗口先例已处理过深 call 形态）——但 x64 wvmpTest 14 stubs 双跑 diff 0 = MSVC x64 真产物未命中（x64 prologue 常 sub rsp 非 push / push 在区外）, **本单修 x86 面, x64 仅栈深 gate 兜底共享（见 B.2）**。

### A.2 修复素材（450 探针全套）
- push-reg 形铁证: ebx=00010000/esi=00000100/edi=00000010 精确落位 [v4−4..v4−0x10]
- 三缺口点位: ① `try_match_jump_table` 基址载入+delta add 两处 `size != S64` 硬判（translator :403/:457 附近, 我本轮重钉）→ x86 S32 链永不匹配（446"参数化"仅步进 tag, 匹配器本体未及）; ② lifter `X86_INS_XADD/BTS/BTR/BTC` 判据 `operands[0].type != X86_OP_MEM → unsupported`（:2245/:2266 直读）= REG-REG 形关门; ③ in-region push 面（本单主体）
- 池现状: multiseed x86 11 样本（jmptbl 以 **gate 负例+helper** 形态在池——修复后 3 正形翻正, 428 翻转先例）

### A.3 方案空间（B.1 实测给数后再入 D1 路线, 不许拍脑袋）
- **(v) entry guard 垫栈**: stub x86 序言在保存区之下再垫 N dword 保护区（guest push 先吃 guard 再谈穿保存区）+ 翻译期静态栈深对账（区域 push 净深 > N 即整函数 C1 gate 兜底）。x64 kCalleeWindow 同族先例; 工程量 M; **覆盖保留率最高**
- **(i) 纯 gate**: 翻译期栈深 gate 独立实施（不垫栈）——正确性达标但真实产物含 prologue push 函数全保原生, x86 虚拟化率塌方, "生产可用"含金量重伤; 作为 (v) 的兜底层保留
- **(ii) esp 全量 rebase**（VM 独立栈区）: 牵 rip-RVA/ExitNative 坐标/442 规则重写=XL; 仅当 (v) 实测被否才评论提议
- guard 深度 N 的预算依据: X0 语料 x86 prologue push 深度分布（可实测 wvmpTest 103 kernel + SysWOW 抽样, 给 p50/p99/max）

## §B 任务

1. **B.1 覆盖率影响实测（先行, 报告第一页）**: 对 wvmpTest x86 103 kernel + forkface 池样本逐函数统计区域 push 净深分布（静态: lifter 面 walk 即可）——给数: 纯 gate (i) 下 x86 虚拟化存活率 vs guard N∈{32,64,128} dword 下存活率（= 103-kernel 与 X0 域语料两口径）; **此表=D1 路线的事实基础**
2. **B.2 主修复（D1 路线实施）**: stub_gen x86 序言 guard 垫栈（尺寸单一来源+派生+static_assert, kStubPushBytes 家族纪律）+ 翻译期栈深 gate（translator: 区域内 push/pop 净值 walk, 超 guard 预算→整函数 C1 gate 保原生; **x64 面同 gate 但默认 guard 维持现窗零行为变——若 x64 有新增 gate 即披露 delta**）+ ExitNative/callgate 坐标联动核对（446 ABI 锚 0x38/0x258 系若因 guard 位移=三处同步+电池联动）
3. **B.3 跳表匹配器 S32**: :403/:457 附近两点 sz 判据按 arch 参数化（sz_step_ 同机制）——**jmptbl 样本 3 正形从 gate 负例翻正为真虚拟化**（翻转断言+旧 gate 行为对账）; 2 负例形（无防御/出区）维持 gate
4. **B.4 REG-REG 位测试族**: lifter `X86_INS_XADD/BTS/BTR/BTC` 收 REG-REG 形（src2 载体域对账——kLockXadd/kLockBts 系现有值域 14..18/22..28 内**禁开新值**, dst=Reg 形 translator 折叠面按 419/432 单 VmOp native 直执行先例; 运行时 x86 handler 复用度实测——X3b 已备 mem 形 Bts/Xadd, REG-REG 若需 dst=Reg 支持=最小 diff）; S16 面维持 gate 口径核对
5. **B.5 回归网**: mul64hi 崩溃反证双侧（修复前 main CLI 崩 rc=0xC0000005 复跑 + 修复后分支 CLI kernel 全绿双跑 diff 0）+ wvmpTest x86 **103 kernel 全量双跑 diff-0 达成**（450 遗留 1 的销账单; 13 gate 位点分布翻正表——guard 后多少转虚拟化, 这是修复价值的直接读数）+ 新样本入池（mul64hi 类真实 push 形 + guard 超限 gate 负例形, 池 11→13±, multiseed 精确数自算披露）+ 电池联动（push 落 guard 区真执行断言 / 栈深 walk 单测正反例）
6. **B.6 x64 零扰动铁证**: dump `ffd47289` 逐字节恒等（x64 stub 若加 gate 不改码体=可保恒等; 若必须动=独立 commit + 433 逐 handler 对账口径披露 delta）+ multiseed 305 全绿 + wvmpTest x64 双跑 diff 0 + ctest 16/16 + dump 门 60 项

## §C 决策点（项目主已拍板）

- **D1 路线 = (v) guard 垫栈 + (i) 栈深 gate 兜底**（✅, B.1 数据若推翻——guard 存活率仍 <60%——停手评论提议 (ii) 评估, 别硬堆 guard 深度掩盖设计问题）
- **D2 guard 深度预算**（✅）: N 由 B.1 p99 定+固定余量, **单一来源派生+static_assert**; guard 全吃后 guest 仍可自由下探（真栈之下）=行为保真, 穿 ctx 区才 gate——精确边界报告画坐标图
- **D3 冻结面**: kCtxSize 0x1C8 / runtime.hpp / vm_op **97 不动**（REG-REG 走折条/native 直执行, 禁新 VmOp）/ 载体域 0..28 禁新值（dst=Reg 判别若需新载体=停手评论）/ 跳表 128 扩容红线不触; 解禁清单: translator/stub_gen/asmgen（限坐标联动）/lifter（限 B.4 四 case）+ 测试/脚本/文档
- **D4 双 arch 对称纪律**: 栈深 gate 逻辑 x64/x86 共享（x64 现网未被 MSVC 产物命中≠没有该雷——手写/第三方 x64 同样收 gate 保护, **这是第 5 个现网盲区预防**）; 若 x64 出现新增 gate 命中=披露（wvmpTest x64 应仍 0 gate）
- **D5 honest disclosure 优先**: guard 方案救不了的形态（深递归×区域 push 组合/call 窗外）逐项列明, 宁窄勿宽; 崩溃修复类验收=反证双侧必贴
- **D6 电池当场炸当场修照贴**（444/445/446 模式, 本单大概率命中: guard 位移×既有 36 例联动）

## §D 验收标准
1. **wvmpTest x86 全量双跑 diff-0 达成**（本单总验收: 103 kernel native/packed 逐 kernel 一致, 含 mul64hi 绿; gate 分布翻正表在报告）
2. 反证双侧: 修复前 main CLI 崩复现（我亲手复验）+ 修复后通
3. B.1 覆盖率实测表（(i) vs (v)@N 存活率, 103-kernel+X0 两口径）
4. jmptbl 3 正形翻正 + bitops 池样本 REG-REG 扩展形真虚拟化（或如实披露维持面）
5. multiseed 全绿（305 + 新样本精确数自算披露）+ 六件套 B.6 + 电池 36+全绿（新增 guard/栈深用例）
6. 冻结契约（D3）+ 硬条款十九连: 命名分支 `mit-x5b-stackfix` + 分批 commit + main 未动 + 零脏 + 切回 main + **worktree 自拆 + .deps 禁 junction 共享**（450 新坑: 主仓 .deps 的 subbuild CMakeCache 被 worktree 路径污染致 FetchContent 炸——本单 worktree 用独立 .deps 或完成后自证主仓 `grep -r wvmp-x .deps/*/CMakeCache.txt` 零命中）+ ≥30 分钟对账

## §E 纪律
worktree 隔离 + 分批 commit（B.1/B.2/B.3/B.4 各批, 每批全绿再推）/ wvmpTest 禁覆写 x64 面（x86 rebuild 产物用 X5 版基线, 若改 wvmpTest 源码报告点名）/ **#33 主战场**: A.1 保存区坐标、A.3 guard 可行性（x64 kCalleeWindow 先例的真实可平移度实测）、:403/:457 点位重钉、REG-REG handler 复用度——全部实测兜底 / 卡壳 ≥3h 评论。

## §F known compromise 预判
1. guard 垫栈吃真实栈底邻近区（深递归×大 prologue 组合仍可能触界）——B.2 边界图 + gate 兜底如实划界
2. 栈深 gate=保守静态 walk（动态循环内 push 不配平形按最坏预算）——宁窄勿宽即打折, 触发形态入册
3. REG-REG bts 系在 x86 客户语料本低频（X0: 位测试族近零）——本单收它是补齐 lifter 关门动作, 非客户驱动; 若 handler 复用评估超预期（>半天）可降级挂账, B.4 报告裁决

时间预算: ~2 天。本单销账 = 多目标平台真正意义上"生产可用"（450 宣告的正确性尾巴割除）。== MIT-X5b 派活单完 ==
