# WVmp MIT-C 派活单 — lifter + translator + asmgen 加整数除法族 div/idiv + 符号扩展 cdq/cdqe/cqo 支持（wvmpTest 真实函数覆盖率主攻单）

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: MIT-393/403 (callgate 修复, 100/100 基线) + MIT-379 (wvmpTest 验收流, 13/14 内核保持原地的病例库) + GAPS.md C2 剩余/C3 + MIT-313 收口裁定 (CDQE/MOVSXD 分裂枚举教训)
> 模板: 沿用 SSE 五连单六件套模式 + MIT-B2 派生化纪律

---

## §A Pre-dispatch baseline (项目主 fresh verify, 2026-08-29 上午, main 43b3827 实测 CONFIRMED)

| 项 | 实测值 |
|---|---|
| main HEAD | `43b3827` (MIT-B2 done) |
| build / ctest | rc=0 / 16/16 |
| **multiseed REQUIRE_REAL=1** | **100 runs = 100 PASS (新基线, 噪声地板已清零)** |
| wvmpTest protect 拦截画像 (08-28 实测, kernels.toml 全量) | 未支持 **cdqe ×10 / cdq ×3 / div ×3** + 区域外跳转 ×13; 当前真虚拟化覆盖 **1/14 内核** (wv_sha256_h0 被 cdqe 8 条拦于 0xd9d8) |
| lifter 白名单 | `X86_INS_CDQE`/`CQO`/`CDQ`/`DIV`/`IDIV` **0 case**; `X86_INS_MOVSXD` 有 (x86_translate.cpp:1358) |
| IR Op / VmOp | 整数 `Div`/`Idiv`/`Cdq`/`Cdqe` **均无** (注意 Op::Divss 是 SSE 单精度除, 勿混淆勿复用) |
| **vendored capstone 枚举陷阱** | `.deps/capstone-src/include/capstone/x86.h`: CDQE=452 / CQO=511 / CDQ=451 / DIV=535 / IDIV=613 / MOVSXD=880 **分裂枚举** (pip capstone 5.x 会把 48 63 C0 合并报 movsxd——以 vendored 为准, 两枚举都要 case) |
| 指令编码 (capstone 实证) | cdq `99` / cqo `48 99` / div r32 `F7 /6` / idiv `F7 /7` / r64 前缀 `48`; **div/idiv 有内存形式** (`F7 31` = div dword[rcx]) |
| 现成模板 | `build_imul`/`build_mul` (双结果槽 rax+rdx 写回先例, 1568 行注释明示对齐 imul/adc/mul); `build_ucomis_flags` (native 直通形态) |
| 环境 | multiseed 脚本 CLI 双探测已落地 (B.3), 镜像 hack 退役; cdb 可用 `C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe` |

## §B 任务 (六件套, 沿用 SSE 模板)

**改动 1 — lifter** `passes/lifter/src/x86_translate.cpp`:
- `case X86_INS_CDQE` → **lifter 内归一**到现有 `translate_movsxd` (语义 = movsxd rax,eax, dst 固定 RAX/src 固定 EAX, **不加新 Op**)
- `case X86_INS_CQO` → 与 CDQ 共用新 Op::Cdq
- `case X86_INS_CDQ` → 新 `translate_cdq` (Op::Cdq, 无操作数, 隐式 rax→rdx:扩展)
- `case X86_INS_DIV` / `X86_INS_IDIV` → `translate_div`/`translate_idiv` (支持 REG + MEM 形式, 操作数宽度 S16/S32/S64 依 REX; 隐式 dividend = rdx:rax **不需 lifter 表达**, VM handler 内部处理)

**改动 2 — IR** `ir/include/wvmp/ir/insn.hpp`: Op 加 `Cdq, Div, Idiv` — append-only 在 `Ucomisd` 之后、`};` 之内 (MIT-375 v2 教训自查: 提交前 grep 验证闭合) + `ir/src/insn.cpp` to_string 3 case

**改动 3 — VmOp** `vm/regvm/isa/.../vm_op.hpp`: 同 3 值 append-only (`Ucomisd` 后), kVmOpMax → Idiv (=79, <128 static_assert 自动守) + to_string 3 case

**改动 4 — translator** `vm/regvm/translator/src/translator.cpp`: 3 个 emit 函数 (Cdq 零操作数; Div/Idiv 单源操作数含 LoadRva 分支——rip 形式的除数走既有 LoadRva 通路)

**改动 5 — asmgen** `vm/regvm/runtime/src/asmgen.cpp`:
- `build_cdq`: native cdq/cdq 模板 (按 size 选 66 99 / 99 / 48 99), 读 rax 槽 → native → 写 rdx 槽; flags 按 Intel SDM **CDQ 不影响 flags** (零 flags 写回)
- `build_div`/`build_idiv`: 对齐 build_imul/build_mul 双结果槽模式 — 读 rax+rdx 槽拼 rdx:rax + 读 src → native div/idiv → **商写 rax 槽 + 余数写 rdx 槽**; flags 按 Intel **undefined**, 处置方式**照抄 build_imul 现状** (报告注明对齐行号)
- **除零/商溢出 = 真 #DE**: handler 内 native 直通执行, rax=0x78563412 式语义自动与 native 一致 (崩溃行为与未加壳一致即正确, 不额外拦); 样本必须含一组"除零崩溃形态 native==protected 同 rc"验证 (见 §E.5)
- 全部立即数/偏移经 `imm()` + 尺寸类常量派生 (MIT-B2 纪律, 禁第二份拷贝)
- handlers 表注册 3 条

**改动 6 — E2E 样本**:
- 新增 `passes/marker_scan/tests/div_sample_{asm.asm,main.cpp}`: 区域内覆盖 `cdq;div` (32/64 位) + `idiv` (负被除数, 验证截断向零) + 商/余双槽回读 + rip 形式除数搭车覆盖; 主函数打印全部结果
- 新增影子样本 `divss` 式 **`div_flags_readback_sample`** (对齐 #79 三件套: ctx.xmm 无关, 读回 rax/rdx 双槽 + flags 状态)
- CMakeLists 注册 2 target; **multiseed_e2e.sh samples 追加 2 项 (100→110 runs)**
- 另把**已存在但从未注册**的 `wvmp_rip_relative_sample` + `wvmp_rip_relative_simple_sample` 也注册进 multiseed (2 样本已在 CMakeLists 躺着, 纯卫生) → 若它们 FAIL, 如实报告 (rip 写路径 StorRva 缺失属 C4 后续单, 本单不扩面)

**改动 7 — wvmpTest 实测 (本单价值证明, 只跑不改)**:
用新 CLI 对 wvmpTest 重跑 kernels.toml protect: 未支持指令 cdqe/cdq/div 命中应**从 16 → 0**; 记录新真虚拟化覆盖数 (基线 1/14, 预期显著提升; 若仍被"区域外跳转"拦属正常, 数字如实写)。wvmpTest 产物不 commit。

**不改**: 冻结契约同前 (runtime.hpp kCtxSize 派生面已闭环, 除 §B.5 需要外不动); StorRva/C4 写路径; 区域外跳转分段 (C1 native-gate 大工程); AVX/x87; 既有样本。

## §C 决策点 (项目主已拍板 2026-08-29)

- **D1. cdqe 形态** (✅ D1.1): lifter 归一到 Movsxd, 不加 Op::Cdqe — 最小面
- **D2. 除零/溢出语义** (✅ D2.1): native 直通 = #DE 行为与未加壳一致, 不做 VM 内拦截; 样本含除零对拍
- **D3. idiv 余数符号** (✅ D3.1): 截断向零 (Intel 语义), 样本必须含负数组合 (如 -7/2 → q=-3 r=-1) 防实现取 floor
- **D4. flags undefined** (✅ D4.1): 照抄 build_imul 现有处置, 不发明新语义; 影子样本只读 rax/rdx 双槽
- **D5. §A 假设错时** (✅ 沿 #33): 诚实披露 + 改方向, 实测优先

## §D 验收标准 (9 项)

1. build rc=0, 0 error (自有码)
2. ctest 16/16
3. **multiseed REQUIRE_REAL=1: 22 样本 × 5 seeds = 110 runs 全绿 (基线 100 + 新 2 + rip 2); 既有 100 项零退化**
4. div 主样本: 真虚拟化 (stub 数>0) + byte-exact; 商/余/负数组合值正确
5. 除零对拍: native rc == packed rc (同为 0xC0000094/#DE 形态)
6. capstone 回读: div/idiv/cdq handler 机器码含真 `f7 /6` `f7 /7` `99` 直通指令, 贴 diff
7. **wvmpTest protect 日志: cdqe/cdq/div 命中 = 0** + 新覆盖数如实记录
8. 冻结契约: commit 仅含 §B 文件集; 分支 `mit-c-intdiv` 未 push 未 merge
9. 报告: 每条数字带实测输出粘贴 (自报 ≠ 完成, #29); **必跑 ≥ 30 分钟** (multiseed 一轮 ~17 分钟, 秒完即 #38 红线); 完工 **git checkout main** 再交报告 (B2 遗留卫生)

## §E 报告模板

沿用 MIT-376/403 报告格式 (改动清单 / 验证 9 项逐条 / capstone 回读 / 决策与披露 / 遗留)。

## §F known compromise

- 整数 div/idiv **不含 8/16 位 AL/AX 形式** (F6/F7 无 REX 的字节形式) 若样本/日志未遇到可留后续; §A 未支持清单里 wvmpTest 无此形态 — agent 实测若发现 lifter 收到 byte 形式, skip note 保持现状即正确
- rip 形式除数经 LoadRva 属搭车路径, StorRva (全局写) 不在本单
- wvmpTest 覆盖提升幅度受区域外跳转制约 (13 处), 本单不解决跳转分段, 数字如实报告

## §G 沉淀预期

- 隐式寄存器操作数族 (rax/rdx 双槽协议) 首次完整落地 → 后续 shld/shrd/rep movsx 类派单的模板
- CDQE/MOVSXD 分裂枚举在 lifter 层的显式双 case 记录 → pitfall 候选
- rip_relative 2 样本注册 = C4 读路径首获 multiseed 覆盖 (无论 PASS/FAIL 都是 C4 收口情报)

## §H close-out (项目主侧)

报告 → 项目主独立 fresh verify (§D 1-7) → `.multica/mit-c-ruling.md` → done → ff-merge → **基线刷新 110/110** → 视 wvmpTest 覆盖数字决定下一棒 (C4-StorRva 写路径 vs C1 跳转分段)。

== 派活单完 ==
