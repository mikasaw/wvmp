# WVmp MIT-X5c 派活单 — ExitNative x86 上界接线修复：backend 单点（pdata_empty 分支补 ub）+ 末区 .text 兜底专项反证（17 处全翻正, stubs 0→10）

> 派活单生成: 2026-09-02, 接手人 (项目主)
> 关联: 多目标平台 X5c（452 X5cr 侦察裁定的 F1 全量实施——D1 拍板=**F1 + 末区兜底验收专项**）| main `9647a13`（452 合入后, 基线 63 样本 315/315, x64 dump 底稿 `ffd47289`, 二十连）| 素材 = `.multica/mit-X5cr-triage.md`（163 行, 动手前通读, §3.1 判据行+§4 F1 方案+§5 泛化）+ 452 裁定 §4 | 后续: 交报后 x86 战役尾巴再清一层; X3d(SSE32)/410(M3) 拍板接排
> 交付形态: **main 之外的命名分支 `mit-x5c-exitbound`**（硬条款二十一连, 违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main 9647a13, 2026-09-02 19:0x)

### A.1 机制（452 裁定的三点亲证, 你复测兜底）
- 唯一判据点: `vm/regvm/backend/src/regvm_backend.cpp` 上界 lambda（452 时点 :98 附近, 行号会漂实测重钉）: `pe==nullptr || pe->pdata_empty → std::nullopt`——x86 PE32 Exception Dir=0（我亲读 DataDirectory[3] RVA=0x0/count=0）→ 恒 nullopt → translator 判定链条件 D 恒败 → `:1671 skip "跳转目标块未找到"` ×17
- translator 判定链本体（`:1644-1669`）x64 复验 17/17 emit=True——**链无 bug, 只缺上界供给**; x86 runtime `build_x86_exitnative`（asmgen:5299, X3c）就绪; 回跳 BFS 0/17 无 blocked 干扰

### A.2 修复点位素材（triage §4 F1 原文）
ub = `min{fr.begin_rva > fn.begin_rva}`（下一区域 begin, 来自 ctx.functions 排序——**注意 begin 相同/嵌套区域病态形的行为定义**）; 无后继区域 → 回退 **.text 节尾**（PeImage sections 字段实读——节尾口径: VirtualAddress+VirtualSize 对齐面你核）。x64 路径: 恒有 .pdata 走原分支**字节不动**（D2）。

### A.3 预期读数（=验收基线, 452 报告 §4 原文）
wvmpTest x86（main CLI 现状 stubs=0 "没有任何函数被虚拟化"）: **en 0→17 / stubs→10 / jtbn 17→0 / 总 skip 面 30→13**（残 13 = push-imm 型 2（aa18/b678 所在函数）+ 间接 jmp 1（aebb）+ stack-depth 1（mul64hi/b38d）+ 其余对账）——你的 13 处分布必须逐项归因, 与我这表失配即 #33 点名。x86 池 13 样本 multiseed 315 应**零 delta**（无越区跳转形态）——这本身是零扰动证据, 若有任何样本 stub 数变化=异常必查。

## §B 任务

1. **B.1 F1 实施**: 上界 lambda pdata_empty 分支补下一区域 begin + .text 节尾回退——**单点位改动**; 函数内注释引用 452 triage 坐标; `x64 路径恒有 .pdata` 事实写成注释+条件序不变（pdata 分支在前原样）
2. **B.2 末区 .text 兜底专项反证（D1 核心条款, 不许躲）**: ① 实测 wvmpTest x86 末区 0xC972 处修复后行为（ub=节尾 → 目标越节尾时判定链走向: ExitNative or skip? 逐条件走查给读数）② **新样本 `x86_tailexit_sample`**（446 MASM 链）: 区域=函数且其后无区域、含 跳向 .text 尾后 gap 的跳转（覆盖"ub 内可 ExitNative"与"目标出 .text 节尾→C1 gate"双形）→ 入池; ③ 兜底语义裁决表: 末区+目标在节尾内=放行 / 目标出节尾=gate——报告明写
3. **B.3 病态形防护**: 嵌套/重叠区域 begin 序（min{begin>fn.begin} 定义域）、区域表空（全 skip 函数? 现状行为对账）、`pe==nullptr` 分支维持 nullopt（保守正确）——各给单测
4. **B.4 回归网**: ① wvmpTest x86 **A.3 读数表逐项对账** + 双跑 diff 0（103 kernel native/packed——新翻正的 10 stubs 函数含 ExitNative 真执行, 这面首次全量真跑）② x64 wvmpTest 14/17/0 不变 ③ multiseed 315+5（新样本）全绿 ④ ctest 16/16（+B.3 单测）⑤ 电池 37 不退（ExitNative x86 用例已有, 若 B.2 语义触发新用例加行）⑥ 三件套 dump 门/静态扫描
5. **B.5 x64 恒等铁证**: dump `ffd47289`/161,861B 逐字节（B.1 若动 x64 码体=违令）+ x64 全链零 delta 声明清单
6. **B.6 文档**: GAPS（407 面 x86 翻正注记 + X5cr triage 结论入册 + gate 分布更新: 30→13 残面）+ STATUS 里程碑行 + 支持矩阵 x86 行覆盖读数刷新（103-kernel 真虚拟化率数字）

## §C 决策点（项目主已拍板）

- **D1 = F1 全量含 .text 兜底 + 末区专项反证**（✅ 本单灵魂——452 §4 我注的倾向, 兜底正确性被测试钉死, 不许用 F1-lite 躲末区）
- **D2 x64 零行为变**（✅）: 条件序 pdata 分支原样在前; dump 恒等机器证明
- **D3 冻结面**: translator.cpp **不改**（链本体无 bug——若实测发现必须动链=停手评论, 这推翻 452 结论属大事）; 解禁清单=regvm_backend.cpp（主点）+ 样本/CMake/multiseed/tests/docs; kVmOpMax=97/载体域/协议面全维持
- **D4 ExitNative x86 语义维持 407 设计**: 单向退出不可回跳、区域粒度、native_sp 协议——本单只供上界, 不动语义
- **D5 13 残面归因铁律**: A.3 表逐项对上; 归因不明的 skip 计数=不合格（452 二十连的配对法可复用）

## §D 验收标准
1. A.3 读数表逐项亲验达成（en=17/stubs=10/jtbn=0/skip 30→13 归因闭合）——项目主将亲手复跑
2. B.2 末区专项: 0xC972 走查读数 + tailexit 样本双形断言入池 + 兜底语义裁决表
3. B.4 六件套 + B.5 x64 dump 恒等（我亲手双 CLI 复跑）
4. 冻结契约 D3（translator 零 diff 为预期态）
5. 硬条款二十一连: 命名分支 + 分批 commit + main 未动 + 零脏 + 切回 main + worktree 自拆 + **.deps 独立/主仓零命中**（451 纪律延续）+ ff-safe + ≥30 分钟对账

## §E 纪律
worktree 隔离（独立 .deps——450 junction 污染坑条款在案）/ 分批 commit（B.1+B.2 样本 / B.3 / B.6 各批, 每批全绿）/ wvmpTest x86 产物 X5 版基线**只读**, protect 输出落 %TEMP% / **#33 主战场**: A.1 lambda 行号、A.3 读数表（452 二手数, 你复跑为准失配点名）、节尾对齐口径、13 残面逐项 / 电池或 E2E 当场炸当场修照贴 / 卡壳 ≥2h 评论。

## §F known compromise 预判
1. 下一区域 begin 作 ub = 保守上界（真实函数体可能更短）——ExitNative 语义本就"区域外即退出", ub 落在下一区域首字节=不吞真函数体的最大安全值; 报告注一句
2. .text 节尾兜底对含 data-in-text/对齐填充的产物——tailexit 样本双形即测此界, 若节尾语义有坑如实收窄（但须回项目主, 不许私改 F1-lite）
3. multiseed 池 +1（tailexit）=320±1 精确数自算披露

时间预算: ~1 天（S 级单点+反证面为主）。交报后 x86 战役剩余 gate 面 = push-imm/间接 jmp/stack-depth 三类（450/451 已裁各归其位）+ SSE32(X3d 待拍)。== MIT-X5c 派活单完 ==
