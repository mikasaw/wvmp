# WVmp MIT-X4 派活单 — x86 全管道打通：stub_gen cdecl 重写 + S64 tag 改形（点位×5）+ D1 硬拒解禁 + x86 E2E 首批入池

> 派活单生成: 2026-09-01, 接手人 (项目主)
> 关联: 多目标平台 X4（**x86 战役"从 0 到 1"一棒**: PE32 输入→全 pass 链→packed x86 exe→WOW64 真执行, 本单后 main 即具备 x86 生产能力）| main `e20b383`（445 X3c 合入后, 基线 50 样本 250/250, x64 dump 底稿 sha `ffd47289`/161,861B, 十六连）| 素材 = `docs/GAPS.md:879-893`（X3c 交接注记: S64 点位×5 + stub ABI 锚×4, 动手前逐点位重测行号——444/445 两单后 translator 已漂移）| 后续: X5 = x86 样本池扩量 + 收口宣告（解禁不再等 X5, 见 D1）
> 交付形态: **main 之外的命名分支 `mit-x4-stub-e2e`**（硬条款十七连, 违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main e20b383, 2026-09-01 22:4x)

### A.1 现网
build 0 / ctest 16/16 / multiseed 250/250 / wvmpTest 14 stubs 双跑 diff 0 / x86 电池 35 例全绿（交叉链独立可重建）/ dump 门 60 项；kVmOpMax=97（**本单禁新 VmOp**——Push/Pop/CallGate/Ret 协议面 X3a-X3c 已全备）。

### A.2 stub_gen 现面（`passes/stub_link/src/stub_gen.cpp`, 208 行全文先通读）
- **Win64 ABI 假设五处**（`:43-122` 实测锚）: `kStubPushBytes = kCalleeSavedIdx.size()*8`（x64 8 个 callee-saved→0x40; **x86 = ebx/ebp/esi/edi 4×4B=0x10, 派生式必须 arch 参数化+mod-16 static_assert**——MIT-B2 尺寸单一来源纪律）; `:62-64` ir::Reg→rcx/rdx 名表（x86=eax..edi 无 r8+）; `:81` 0x208 链（8*push+kCtxSize——x86 重算）; `:117 mov rcx, rsp`（x86 cdecl = push ctx 或 eax 载入, 对齐 runtime_x86 entry 已实证形: **ctx 指针经 [esp+0x14] 读栈参——443 电池 entry 亲验, stub 侧按此对接**）; `:122` 易失回写表
- 出口槽消费 `:34-35`: 双基准换算纪律在位; x86 = **kX86ExitSlotDepth 消费面**（GAPS 锚①: [ns−0x258]）
- stub 目标地址: x64 RVA+image_base 立即数 → x86 同式但 imm32（407 v2 RVA/VA 铁律沿用: 裸 RVA 进槽=野跳）

### A.3 S64 tag 改形（444 挂账, 交接注记点位①-⑤）
① translate_push/pop rsp 步进; ② emit_address 双形全链; ③ emit_imm64_split; ④ LeaRva 通路; ⑤ G3 串微程序步进。**方向（注记原文）**: 栈步进改 VmOp::Push/Pop 单 op（X3b 已备 4B handler）或 sz 参数化; 地址算术改 S32 步进 tag。**D2 铁约束: x64 路径维持现形逐字节不动**（x64 下 S64=native 正确宽度本无 bug——改形纯为 x86 3 路链不折 no-op; 改后 x64 dump `ffd47289` 恒等是机器证明项）。行号必重测（注记坐标=445 时点, 445 动过 translate_call 邻域）。

### A.4 管线其余面 x86 就绪度（各单遗产清单）
marker_scan 双段 magic ✓（437, 构建期断言守卫在位）/ lifter arch 分叉 ✓（414 地基+X1b+442/445: pointer_size、SEH gate、call [mem] 开口）/ translator ✓（442/444/445）/ runtime x86 ✓（X3a/b/c: 60 handler+真执行实证）/ virtualize 层 arch 透传——**本单实读核**（stub 尺寸/entry 写回/passes 链参数）/ pe_loader 解析 ✓ 硬拒在位（`:66-71` 实测文案）/ **pe_writer x86 首碰面**: 节对齐/entry RVA/段特征/可选头 32 位形——先读现码评估, 缺口大即 D6 停手线。

## §B 任务

1. **B.1 stub_gen x86 cdecl 重写**: arch 参数化（HostArch 或等价注入通道——经 stub_link pass 的 arch 字段, 414 基建）+ x86 序言/终态链（4 callee-saved push、ctx 经栈参 [esp+0x14]、kStubPushBytes x86 派生 0x10+static_assert、ExitNative 消费 kX86ExitSlotDepth、HALT 回写表 eax..edi 形、ret 32 位）+ **callgate 参数窗**（交接锚④: x86 cdecl 栈参数预置=build_callgate_x86 与 stub 两处同步, 445 D2"不特化"留待本单落）
2. **B.2 S64 tag 改形点位×5**: 逐点位 arch 分叉（x64 现形零动）; 与 x86 电池联动（改形后 S64 防御出口回归防护=电池加断言 or 新用例; 3 路链不再折 no-op 的正反证据）
3. **B.3 D1 解禁（本单拍板落地）**: pe_loader x86 通行——`auto+x86`/`x86+x86` 双形放行（mismatch 硬拒维持原样）; 硬拒文案翻正+GAPS C4/STATUS 行同步; lifter/translator 未支持形在 x86 真管道下全部走既有 gate（**x87=R-SSE-only 定稿面亲验**: x87 指令样本在 x86 管道=整函数 gate 原生, 落负例区）
4. **B.4 x86 E2E 首批（本单灵魂）**: 新 x86 marker 样本 **3 个族级**（MASM `/MACHINE:X86` 构建链 437 已备）: ① 整数+控制流（forkface-x86 移植形: leave/串/S16/cwde/call reg/call [mem]/ret imm）② SSE 面（movdqa/movdqu/movaps 折叠族 x86 形）③ 混合+cdecl callgate 参数窗。每样本: protect → **machine=0x14C 断言 + stub 计数断言 + WOW64 native/packed byte-exact**; multiseed `x86_samples=()` **首次填池**（442 预铺面启用, 3 样本×5=15 → 基线 250→**265**）
5. **B.5 pe_writer/loader 联动**: 32 位可选头写回/节表/entry/对齐实测面（A.4 评估结论落地）; reloc/ASLR 口径=**对齐 x64 现网事实**（x64 仅 ImageBase 声明不发布 reloc——x64 实测结论直读 pe_writer:39-42 注释; x86 同口径文档化, 不扩面）
6. **B.6 x64 零扰动铁证（最高优先机器证明）**: ① x64 asm_dump `ffd47289`/161,861B **逐字节恒等**（B.1/B.2/B.3 全改动不得动 x64 路径）② multiseed 既有 250 全绿 + 新 15 = **265/265** ③ wvmpTest 双跑 diff 0 ④ ctest 16/16 ⑤ 电池 35+ 不退 ⑥ dump 门 PASS。
7. **B.7 文档**: GAPS（D1 行翻正/C5 收口/x86 全管道支持矩阵行——x87 R-SSE-only 定稿入册）+ STATUS 里程碑（"x86 生产可用·样本池首批"）+ X5 交接注记（样本池扩量优先级+已知 gate 面清单+跳表余量现状 30）

## §C 决策点（项目主已拍板）

- **D1 解禁=本单落地**（✅ 变更既定计划）: X4 后 main 即 x86 生产可用; X5 职责=池扩量+回归加固+阶段宣告。**代价**: 本单风险面=全管道首通, A.4 评估缺口大时按 D6 停手不许硬补
- **D2 x64 恒等铁约束**（✅）: dump `ffd47289` 逐字节——B.2 改形=arch 分叉不是统一重构; 若任何方案迫使 x64 码体动=停手评论（445 先例: 唯一合法 delta 须裁定背书）
- **D3 冻结面维持**: kCtxSize 0x1C8（x86 regs 8B 槽零扩展=444 既定设计）/ vm_op 97 / runtime.hpp 出口协议（kExitSlotDepth x64 式不动, x86 新常量走 runtime_x86.hpp 派生单一来源）/ 载体域 0..28 / markers / SDK。**解禁清单**: stub_gen.cpp/stub_link pass（主角）+ translator.cpp（限 B.2 五点）+ pe_loader（B.3 文案与判定）+ pe_writer（B.5 实测联动）+ tests/scripts/docs
- **D4 样本纪律**: x86 样本 native 全绿先（428 教训——32 位栈越界写形态）再入 multiseed; REQUIRE_REAL=1 硬项; 每样本 ≥1 真可虚拟化函数（407 池纪律）
- **D5 电池联动**: B.2 改形后 x86 电池必须加"rsp 步进真生效"正反用例（错形样本 esp 不推进=S64 no-op 复辟探测器）——444"静默空转"挂账的终验就在这一条
- **D6 E2E 卡点红线**: 全管道首通必踩新面（loader 解析细节/pe_writer 布局/reloc/WOW64 加载差异）——**单点卡壳 ≥3 小时→停手评论**披露点位+已排除项+建议拆法, 别私扩 pe_writer/别硬凑样本绕开真缺口。本单允许"3 样本 2 通 1 卡"式部分交付（卡的如实标注+负例区钉住）

## §D 验收标准
1. §B.6 六件套全绿（x64 dump 恒等 = 第一机器证明项）
2. **x86 E2E 实证（项目主将亲手复跑）**: 新 CLI × x86 样本 → packed PE32（dumpbin machine=0x14C）→ WOW64 双跑 byte-exact, 3 样本逐个; multiseed 265/265（含 x86 池 15）
3. B.1 stub 反证链: x86 stub 生成码 dumpbin/capstone 反汇编入报告（序言/ctx 传递/终态/ExitNative 消费点逐段对照 runtime entry 实证形）
4. B.2 每点位独立 commit + D5 电池正反用例在位
5. B.3 硬拒四象限回归: x64 声明+x86 目标仍拒 / mismatch 文案在位; auto+x86 放行后 x64 全链不受扰
6. 冻结契约（D3 解禁清单外零 diff）; kVmOpMax=97 不动
7. 硬条款: 命名分支 `mit-x4-stub-e2e` + main 未动 + tracked 零脏 + 切回 main + worktree 自拆 + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 + 分批 commit（B.2 五点位/B.1/B.3/B.4 各批, 每批全绿再推）/ wvmpTest 禁覆写 / `cmd /c` 查时间戳 + build log 大小（shell 教训在案）/ **#33 主战场**: A.2/A.3/A.4 全部锚（点位行号/stub 208 行现面/virtualize 透传现状/pe_writer 32 位支持度）实测兜底——**交接注记坐标允许失效, 实测结论不许缺席**; 硬拒文案改动前后亲跑对照 / 电池当场炸当场修实录照贴 / 卡壳 ≥3h 评论（D6 本单从严）。

## §F known compromise 预判
1. x86 管道首通样本面窄（3 族级 vs x64 50 样本）——X5 扩量既定
2. WOW64 真机差异（与真 32 位 OS）——寄存器池同构预期无差, 若遇披露
3. reloc/ASLR x86=同 x64 现口径（ImageBase 声明位）——非本单新债, 文档点名
4. 若 pe_writer 32 位缺口大触发 D6 → 部分交付+拆 X4b 预案（loader/writer 面独立单）

时间预算: ~2-3 天。交报后 X5（样本池扩量+收口宣告+M2.5-X 阶段行）接排——x86 战役主冲线棒。== MIT-X4 派活单完 ==
