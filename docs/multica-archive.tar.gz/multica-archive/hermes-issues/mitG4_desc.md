# WVmp MIT-G4 派活单 — lock 前缀原子指令族 VM 化（Interlocked*/lock RMW，G 线 W3 后继）

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: G 线缺口清单 G4 | main `51c2870` (417/418 链式合并后, 基线 36 样本 **180/180**, wvmpTest 14/14) | 415 (G3) 刚改造的前缀闸体系 | 416 登记的 ml64 部分编码拒汇编坑
> 前置阅读: 本单 → x86_translate.cpp:1430-1444 (415 串指令前缀闸, F0 拒判模板) → translator.cpp:1317-1330 (dst=Mem ALU 折条, **本体通路已在**) → asmgen build_cmpxchg (:3109)/build_xchg (:3106)

---

## §A 基线实测事实 (项目主 fresh verify @ main 51c2870, 2026-08-30 02:0x)

### A.1 现网
- main = `51c2870`; build 0 错 / ctest 16/16 / **multiseed 基线 36 样本 × 5 = 180/180** / wvmpTest 14/14 满贯 + jump-table/ExitNative 17 + 双跑 103/103
- 415/416 后新纪律全部生效在案: 交付命名分支铁律 (417 首单满分) / note 前缀与 backend 过滤白名单对账 / 时间对账 (417 主动追评修正先例)

### A.2 lock 面现状 (三处直读钉死)
| 层 | 实测 | 结论 |
|---|---|---|
| lifter 前缀闸 | `translate_alu` (:133-148) 双操作数含 Mem 全放行; **但通用入口 :1494 域**: 带 `x.prefix[0]!=0` (含 F0) 的指令 → unsupported (415 串指令处理器 :1433-1438 另有字节级 F0 扫描专拒) | **lock 全系在 lifter 入口被拒** → 本单主挂点 |
| translator | **:1322-1330 dst=Mem ALU 已折条** `[m] op src → emit_address→Load(或 LoadRva if rip)→ALU→Store(StoreRva)` — "lock 去前缀后"的 GP 原子 RMW 本体通路**全在** (1637-1643 add/sub/adc/sbb/and/or/xor 白名单齐) | 多数 lock 族 = **仅 lifter 开口子, translator 零改动** |
| handler | build_cmpxchg (:3109)/build_xchg (:3106) 在位; **lock cmpxchg/xchg 与无锁版执行语义单线程 VM 内相同** (见 D1) | 复用候选, 你实测 |

### A.3 真实产物频率先验 (你实测复核, #33 推翻优先)
MSVC x64 对 `Interlocked*` 家族 intrinsic 的产物 (你样本必实测反汇编定形): `InterlockedAdd → lock xadd` (≠ lock add! x86 特有, 返回旧值), `InterlockedExchange → lock xchg`(或 mov+原子语义版, 实测), `InterlockedCompareExchange → lock cmpxchg`, `InterlockedAnd/Or/Xor → lock and/or/xor`。即 **Interlocked 族 = {lock xadd, lock xchg, lock cmpxchg} + GP 本体已有族** —— 项目主已知 `X86_INS_XADD` 不在白名单 (grep x86_translate 零命中, 与 bts 系同缺)。

### A.4 原子性语义边界 (本单最重要的一节, D1 裁决基座)
VM 单线程解释器内 `Load→op→Store` 折条序列**不被自身打断** → VM 线程视角的原子性成立。**但**: 若宿主进程有其他原生线程并发 RMW 同一地址, lock 的硬件原子保证在 VM 折条下**不成立** (撕裂竞态窗口)。
- **D1 裁决 (项目主拍板)**: v1 接受该边界——`lock` 前缀 strip + 本体折条执行, **known compromise 显式登记**: "多线程并发竞争同一受保护全局时原子性不保证" (GAPS 强度表 flags 活跃性同族: 正确性面文档化限制, 非静默; 未来"真原子 handler (lock 前缀原生指令直执行)"另单)
- **替代方案 (你实测若推翻 D1 优先披露)**: `lock add [m],r` 可整条作**单 VmOp 新 handler 直执行原生 lock 指令** (原子性保真), 代价 = 每指令族新 handler (7+ 条) + 编码/flags 对齐——若你实测认为值得, 评论披露再动 (408 D1"编码墙换路"先例, 换路不算失败)

## §B 任务

1. **B.1 lifter 前缀闸开 F0 口**: 通用入口 (:1494 域) `prefix[0]==0xF0` + 白名单三元组 (`mnemonic ∈ {add,and,sub,sbb,or,xor,adc} × mem-dst 形状` + `cmpxchg/xchg` mem 形式 + **新族 xadd/bts/btr/btc 见 B.2**) → 剥离 F0 lift 为本体 IR (ci.size 修正: 剥前缀后 addr/size 记账保持整条, 参照 415 处理方式); 非白名单组合 (lock 后接 reg-dest / 不可锁助记符 / lock+rep 串=undefined) **照旧拒**; **F0 字节级扫描纪律继承** (415 :1433 实证 capstone 吸收 F0 只报 F3——你的白名单判据以字节流为准不轻信 prefix 字段)
2. **B.2 新助记符白名单**: `X86_INS_XADD` (lock xadd 返回旧值语义 = xadd 本体 handler 在位? 实测——无则新 VmOp+handler, append-only #34 + dump/static 双门 + 影子读回 #79); `X86_INS_BTS/BTR/BTC` (+lock 版) 若砍面须 §F 登记理由 (编译器产物频率实测支撑, InterlockedBitTestAndSet 系)
3. **B.3 translator**: dst=Mem 折条复用零改动为期望 (§A.2); **cmpxchg/xchg mem 形式的 dst=Mem 覆盖实测** (:1295 域现有语义下 lock cmpxchg [m] 走不走得通, rip 目标变体一并验); 不通则最小补
4. **B.4 diag note**: `lock-strip @ rva` 级 note (剥前缀执行声明, **与 regvm_backend 过滤白名单对账**——413 纪律, 命中不触发 gate); 拒绝组合保持原 unsupported note
5. **B.5 E2E 样本**: `wvmp_atomic_ops_sample`: ① C++ `InterlockedAdd/And/Or/Xor/Exchange/CompareExchange` 族 (真产物形态, 反汇编表进报告) ② MASM 直写 `lock xadd/lock bts/lock cmpxchg rip 目标` 全谱 + 返回旧值断言 ③ **单线程语义校验**: 结果值/flags/ZF (cmpxchg 后 je 惯用法) ④ 负例: `lock mov [m],r` (不可锁助记符) + `lock nop` + `F0 F3 A4` 已知 #UD 组合 (断言 gate, 不执行——415 教训: 该组合原生即崩, 禁入可执行路径, 仅单测) ⑤ REQUIRE_REAL 主函数真虚拟化; 影子样本: cmpxchg ZF 读回 flags 探针 (若 B.3 涉 flags 面)
6. **B.6 注册+基线**: CMakeLists + multiseed 36→37 (预计 **185/185**), 注释头对齐 (408 尾巴纪律)
7. **B.7 GAPS**: 不支持面 lock 行收口 + **原子性语义边界显式声明** (D1 文本进 GAPS 强度/正确性交界节——参照 x87 R3 节格式: 行为承诺+回归样本钉死+残余登记)

## §C 决策点 (项目主已拍板)

- **D1 strip-and-execute + 边界文档化** (✅ 先验): 见 §A.4; 真原子 handler 替代案你实测后推翻优先
- **D2 族面**: add/and/sub/sbb/or/xor/adc (本体已有) + cmpxchg/xchg (本体已有 handler) + **xadd (InterlockedAdd 真产物, 必做)** + bts 系 (实测频率, 可砍面); lock not/neg (非法编码) 不做
- **D3 66 前缀 lock 变体** (✅): 16 位操作数砍面 (415 同纪律), `lock bts` 的 imm8 形式支持 (MASM 高频)
- **D4 F0 位置容忍**: 多前缀序 (F0 67 …/66 F0 …) 中 67/66 照旧拒 → 仅 `F0` 独前缀 (+REX) 放行, 组合前缀面收窄

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 (+lifter 白名单/负例全谱单测 ≥6, +xadd/translator 形状单测) / **multiseed 185/185**
2. 新样本: protect stub 计数真虚拟化 + 语义值 (返回旧值/ZF/结果) 全对 + 负例 gate 日志逐字节 + `lock-strip @` note 谱; 双跑 byte-exact
3. 实汇编对照表: Interlocked* 源码 → MSVC 产物 (capstone 实证字节) → IR (strip 后) → VmOp 链路, 每子族 ≥1 行
4. 零回踩: 180 既有全绿 + wvmpTest 14/14 (jump-table/ExitNative 17/string-op 面原样) + 双跑 103/103 diff 0
5. 冻结契约: runtime.hpp / kFlagsMask / ir::Op / backend.hpp / callgate 面 (417 刚动过, **禁再触**) / kExitSlotDepth / 跳表容量 (零/少量新 VmOp 预算内)
6. 新 note `lock-strip @` 与 backend :136-137 过滤白名单对账披露 (413 纪律)
7. **硬条款 (417 版)**: 交付落命名分支 (如 `mit-g4-lock-atomic`) + main 未动 + tracked 零脏附输出 + 完工切回 main (无并发时; 占用则 412 例外注记如实披露) + ff-safe
8. ≥30 分钟; 时间报告与 run 起止对账 (412/417 纪律); 数据主张附复跑命令

## §E 纪律

worktree 隔离 / wvmpTest 基线禁覆写 / `cmd /c` / vendored capstone 枚举名实测 (XADD/BTS id, 404 教训) / ml64 对 lock 族编码的接受度实测 (416 发现 D8-DF 部分拒汇编先例 → db 直发兜底) / **#33**: §A.3 intrinsic 产物形态先验全部要反汇编实证, 与实测不符按实测调整白名单, 推翻优先。

## §F known compromise 预判

1. **多线程并发原子性不保证** (D1 核心边界——GAPS 显式声明, 非静默)
2. bts 系若砍面 → 残余登记; 16 位操作数/67 地址宽/组合前缀照旧 gate
3. lock 的 MFENCE 附带语义 (全序) 在 VM 内不建模 (单线程等价, 多线程见 1)
4. xadd 若走新 VmOp: kVmOpMax 86→87+ 预算内, 跳表 128 项余量充足 (416 扩容议题仅 x87 全族才触发)

时间预算: ~半天。== MIT-G4 派活单完 ==
