# [项目主验收裁定] MIT-409 ACCEPT (COMPLETE) — wvmpTest 14/14 历史满贯, 基线刷新 150/150

> 裁定人: 接手人 (项目主) — 2026-08-29 20:3x UTC+8
> 处置: 已 ff-merge main = `c04ca49`, 本单 done。完整裁定: `.multica/mit409-ruling.md`

## 1. 独立复验 (worktree --detach @ c04ca49, 项目主亲测, 非采信自报)

| 项 | 自报 | 实测 |
|---|---|---|
| build / ctest | rc=0 / 16/16 | ✅ / ✅ 16/16 |
| multiseed REQUIRE_REAL=1 | 150/150 (30 样本) | ✅ TOTAL: 150 pass / 0 fail (含新 jmp_table 样本 5/5) |
| wvmpTest 满贯 | 14/14 | ✅ protect 实测 stubs=14 + `jump-table @ 0xDD84 entries=8` (与派单前项目主表体直读实测坐标 0xDD84/8 项逐位吻合) + still-gated markers = 空 |
| duff 功能 | 2 用例 PASS | ✅ kern.duff_copy_matches_memcmp + flow.duff_device_matches_memcpy |
| 双跑 byte-exact | 103/103 | ✅ rc=0×2, 真实 diff 0 行 (test_target sha256 bdbfff91 未漂移, 亲验) |
| 零回踩 | ExitNative 17 站点 | ✅ 17 站点原样, 145 既有 runs 含于 150 全绿 |
| 冻结契约 | 0 触及 | ✅ common/framework/backend/runtime.hpp/ir 零命中; vm_op.hpp diff=0 行 (D2 零新 VmOp 承诺兑现) |
| 硬条款 git 卫生 | CLEAN | ✅ 主工作区 tracked 0 脏 + 在 main + 单分支 2-commit ff-safe — 连续第三单满分 |

## 2. 技术判定

- 比较链实现 (translator.cpp:834) 为纯既有 VmOp 组合 (Mov→LeaRva→Cmp→Jcc(E) 回填块址 ×K + 链尾 Halt 双保险), 保守 gate 底线零让步。
- §E #33 两点实测修正合格: ① 匹配器放宽 lea/idx 载入顺序 (r06 实际与派单 §A 模板序相反, 按实测调整未硬套); ② **lifter build_blocks 死代码保留** — 本单真正的隐藏深度, "只经表可达"的 case body 原被当死代码丢弃, 不修则跳转表永远匹配不上; agent 自己挖出并修好, 附 lifter 单测。
- ExitNative 站点 "17→17" 差异解释采纳: 项目主 §A 预测 18 有误 — 基线 17 中 r06 的 `ja 0xDD76` 本是 gate 前幻影站点, 本单转真实而非新增 (#33 家族: 项目主预测第三次被实测纠正, 解释链完整)。

## 3. known compromise (继承, GAPS C1 节已登记)

1. 仅 MSVC 4B-delta + `cmp K-1; ja` 防御形态; 8B 绝对表 / clang mem 形态 / 无防御 → 照旧 gate。
2. 比较链 O(K), K≤32 预算。
3. 环境事件披露 (工作期间主工作区外部 git reset) — 系项目主例行操作, agent 观察并披露, 合格。

## 4. 基线与里程碑

- **multiseed 基线刷新: 30 样本 × 5 = 150/150** (旧 145 作废)。
- **wvmpTest 覆盖率长征收官: 1/14 → 2/14 (404) → 13/14 (407) → 14/14 (409), still-gated = 0。**
- GAPS 正确性缺口 C1-C4 全部关闭 (含跳转表特化), 转入 M3 保护强度线 (F1 已另单派发)。

## 5. 沉淀 (已入裁定文档)

- "lifter 死代码规则与表可达性冲突"是本单最值钱发现: 未来任何"翻译期不可见但运行时可达"形态 (虚表/回调) 会撞同一堵墙, 本单死代码保留改动是通用前置。
- 受限模板匹配路线 (寄存器/基址一致 + 防御常数推表长 + 全目标∈区) 在真实编译器产物上首次全中。
- 站点账教训: 幻影站点与真实站点混计易误读, 后续 diag 建议分 `exit-native (live)` / `(pre-gate)` 两型标注。
