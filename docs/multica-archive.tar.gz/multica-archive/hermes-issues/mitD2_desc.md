# WVmp MIT-D2 派活单 — translator ExitNative 单向退出（.pdata 上界）+ wvmpTest 真实函数覆盖 2/14 → ≥13/14

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: MIT-405/D1 侦察单 done (裁决 **B' 全行**, 报告 `.multica/mit-D1-triage.md` 147 行, §6 八条素材 = 本单 §A 主体, 项目主已独立复算) + MIT-404 done (main 2f1bcec, 除法族, wvmpTest cdqe/cdq/div 命中清零) + MIT-406/E1 done (main 8a3d510, callgate 4KB callee 窗口 + movaps 对齐, wvmpTest sha256 红灯摘除) + MIT-379 done (wvmpTest 14 内核标记 + 双跑 diff 验收流)
> 前置阅读 (按序): `.multica/mit-D1-triage.md` **全文, 尤其 §2 四问矩阵 / §5 裁决 / §6 素材** → `.multica/mit406-ruling.md` §3 (callgate 窗口现状) → `.hermes/plans/2026-08-29_D-jump-region-plan.md` (B' 决策过程)

---

## §A 基线实测事实 (项目主 fresh verify @ main 8a3d510, 2026-08-29 14:3x)

### A.1 现网状态
- **main = `8a3d510`**; build 0 错; ctest 16/16; **multiseed REQUIRE_REAL=1 基线 = 26 样本 × 5 seeds = 130/130 全绿**
- wvmpTest 现状: **2/14 真虚拟化** (r09 mul64hi + r12 sha256); packed 双跑 103/103 byte-exact (E1 后恢复绿灯)
- 剩余 12 个 marker 被拦画像 (08-28 日志, 404 后): **11 个纯越区跳转病灶 + r06 duff_copy (间接 `jmp rax`, B' 范围外维持 gate)**
- ⚠️ 全部 triage RVA 仅对 sha256 `bdbfff91…` 的 08-28 test_target.exe 有效; 你重建后 **RVA 必漂移**——一切判定用算法重测, 禁止照抄 §A 数字当坐标 (triage §F.4)

### A.2 D1 已实证裁决 (17 条越区跳转全量, 0 抽查, 项目主独立复算 4 项 MATCH)
1. **上界算法 = .pdata 函数真边界** 17/17 完胜 (next-marker-begin 16/17, int3 扫描 13/17——MSVC 紧排布函数间实测 0 字节垫)
2. **0 反例**: 17 条目标可达集 (≤3 层静态 jcc/jmp 边) 均不回跳本区
3. **13/17 目标 == 本区 END-call == 现有 stub resume 点**——这些退出与今天的 HALT 链逐字节等价, 真正新增的只有"动态目标"
4. 栈契约: 17 落点全部 rsp==entry 态 (与 callgate 同一实测契约, E1 刚验证过)

### A.3 代码锚点 (项目主本轮 grep/sed 实测)
| 锚 | 位置 | 事实 |
|---|---|---|
| 越区 gate 行 | `vm/regvm/translator/src/translator.cpp:525` | `return skip(in, "跳转目标块未找到（区域外/未 lift）")` —— **ExitNative 条件 emit 挂点在此** |
| stub 终态跳转 | `passes/stub_link/src/stub_gen.cpp:121` | `jmp <resume_rva>` (静态 rel32) —— **唯一结构改动点**: → `jmp [rsp+EXIT_SLOT]` 间接化 |
| Jcc 复用件 | `asmgen.cpp:965 build_jcc` (:2859 注册) | cond 求值链现成 (triage §6.2: 12/17 站点是 jcc, 需条件退出) |
| VmOp 锚 | `vm_op.hpp:424 起 Cdq, Div, Idiv` | kVmOpMax=79; 新值 append 其后 (#34), +1 → 80 < 128 跳表 |
| callgate 窗口 | asmgen.cpp `kCallgateCalleeWindow = 0x1000` | E1 落地; **ExitNative 写回复用链与此窗口零冲突, 但不得动 step 4-8 语义** |
| pe_loader | 现不解析 .pdata (grep 0 命中) | RUNTIME_FUNCTION 12B/条排序数组, 新增解析 + 二分 |
| lifter 日志 bug | `lifter_core.cpp:159` | `"0x" + std::to_string()` 十进制挂 0x 前缀 —— 顺带修复 (triage §6.8) |

## §B 任务 (按序)

1. **pe_loader**: .pdata → RUNTIME_FUNCTION 表解析 (BeginAddress/EndAddress, 二分查 begin_rva); 无条目/chunk 分片防御性回退 (末区用 section-end; chunk 本语料 0 出现但必须不崩)
2. **translator :525 挂点改造**: 目标 ∈ [end_rva, pdata_end) 且 ≤3 层可达集不回跳本区 → 译出 `VmOp::ExitNative` (aux=target RVA u32; cond_or_size=ir::Cond, 无条件形态固定值); 不满足 → **照旧 skip+gate, 行为与今天逐字节一致**
3. **VmOp::ExitNative + asmgen handler**: 复用 stub HALT 写回链 (rax,rcx,rdx,r8-r11+xmm0-7+add rsp/pop, 一字不动); 命中时把 stub 入口预写的 end_rva 槽覆写为 aux → `jmp [rsp+EXIT_SLOT]`; jcc 形态复用 build_jcc cond 求值 (条件不满足则继续 VM, 满足才退出)
4. **rsp/EFLAGS 契约**: 沿用 entry rsp (ctx+0x120 native_sp, 与 callgate 同基准); EFLAGS 不回写 (triage §6.5 实测落点不消费); 契约写明"退出点未配平 push 属现有 HALT 链同样存在的潜在约束"
5. **diag**: `exit-native @ <rva> -> <target> (<cond>)` note 级每站点一条 (triage §6.7)
6. **E2E 样本** (新, 注册进 multiseed): 正样本含 END-call 等价退出 + 早返回 jcc 退出形态; 反例样本回跳形态 (≤3 层检出 → 照旧 gate) + 超界形态 (→ 照旧 gate)。⚠️ **每个新样本 exe 必须另含 ≥1 个真可虚拟化函数产生 stub, 否则 REQUIRE_REAL=1 直接 FAIL** (§B.3 gate 无真 stub 不算 PASS)
7. **顺带 (非阻断)**: 修 lifter_core:159 日志 bug; deepcall 样本加深递归使栈需求 >0x40B 让它对 E1 窗口缺口有区分度 (mit406-ruling §5 L1) 并复跑"修复前必崩"反证——**这次反证必须成立才算闭环**
8. **#33 兜底**: 任何 §A 假设被实测推翻 → honest disclosure 优先, 按实测方向继续

## §C 决策点 (项目主已拍板 2026-08-29)

- **D1. 只做单向退出 (B'), 不做 C 双向分段** (✅ 已定, triage §5: "C 入场理由=不需要, re-enter 实测语料 0 出现"; 间接 jmp/ret 目标一律维持 gate)
- **D2. 上界 = .pdata, 回退链 = next-marker-begin → section-end** (✅ 已定, 17/17 vs 16/17 无悬念; D2.1 打平选 int3 的旧拍板随 triage 数据作废)
- **D3. 可达集检查深度 ≤3 层** (✅ 已定, triage B.3① 已证 walker 可检出反例形态; 若 ackermann 递归区编译时间异常, 披露后调)
- **D4. 反例样本可合 1 个文件双函数** (✅ 允许, 降低注册成本; 正样本形态不限, 但须覆盖 END-call 等价 + 早返回 jcc 两类)

## §D 验收标准

1. build rc=0 (新增改动 0 warning) + ctest 16/16
2. **wvmpTest ≥13/14 覆盖** (11 ExitNative 救回 + 2 真虚拟化; 以 diag 行数/stub 数实测); packed 双跑 **103/103 + byte-exact**; sha256 保持绿 (E1 窗口不得回归)
3. **multiseed REQUIRE_REAL=1 全绿** (既有 130 零退化 + 新样本; 预计 145/145 @ 29 样本)
4. 保守 gate 底线: r06 duff_copy 行为与修复前**逐字节一致**; 反例样本维持 gate 且原因行仍是"跳转目标块未找到"
5. enum append-only 括号内自查 (#34, 交越括号 diff); 全部立即数走 imm() 且跑 static_scan_bare_immediates.ps1 PASS (#78)
6. 冻结契约: 不改 callgate step 4-8 语义 / 130 既有样本 / runtime.hpp 布局常量 (ExitNative 若需 ctx 新字段, 先披露再动)
7. 报告含: 每病灶 marker→(旧 RVA, 新 RVA) 映射表 (RVA 漂移实测) + ExitNative 站点计数 vs triage 预测 17 的差异解释
8. 完工 `git checkout main` 后再交报告 (403/404/406 三单连踩的卫生尾巴, 本单明文强制)

## §E 纪律

- ≥30 分钟; 5 分钟内报"完成"按 #38 假完成 REJECT
- **修复前/后反证必须成对且项目主可复跑**: 声称"某形态修复前 FAIL"须给出固定 pre-fix 二进制 (main 8a3d510) 上的复现命令 (E1 教训: 你单方粘贴的反证不算数)
- build/ 被并发任务占用时自建 worktree 隔离 (405/406 先例); wvmpTest `out/base_*.log` 禁覆写, 你的产物落 %TEMP%
- 环境: vcvars64 = VS 18 Insiders 路径; `cmd /c` 单斜杠调 bat; multica.exe 用绝对路径

## §F known compromise 预判

1. .pdata 依赖: stripped/自改 PE 无异常表 → 回退链覆盖, 覆盖数如实报告
2. 落点不消费 flags 是本语料实测, 非普适证明——契约注释写明适用边界
3. `jmp [rsp+EXIT_SLOT]` 间接化使 stub 出口多一次内存读 (性能可忽略, 记录)
4. 13/14 后剩余 r06 间接跳转属未来"间接跳转 lift"独立棒次, 不在本单

时间预算: ~4-6 小时。== MIT-D2 派活单完 ==
