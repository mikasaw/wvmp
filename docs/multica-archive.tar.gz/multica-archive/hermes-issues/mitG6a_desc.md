# WVmp MIT-G6a 派活单 — VEX.128 档A：26+ 个 SSE id 的 V-对折叠进既有通路（三地址折叠器，零新 VmOp）

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: MIT-424 (G6r) 路线裁决 **R2 已拍板**（triage `.multica/mit-G6r-triage.md` §4 档A 蓝图 = 本单骨架，**动手前必读全文**）| main `e652eff` (425 合入后, 基线 40 样本 **200/200**, wvmpTest 14/14) | 上游 425 已落 legacy SSE mul/pand/andnps 面 → 其全部 V-对今天可折叠
> 交付形态: **main 之外的命名分支 `mit-g6a-vex128`**（硬条款，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main e652eff, 2026-08-30 18:5x)

### A.1 现网
- main = `e652eff`; build 0 错 / ctest 16/16 / **multiseed 40 样本 × 5 = 200/200** / wvmpTest 14/14 满贯 + jump-table@0xDD84 + ExitNative 17 + 双跑 103/103 byte-exact
- 硬条款四连满分 (417/419/423/425), 本单第五单

### A.2 现状 VEX 行为链（424 E2E 六区域实证，triage §3——本单改动基线）
- **VEX 不经 legacy prefix 数组**: capstone 对 C4/C5/EVEX 全报 `prefix=[0,0,0,0]` → lifter 入口前缀闸（:1426-1433 rep/F2/F3/66/67/F0）对 VEX **不触发** → VEX 指令直达 `switch (ci.id)` 的 default → unsupported → C1 gate 整函数原生保持（零逃逸、byte-identical——**现状"半 R3"，本单不破坏该性质：白名单外的 V 对仍须走此 gate 链**）
- `X86_INS_V*` 白名单现 **0**（本单 grep 亲验）；V-对 id vendored 头全存在（派单方抽验 19 组 EXISTS + triage §2.4 "26 个既有 SSE id V-对逐个核验"——**动手前你重跑全量对账，SSE 白名单行 vs V-对存在性逐行生成映射表**，别信两边任何一个数字）

### A.3 三地址形态分布（档A 核心成本，triage §2.3 实测，.pdata 域语料）
| 形态 | 占比 | 折叠成本 |
|---|---|---|
| dst==src1（`vaddps xmm1,xmm1,xmm2`） | 23–71% | **零成本**：直映射既有 2 地址 handler |
| dst==src2 且可交换（add/mul/and/or/xor/min/max） | 2–7% | 交换 src1/src2，零成本 |
| **dst 独立**（`vmovaps xmm0,xmm1` 本质=mov；`vaddps xmm2,xmm0,xmm2`） | **26–70%**（python314 69.8% / ucrtbase 60.5%） | **前置一条既有 Op::Mov(dst←src1)** 再走 2 地址——每指令最多 +1 Mov，零新 VmOp |
| 非交换 dst==src2（`vsubss xmm2,xmm0,xmm2`） | 未单列（低频） | **D2 决策点**：scratch 双槽 v18..v23 先例折 或 gate 拒——你按实测频率选 |
| reg-mem（`vaddps xmm1,xmm1,[mem]`） | 与 3reg 同量级 | 复用 408 MEM 通路 + Mov 前置组合 |

### A.4 范围边界（triage §1 家族表 + §4 范围外，本单 = 家族 1/2/3 的 **128-bit 位宽**）
- **入面**: VEX.128 packed FP（vaddps/vmulps/vdivps/vmaxps/vsqrtps/vandps/vmovaps...）+ **标量 FP**（vaddss/vmulsd/vcomiss/vucomisssd——**/arch:AVX 下 100% 标量浮点走 VEX**，triage §2.1 探针实测=本单最大流量价值）+ **整数位运算**（vpxor/vpor/vpand/vpandn——425 已落 legacy pand/por/pxor/pandn，V-对镜像直折）
- **不入面（显式 gate 保持）**: ① ymm/zmm 任何形态（档B，kCtxSize 冻结面）② **BMI-GP（rorx/mulx/andn/shlx）= G8 独立缺口**（triage §6.2：VEX id 但是 GP 域——**GAPS 文档本单须显式声明"VEX-GP 不在 SIMD 档A 内"**，防后续误当漏项）③ FMA（双舍入红线 §6.5，永不拆 mul+add）④ vpaddd/paddq 系（legacy 本体 paddq 仍 gate→G1c，V-对镜像跟本体）⑤ vzeroupper（档B ABI 面）⑥ 加密（vaes/vpclmul 直执行另议）⑦ EVEX/AVX-512 全谱

## §B 任务

1. **B.1 V-对白名单生成**: 以 lifter 现状 SSE 白名单逐行（425 后含 mul/pand/andnps 面）映射其 V-对 → `case X86_INS_V*: return translate_sse_binop(...)` 同构复用**既有 translate 函数**（translate_sse_add/mul/bitwise/ucomis/mov——**零新 IR 语义、零新 VmOp、零新 handler**，triage §4 A-1 承诺）
2. **B.2 三地址折叠器**: 新公共函数（建议 `translate_vex128_binop` 包装层）按 §A.3 三分法：d==s1 直走 / d==s2 交换 / d 独立前置 `Op::Mov`（xmm→xmm 既有 16B 通路先例：413 XmmLoad 双槽 / 408 Load/Store 通路——movaps 家族本身即 d 独立高频主力，注意 **vmovaps/vmovups d 独立 = 纯拷贝，禁走 binop 通路**，直接折叠成 Op::Mov 单条）。操作数 slot 语义（capstone VEX op_count=3，operand[0]=dst）实测对账进报告
3. **B.3 D2 非交换 d==s2**: 折叠方案 or gate 二选一——**要求先在 424 语料（smartscreen/ucrtbase/onnxruntime 任一已扫 exe）实测该形态频率**再拍板（scratch 槽双折 if 高频，gate if <1%），报告附计数命令
4. **B.4 位宽闸**: 入面判定必须检查 `x.op_size`/寄存器宽（xmm=16 vs ymm=32）——**ymm 形态禁入**（vaddps ymm 与 xmm 同 INS id! `X86_INS_VADDPS` 覆盖 128/256 两宽——**这是本单最大陷阱**：仅靠 mnemonic 白名单会放 ymm 进来→错误 lift 静默坏壳。**必须 operand register size 判 16B 才入既有通路，32B 落 unsupported gate**，单测钉死: vaddps ymm 版本仍整函数 gate byte-identical）
5. **B.5 验收样本**: 主样本 `wvmp_vex128_sample`（MASM 直写全形态：标量 FP 3 地址三态 + packed + 整数位运算 + reg-mem + **d独立 Mov 前置** + 负例区：ymm 同 mnemonic / FMA / rorx / vzeroupper / vpaddd——**负例区与正例区函数级分离**，禁跨区污染）+ REQUIRE_REAL E2E；multiseed 40→41（预计 **205/205**）
6. **B.6 424 §7 文档联动**: GAPS:153 行按 triage 草案改写（档A 落地后精确残余 = 档B/G8/G1c/FMA/加密）+ **x86_translate.cpp:1929 邻域错配注释修正**（"vpxor/vpor/vpand VEX.NDS.128.0F.WIG 57/56/54"名实错配——triage §0.6 + §7.2 文本现成）
7. **B.7 零回踩守护**: 既有 legacy SSE 通路（371-376/408/411/425 五代）与 419/423 lock 面、415 串指令面**逐字节不动**——折叠器只做"V-对 → 既有 translate_*"的调度层；既有 200 样本全绿 + wvmpTest diff 0

## §C 决策点（项目主已拍板）

- **D1 零新 VmOp 为硬约束**（✅）: triage A-1 承诺 + kVmOpMax=95 跳表余量 33 留给档B/x87——**本单若出现任何新 VmOp 即设计错误**（Mov 前置只用既有 Op::Mov→既有 handler）。dump 门（#79）SSE_HANDLERS 集合应**完全不变**
- **D2 非交换 d==s2 = 频率驱动**（✅）: §B.3 实测计数后你选 scratch 折 or gate；若 gate 则负例样本钉断言
- **D3 标量 FP 优先**（✅）: /arch:AVX 100% 标量走 VEX = 本单存在价值锚——vaddss/vmulsd/vcomiss 家族是主验收面，packed 次之，整数位运算（425 镜像）顺带
- **D4 vmovaps/vmovups 直折 Op::Mov 不进 binop 框架**（✅）: 纯拷贝语义，避免 Mov 前置包装自身递归
- **D5 C5 短前缀与 C4 全前缀同 INS id**（✅）: capstone 已解 VEX bits（triage §2.4 rex=64 常量披露、lifter 不消费）——白名单按 id 入面天然覆盖两编码；单测各钉一条 C5 短写/C4 全写形态

## §D 验收标准

1. build 0 新警 / ctest 16/16（+新用例：三态折叠各 ≥2、**ymm 位宽闸负例必钉**、C4/C5 双编码）/ **multiseed 205/205**（41 样本）
2. 新样本真虚拟化 + mul/add 语义值手算 + Mov 前置后目标寄存器终值断言（影子 #79 ctx.xmm 读回）+ 负例区五族全 gate（ymm/FMA/rorx/vzeroupper/vpaddd 逐条 note）；multiseed 主/影 byte-exact
3. **实汇编对照表**: MASM 直写字节 → capstone id/op_size → 折叠决策（三态归属）→ VmOp 链——每形态 ≥1 行；另附 /arch:AVX cl 真产物（.FAcs）vmulsd/vaddsd 折叠验证 ≥2 函数
4. 零回踩: 200 既有全绿 + wvmpTest 14/14 + jump-table/ExitNative 17 + lock-strip/string-op/425 面 note 原样 + 双跑 103/103 diff 0
5. **kVmOpMax 仍 =95 不动**（D1）+ 冻结契约全套（runtime.hpp/ir::Op/backend.hpp/callgate/lock 标记域/string 载体域）
6. 硬条款: 命名分支 `mit-g6a-vex128` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账
7. dump/static 双门 PASS 且 **SSE_HANDLERS 集合与 main 完全一致**（零新 handler 的机器证明）

## §E 纪律

worktree 隔离（分支签出自建）/ wvmpTest 禁覆写 / `cmd /c` bat（禁 `cmd //c` 静默空跑）/ vendored capstone 枚举名实测（`.deps/capstone-src/include/capstone/x86.h`，404 CDQE 教训——V 对 id 名以头文件为准）/ MASM 手编 F7 组纪律（423 §7.4: ModRM 手算双验，误编即 cdb 反查，禁猜）/ **#33 铁律**: §A.2 "prefix 全零"、§A.3 三分法占比、§A.4 范围边界、D4 "vmovaps=纯拷贝" 全部是 agent 侧实测兜底项（尤其 **D4 注意 vmovaps 在 AVX 有 ymm 变体**——同 §B.4 位宽闸），与先验冲突以实测为准推翻优先。

## §F known compromise 预判

1. 非交换 d==s2 若选 gate：该形态函数整函数原生（保守退化，非坏壳）——频率证据 + GAPS 文本兜底
2. Mov 前置使 d-独立形态字节码 +1 条 handler 开销（性能非正确性，425 §F2 同款）
3. EVEX(62) 前缀指令与 C4/C5 不同 INS 空间（AVX-512 家族独立 id）——天然不入本白名单，gate 链保持；GAPS 文本仍显式列
4. `vmovsd xmm0,xmm1,xmm2`（VEX 插入语义 ≠ 纯拷贝！低 64 位拷贝高 64 位保留 src1）——**这是 mov 家族里的"假 Mov"**，单数 movss/movsd/partial-register merge 语义三态折叠器必须区分（legacy 时代 movsd 376 有先例语义，映射到 V 对时对齐，禁当 Op::Mov 直折）

时间预算: ~3-4 天（triage §4 档A 估）。== MIT-G6a 派活单完 ==
