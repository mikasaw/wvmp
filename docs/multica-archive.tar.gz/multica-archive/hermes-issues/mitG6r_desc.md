# WVmp MIT-G6r 派活单 — AVX/VEX 支持侦察：真实产物频率实测 + 架构成本量化 + 路线裁决蓝图

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: G 线 W5a (侦察先行, 405/D1、412/G7r、416/G5r 三先例) | 与 MIT-420 (G4b, lifter lock 面) **零文件冲突**——纯侦察不落主仓代码
> 交付: `.multica/mit-G6r-triage.md` (先例格式) | 侦察者: WVmpVerifier

---

## §A 基线事实 (项目主 fresh verify @ main 92b21cb, 2026-08-30 03:5x)

### A.1 现网与 SSE 线状态
- multiseed **37 样本 185/185**; wvmpTest 14/14; **SSE 标量/打包算 (add/sub/div)/位运算/comis/mov mem 全在**, 但 SSE 既有残余 (mul 族/SSE2 整数/andnps) 已立 G1b 后续单——**本侦察范围 = VEX 编码族 (xmm 宽 AVX + ymm AVX2 全谱), 不含 SSE legacy 残余** (避免与 G1b 重叠)
- lifter 现状锚: :1929 注释明文 "AVX VEX 编码由 capstone 报独立 INS id, 不在范围 → C1 gate 兜底"; VEX 是 0xC4/0xC5 前缀字节 (非 legacy prefix 数组)——**capstone detail.prefix 对 VEX 指令报什么、指令 id 命名空间 (X86_INS_V*, vendored 头实测 719 个)、与 SSE 同名指令 (addps vs vaddps) 的 id 分裂程度 = 你的第一批实测**
- 416 x87 侦察已量化的公共前置: **跳表 kTableEntries=128 现用 ~90** (419 后 kVmOpMax=90)——AVX 全族 VmOp 增量必撞 128 扩容议题 (与 x87/G7 共享前置); xmm[8]@0x140 槽模型 (XmmSlot 16B/槽) → **ymm=32B 槽 / zmm 不在面** 的 kCtxSize 布局冲击

### A.2 关键频率先验 (你必实测, 与 x87 的胜负手就在这)
项目主先验 (**预期与 x87 结论相反——AVX 是真需求, #33 推翻优先**):
1. MSVC x64 **/O2 默认不产 AVX** (/arch 默认 SSE2), 但 **/O2 /arch:AVX/AVX2 下向量化循环自动出 vaddps/vmulps/ymm** —— 现代 Release 构建常开 /arch:AVX2
2. MSVC **/O2 float 标量**是否产 VEX 编码的 xmm 宽形式 (vmovss/vaddss)? (部分版本 /arch:AVX 下标量也升 VEX——这决定"VEX.128 折叠档"的真实价值)
3. 常见第三方运行时/CRT/.NET/游戏引擎 exe 的 AVX 密度抽测 (416 手法: dumpbin 扫 + 分档统计)
4. **你的探针矩阵**: 同一组 C++ 浮点/整数 SIMD 源 (循环/点积/位混合), {/O1,/O2}×{/arch:SSE2,AVX,AVX2} 九宫格反汇编, 统计 x87/SSE/VEX128/VEX256 四态占比

### A.3 成本评估输入 (不实施, 量化)
- **折叠复用度实测**: `vaddps xmm0,xmm1,xmm2` (3-operand) ↔ 既有 SSE 2-operand 语义映射——dst≠src1 时折条需多 1 条 mov (或新 VmOp 三地址形态); VEX.128 与 legacy SSE 的 handler 差异 (无 #IA 差异? VEX 忽略高 128 位/置零 ymm 上文的 dirty 语义——vzeroupper ABI 面)
- **ymm 档**: XmmSlot 16→32B (kCtxSize 布局变更=触冻结面, E1/380 先例评估通道)、物理 ymm 保存/恢复成本 (AVX-SSE transition penalty 性能面披露)、vzeroupper 语义处置
- **新 VmOp 增量估算**: VEX.128 折叠档 vs ymm 全族两档各自撑爆跳表吗 (128 余量 ~38)
- **flags 面零涉** (浮点 flags 例外, ucomis 系已有通路)
- x87 R1 蓝图先例: 若某档不排波, 留档格式照 §4

## §B 任务 (四问矩阵, triage 先例格式)

1. **B.1 形态枚举+频率数字**: 探针九宫格 (§A.2.4) + 真实二进制抽样 (≥10 个含 /arch:AVX 编译痕迹的产物; system32 里挑 .NET/新组件)——分档: 编译器自然产物频率 vs 手写/intrinsic 频率 vs 运行时库密度
2. **B.2 现状三态实测**: 标记区域内放 vaddps xmm / vpaddd ymm / vmovaps [rip],ymm 各 → protect 行为链 (lifter 拒→gate→byte-identical? **确认 VEX 不逃逸不产坏壳**——x87 当年"半 R3"验证同构; 若有逃逸=上报, 参照 416 D2 停下上报义务)
3. **B.3 拆单蓝图 (两档分级)**: 档A = **VEX.128 折叠进既有 SSE 通路** (xmm 宽 AVX, 预期 M 级——若频率数字支持这是性价比之王); 档B = ymm 256 (kCtxSize 冲击+跳表扩容, L/XL); 每档依赖/前置单/工作量锚点清单 (禁拍脑袋, 412 标准)
4. **B.4 路线裁决输入**: (R1) 档A+档B 全排波 / (R2) 只档A, ymm 永久 gate 文档化 / (R3) 全 gate 文档化 (x87 先例格式: 样本钉回归+GAPS 声明)——**核心裁决数 = §B.1 的"/O2+/arch:AVX2 真实世界占比"与"受保护客户画像"匹配度** (本项目保护目标=商业软件核心算法, Release 构建习惯 /arch:AVX2 的量化频率)
5. **B.5 GAPS/文档联动**: 现状声明精确化 (:1929 注释 + GAPS AVX 行——"VEX 编码全谱 C1 gate 保持原生"+行为承诺); 观察清单转录

## §C 硬纪律

1. 不落主仓代码不碰 main; 实验 %TEMP%/自建 worktree; **MIT-420 (G4b) 并发期主工作区可能占用——不扰动 (412 例外注记), 复验一律 --detach**
2. #33 全适用: §A.2 四条先验逐条实测支持/推翻, 推翻明示; §A.1 "VEX 走 prefix 数组" 是我猜的, 实测 capstone detail 报法为准
3. 每个频率数字带分母+方法+反例; 三态 (支持/gate/逃逸) 判定证据齐; **若发现任何 VEX 逃逸进 VM (坏壳风险), 报告置顶 + 工单评论即报** (416 D2 先例——那是 P0 不是残余)
4. ≥30 分钟 + 时间对账 (412/417 纪律); 交付前主工作区状态如实报告; 样本/留样清单 + 复跑命令 (416 教训: **留样在 %TEMP% 会被系统清理**——关键复现产物改存你的分支内 tests/ 或报告内嵌字节, 二选一)
5. cdb/dumpbin/capstone 路径见先例; 工具缺失如实报告

## §D 质量基线

三先例 (D1/G7r/G5r) 标准: 互证≥3路 / 派单方 §A 错误直纠 / 路线每条附第一张前置单草案 / 结论置信度自评。本单额外要求: **路线建议必须显式对齐 G 线总排程** (你建议的波次与 G1b/G7P1/410 的先后关系一句话)。

时间预算: ~半天 (侦察)。== MIT-G6r 派活单完 ==
