# WVmp MIT-X2a 派活单 — 形级 fork 面收口：call [mem] / plain 串形 / leave / S16 双 arch 分叉 + x64 全链实证（asmgen XL 前置单）

> 派活单生成: 2026-09-01, 接手人 (项目主)
> 关联: 多目标平台 | main `110a6aa`（438 合入后, 基线 49 样本 **245/245**, 十二连满分）| 素材权威源 = `.multica/mit-X0-triage.md` §1.4 fork 面表 + §6 拆单表（动手前通读）
> **范围澄清（对 X0 §6 表的切分，重要）**: X0 表"X1 行"的 translator S32 分叉+基建参数化切片 + 表外 §1.4 fork 面/leave 顺路 = **本单（称 X2a）**；X0 表的"X2a=asmgen XL"**顺延称 X3**（本单交报合入后立即接排）。438 X1b 已落 Ret aux 通道与 CLI arch 字段，本单不重复。
> **x87 三路线 D1 悬置维持合法**（X0 §6: 不改 X1-X3 共享面）——本单六类指令形态与 x87 无关；正式拍板点=X3 asmgen 单交报时（届时给项目主一页裁决备忘即可）。
> 交付形态: **main 之外的命名分支 `mit-x2a-fork-fold`**（硬条款十三连，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main 110a6aa, 2026-09-01 11:5x)

### A.1 现网
- main=`110a6aa`; build 0 / ctest 16/16 / **multiseed 49×5=245/245** / wvmpTest 14/14; kVmOpMax=97（跳表余量 30——**本单目标零新 VmOp 全折条**）
- 438 遗产直读: `case ir::Op::Ret` aux 通道范式（D2(i) 闲置槽）+ `build_ret` 终态链先例 + **SEH/FS 入口闸 `prefix[1]!=0→unsupported`**（X86 段前缀已在拦——S16 的 66 前缀判据别撞此闸，见 B.4）
- 437 遗产: marker_scan x86 双段锚点在位（扫描面对 x86 已通，**消费面=本单 lifter/translator**）
- **硬拒面不动**: x86 输入仍 rc=2（414/438 D1 链）——本单 x86 侧交付=**lifter/translator 双 arch 单测纸面级**（X0 §F.3 证据分级纪律）+ x64 侧全链实证（见 D3）

### A.2 fork 面素材（X0 §1.4 直读行，本单六块主体）
| 块 | X0 行证据 | 折叠预判（项目主读，实测兜底）|
|---|---|---|
| ① **call [mem]** | CALL 现拒 mem 形; msvbvm60 **35% 的 call=mem 形**（IAT thunk `call [__imp_x]`/`call [esp+..]`）; call reg **已在白名单可直用**（dxcompiler 4167 实测）| **= Load(目标地址) + 既有 call-reg 通路折条，零新 VmOp 高置信**（若 callgate 协议仅吃 rel32-RVA 不吃 reg 值目标——实测核，有雷即停披露）|
| ② **plain 串形** movsd/lodsd/scasd (A5/AD/AE 无 rep) | 单发结构体拷贝惯用 (dxcompiler 10116/msvbvm60 1311 级); G3 只收 F3 前缀 | 单步 = G3 微程序"循环一次"形 or DF=0 直译 Load+Store——**415 微程序框架现成**; DF 语义引用 G3 D1 裁决 |
| ③ **leave** (C9) | 0.37% 非 FP 缺口第一名; x86 栈帧主形 | **= Mov(rsp←rbp) + Pop(rbp) 两既有 op**——**x64 今天可全链 E2E**（编译器真产 leave!）——本单最佳实证点 |
| ④ **cld/std** | rgn_str 实测串前置惯用 | VM flags 无 DF 位（G3 D1 在案）→ **no-op 放行+披露**（对齐 415 既定 DF 判）or 保持 gate——按 G3 现面对齐, D5 |
| ⑤ **S16/p66** | 全语料 0.82% (msvbvm60 2.6%); X0 注"VM S16 通路'现成'声明(G3) 需 x86 实测" | **translator 5 处 S64 硬编码点分叉**（412 §2: :127-145/:316-346/:370/:403——行号系 412 时代, 你重定位）; 16-bit load/store 若 runtime 宽度参数化不通——**授权砍面（D2）留 X3 顺路, 砍要有复杂度证据** |
| ⑥ 长尾清点 | shld/shrd（结构性必收但低频——**归 X3 别动**）、cwde/cbw（98, 低频, x64 可折 Movsx 语义先例——**若 ≤1 小时顺路收, 否则文档挂账**）| 报告逐条点名去向 |

## §B 任务

1. **B.1 lifter 开口**: ①②③⑥(cwde/cbw) 各 case + 双 arch 判据（**arch 参数已在链**: fr.arch 自 437/414 贯通——消费它, 禁新侧信道）
2. **B.2 translator**: 折条落地（①=Load+Call ②=串单步 ③=Mov+Pop）+ 412 §2 S64 硬编码点位复核分叉（哪些真属 arch 宽度、哪些本为常量误名——逐点披露）
3. **B.3 S16 判定实测（D2 双向授权）**: 66 前缀 p66 通路从 lifter 判据→IR size→translator 字节码→**x64 面 runtime 行为**（x64 也能编 66 39 c0 测 runtime 宽度语义!）全链试通——通=收（x86 纸面钉）, 爆=砍+复杂度证据+X3 挂账文本
4. **B.4 前缀闸对账**: 66（S16）与 67（addr16）与 SEH 的 `prefix[1]` 闸（438）**互不误伤**——66 在 x86 prefix[2] 位（X0 §7 报法在案）但双 arch 位置判据你实测重钉; `call [mem]` 的 67 形（若现）默认拒（16 位寻址编译器不产,X0 §1.4 lea 行判）
5. **B.5 x64 全链实证（D3 硬项）**: 新样本 `wvmp_forkface_sample`——**x64 可执行形态全链**: 区1 leave 链（函数序尾真产/直写均可）/ 区2 call [mem] IAT 形（`call [*imp_printf]` 类——经 got/rip 相对 x64 变体, 语义同构）/ 区3 plain movsd 单发拷贝 / 区4（若 B.3 通）p66 66 形 ALU / 负例区: std/cld 视 D5 裁决 + 16 位寻址形 gate; REQUIRE_REAL + multiseed 49→**50/51 = 250/255**
6. **B.6 x86 纸面断言层**: 六形态 × 双 arch lifter/translator 单测矩阵（RetImm16LiftIntoSrc 先例格式）+ X0 §1.4 行号更新对照表（交付后哪些行从"fork→X"翻"direct"）
7. **B.7 基建参数化预铺**: multiseed 脚本 arch 维度**架子**（x86 样本目录/清单参数化, 空池不跑——X5 收口单填池; 若判定预铺别扭, 整体留 X5 亦可, 披露即可）
8. **B.8 文档**: GAPS X0 fork 面行翻正/挂账同步 + "x86 已知 gate 清单"续块（438 模板）+ STATUS 里程碑

## §C 决策点（项目主已拍板）

- **D1 x87 悬置维持**（✅）: 本单不拍; X3 交报时附一页备忘（三路线数字引用 436 即可）
- **D2 S16 双向授权**（✅）: 实测全链说话, 砍/留都要证据（408/425 先例格式）
- **D3 x64 实证为硬项**（✅）: leave/call [mem]/串形/x64-66 全部在 x64 现管道有真形态——**只交纸面=不合格**（本单价值锚=把 X0 "fork 面 2-4%"先落成可跑代码）
- **D4 asmgen 零触碰红线**（✅）: runtime x86 codegen=X3 asmgen 单; 本单任何形态若实测需 asmgen 改动（如 call 目标为运行时值与 callgate RVA 协议冲突）——**停手评论披露归 X3, 别硬改**
- **D5 cld/std 对齐 G3 现面**（✅）: 查 415 对 DF 的既定处置（no-op+披露 or 白名单外）, 同款处理, 禁新语义发明
- **D6 call [mem] 与跳转表的边界**（✅）: `jmp [mem]` 已由 G2 模板收（409/413）——call [mem] 的模板/防御常数问题独立评估: **vtable/IAT 直读形先收, call 表分发（call [tbl+idx*4]）若无防御模板支撑即 gate 挂账**（别造第二套跳表逻辑）

## §D 验收标准
1. build 0 新警 / ctest 16/16（+双 arch 矩阵 ≥10 例: 六形态 lift/translate + D4 前缀闸互不误伤三对 + B.6 对照）/ **multiseed 250-255 全绿**（245 既有零回踩）
2. **x64 新样本真虚拟化**: leave/call [mem]/串形区 REQUIRE_REAL 过 + 语义值断言（栈平衡哨兵 bal=0 形沿用 438; IAT call 打真 API 或自写函数）+ 负例区逐条 gate note + 影子双跑 byte-exact
3. S16 裁决报告（通=全链证据 / 砍=X3 挂账文本+复杂度数据）
4. 零回踩: 245 既有全绿 + wvmpTest 14/14 双跑 diff 0 + **438 Ret 面/437 扫描面零 diff**（互斥审计）
5. **kVmOpMax=97 不动**（全折条目标）+ 冻结契约全套（runtime.hpp/backend/callgate/载体域 0..22/aux Ret 语义不动）; asmgen **零 diff**（D4 机器证明）
6. 实汇编对照表: 六形态 x64 真字节 + x86 直写字节 → capstone 双 arch 解 → 折叠 IR 链（x86 侧标"纸面"级）
7. 硬条款: 命名分支 `mit-x2a-fork-fold` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 / wvmpTest 禁覆写 / `cmd /c` 查时间戳 / MASM 手编双验（x64 66 前缀形+C9/A5 直写; 423/428 纪律）/ 观察纪律 427 / #33: A.2 六块折叠预判（call [mem] 零新 op / leave 两 op / S16 现成声明）**全部实测兜底推翻优先**——尤其 G3"S16 通路现成"是 415 时代声明, 本单首次真验 / 幻影 begin 观察（432 §6.2）与本单无关别顺手。

## §F known compromise 预判
1. x86 面纸级（rc=2 硬拒下无真 E2E 通道）——D3 用 x64 全链补实证, x86 待 X3
2. plain 串形的 DF=1 病态沿用 415"不回滚副作用"披露口径
3. B.7 预铺若别扭可整体推 X5——不硬做

时间预算: ~2-3 天（六块+双实证层; S16 若通 +0.5 天）。== MIT-X2a 派活单完 ==
