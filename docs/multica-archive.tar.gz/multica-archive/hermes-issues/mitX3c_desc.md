# WVmp MIT-X3c 派活单 — asmgen x86 协议面收口：CallGate reg-target（x64 同收，442 挂账闭环）+ ExitNative 4B + Ret x86 形 + x87 D1 一页备忘

> 派活单生成: 2026-09-01, 接手人 (项目主)
> 关联: 多目标平台 X3 拆单第 3 张（协议面收官棒）| main `9c00962`（444 X3b 合入后, 基线 50 样本 250/250, x64 恒等 sha `f67c2d40` 底稿, 十五连）| 素材 = X0 triage §3.2-C(4) + 442 裁定 §3 挂账 + 443 裁定 §4 + 444 裁定 §5（X3c 重排版）| 后续: X4 stub_gen cdecl（含 translator S64 tag 改形前置）→ X5 收口
> 交付形态: **main 之外的命名分支 `mit-x3c-protocol`**（硬条款十六连，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main 9c00962, 2026-09-01 18:4x)

### A.1 现网
build 0 / ctest 16/16 / multiseed 250/250 / wvmpTest 14 stubs 双跑 diff 0；kVmOpMax=97（余量 30，**本单禁新 VmOp**）；D1 硬拒维持；x86 真可跑面=57/96；x86 电池 28 例 + dump 门 57 项 + 三件套同步纪律（444 验收亲点模式）沿用。

### A.2 协议三件套现状（4050a4c→9c00962 锚重钉, 442 旧行号已漂移作废）
- **CallGate reg-target**: translator `:1678-1696` `translate_call` 双 skip 在位（运行时值目标 + call [mem] rip 形"折条=Load+Call(reg) 需 CallGate reg-target 通路, asmgen 改动归 X3"）；asmgen 侧 build_callgate 存在（x64 表已登记）但**只吃 aux 翻译期 RVA**——runtime 从无 reg 值目标通路（442 D4 停手实证）。**#33 前置动作**: 动手前先把 forkface 样本 callmem=997 的现通路亲测清楚（生成码 dump 反汇编钉它走了哪条链——442"IAT 直读形先收"的实现细节报告未展开，别照猜改）。
- **ExitNative**: x64 handler `:1212` 主面（407 退出槽 kExitSlotDepth 派生纪律在位）；x86 表缺席（`sed` 亲验协议 3 面全缺）。X0 §3.2-C(4)=4B 槽协议形。
- **Ret**: x64 `build_ret`（`:1316`，438 清栈形, kRetFrameDiscard=0x210/kRetGuestRspFromNs=0x1D8 派生常量+static_assert）；x86 表缺席——x86 形=4B 栈宽+同构终态链（X3a epilogue 4 callee-saved 模板已在），**438"guest 栈写恒≥ns"规则与保存区 [ns-4..ns-0x10] x86 形（X3a B.4）必须对账**。
- **不动面**: shld/shrd/cwd 评估（442 挂账④）降级为 §B.5 **只出数裁决**（lifter 现状 grep 已亲验: shld/shrd 无 lift 形=cwd 双 id 仅 cwde/cbw 系 442 面）——除非实测推翻。

### A.3 x87 D1 备忘要求（三路线, X0 §4 数字 + 432/435 语境）
一页进报告（不改代码）: R-SSE-only / R-x87-L0（+2.61% 覆盖, 178>128 强制跳表扩容, MMX 缝合成本）/ 全 gate（浮点函数裸奔）——每路线给: x86 客户覆盖增量（引 X0 分档实测）、工程量级（跳表扩容 S 级实证在案）、风险。**项目主 X4 前拍板, 默认定稿=R-SSE-only**（X0 倾向, x64 承诺一致）。

## §B 任务

1. **B.1 CallGate reg-target（主菜, 双 arch 同收）**: 先亲测现通路（A.2 #33）→ 设计（目标值经帧槽/ctx 槽中转的进 handler 协议——禁改 kCtxSize/runtime.hpp）→ asmgen build_callgate 加 reg 值目标形（x64+x86 双份）→ translator skip 解除 + call [mem] 折条（Load+CallGate(reg)）落地 → **x64 全链实证（442 反证翻案）**: forkface 样本 callmem/callreg 从 gate/纸面 → 真虚拟化, bal=0 哨兵+byte-exact; x86 电池新增 CallGate 用例（目标值经 reg 槽传入的 callee 真调用, 参数窗/返回值写回对齐 X3a 帧形）。⚠️ callee-saved 约束（X3a roll 预保留注释: ctx_/base_ 占 4 callee-saved 其二——callgate step 序列对 callee-saved 的影响逐 step 对账）。
2. **B.2 ExitNative x86 形**: 4B 退出槽协议 + x86 epilogue 对齐（栈帧 0x24 回收 + 4 callee-saved pop 序）+ 电池用例（区域外 jmp 单向退出真执行断言）；x64 侧零扰动（既有 handler 不动, dump 恒等）。
3. **B.3 Ret x86 形**: 4B 清栈返回（438 aux 语义 arch 分叉: imm16×2? 不——x86 下 guest esp 步进规则按 444 裁决表"零扩展不变量+dword 低半字算术"）+ 保存区对账 + 电池用例（普通 ret / ret imm 栈平衡双断言）。
4. **B.4 冻结面解禁声明（本单唯二解禁 = asmgen.cpp + translator.cpp）**: translator 改动**严格限定 translate_call 通路**（skip 解除+折条）；**S64 tag 改形（444 挂账）不归本单**——X4 前置（rsp 步进/rip-RVA 全管道面, 电池不需要它）；越界想法（如顺手改 S64）=停手评论。
5. **B.5 shld/shrd/cwd 评估**: 语料数（X0 missing 表内占比）+ 折条可行性一句话裁决（入 GAPS, 不实施）。
6. **B.6 x87 D1 一页备忘**（A.3 格式）随报告交付。
7. **B.7 x64 零扰动铁证（分级口径, 433/444 教训融合）**: ① 除 forkface 外 48 样本+multiseed 既有池 asm_dump 逐字节恒等（sha `f67c2d40` 底稿口径亲验——**forkface 例外因 B.1 翻案是预期 delta, 逐 handler 对账披露改了哪几个 op 的码体**）② multiseed 250/250（forkface 输出串 bal=0/callmem=997/callreg=998 值不变——行为恒等, 码体 delta 合法）③ wvmpTest 双跑 diff 0（stubs=14 不变）④ ctest 16/16。
8. **B.8 文档**: GAPS（协议面收口+call [mem] 行翻正+S16 串形配方留档核对）+ STATUS 里程碑 + X4 交接注记（S64 tag 改形精确点位×N + stub ABI 对齐锚更新——若 B.1 动了 entry/帧形则必须同步）。

## §C 决策点（项目主已拍板）

- **D1 禁新 VmOp**（✅）: kVmOpMax=97; reg-target 走 aux/cond_or_size 既有字段的编码扩展或帧槽协议——方案自定但报告给字节级布局图。
- **D2 call 语义基准**: reg-target callgate 的栈序/参数窗与 x64 Microsoft x64 ABI 对齐形保持一致（442 step 序列对账），x86 侧 cdecl 参数窗=X4 面——本单 handler 协议**不为 x86 参数窗特化**, 留 stub_gen 对接（越单禁硬凑）。
- **D3 双 arch 同收**（✅）: reg-target 只做 x86 会留 x64 半截——x64 是现网正确性面（442 已证 call reg E2E 从无）, 双份交付。
- **D4 S64 tag 改形越单**（✅）: 见 B.4, 停手红线。
- **D5 电池优先**（X3a D5 沿用）: 三件套若吃不下, Ret→ExitNative→CallGate 逆序砍（CallGate 是主菜最后保）——半程停手如实标注。
- **D6 forkface delta 合法性**: 翻案导致该样本码体变=预期内, 但**语义输出串必须逐字节不变**（值域恒等）+ 其余 48 样本 dump 恒等——两个口径都铁才算 B.7 过。

## §D 验收标准
1. x64: build 0 新警 / ctest 16/16 / multiseed 250/250 / wvmpTest 双跑 diff 0（stubs=14）/ 48 样本 dump sha `f67c2d40` 恒等 + forkface 逐 handler delta 表
2. x86: 电池 **31+** 全绿 rc=0（项目主将亲手 WOW64 复跑）——CallGate/ExitNative/Ret 各 ≥1 真执行用例 + dump 门 BATTERY_HANDLERS 同步（60±）+ 静态扫描双面 PASS
3. B.1 现通路亲测记录（改前 dump 反汇编证据）入报告——防"没摸清就动刀"
4. 冻结契约: runtime.hpp/vm_op(97)/kCtxSize/backend/lifter/cli/sdk/载体域 0..28 零 diff; **唯二解禁=asmgen+translator(限 translate_call)**
5. x87 D1 备忘一页 + shld/shrd/cwd 裁决行 + X4 交接注记（S64 点位清单）
6. 硬条款: 命名分支 `mit-x3c-protocol` + main 未动 + tracked 零脏 + 切回 main + **worktree 自拆** + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 + 多批次 commit（三件套各一批, 每批全绿再推——444 七 commit 模范）/ wvmpTest 禁覆写 / `cmd /c` 查时间戳 / **#33 主战场**: A.2 全部锚（现通路/退出槽形/保存区 x86 形/callee-saved 影响）实测兜底——442"call reg 可直用"错觉的前车之鉴,**任何"应该可以"必须先 dump 反证** / 电池当场炸当场修实录照贴（444 模式）/ 卡壳 ≥2h 评论披露。

## §F known compromise 预判
1. reg-target callgate 在 x86 全管道前=E2E 纸级（电池真执行+X5 全链收口）——D1 未解锁维持
2. x86 参数窗未定形（cdecl=X4）——本单协议若被 X4 修订需两处同步, 交接注记点名
3. call 目标若涉尾调用/间接跳表分发（call 表形）——维持 442 gate 不扩（D6 边界沿用）

时间预算: ~2 天。交报后 X4（stub_gen cdecl + S64 tag 改形 + 全管道半解锁准备）接排。== MIT-X3c 派活单完 ==
