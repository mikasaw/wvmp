# WVmp MIT-G5r 派活单 — x87 FPU 支持侦察：形态枚举 + 编译器产物频率实测 + 实施拆单蓝图

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: G 线 W4a (侦察先行, 405/D1 与 412/G7r 先例) | GAPS"不支持面 x87 (Block A/MIT-377 候选)" | 与 MIT-415 (G3 串指令实施, translator/lifter 改面) **零文件冲突** — 纯侦察
> 交付: `.multica/mit-G5r-triage.md` (triage 先例格式, 你 412 已证明质量) — **不落主仓代码**

---

## §A 基线事实 (项目主 fresh verify @ main 92928e0, 2026-08-29 23:2x)

- multiseed **165/165** (33 样本); wvmpTest 14/14; SSE 线 (371-376/408/411) 浮点全走 xmm; **x87 在白名单 grep FLD/FADD/FCOM 全零** (完全未入门)
- VM 状态面: VmContext = `u64 regs[32]` + xmm[8]@0x140 (408 借槽体系); **无 x87 ST(0..7) 栈模型** — 本侦察的架构核心问题
- ir::Op 冻结先例: (op,Size) 双语义 / SSE 借道 GP 双槽临时 (408 D1) — x87 的 80-bit extended 精度无 u64 承载先例, 冲击面比 AVX-ymm (G6 预告) 更异形
- 编译器产物先验 (**你必实测, 项目主先验如下, #33 推翻优先**): x64 ABI 浮点=SSE 强制, **MSVC x64 正常不产 x87**; 残余入口 = ① long double (MSVC=double 不产; **clang-cl/mingw x64 产 80-bit x87**!) ② `volatile float` 某些 /O1 路径? ③ 32 位目标 x86 主战场 (与 G7 P1 强耦合! x86 PE 的浮点几乎必走 x87) ④ intrinsic 逃逸 (`_emul`?) ⑤ 手写 asm

## §B 任务 (四问矩阵)

1. **B.1 形态枚举**: x87 指令全族分组 (数据传输 fld/fst/fstp·st/i, 算术 fadd..fcomip, 超越函数 fsin/fptan 系, 状态控制 fldcw/fnstcw/fnclex, 条件 fcmov/fstsw) — **每组给"真实世界出现频率"估计与证据** (不是理论全集):
   - 实测路: 你的机器上有什么编译器 (cl x64/x86 host、cl_arm64?、.NET、rustup 带的 mingw? Python 嵌入的 vcruntime 目标?) — dumpbin /disasm 扫常见 exe/dll 的 x87 密度 (样本: system32 挑几个非托管 exe + 任何你手头的 mingw 产物)
   - 32 位维 (G7 P1 耦合): x86 cl 产 /arch:IA32? (实测有无该旗标) 浮点代码的 x87 占比
2. **B.2 架构适配成本评估** (不实施, 量化):
   - ST(0..7) 栈语义 → regs[32] 槽模型映射方案空间 (真栈 vs flat+tag 仿真) 与 kCtxSize 冲击
   - **80-bit extended**: 10B 内存态/寄存器态编码、双 u64 借槽先例 (C2-Sar 128 位双寄存器先例!)、RNDMODE 差异 (x87 与 SSE 结果**不同**——同表达式两路精度分叉, 语义等价性怎么证?)
   - x87 flags (C3/C2/C1/Z...C0) → VM flags 槽 (仅 5 位!) 的翻译通路
   - transcendental (fsin 微码!) 的 handler 可行性 (native 直调?)
3. **B.3 工作量分级 + 拆单蓝图**: 按"最小可用" (fld/fstp/fadd/fmul 基础算术闭合=能跑老代码) 到"全族"分级, 每级前置依赖 (e.g. ST 模型→数据组→算术→比较→超越→状态控制) + 与 SSE 既有件 (408 XmmLoad 通路) 复用点
4. **B.4 路线建议**: (R1) 全量 x87 排波实施 / (R2) 仅 32 位目标耦合场景触发 (G7 P1 立项时捆绑最小集, 单独不投) / (R3) 永久 gate 文档化 (x86 目标浮点=限制) — **核心裁决输入 = B.1 的真实世界频率数字**: 若"只有手写 asm/冷门编译器产 x87"则 R3/R2; 若 mingw/G7-x86 路径高频则 R1 拆单蓝图生效

## §C 硬纪律

1. 不落主仓代码不碰 main; 实验全 %TEMP%/自建 worktree; **MIT-415 (G3) 并发期主工作区可能被签出占用——不扰动 (412 例外注记纪律), 你的复验一律 --detach worktree**
2. #33 全面适用: §A 先验 (MSVC 不产 x87 / clang-mingw 产 / x86 高频) 每一条都要你的实测证据支持或推翻, 推翻处明示
3. 每个频率数字 = 样本集 + 统计方法 + 反例逐条 (D1/G7r 标准); "已支持/真缺口/不可行"三态证据齐
4. ≥30 分钟 (时间报告与 run 起止对账, 412 教训); 交付前主工作区状态如实报告 (若被 415 占用则披露留给收口方)
5. 工具: dumpbin (vcvars64)/cdb `C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe`/capstone `C:/Python314/python.exe` (vendored 枚举名以 .deps 头为准)

## §D 质量基线 (405/D1 + 412 双先例标准)

互证 ≥3 路; 派单方 (我) §A 错误直纠; 数字带分母; 路线建议每条附"若选此路的第一张前置单草案"。

时间预算: ~半天 (侦察)。== MIT-G5r 派活单完 ==
