# MIT-379 裁定型派活单 — wvmpTest kernels WVMP 虚拟化标记验收 (沿用 MIT-375 同一流程)

> 派活单生成: 2026-08-28, hermes (project owner)
> 关联: MIT-375 (status=done, ruling .multica/mit375-ruling.md, commit 694eda0)
> MIT-379 commit: 6f23f8e (wvmpTest main HEAD, "MIT-379: wvmpTest kernels.cpp 加 WVMP 虚拟化标记 + 加壳 diff 验证 (部分达成)")
> 模板: MIT-375 ruling 流程 + pattern 7 verifier 错误方翻转 + pitfall #33 §A baseline CONFIRMED

---

## §A Pre-dispatch baseline (project owner fresh verify, 2026-08-28 17:30 UTC+8)

实测已校（pitfall #70 CONFIRMED, MIT-379 §A 数字对齐真实机器状态）：

| 项 | 实测 | 派活单原文 | 一致性 |
|---|---|---|---|
| kernels.cpp 行数 | 359 | 未给 | n/a |
| WV_TARGET_NOINLINE 函数 | **14** (line 117,130,148,161,172,183,212,245,267,281,299,313,331,362) | "16 个 WV_TARGET_NOINLINE 函数" | ⚠️ 派活单 §A 数字错（应改为 14，pitfall #33） |
| PROTECT_BEGIN 命中 | **15** (含 14 函数 + 1 wv_sha256_compress 函数体内同名注释?) | "14 函数加 WVM |  |
| P 标记对" |  | ⚠️ 派活单未明确，agent commit message 实测修正为 14 |  |
| PROTECT_END 命中 | **15** | n/a | n/a |
| kernels.h WV_TARGET_NOINLINE 命中 | **15** (2 宏定义 + 14 函数声明 - 1 注释中提及) | "kernels.h 声明含宏定义行共 15 处命中" (agent commit) | ✅ 一致 (但派活单原文无明确说法) |
| kernels.h 是否声明 wv_sha256_h0 | 未声明 (在别处, agent 不打标 ✅) | n/a | n/a |
| packed.exe 大小 | 963072 bytes | n/a | n/a |
| test_target.exe (unpacked) 大小 | 941056 bytes | n/a | n/a |
| packed vs unpacked 大小差 | +22016 bytes (markers 字节) | n/a | n/a |
| base_packed.log SUMMARY | **passed=103 failed=0 skipped=0** | "expected 128bit hex string, but got garbage" | ❌ **与派活单 §E 描述矛盾** |
| base_unpacked.log SUMMARY | **passed=103 failed=0 skipped=0** | n/a | n/a |
| diff base_packed vs base_unpacked | **空** (byte-exact 一致) | n/a | ✅ |
| agent 自报 blocker 原因 | "wvmpTest packed kern.sha256 segfault 0xC0000005" | 同左 | ⚠️ 与 §A baseline 实证矛盾 |

**关键 conflict**: agent commit message 与 §A baseline **双重矛盾**:
1. **agent 自报 vs fresh verify**: agent 自述 "kern.sha256_block_vectors expected 128bit hex string, but got garbage", 但 fresh verify base_packed.log 显示 `[PASS] kern.sha256_block_vectors` (L72)。
2. **agent 自报 vs fresh verify**: agent 自述 "packed.exe segfault 0xC0000005", 但 fresh verify base_packed.log SUMMARY 显示 passed=103 failed=0 + 项目主刚跑一次完整 packed.exe 也是 passed=103 failed=0。

→ 派活单派发**前** verifier 必交叉核查 (D2.1 决策点: 要求 verifier 写明 conflict + root cause)。

---

## §B 任务 (派活单派发 verifier, WVMP RULING 模式)

**Verifier 唯一任务**: 验证 commit `6f23f8e` 是否**真实达成**验收流"标记 -> 编译 -> protect -> packed 与 unpacked 输出逐字节比对"。

### B.1 代码层核查 (must pass)
1. **`wvmpTest/src/targets/kernels.cpp`** (commit 6f23f8e 改动)
   - `#pragma optimize("", off)` 在 L108 存在 ✅ 必查
   - `#include "wvmp_protect.h"` 在头部存在
   - 14 个 WV_TARGET_NOINLINE 函数体首尾插入 `PROTECT_BEGIN("..."); ... PROTECT_END();`
   - `wv_sha256_h0()` 不打标 (派活单设计, 函数体只有 return)
   - 配对正确: 14 个 BEGIN / 14 个 END (实测 15/15 是含 1 个 wrap-up 注释?, 必须确认)
2. **`wvmpTest/src/targets/wvmp_protect.h`** (commit 6f23f8e 新增)
   - marker 桩 noinline + volatile imm64 落码
   - magic 字节 "WVMPBEG1" / "WVMPEND1" 与 sdk/markers.hpp kBeginMagic/kEndMagic 严格同步
   - static 不出符号
3. **`wvmpTest/kernels.toml`** (commit 6f23f8e 新增)
   - paths 绝对式
   - passes 沿用 default.toml 六段管道 (pe_loader, marker_scan, lifter, virtualize, stub_link, pe_writer)
   - seed=12345
   - input = `C:/Users/www/AiCode/WVmp/wvmpTest/build/x64/test_target.exe`
   - output = `C:/Users/www/AiCode/WVmp/wvmpTest/build/x64/packed.exe`

### B.2 行为层核查 (must pass) — D1.1 决策点: 完整复跑 packed.exe 103 测试

**完整复跑命令** (verifier 必跑, 沿用 MIT-375 模式):
```bash
# 1. 重建 wvmpTest (用 vs2019/2022 msbuild 或 build.bat, 沿用 wvmpTest/build.bat)
# 2. 用 wvmp_cli.exe 跑 kernels.toml 重新生成 packed.exe
# 3. 跑 base_unpacked.log 用 test_target.exe (unpacked)
"C:\Users\www\AiCode\WVmp\wvmpTest\build\x64\test_target.exe" > out\verifier_unpacked.log 2>&1
# 4. 跑 base_packed.log 用 packed.exe
"C:\Users\www\AiCode\WVmp\wvmpTest\build\x64\packed.exe" > out\verifier_packed.log 2>&1
# 5. diff
diff out\verifier_unpacked.log out\verifier_packed.log
echo "diff exit=$? (0=byte-exact PASS)"
```

**派活单 §E 实证预期** (project owner 已校):
- `out\verifier_packed.log` SUMMARY = `passed=103 failed=0 skipped=0`
- `out\verifier_unpacked.log` SUMMARY = `passed=103 failed=0 skipped=0`
- diff 输出**空** (byte-exact 一致)
- `kern.sha256_block_vectors` 在 verifier_packed.log 显示 `[PASS]`

### B.3 Byte-exact cross-verify (must pass)
- diff base_packed.log vs verifier_packed.log (上一轮 vs verifier 重跑) = 应空 (除非 seed 变更)
- diff base_unpacked.log vs verifier_unpacked.log = 应空

### B.4 conflict 解释 (D2.1 决策点, 必须)

**verifier 必给**:
1. agent commit message 自述 "kern.sha256_block_vectors expected 128bit hex string, but got garbage" 与 base_packed.log `[PASS] kern.sha256_block_vectors` 矛盾的根因
2. agent commit message 自述 "packed.exe segfault 0xC0000005" 与项目主 fresh verify "passed=103 failed=0" 矛盾的根因
3. agent commit message 自述 "SHA 128bit 期望值错位" 是否真正发生过 (沿用 MIT-380 honest disclosure 模式: 派活单 §A 假设不一定是真根因 pitfall #33)

**预期结论**: agent self-report (status=blocked) 是诚实披露但与 fresh verify 实证矛盾 → **commit 6f23f8e 实际已达成验收** → push MIT-379 status done。

---

## §C 工作目录与工具链

- **wvmpTest HEAD**: `6f23f8e` (main, commit msg: "MIT-379: wvmpTest kernels.cpp 加 WVMP 虚拟化标记 + 加壳 diff 验证 (部分达成)")
- **wvmpTest 仓库**: `C:\Users\www\AiCode\WVmp\wvmpTest` (独立仓库)
- **不创建 worktree** — 改动小且已完成, 直接在 main 上 fresh verify
- **不需要 cherry-pick / 不需要 amend / 不需要新 commit** — 任务**只是验证**,不改代码
- **工具**: `git -C C:\Users\www\AiCode\WVmp\wvmpTest ...`
- **CLI**: `C:\Users\www\AiCode\WVmp\wvmp\build\cli\wvmp_cli.exe` (沿用 wvmp main 编译产物)
- **build script**: `wvmpTest/build.bat` (单条 cl 直编, 沿用 wvmpTest 现有 build 模式)

---

## §D 决策点 (项目主已拍板 2026-08-28, 沿用 MIT-375 决策合作模式)

== 决策点 (项目主已拍板 2026-08-28) ==

- **D1. verifier 验收深度** (✅ 已定 D1.1): **完整复跑 packed.exe 103 测试 + diff base_packed vs base_unpacked**, 不接受"只验 §A baseline 关键数字" 浅度
- **D2. agent 自报 vs 实证矛盾处理** (✅ 已定 D2.1): **要求 verifier 写明 conflict + 给出 root cause**, 不接受"只报 Accept/Reject 不解释矛盾"

---

## §E 验收 (verifier 必跑, 顺序固定)

1. **git state baseline**:
```bash
git -C C:\Users\www\AiCode\WVmp\wvmpTest log --oneline -3
git -C C:\Users\www\AiCode\WVmp\wvmpTest status --short
git -C C:\Users\www\AiCode\WVmp\wvmpTest show --stat 6f23f8e
```
   预期: HEAD = `6f23f8e`, working tree clean, commit 改动 = 2 改 + 1 新增 toml

2. **代码层 3 处核查** (B.1):
```bash
Get-Content C:\Users\www\AiCode\WVmp\wvmpTest\src\targets\kernels.cpp | Select-String "pragma optimize|PROTECT_BEGIN|PROTECT_END"
Test-Path C:\Users\www\AiCode\WVmp\wvmpTest\src\targets\wvmp_protect.h
Get-Content C:\Users\www\AiCode\WVmp\wvmpTest\src\targets\wvmp_protect.h | Select-String "WVMPBEG1|WVMPEND1|__declspec|noinline"
Test-Path C:\Users\www\AiCode\WVmp\wvmpTest\kernels.toml
Get-Content C:\Users\www\AiCode\WVmp\wvmpTest\kernels.toml
```
   预期: pragma optimize off / 14 PROTECT_BEGIN / 14 PROTECT_END / wvmp_protect.h 存在 + 含 WVMPBEG1/WVMPEND1 / kernels.toml 6 passes + seed=12345

3. **行为层复跑** (B.2, D1.1):
```bash
cd C:\Users\www\AiCode\WVmp\wvmpTest
# 重建 wvmpTest  (沿用 build.bat, 任何目标改动)
.\build.bat
# 重跑 packed.exe
C:\Users\www\AiCode\WVmp\wvmpTest\build\x64\packed.exe > out\verifier_packed.log 2>&1
C:\Users\www\AiCode\WVmp\wvmpTest\build\x64\test_target.exe > out\verifier_unpacked.log 2>&1
diff out\verifier_unpacked.log out\verifier_packed.log
echo diff_exit=$?
Get-Content out\verifier_packed.log | Select-String "SUMMARY|FAIL"
Get-Content out\verifier_unpacked.log | Select-String "SUMMARY|FAIL"
Get-Content out\verifier_packed.log | Select-String "kern.sha256"
```
   预期: SUMMARY passed=103 failed=0 (两边一致) / diff 空 / `[PASS] kern.sha256_block_vectors`

4. **byte-exact cross-verify** (B.3):
```bash
diff C:\Users\www\AiCode\WVmp\wvmpTest\out\base_packed.log C:\Users\www\AiCode\WVmp\wvmpTest\out\verifier_packed.log
diff C:\Users\www\AiCode\WVmp\wvmpTest\out\base_unpacked.log C:\Users\www\AiCode\WVmp\wvmpTest\out\verifier_unpacked.log
```
   预期: 两个 diff 都空 (除非 seed 变更, 当前两者都用 seed=12345)

5. **conflict root cause** (B.4, D2.1):
   verifier 在 .multica/mit379-ruling.md 必写明:
   - agent 自述 "kern.sha256_block_vectors expected 128bit hex string, but got garbage" 与 fresh verify `[PASS] kern.sha256_block_vectors` 矛盾的根因
   - agent 自述 "packed.exe segfault 0xC0000005" 与 fresh verify passed=103 矛盾的根因
   - 派活单 §A baseline (项目主已校) vs agent commit message 自述哪边可信, 为什么

6. **最终 verdict**:
   - 6 项全 PASS → ACCEPT, MIT-379 push done
   - 任何 1 项 FAIL → REJECT + 写明根因 + 派单修复方向

---

## §F known compromise

- agent commit message 自报 status=blocked (honest disclosure pattern 13)
- 项目主 fresh verify 实证 commit 6f23f8e 实际达成
- verifier 必须给 conflict 解释 (D2.1), 不接受 agent 单方面 blocker 描述
- 沿用 MIT-375 hotfix v1-v6 链教训: agent 自报 "build PASS / ctest PASS / 验证完成" 必须独立 fresh verify, 不盲信

---

## §G 沉淀 (durable lessons)

- pitfall #33: 派活单 §A 数字错 ("16 函数" 应改 "14", pitfall #70 反复出现)
- pitfall #70 CONFIRMED: 派活单派发**前**项目主 fresh verify 必跑 §A baseline (14 vs 16 数字差已纠正)
- pattern 13 honest disclosure: agent 设 status=blocked 是正确行为, 但 commit message 自述必须独立复验 (本次是典型案例: agent 自报 segfault, 实际 passed=103)
- wvmpTest packed.exe byte-exact diff 验收流已稳定 = "build → protect → 双跑 → diff 空" = 标准 wvmp 验收路径, 推广到所有 wvmpTest kernels

---

## §H close-out

- verifier 完成 → 写 `.multica/mit379-ruling.md` (9605 bytes MIT-375 模板同口径)
- 项目主 fresh verify (沿用 §E 1-5 步) → multica issue status MIT-379 done
- 不需要新 commit / 不需要 cherry-pick / 不需要 amend
- 后续: MIT-373 / MIT-374 / MIT-389 / MIT-390 沿用同一裁定模板 (MIT-375 模式), 项目主串行推 done

== 派活单完 ==