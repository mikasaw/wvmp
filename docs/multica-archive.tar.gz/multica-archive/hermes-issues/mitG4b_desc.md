# WVmp MIT-G4b 派活单 — lock inc/dec 原子补齐（419 残余清偿，InterlockedIncrement/Decrement 真产物）

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: MIT-419 done (main `92b21cb`, lock 族主体, 基线 37 样本 **185/185**) | 419 §六 自报残余: "lock inc/dec 未入面 (InterlockedIncrement/Decrement 真产物, CRT 高频)" | 419 D1 原子性边界框架
> 前置阅读: 本单 → 419 交付 (`x86_translate.cpp` translate_lock_op :1565 + 标记域枚举 :1431-1435 + 入口派发 :1813-1819 / translator.cpp `is_lock_marker` :69-73 + `is_lock_carrier_op` :77-86) → `.multica/mit419-ruling.md`

---

## §A 基线实测事实 (项目主 fresh verify @ main 92b21cb, 2026-08-30 03:4x)

### A.1 现网
- main = `92b21cb`; build 0 错 / ctest 16/16 / **multiseed 37 样本 × 5 = 185/185** / wvmpTest 14/14 满贯
- 命名分支铁律连 2 单满分 (417/419), 本单继续适用

### A.2 lock 框架现状 (419 遗产, 本单是白名单+标记域扩展, 非新机制)
- `translate_lock_op`: F0 独前缀(+REX) + mem-dst 白名单 {ALU7 族, cmpxchg, xchg, xadd, bts/btr/btc} → 剥 F0 复用本体 / Mov 载体族
- **src2=imm 标记域现状 (双文件镜像对账)**: `5..8` = Mov 载体族 (kLockXadd/kLockBts/kLockBtr/kLockBtc), `9..11` = 本体 op 族 (kLockStripAlu/Cmpxchg/Xchg); lifter enum (:1431-1435) 与 translator enum (:69-70) **必须同步扩**
- **419 铁律 (载体域碰撞第 3 次教训)**: `is_lock_carrier_op` op 限定防 imul 3-op imm 撞值域; **本单扩域 12.. 前必须全域对账**——见 §B.1 硬要求
- 本体通路实测在位: `translate_unary` (:151-157) **dst 允许 Mem** (Inc/Dec 走它), translator dst=Mem 一元折条: 你实测 `:1295` 域 Inc/Dec 是否已折 (ALU 折条 if 分支是否覆盖一元 op——**419 报告说"折条复用 Inc/Dec 本体通路"是项目主建议, 非实测确认, 你自己验**)

### A.3 目标形态 (MSVC 真产物先验, 你反汇编实证 #33)
```
_InterlockedIncrement(&g_i32)  → f0 ff 06 / f0 ff 00   lock inc dword ptr [..]
_InterlockedDecrement(&g_i32)  → f0 ff 0e              lock dec
_InterlockedIncrement64(&g_i64) → f0 ff 00 (REX.W)     lock inc qword
```
频率主张 (419: "CRT 内高频") 你样本区实测反汇编复核。SDM 补正: **lock not/lock neg 合法** (F7 /2、F6|F7 /3 特例)——419 的负例清单把它们拒了属保守正确但登记"合法可锁族未入面"; 本单 D2 一并裁决。

## §B 任务

1. **B.1 标记域扩展 + 全域对账 (本单灵魂)**: 扩 `kLockStripInc=12` (或你的方案), **动手前**完成 419 铁律对账清单并写进报告: ① 全仓 grep 所有 `src2.*imm` 写入点与读取点 (lifter 各 translate_* + translator 各消费函数) ② 新值 12/13 与现存"任意 imm 落 src2"op (imul 已知, 还有谁?) 的碰撞面枚举 ③ `is_lock_carrier_op` 补 Op::Inc/Op::Dec 后, Inc/Dec 的 src2 默认值实测 (translate_unary 不设 src2——其 kind 默认是否 Imm? 若是, 默认 imm=0 不在 5..13 域则安全, 给证据) ④ 双文件 enum 镜像同步
2. **B.2 lifter**: translate_lock_op 白名单 + {inc, dec} (S32/S64, mem-dst 唯一形状; reg-dst `lock inc ecx` 非法→拒); 剥 F0 lift 本体 Op::Inc/Dec + 标记
3. **B.3 执行语义选型 (D1)**: **优先零新 VmOp 折条** (Load→Inc→Dec→Store, 撕裂窗口同 ALU 族, GAPS 边界文本并入既有"折条路径"段) —— Inc/Dec 与 add/sub 1 差值, 硬件原子收益低于 xadd (计数器竞态丢增量=真实 bug 面! **这条你实测想想再裁决**: inc/dec 丢更新恰是 InterlockedIncrement 的存在意义, 撕裂窗口语义损失比 add 更隐蔽? 若你判定应走 native 单 VmOp handler (keystone `lock inc` 编码实测, 419 build_xadd 模板), 换路不算失败但+2 VmOp+2 handler+影子读回全套)
4. **B.4 D2 lock not/neg**: 入面 (本体 Not/Neg handler 已在, 折条同族) 或 继续 gate——按真实产物频率实测裁决 (MSVC 不产 `lock not/neg`, 仅手写/第三方), 砍面则 GAPS 残余改精确文本
5. **B.5 E2E**: `wvmp_atomic_incdec_sample` (MASM lock inc/dec 双宽 + C++ _InterlockedIncrement/Decrement 真产物双路 + 循环计数语义校验 + rip 目标变体 + 负例: `lock inc ecx` reg-dst 非法/`lock not` 若 D2 砍面) ; REQUIRE_REAL 主函数; multiseed 37→38 (预计 **190/190**)
6. **B.6 GAPS**: G4 节残余行收口 (inc/dec 摘除 + not/neg 按 D2 结果精确化) + note 域对账记录
7. **B.7 硬条款 (419 版)**: 命名分支 (`mit-g4b-lock-incdec`) + main 未动 + tracked 零脏附输出 + 切回 main + 单 commit ff-safe + ≥30 分钟 + 时间对账

## §C 决策点 (项目主已拍板)

- **D1 折条优先, native 授权换路** (✅ 见 B.3——但 B.3 的"丢增量"语义论证你要写进报告, 不能只按工作量选)
- **D2 not/neg 按频率实测** (✅ 倾向: 无真实产物则 gate+精确文本, 省面)
- **D3 标记域方案自由** (✅ 12/13 顺号或重排, 但 B.1 对账清单不可省)
- **D4 不动 419 已交付面** (✅ xadd/bts/cmpxchg/ALU 族零触碰, 只扩白名单/域——回归锚 185/185 全绿)

## §D 验收标准

1. build 0 新警 / ctest 16/16 (+lifter lock-incdec ≥4 用例 + translator 形状/note 用例, **含"imul ...,12 不误拦"回归用例——419 教训的直接固化**) / multiseed **190/190**
2. 新样本真虚拟化 + 语义值 (增量结果/flags: inc/dec 不写 CF! SDM——你实测 VM flags 语义与原生逐位一致) + 负例 gate 逐字节
3. 实汇编对照表 (B.3 选型证据链 + keystone 编码实测若走 native)
4. 零回踩: 185 既有全绿 + wvmpTest 14/14 + jump-table/ExitNative 17/lock-strip note 面原样 + 双跑 103/103 diff 0
5. 冻结契约: runtime.hpp/ir::Op/backend.hpp/callgate/kExitSlotDepth + 419 面 (xadd/bts enum 值域不重排)
6. B.1 对账清单完整入报告 (缺项=一票否决)
7. 硬条款全套 (§B.7)

## §E 纪律

worktree 隔离 / wvmpTest 禁覆写 / `cmd /c` / vendored capstone 枚举实测 (INC id 的 lock 形态 prefix 报法——419 实证 capstone 会吞 F0, 字节扫描纪律继承) / ml64 拒码兜底 db 直发 (416/419 先例) / **#33**: §A.3 产物字节与 §A.2 "本体通路已在"两处都是先验, 实测推翻优先。

## §F known compromise 预判

1. 折条路径撕裂窗口扩大 (inc/dec 并入 GAPS 既有边界段) 或 +2 VmOp 原子保真——D1 二选一都合法, 报告说清
2. not/neg 按 D2 可能续 gate
3. `xadd` reg-mem 双形态 / bts reg 形式等 419 既有残余不动

时间预算: ~半天内 (框架全在, 主要是 B.1 对账+B.3 论证)。== MIT-G4b 派活单完 ==
