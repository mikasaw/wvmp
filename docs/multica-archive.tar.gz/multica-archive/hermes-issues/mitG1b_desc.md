# WVmp MIT-G1b 派活单 — SSE 收官包：mul 族 + andnps/andnpd + SSE2 整数族（指令虚拟化阶段最后一张 SSE 单）

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: G 线收官序 | main `123bf09` (423 合入后, 基线 38 样本 **190/190**, wvmpTest 14/14) | 缺口清单 R1(mul)+R2(SSE2 整数)+R3(andnps) 三项合一 | 424/G6r 排程建议: **G1b 先行, G6a(VEX.128) 将直接复用本单产物**
> 前置阅读: 本单 → 408 (XmmLoad/XmmStore+sd 族模板) → 376 (`translate_sse_bitwise` @translator:1521 + `translate_ucomis`) → 411 (pd 折叠 ps / comiss 折叠 ucomis 先例) → `.multica/mit-G6r-triage.md` §档A

---

## §A 基线实测事实 (项目主 fresh verify @ main 123bf09, 2026-08-30 17:0x)

### A.1 现网
- main = `123bf09`; build 0 错 / ctest 16/16 / **multiseed 38 样本 × 5 = 190/190** / wvmpTest 14/14 + jump-table/ExitNative 17
- 硬条款三连满分 (417/419/423), 本单第四单延续

### A.2 三个缺口面 (全部本轮 grep 实测 =0, 非文档推断)
| 子项 | 现状 | 模板锚 |
|---|---|---|
| **R1 SSE mul 族** `mulss/mulsd/mulps/mulpd` | `X86_INS_MULSS/MULSD/MULPS/MULPD` 白名单 **0**——add/sub/div 全在、mul 独缺 (371-376 时代遗留, 411 报告 §六.3 登记"仍 gate") | add 族三件套 (371) + 408 mem 源折条全链复用; `Op::Mul` GP 语义已占 (整数乘法)——**ir::Op 冻结下 SSE mul 的折叠方案你实测选** (复用 Addss 通路改 aux? or (Op,Size) 双语义先例 408?) |
| **R3 andnps/andnpd** (0F 55 / 66 0F 55) | `ANDNPS` 白名单 **0**; 411 说"留 412+"但 412 是 x86 侦察——**漏网债**, 419/423 样本还拿它当负例钉着 | 411 `translate_sse_bitwise` 三 case 折叠先例; **语义注意 andnps = NOT(dst) AND src**——非纯位运算三元组可折叠, 需 Andps+Not 两条折 或 新 VmOp, 你实测选 (411 主样本 andnps_neg=F0F0F0F0 手算基线现成) |
| **R2 SSE2 整数族** `pand/por/pxor/pandn (66 0F DA-EB)` + `movd/movq (66 0F 7E / 0F 7E / REX.W)` + `paddq/psubq` 系 | 白名单 **0** (GAPS:152 混列行) | **关键先验 (424 §B.1 实测)**: MSVC 对 `_mm_and_si128/_mm_xor_si128` 等 **/arch:SSE2 直产 pand/pxor legacy 编码** (与 411 发现 ps/pd 互认同理), 整数 SIMD 是 memcpy 式位操作常客; `movd xmm,r32 / movq xmm,r64` 是 GP↔xmm 桥 (新语义面: 两侧状态互写, 413 XmmLoad GP 双槽先例反用) |

### A.3 频率与优先级实测输入 (项目主预裁定 D3 依据)
- 424 triage 真实语料: smartscreen vpxor **4634 条** (intrinsic 为主)、ucrtbase vmulsd/vaddsd 高频 (mul 族=浮点热循环基本盘)、python314 位混合族常客
- **mul 是 4 个中唯一"编译器自然产物高频"** (任何 FP 乘/除都躲不开, /Od 直产 mulss/mulsd)——样本可纯 C++ 天然形态, 与 411 的 comiss 同路

### A.4 411 GAPS 债 + 顺带项
- GAPS:152 混列行 ("andnps/andnpd、comiss/comisd...AVX/x87/SSE2 整数族") 中 comiss 已由 411 收、x87 已由 418 拆独立节——本单后该行仅剩 AVX (转 424 路线) + 本单收口面, **改写为精确残余文本**
- **GAPS:194 `kVmOpMax=86` stale** (419 后=90, 424 顺手指认) → 本单注册行顺带刷新 (408 尾巴同款纪律)

## §B 任务

1. **B.1 R1 mul 族**: `mulss/mulsd/mulps/mulpd` lifter+translator 全链 (reg-reg + **src=mem 含 rip** 一次到位——408 通路现成); ir::Op 折叠方案实测选型披露 (禁扩 ir::Op 冻结枚举)
2. **B.2 R3 andnps/andnpd**: 语义 NOT(dst)&src 双折或新 VmOp 你选 (411 手算基线 F0F0F0F0 进单测); pd 变体按 411 ps/pd 互认先验折叠
3. **B.3 R2 SSE2 整数**: 分两档诚实交付——**档① pand/por/pxor/pandn** (408 XmmLoad/Store 16B 通路+位运算模板, M 内) **必做**; **档② movd/movq GP↔xmm 桥 + paddq/psubq** 若实测复杂度爆面, **砍面留 G1c 不算失败** (披露工作量证据)
4. **B.4 411 负例翻转**: 419/423 样本里 andnps/pand 类 gate 负例断言按新面精确翻转 (andnps 转正例; 仍 gate 的族如 paddq 若砍面保留负例)——**同 exe 负例区清单逐条对账进报告**
5. **B.5 E2E**: `wvmp_sse_fin_sample` (主: mul 族 C++ 天然 + _mm_and_si128 intrinsic 真产物 + andnps 手算基线) + 影子 (`wvmp_sse_fin_xmm_readback_sample`, #79 全套: 新 handler 进 `dump_handler_xmm_check.py` 注册表 + ctx.xmm 读回) + REQUIRE_REAL; multiseed 38→39/40 (预计 **195-200/195-200**)
6. **B.6 enum/容量**: 新 VmOp append-only #34 自查 (kVmOpMax 90→≤95 预算; **跳表 128 余量 33——本单族面严禁越界挤 G6a/x87 空间**, 估算入报告); GAPS:194 stale 行顺带修
7. **B.7 GAPS**: :152 行改写精确残余 (mul/andnps/pand 摘除; AVX 指 424 路线; 档② 若砍面留 G1c 登记) + STATUS 同步

## §C 决策点 (项目主已拍板)

- **D1 单张全收** (✅): R1+R2 档①+R3 合一; R2 档② 授权砍面留 G1c
- **D2 折叠优先于新 VmOp** (✅): 411 ps/pd 互认 + 408 双语义先例; but **mul 的 Op 撞名 (GP Op::Mul) 解法不许 hack aux 位域**——干净方案 (如复用 Addss 编码族扩 (Op,Size) 语义表) 才收
- **D3 movd/movq 桥是 G6a 前置判据** (✅): 424 档A 的 VEX 整数族复用度取决于本单 movd 通路——若你判定档②复杂度值得提档, **可反向把 movd 从档②提到档①**, 披露理由即可 (D1 的"砍面"允许双向)
- **D4 不做 FMA** (✅): 424 🟢#3 双舍入红线, 独立面 (仅 /fp:fast), 不混本单

## §D 验收标准

1. build 0 新警 / ctest 16/16 (+新用例每子族 ≥2) / **multiseed 全绿** (预计 195-200, 39/40 样本)
2. 新样本真虚拟化 + mul 语义值 (整数乘积双精度手算) + andnps F0F0F0F0 基线 + pand 位图案; 影子 byte-exact; 负例翻转对账表 (§B.4)
3. 实汇编对照表: _mm intrinsic → MSVC 产物字节 (实测, 预期 legacy pand/mulss 形态, 424 先验) → IR → VmOp 链路
4. 零回踩: 190 既有全绿 + wvmpTest 14/14 + jump-table/ExitNative 17 + lock-strip/string-op note 面原样 + 双跑 103/103 diff 0
5. enum ≤95 (跳表余量守护, §B.6) + 冻结契约全套 (runtime.hpp/ir::Op/backend.hpp/callgate/419 lock 面/423 标记域)
6. 硬条款: 命名分支 `mit-g1b-sse-finale` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账
7. dump/static 双门 PASS (新 handler 全进注册表, #79)

## §E 纪律

worktree 隔离 / wvmpTest 禁覆写 / `cmd /c` / vendored capstone 枚举名实测 (MULSS id 与 GP MUL id 分裂度, 404 CDQE/MOVSXD 教训) / **#33**: §A.2/§A.3 三处先验 (mul 纯 C++ 天然产、pand intrinsic 直产 legacy、andnps 双折可行) 全部实测兜底, 推翻优先。

## §F known compromise 预判

1. R2 档② (movd/paddq) 可能延 G1c——但 movd 是 G6a 依赖, 砍面需同步知会 G6a 派单
2. andnps 双折 (Not+And) 字节码 ×2 膨胀, 频率低可接受
3. SSE 整数比较族 (pcmpeq 系) 不在本单面 (GAPS 精确文本登记)

时间预算: ~1 天 (三子族全在既有模板上, 但面广)。== MIT-G1b 派活单完 ==
