# WVmp MIT-X3b 派活单 — asmgen x86 整数面全支持：A 档 ~45 宽度模板批迁 + B 档 GP（Push/Pop/RVA 族）+ translator pop 宽度/S16 串形收口

> 派活单生成: 2026-09-01, 接手人 (项目主)
> 关联: 多目标平台 X3 拆单第 2 张 | main `4050a4c`（443 X3a 合入后, 基线 50 样本 250/250, 十四连）| 交接权威 = `docs/GAPS.md:745-760`（X3a 交接注记, 动手前通读）+ X0 triage §3 + 443 裁定 §4 | 地基: asmgen 双模/池 6/entry/dispatch/x86 dump 门全部就位, **X3b = 直接往 x86 handler 表加行 + 电池加 TEST 行**（X3a 可扩展设计兑现单）
> 交付形态: **main 之外的命名分支 `mit-x3b-asmgen-int`**（硬条款十五连, 违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main 4050a4c, 2026-09-01 16:1x)

### A.1 现网
build 0 / ctest 16/16 / multiseed 250/250 / wvmpTest 14 stubs 双跑 diff 0；kVmOpMax=97（余量 30 不动——**本单禁新 VmOp**）；D1 硬拒维持（X5 拍板）；x86 交叉构建链两条已独立可重建（x64 380/380 + x86 119/119, `build_x86_tests.bat`）。

### A.2 handler 面对账（4050a4c 实测）
- x64 表: 115 登记行 / **96 唯一 VmOp**；x86 表: `asmgen.cpp:4057` 起, 29 登记行 / 电池集 19 函数（`build_x86_mov` 等, 三宽度 S8/S16/S32 显式 cmp/je 分派, S64 防御 no-op）
- **仍纸面 ~77 op**（x86 码体内跳表折叠 Halt, 恢复友好）= GAPS:745-760 已分档:
  - **A 档** ~45: 宽度模板平移（Mul/Div/Mulhi/Shift 族/Not/Neg/Movsx/Movzx/Rol/Ror/Bmi 支撑 op/Sbb/Adc/Cmovcc/Test? 族——**具体清单自己按 x64 表对账 x86 表补集列全**, 以补集为准不许数"45"这个粗数）
  - **B 档 GP**: Push/Pop（**4B 槽问题**: 442 translator 注"rsp 槽算术恒 S64=VM 槽宽与 arch 无关" vs 交接注记"Push/Pop 4B 槽"——guest esp 步进 4B vs ctx 槽 8B 读写的分界自己核清, 给裁决表）+ RVA 族（image_base imm32 语义在 32 位=identity? 你实判）+ Jmp/Jcc S32 目标（X3a 已做, 验证性回归即可）
  - **translator 面收口（442 挂账③）**: pop 位宽（442 只 gate 了 push S16/S8——pop 对称面核对）+ S16 串形元素宽（442 砍了串形 S16——现在 x86 真需求来了, 评估 size 参数化通路; 做不动维持 gate 如实披露, **别硬开静默错形**）
- **本单不碰**（X3c 面, 别越）: CallGate reg-target / ExitNative 4B / Ret x86 协议面 / SSE 族 34 handler / x87。
- 电池扩展三件套（X3a 设计）: `tests/test_runtime_x86.cpp` 加 TEST + handler 表加行 + `verify_x86_dump.py` BATTERY_HANDLERS 集合同步——**三处每 handler 齐动, 缺一即 dump 门/电池不对账**。

### A.3 结构约束（X3a 遗产, 沿用）
- 池 6/临时 4 + 固定栈帧 0x24 spill；rs() x86 数据临时限 {eax,edx,ebx}（bpl/sil/dil REX 专属）——批迁 handler 若需 >4 并发 temp 按 X3a spill 模板走帧槽, 禁私加寄存器
- zero5 x86=空（setcc 直写帧槽+movzx 读）——flags 捕获族 handler 全按此模板
- dispatch 双字取指已落帧——handler 消费 insn_lo/aux 帧槽约定对齐 X3a 面

## §B 任务

1. **B.1 A 档批迁（主菜）**: 补集清单先入报告（每 op 一行: 名称/x64 模板函数/宽度组合/是否 flags 捕获/电池用例名）→ 批迁 → 每 handler ≥1 真执行语义断言（32 位进程内）+ 边界值（Mul 溢出/Div 除零 gate 面/Shift count 掩码 0x1F vs 0x3F 差异——**x86 移位掩码 S64 档不适用但 S32=0x1F 与 x64 相同, 实测钉**）
2. **B.2 B 档 GP**: Push/Pop 4B 槽裁决表（esp 步进/ctx 槽读写/S16 push 维持 gate 口径核对）+ 电池；RVA 族 x86 语义实判 + 电池（如可达）
3. **B.3 translator 收口**: pop 位宽对称面 + S16 串形评估（做/不做都给证据; 做则 x64 零回踩+lifter/translator 面 diff 最小化——**translator 改动本单获授权**, 443 时"translator 零触"口径由本单显式解禁此项, 其余面维持）
4. **B.4 电池规模目标**: x86 真可跑面从 19 → **60+**（A 档全 + B 档 GP; 除零/未支持形保持折叠 Halt 语义）；FiveSeed 型稳定性用例扩到新 handler 抽样（不必全乘, 但 ≥15 op 抽查）
5. **B.5 x64 零扰动铁证（D6 沿用）**: 双 CLI 同 seed asm_dump 逐字节恒等（X3a 底稿 161,756B 可作起点参考）+ multiseed 250/255（若 B.3 动了 translator 产生新样本形态则按需+1 样本入池, 上限 51）+ wvmpTest 双跑 diff 0 + ctest 16/16
6. **B.6 dump 门/静态门同步**: BATTERY_HANDLERS 集合 60+ 全覆盖 + 静态裸立即数扫描 PASS（x86 码体面同跑）
7. **B.7 文档**: GAPS 交接注记翻正（真可跑清单/仍纸面清单=X3c 输入精确化: SSE 34 + callgate/ExitNative/Ret 协议面）+ STATUS 里程碑行

## §C 决策点（项目主已拍板）

- **D1 批迁以补集为准**（✅）: "45"是 GAPS 粗数; 你列的补集清单若把某 op 判归 X3c（协议依赖）→ 移出并披露, **宁少而准勿凑数**
- **D2 除零/协议依赖形保持折叠 Halt**（✅）: Div/Idiv 真执行涉异常边界（VM 内 #DE 语义未定义）→ 维持折叠, 入 X3c/未来单评估; 别为凑数造异常语义
- **D3 冻结面维持**: kVmOpMax=97 / runtime.hpp / kCtxSize 0x1C8 / 载体域 0..28 / backend / markers / SDK / cli / 池规模 6——**唯二解禁**: asmgen.cpp（主角）+ translator.cpp（限 B.3 pop 宽度/S16 串形两点）; 其他越界想法=停手评论
- **D4 保存区规则维持**（X3a 裁决）: guest 栈写恒 ≥ns; push/pop 批迁不得引新越界形
- **D5 x64 恒等口径沿用 D6/433**: 逐 handler dump 对账, 禁 packed sha 论恒等
- **D6 若单会话吃不下 60+**: **按 A→B→B.3 顺序分档交付, 每档全绿（电池+门+回归）再推下一档**——半程停手如实标注仍纸面集, 比"全迁但验不透"值钱（427 观察纪律）

## §D 验收标准
1. x64 build 0 新警 + ctest 16/16 + multiseed 250/250（±新样本口径见 B.5）+ wvmpTest 双跑 diff 0（stubs=14 不变）
2. **x86 电池扩面真跑**: 32 位 exe 项目主将亲手 WOW64 复跑——全绿 rc=0; 新 handler 语义断言逐 op 可点数（报告含补集清单↔TEST 名对照表, 一 op 不漏）
3. x86 dump 门 PASS（BATTERY_HANDLERS 同步后）+ 静态扫描 PASS
4. x64 asm_dump 双 CLI 逐字节恒等（证据贴报告: 双方 sha256+size）
5. B.3 translator 改动: 每点独立 commit + x64 零回踩证据（若 S16 串形开面, 442 负例区行为对账）
6. 冻结契约（D3 唯二解禁外）零 diff；kVmOpMax=97 不动
7. 硬条款: 命名分支 `mit-x3b-asmgen-int` + main 未动 + tracked 零脏 + **切回 main + worktree 自拆**（443 模范执行, 十五连延续）+ ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 + 多轮小步 commit（A 档按族分批, 每批绿一次提一次——大 diff 一把梭禁）/ wvmpTest 禁覆写 / `cmd /c` 查时间戳 / **#33 主战场**: A.2 全部粗数（45/GP 4B 槽/RVA 语义）实测兜底, 交接注记与本单任何锚失配→报告点名 / 载体域若涉新值=停手（本单理论上不该碰）/ 卡壳 ≥2h 评论披露, 交付节奏>一次成型。

## §F known compromise 预判
1. 补集判归 X3c 的协议依赖 op（如 Cmc/Std/Cld 已折叠形? 以实测为准）——移出披露即合格
2. RVA 族在 x86 全管道未通前纸级（电池层可验生成语义, E2E=X5）
3. Div/Idiv 折叠=整数面"全支持"的有意例外（D2）——x86 客户产物含除法函数时再评估异常语义

时间预算: ~2 天。交报后项目主按剩余纸面真数重排 X3c（SSE 34 + 协议面可拆 X3c/X3d）。== MIT-X3b 派活单完 ==
