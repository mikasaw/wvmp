# WVmp MIT-F1 派活单 — BytecodeCodec 接线：.wvmp 字节码流加密（M3 保护强度线第一棒）

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: MIT-409/A6 done (main `c04ca49`, wvmpTest **14/14 满贯**, 基线 150/150) — 正确性线全部收口后转入 GAPS"保护强度缺口"表首项
> 前置阅读: 本单 → `docs/GAPS.md` 强度表 → `vm/include/wvmp/vm/backend.hpp` :9-13 (BytecodeCodec 抽象) → `passes/crypt/src/crypt_pass.cpp` (TODO 占位) → `stub_link_pass.cpp` blob 布局

---

## §A 基线实测事实 (项目主 fresh verify @ main c04ca49, 2026-08-29 20:3x)

### A.1 现网
- main = `c04ca49`; build 0 错 / ctest 16/16 / **multiseed 基线 30 样本 × 5 = 150/150** / wvmpTest 14/14 + 双跑 103/103 byte-exact
- **覆盖率线已收官**: GAPS 正确性 C1-C4 全关 (含跳转表特化); 强度表 6 项全部 = 占位/未做 (GAPS 原文照抄: crypt / mutate / anti_debug / integrity_crc / import_protect / W^X / flags 活跃性)

### A.2 crypt lane 现成骨架 (本单接线对象)
| 锚 | 实测 |
|---|---|
| `BytecodeCodec` 抽象 | `vm/include/wvmp/vm/backend.hpp:9-13` — `virtual void encrypt_stream(Rng&, std::vector<u8>& bytecode)` **接口已在, 无任何实现类** (grep 全仓 0 实现) |
| `CryptPass` | `passes/crypt/src/crypt_pass.cpp:8-11` — 函数体仅 TODO 注释 ("run BytecodeCodec::encrypt_stream over vm.program bytecode and record codec metadata for the interpreter decrypt stub") |
| seed 通道 | `cli/src/config.cpp:133-138` seed 已解析入 config; multiseed 5 seeds (1/12345/99999/3735928559/3405691582) 走此字段 |
| blob 布局 | stub_link: 全函数字节码流拼成连续 blob @ .wvmp 节 (RWX, `stub_link_pass.cpp:27` v1 取舍注释); dispatcher 经 `ctx.bytecode` 读 — **加密对象 = blob 字节区间, 解密时机自选 (stub 内/vm_entry 前)** |
| 管道注册 | 6-pass 顺序 pe_loader→marker_scan→lifter→virtualize→stub_link→pe_writer; crypt 在注册表但**不在 kernels.toml/样本管道内** (启用面含配置文档) |

### A.3 验收口径的连锁影响 (项目主预判决策见 D3)
multiseed/wvmpTest 现口径 = packed 与 native **stdout byte-exact**——加密不改变 stdout, 口径不变; 但"同 seed 两跑产物 byte-exact"的构建确定性必须保持 (encrypt 用 seed 派生 keystream, 禁 entropy/时钟)。**回归新面**: 5 seeds × 30 样本下每 seed 的 packed 字节流不同但行为全等 → multiseed 脚本本就逐 seed 独立跑, 零改动适配 (实测确认)。

## §B 任务

1. **B.1 实现 BytecodeCodec 子类** (放 `passes/crypt/` 或 `vm/` 内, 你选型): keystream XOR (推荐 RC4-in-keystream 或 SHA-256-CTR 派生自 seed; **禁自定义弱轮函数**——强度线代码自己不能是弱点)。接口冻结: backend.hpp 抽象签名一字不动, 新增实现类合规
2. **B.2 CryptPass 接线**: 在管道中拿到 blob 后 encrypt_stream + 写 codec metadata (密钥/偏移/长度入 stub 生成端可读位置); **pass 顺序**: crypt 必须落 stub_link 前 / blob 定稿后的正确位置, 你按 framework 契约实测选型并披露
3. **B.3 解密 stub 生成**: runtime 入口路径 (vm_entry prologue 或 stub) 对 blob 区间原地 XOR 解密; 解密代码本身禁新增可预测特征常量 (v1 允许简单形态, 特征消除留 F2+); **ExitNative/callgate/HALT 全链在解密后字节码上运行的语义零变化**
4. **B.4 强度自证**: 新 verifier 脚本 `scripts/verifier/bytecode_crypt_check.py` — 对 packed.exe 断言: ① .wvmp blob 区间 capstone 反汇编不出合法 handler 序列 (静态不可读) ② 同 seed 二次构建 blob 字节一致 (确定性) ③ 不同 seed blob 字节不同 (seed 敏感性)
5. **B.5 E2E**: kernels 配置管道启用 crypt pass (wvmpTest 侧 kernels.toml 加一行——**wvmpTest 仓库改动走同单披露, 主仓外改动需列文件**) ; 新 E2E 样本可省 (既有 30 样本即全回归面), 但 multiseed 全绿必须含 wvmpTest 双跑 (sha256 类内核重跑, 行为不变)
6. **B.6 开关与默认**: config `crypt = false` 默认关 (渐进启用, 不破坏任何未显式开启的既有行为); 开启面 = 新样本/文档/wvmpTest 配置
7. **B.7 文档**: GAPS 强度表 crypt 行更新 + README/docs 配置说明 + 已知强度边界 (见 §F)

## §C 决策点 (项目主已拍板 2026-08-29)

- **D1. keystream 算法 = SHA-256-CTR** (✅ 已定: 仓内已有 sha256 依赖? **无则内嵌单文件实现**——禁拉新第三方库, 内嵌实现附 KAT 测试向量; RC4 为 fallback, 你实测后择一披露)
- **D2. 解密时机 = vm_entry 前一次性原地解密整 blob** (✅ 先验推荐; 若你实测发现 stub 内解密更省 (如 runtime dump 钩子位置) 可换, 披露即可; **逐条懒解密不做**——F1 目标是静态不可读, 非抗动态 dump)
- **D3. 验收 byte-exact 口径**: stdout 行为口径不变; 新增"同 seed 产物字节确定"由 B.4② 保证; multiseed 脚本零改动 (A.3 实测)
- **D4. 默认关** (✅): 未开 crypt 的 150 既有 runs 必须逐字节不动 (零回踩底线); 开 crypt 的新回归 = wvmpTest + 你选的代表样本集 (≥5 样本 × 5 seeds 全绿, 报告列明选择理由)

## §D 验收标准

1. build rc=0 (0 新警) / ctest **17/17 或 16/16+KAT 并入既有** (codec 单测必新增: KAT 向量 + keystream 确定性)
2. **零回踩**: multiseed 默认 (crypt=off) REQUIRE_REAL=1 = **150/150** 且产物与 main 逐字节一致 (抽 3 样本 diff packed.exe 哈希)
3. **开启面**: crypt=on 下 wvmpTest 14/14 + 双跑 103/103 byte-exact + 代表样本集 ≥25 runs 全绿; ExitNative 17 站点 + jump-table diag 全数原样
4. B.4 三断言 verifier 脚本 PASS (静态不可读 + 确定性 + seed 敏感)
5. 冻结契约: backend.hpp BytecodeCodec 签名 / runtime.hpp 布局 / callgate/ExitNative 链 / ir::Op 零触碰; `.wvmp` 节大小增幅报告实测数 (keystream 不落盘则增幅应≈0, 解密代码 ≤ 数百 B)
6. 报告含: 算法/时机选型披露 + 强度边界自述 (§F 对齐) + 开启面样本选择理由 + 硬条款 (git CLEAN 附输出 / 切回 main / 单分支 ff-safe)
7. ≥30 分钟; 数据主张附复跑命令

## §E 纪律 (407 v2 版全文继承)

worktree 隔离 / wvmpTest `out/base_*.log` 禁覆写 + **wvmpTest 仓库若改 kernels.toml, 改前 mtime/内容双留档, 报告列 diff** / `cmd /c` / **#33**: §A 骨架若与实测不符按实测调整, 披露优先。

## §F known compromise 预判 (强度自述必含)

1. **F1 只防静态分析** (IDA 直反汇编 blob): 运行时解密后内存明文, 动态 dump/attacher 可取——anti_debug (F2) 与逐条解密 (未来) 的靶子, 非本单
2. key 由 seed 派生且 seed 明文在 config/stub——**密钥管理不在本单面**, 强度上限 = 混淆级, 报告勿称"加密强度"过誉
3. 解密 stub 自身是静态特征点 (F3 handler 变异/特征消除的对象)
4. W^X 仍单节 RWX (GAPS 独立行, 不混入本单)

时间预算: ~1-2 天。== MIT-F1 派活单完 ==
