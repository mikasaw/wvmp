# WVmp MIT-G1 派活单 — SSE 尾扫包：双访存 mem-op 形态 + comiss/comisd + pd 位运算族

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: GAPS 收口计划 (G 线) W1 实施单 | MIT-409 done (main `c04ca49`, wvmpTest 14/14, 基线 150/150) | 408 D3 授权砍面的兑现单
> 前置阅读: 本单 → 计划 `.hermes/plans/2026-08-29_G-gaps-closure.md` §2-G1 → `.multica/mit408-ruling.md` (XmmLoad/XmmStore 通路)

---

## §A 基线实测事实 (项目主 fresh verify @ main c04ca49, 2026-08-29 20:3x)

### A.1 现网
- main = `c04ca49`; build 0 错 / ctest 16/16 / **multiseed 基线 30 样本 × 5 = 150/150** / wvmpTest **14/14 满贯** + 双跑 103/103 byte-exact + jump-table/ExitNative 17 站点全在位
- 环境漂移: multiseed 脚本双探测已根治路径漂移, 镜像 hack 退役 (403 B.3)

### A.2 本单三个挂点 (全部实测定位)
| 子项 | 现状锚 | 缺口 |
|---|---|---|
| **G1-a 双访存** `addsd/subsd/addss/subss/addpd… [mem], xmm` (dst=MEM) | translator `translate_sse_add` @ **translator.cpp:1336**; 408 已通 src=mem (`LeaRva?→XmmLoad→ALU` 三条, @:572/:1326 注释) | dst=MEM 方向仍 gate: 需 读mem→算→**StoreRva/XmmStore 写回mem** |
| **G1-b comiss/comisd** (0F 2F / 66 0F 2F) | `translate_ucomis` (0F 2E 系) 全链在位含 mem src; 白名单 grep `X86_INS_COMIS` = **0** (lifter 未放行) | lifter case + comiss 语义差异实测 (dest=mem/src=reg 方向, flags 语义与 ucomis 同: unordered→ZF=PF=CF=1) |
| **G1-c andpd/xorpd/orpd** (66 0F 54/56/57) | lifter case 仅 `X86_INS_XORPS/ORPS/ANDPS` @ **x86_translate.cpp:1601-1603** (无 66 变体); VmOp Xorps/Orps/Andps @ vm_op.hpp:390-394 | **位运算与操作数宽度无关** (128-bit 全按位) → 假设可**零新 VmOp** 复用 ps 编码 (66 前缀仅语义命名差) — **你必须实测确认后披露**; capstone 对 66-prefixed 报独立 id (X86_INS_ANDPD 等, vendored 版枚举名实测) |

### A.3 编译器形态先验 (样本构造红线)
MSVC /Od 对 `volatile double g_arr[]` 高频产: `movsd xmm0,[g]` / `addsd xmm0,[g+8]` / `ucomisd xmm,[g]`——dst=mem 双访存 (`addsd [mem],xmm`) 与 comiss 是 **/O2 intrinsics 或 xmmintrin 强转形态**，非自然产物。样本必须:
1. 双访存: `volatile double* p; _mm_addsd 不可达时手写` `*(volatile double*)&xmm += x` 不产 mem-op; **推荐 `/O2` 局部 + `_mm_store_sd(&g,_mm_add_sd(_mm_load_sd(&g),v))` 实测反汇编定形** (可能仍被优化回 reg 形态 → 若 MSVC 不产 dst=mem, 用 masm 内嵌 `addsd [rsp+8],xmm0` 或改判样本仅覆盖语义路径, **#33 按实测**, 披露后调整)
2. comiss: `float` 比较 `if (*(volatile float*)&g == f)` 实测 capstone 产物定形
3. 负例: 不可支持混合形态 (如 lock 前缀+66 组合) 断言照旧 gate
4. 主正样本含真可虚拟化函数 (REQUIRE_REAL 红线, 409 教训 ③)

## §B 任务

1. **B.1 translator**: `translate_sse_add` gate 分支扩 dst=MEM 形态 (读→算→写回; 写回复用 XmmStore 通路的 mem 目标变体或 StoreRva, 实测选型披露); rip 目标双访存 (`addsd [rip+g],xmm`) 一并打通
2. **B.2 translator/comis**: `translate_comis` (或参数化 ucomis) — dest/src 方向差异实测后实现; flags 写回真语义 (#79, updates_flags=true)
3. **B.3 lifter**: ANDPD/XORPD/ORPD + COMISS/COMISD 白名单 case; pd 若复用 ps VmOp 则**仅 lifter+translator 层折叠, 注释写明实证依据** (capstone id + 编码字节实测)
4. **B.4 E2E 样本**: `wvmp_sse_memop_sample.c` (+影子 `wvmp_sse_memop_shadow.txt`): 三子项各自正例 + 边界 (NaN comiss→unordered / 对齐非对齐 / rip 双访存) + 负例 gate; 主样本真虚拟化
5. **B.5 注册+基线**: CMakeLists + multiseed (30→31 样本, 预计 **155/155**) + **顺带修 408 尾巴: 脚本注释头样本数与实际数组对齐**; 影子/静态扫描/dump 门: 新 handler 进 `dump_handler_xmm_check.py` 注册表 (#79)
6. **B.6 零回踩**: ExitNative/callgate/jump-table/kExitSlotDepth/kCtxSize 派生链全链禁触碰; wvmpTest 14/14+103/103+17 站点+jump-table diag 原样

## §C 决策点 (项目主已拍板)

- **D1 pd 复用 ps 编码** (✅ 先验推荐, 你实测兜底): 位运算语义与后缀宽度无关; 若 asmgen handler 有 ps/pd 行为分叉证据 → 新 VmOp append-only #34 自查 (kVmOpMax 86→89 预算内)
- **D2 comiss 实现 = 参数化既有 translate_ucomis** (✅): 方向差异用 src/dst 交换 + 条件码映射表; 禁复制粘贴第二套 (维护面)
- **D3 样本形态** (✅): MSVC 不产 dst=mem 自然形态时, **masm 内嵌是正当手段** (壳的目标 = 形态支持, 非编译器意愿); 披露实汇编即可
- **D4 `andnps/andnmpd` 不在本单** (✅): 0F 55 系留 412+ (缺口清单已排除, 勿扩面)

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 (+新单测) / **multiseed REQUIRE_REAL=1 = 预计 155/155**
2. 新样本: 真虚拟化 (protect stub=1) + native/packed byte-exact + 影子 ctx.xmm 读回
3. 三子项各附**实汇编对照表** (样本里逐指令 capstone → ir::Op → VmOp 链路) 
4. 零回踩: wvmpTest 14/14 + 双跑 103/103 diff 0 行 + ExitNative 17 + jump-table 命中 + 30 既有样本绿
5. dump/静态扫描双门 PASS (新形态 handler 注册); enum 括号内 append 或零新增 (D1 两条路都走 #34 自查)
6. 冻结契约: runtime.hpp / ir::Op / backend.hpp BytecodeCodec / callgate step4-8 / kExitSlotDepth 零触碰
7. **硬条款**: 报告前 `git status --short` tracked 零脏附输出 + 切回 main + 单分支 ff-safe commit 链
8. ≥30 分钟; 反证/数据主张附复跑命令

## §E 纪律 (407 v2 版全文继承)

worktree 隔离 (主工作区 build/ 被占) / wvmpTest 基线产物禁覆写 / `cmd /c` 单斜杠 / cdb = `C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe` / capstone = `C:/Python314/python.exe` (**vendored 枚举名以仓内 capstone 头文件为准, 404 CDQE/MOVSXD 分裂枚举教训**) / **#33**: §A 三处"推荐/先验"均可能被实测推翻, 推翻优先于照抄。

## §F known compromise 预判

1. `addsd [mem],xmm` 写回非原子 (lock 版属 G4, 不混)
2. comiss 与 ucomis 之外 (0F 2E/2F) 的 SSE 比较家族 (cmpss 系列 0F C2) 不做
3. 双访存 rip+idx 混合 (SIB 基址+变址全谱) 按 408 既有限制推进, 超面 gate

时间预算: ~半天。== MIT-G1 派活单完 ==
