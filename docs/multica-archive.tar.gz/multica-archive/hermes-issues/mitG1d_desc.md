# WVmp MIT-G1d 派活单 — movdqa/movdqu 对齐传送族（零新 VmOp 折叠 + 427 桥溢出负例翻转闭环）

> 派活单生成: 2026-08-31, 接手人 (项目主)
> 关联: G 线 | main `35ea03d` (427 合入后, 基线 44 样本 **220/220**, wvmpTest 14/14, 硬条款六连满分) | 427 §排程建议: movdqa/movdqu 优先单开——**"/Od intrinsic 桥正例不可行"（427 #33④）的根因正是本族 gate**，本单落地即翻转 | docs/GAPS.md:183-184 "砍面留档按频率单开"登记行
> 交付形态: **main 之外的命名分支 `mit-g1d-aligned-mov`**（硬条款，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main 35ea03d, 2026-08-31 01:0x)

### A.1 现网
- main = `35ea03d`; build 0 错 / ctest 16/16 / **multiseed 44 样本 × 5 = 220/220** / wvmpTest 14/14 + jump-table@0xDD84 + ExitNative 17 + 双跑 103/103
- kVmOpMax = **97**（427 后）; 跳表容量 128 → 余量 30（x87 L0/G7 统裁空间——**本单目标零新 VmOp，不动 97**）
- harness crash guard 已在位（427 B.5 三判据版，样本注入验证过）

### A.2 缺口面现状（本单 grep 亲验）
- lifter `X86_INS_MOVDQA/MOVDQU` 白名单 = **0**；capstone id 在位：x86.h:855-856（legacy 66 0F 6F/7F）+ **:1415/:1420 VMOVDQA/VMOVDQU（VEX 对）** + :1413-1414 VMOVDQA32/64（EVEX——**不入白名单，天然落 426 §F.3 gate 链，GAPS 文本显式列**）
- **427 频率证据（本单立项依据）**: dumpbin probe 实测——/Od 下 `_mm_cvtsi32_si128/_mm_set_epi64x/_mm_add_epi64` 等 **每处桥/整数 intrinsic 必伴随 movdqa/movdqu 栈溢出**；427 桥样本负例区 cpp 函数 gate note 即含 movdqa+movdqu。→ 任何用 intrinsic 的真代码都在发本族，**SSE 残余里唯一有直接产物数据支撑的高频面**。

### A.3 折叠通路锚点（本单核心 = 零新 VmOp，直读在位）
- `:2409-2411`: `case X86_INS_MOVAPS → translate_sse_mov(..., Op::Movaps, Size::S64)`；`MOVUPS → Op::Movups, S64`——**movdqa/movdqu 语义 = 16B 全宽拷贝，与 Movaps/Movups 同构，复用即成**
- `:1188-1189` 对齐先例（375 D2）：**"movaps/movapd 的 mem 形式运行时一律 movups 非对齐语义（PE 不保证全局 16B 对齐）"**——movdqa 对齐陷阱语义直接沿用此判（D2 条款见 §C）
- `:1192-1198` translate_sse_mov 形式矩阵：(Reg,Reg)/(Reg,Mem)/(Mem,Reg) 三形分派现成；(Mem,Mem) unsupported
- `:1586` 426 D4：vmovaps/vmovups 纯拷贝 2-op 直折单条——VEX 镜像框架同款可用（`vex_desc_of` 扩挂，427 B.3 Bridge 族扩挂先例）

### A.4 ⚠️ 编码方向陷阱（§E 纪律挂钩，实测必钉）
movdqa/movdqu 仅 **6F（load 方向）/ 7F（store 方向）** 两 opcode，但 **reg,reg 形态两编码都能编**（66 0F 7F reg,reg = 反写 src1 的合法形）——与 movaps 28/29 双编码的分布不同。capstone 报的 operands 归一化方向**必须 probe 实测**（每编码×每形态一行对照表），禁按 mnemonic 直觉折叠（426 vvvv 手算 4 错被 probe 纠正同款教训）。

## §B 任务

1. **B.1 legacy 入面**: `X86_INS_MOVDQA` → `translate_sse_mov(..., Op::Movaps, S64)` 路 / `X86_INS_MOVDQU` → `Op::Movups, S64` 路——**lifter 两 case + 方向判据（§A.4 实测矩阵），translator/handler/VM 零改动**（若实测发现 movdqa 7F-reg-reg 等形态与既有分派不兼容，最小调度层修正，禁扩 VmOp/改 handler）
2. **B.2 VEX 镜像**: `X86_INS_VMOVDQA/VMOVDQU` 经 426 `vex_desc_of` 扩挂（Fam::Mov/纯拷贝 2-op 直折，D4 先例）；**位宽闸继承（ymm 禁入）+ xmm8..15 同口径 gate + EVEX VMOVDQA32/64 显式不入面**
3. **B.3 427 负例翻转对账（本单审计重点）**: 427 桥样本 9 条 gate note 逐族对账——①仅因 movdqa/movdqu 而 gate 的函数（若有）翻正例、stub 计数变；②punpckldq/punpcklqdq/pmovmskb/pcmpeqd/paddq/psubq/MMX-movq 仍 gate 的函数断言**原样**；③**新增 intrinsic 真产物正例函数**（`_mm_cvtsi32_si128`+spill 形态，427 #33④ 的翻转闭环——/Od C++ 函数自此可入正例区，dumpbin 对照表 ≥2 函数）——翻转对账表逐函数进报告
4. **B.4 对齐语义披露**: movdqa 运行时不模拟 #GP 对齐陷阱（沿用 :1188 D2 判），GAPS 文本一句话 + 报告论证（MSVC 产物恒对齐目标 / 分歧仅程序显式依赖 trap——不存在场景）
5. **B.5 样本**: 主样本 `wvmp_aligned_mov_sample`（MASM: movdqa/movdqu 双向×(reg-reg 双编码/栈槽/rip) + **非对齐地址 movdqa 行为钉**（对齐语义基线）+ VEX vmovdqa/vmovdqu + 负例区: vmovdqa32(EVEX db 形)/vpaddd ymm/punpcklqdq/pmovmskb）+ 影子（#79: ctx.xmm 读回钉 16B 全宽+高位语义；**无新 handler → dump 门 SSE_HANDLERS 集合恒等 = 零新 VmOp 机器证明**，426 §D.7 同款）；multiseed 44→**46**（主/影配对 425-427 惯例）→ 预计 **230/230**
6. **B.6 GAPS/STATUS 联动**: :183-184 行改写（movdqa/movdqu 摘除；残余=pmovmskb/pcmpeq/punpck 族+paddq 砍面+G8-BMI+档B）+ 427 G1c 节"支持面不可达"句补"428/G1d 已翻转"链 + 里程碑行

## §C 决策点（项目主已拍板）

- **D1 零新 VmOp 硬约束**（✅）: kVmOpMax=97 不动为验收硬项；本族语义与 Movaps/Movups 全等（§A.3），出现任何新 op 即设计错误。dump 门 handler 集合恒等机器证明（426 先例）
- **D2 对齐陷阱不模拟**（✅）: 沿用 375 D2 先例文本，movdqa=非对齐宽松拷贝；报告一句话论证 + GAPS 登记（若你实测发现 movaps 既有 handler 有对齐强校验分叉，披露并统一，别静默）
- **D3 movdq* 直复用 Op::Movaps/Movups 双 op，不统一折叠成单 Op::Movups**（✅ 建议）: reg-reg 语义 movdqa≡movaps、movdqu≡movups 可区分保留（GAPS 语义精确）；若实测两 op handler 字节码全同想省一面，披露理由允许统一
- **D4 punpckldq/punpcklqdq 不入本单**（✅）: 交织语义非纯拷贝（需 lane 提取组装），427 负例原样保持——GAPS 残余精确化登记

## §D 验收标准

1. build 0 新警 / ctest 16/16（+新用例: 双编码×三形态矩阵、非对齐 movdqa 行为钉、VEX C4/C5 双编码、ymm/EVEX 负例、intrinsic 翻转正例 ≥1 函数）/ **multiseed 230/230**（46 样本）
2. 新样本真虚拟化 + 影子 byte-exact + 427 负例翻转对账表（§B.3，逐函数 gate note 前后对照）
3. 实汇编对照表: §A.4 编码方向矩阵全形（MASM 真字节 → capstone id/operands 归一化 → 折叠决策）+ /Od C++ intrinsic spill 真产物（dumpbin ≥2 函数：movdqa/movdqu+桥 共存形态 → protect 真虚拟化，**427 #33④ 翻转实证**）
4. 零回踩: 220 既有全绿 + wvmpTest 14/14（stubs=14/jump-table/ExitNative 17/diff 0）+ **427 桥样本/426 vex128 样本/425 fin 样本 gate 断言按对账表精确演进（不许静默变数）** + lock/string note 原样
5. **kVmOpMax=97 不动 + handler 集合恒等**（D1 机器证明）+ 冻结契约全套（runtime.hpp/ir::Op/backend.hpp/callgate/419/423 域 5..13/425 域 14..18/427 域 19..21/426 TranslateResult.extra）
6. 硬条款: 命名分支 `mit-g1d-aligned-mov` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账
7. dump/static 双门 PASS（桥 handler 注册表不动，零新 handler）

## §E 纪律

worktree 隔离（分支签出自建）/ wvmpTest 禁覆写 / `cmd /c` bat（禁 `cmd //c` 静默空跑，查 build log 时间戳）/ vendored capstone 实测（`.deps/capstone-src/include/capstone/x86.h`:855/1415 等 id 亲验在位，operand 形态=probe 实测）/ MASM 手编纪律（423 §7.4 + 426 vvvv 教训：ModRM/vvvv 手算双验，误编即 cdb/探针反查禁猜）/ 观察模式纪律（427 披露①：GP 方向观察禁区域外读 callee-saved，区内 Store 通路）/ **#33 铁律**: §A.3 折叠同构、§A.4 方向矩阵、B.3 翻转预期（哪些函数翻正/哪些仍 gate）全部实测兜底，与先验冲突推翻项目主优先。

## §F known compromise 预判

1. movdqa 非对齐地址不 trap（宽松化）——:1188 同款已判先例，GAPS 文本兜底
2. movdqa 7F-reg-reg 反写形态若 capstone 归一化后与 (Mem,Reg) store 分派冲突——lifter 调度层最小修正允许，报告披露
3. EVEX vmovdqa32/64 与 VEX 同名族分叉（按 INS id 分裂天然区分，426 §F.3 同款）——GAPS 显式列防误当漏项
4. 翻转后 427 样本若含纯 spill 无 punpck 函数→其 stub 数变化属**预期演进**（对账表钉死，非回踩）

时间预算: ~0.5-1 天（折叠单，但含 427 对账审计）。== MIT-G1d 派活单完 ==
