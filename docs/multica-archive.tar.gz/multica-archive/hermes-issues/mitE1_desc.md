# WVmp MIT-E1 派活单 — CallGate callee 专用栈窗口（栈预算缺口修复, wvmpTest sha256 崩溃转绿）

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: MIT-404 done (main `2f1bcec`, 除法族; 报告"遗留"节 = 本单 §A 证据来源) + MIT-249 (callgate 设计) + MIT-403 (B2 栈常量派生纪律, 本单沿用) + MIT-405 (D1 triage, 其 §2.4 栈基准事实本单引用)
> 性质: 修复单。**优先级最高** — main 的 wvmpTest 验收流自 404 合入起为红灯 (known-regression), 本单负责转绿
> 模板: MIT-B2 八步纪律 (constexpr 派生 + 同族 grep + 报告实测粘贴)

---

## §A 根因与栈布局事实 (项目主 + 404 agent 双源实测, 2026-08-29)

**症状**: wvmpTest packed.exe 双跑崩于 `kern.sha256_block_vectors` (rc=0xC0000005; unpacked 103/103 全绿; md5 及以前测试全 PASS 后截断)。项目主 12:10 独立复现确认。

**根因 (404 agent cdb+硬件断点证据链, 项目主复核采信)**: sha256 区域含 **54 个 CallGate**; native callee 调用树 `sha256_K→frac_cbrt_prime→wvpow13→pow/floor` 实测栈深 **~0x250B**, 砸穿驻留同栈的 VmContext → ctx 槽被写垃圾 (`b50e67c0_1972cb24`) → VM 状态毁坏。**是暴露非引入** (sha256 08-28 被 cdqe gate 从未进 VM; 其唯一 404 相关 op = 8×cdqe→Movsxd, 该路径本身 5 seeds 全绿)。

**栈布局三事实** (asmgen.cpp:1012-1022 注释链 + stub_gen.cpp:68-77 实读):
```
native_sp (caller 原始 rsp, ctx+0x120 槽)
  [native_sp-0x28 ]  callgate 现状: callee 树从这里向下生长
  [native_sp-0x40 ]  stub 8 push 保存区上沿
  [native_sp-0x208, native_sp-0x40)  ← VmContext (kCtxSize=0x1C8) 驻留区
  [native_sp-0x250 = host_rsp ]  ← 解释器执行期 rsp
```
→ **callee 可用预算 = 0x208−0x28−8(ret) ≈ 0x1D0** (404 报告口径 ~0x1A0B), sha256 需求 0x250B 超预算 → 必穿 ctx。
→ **`host_rsp` 以下当前无任何消费者** (entry 的 8 push 在 host_rsp 以上; dispatch 纯跳表无递归; handler 仅 callgate 动 rsp) — **干净窗口**。agent 必在报告中 grep 实证此点 (全 runtime 生成文本中 rsp 减法/push 点清单)。

## §B 修复方案 (决策已拍板, 见 §C)

**核心**: callgate 的 native 执行窗口从"贴 ctx 顶的缝隙"改为"**ctx 下方专用窗口**":

1. `vm/regvm/runtime/src/asmgen.cpp` 文件头新增 `constexpr u64 kCallgateCalleeWindow = 0x1000;` (4KB; static_assert `% 16 == 0`; 注释写预算推导: 实测最深树 0x250 → 0x1000 ≈ 6.5× 余量 + CRT 深链防御)
2. **step 4** (切 rsp 到 native 执行位): `t1 = native_sp − 0x28 − kCallgateCalleeWindow` (原 `− 0x28` 基础上再减窗口; 全部经 `imm()` 派生, 禁字面量第二份拷贝 — B2 纪律); **切换后 `mov qword ptr [t1], 0` 一次探针写** (Win64 guard-page skip 防御: 单次跳跃 ≤0x1028 距一页整, 探针消除边界; 注释引用栈探测规则)
3. **step 7** (回退): `sub rsp, (kCallgateSpRollback + kCallgateCalleeWindow)` — 表达式派生, 注释链同步刷新 (host_rsp = native_sp−0x250 不变量重推: 现状 sub 0x230 语义 → 新值推导过程写进注释)
4. **同族 grep (B2 模式)**: 全 runtime 再扫 `native_sp−0x28` 语境/0x28 摆位/其他把 callee 栈假设在 ctx 上方缝隙的代码点 (如未来 push/pop handler 的 v4 写位与窗口的关系 — 窗口在 host_rsp 以下, 与 v4 写位 native_sp−8↓ 方向相反, 天然不撞, 报告给一句论证)
5. **契约注释**: 区域 VM 栈 (v4 向下) 与 native 窗口的互斥关系写进 build_callgate 头注释; 405 §2.4 的"未配平 push 潜在约束"一并引用 (不在本单修, 写"已知边界")

**新样本 ×2** (E2E 覆盖缺口: 既有 call_gate 样本 callee 全浅帧 ≤0x30B, 从未测过预算边界):
6. `passes/marker_scan/tests/deepcall_sample_{asm.asm,main.cpp}`: 标记区域内 call → ≥12 级 NOINLINE 递归链 (每帧 ≥0x40B 含本地缓冲), 静态可核算总深 **≥0x400B** (报告附帧数×帧深推导); 打印递归结果 byte-exact
7. `passes/marker_scan/tests/deepcall_div_sample_*`: 组合形态 — 区域内 div/idiv (rax/rdx spill 防护) + 深 call 共存, 验证窗口切换与 404 防护机制互不干扰
8. CMakeLists 注册 2 target; multiseed_e2e.sh 追加 2 样本 (24→26, 基线 130 runs)

**不改**: runtime.hpp kCtxSize 派生面 (只引用) / stub_gen.cpp 布局 / translator/lifter / 既有 24 样本 / VmContext 移出调用路径大手术 (§D1 否决)。

## §C 决策点 (项目主已拍板 2026-08-29)

- **D1. 修复形态** (✅ D1.1): callee 窗口放 host_rsp 下方 0x1000 (小步方案, 复用现有 rollback 算术)。**否决** "VmContext 移出调用路径" 大手术 (改 stub 入口/出口协议全链, 面大)。
- **D2. 窗口大小** (✅ D2.1): 0x1000 单常量; 不做"从调用树深度动态推导" (深链静态不可知, 6.5× 实测余量 + 探针写防御即可)。
- **D3. 探针写** (✅ D3.1): 加 (见 §B.2); 若实测证伪必要性 (同跳幅正常), 保留代码但注释降级为 defensive。
- **D4. 组合样本** (✅ D4.1): deepcall_div 必做 (§B.7)。
- **D5. §A 若被实测推翻** (✅ #33): 诚实披露 + 改方向。
- **D6. wvmpTest 若转绿但暴露新问题** (✅ D6.1): sha256 之外的新崩溃/FAIL 如实报告, 不算本单失败但必须列 (如 duff 的 idiv S16 形态撞上 §F 不支持面)。

## §D 环境基线 (fresh verify 2026-08-29 12:15, main 2f1bcec)

- build rc=0 / ctest 16/16 / **multiseed = 24 样本 120/120** ← 修复前
- wvmpTest: protect stubs=2 (mul64hi+sha256), 命中 cdqe/cdq/div=0, 残余 17 跳转+1 间接 jmp (D2 棒范围); **packed 双跑红** (sha256 崩) ← 修复后必须转绿
- 工具链/cdb/TOML/ASCII/双探测等环境纪律沿用 MIT-404 版 (§C), 此处不重贴; multiseed CLI 双探测已落地无镜像 hack

## §E 验收标准 (9 项)

1. build rc=0 自有码 0 警 0 错
2. ctest 16/16 零退化
3. **multiseed REQUIRE_REAL=1: 26 样本 × 5 seeds = 130 runs 全绿 (130/130)**, 既有 120 零退化, 新 2 样本 10/10 (真虚拟化 stub 数>0 + byte-exact)
4. **wvmpTest packed 双跑 `SUMMARY passed=103 failed=0` + 与 unpacked byte-exact (diff 空)** ← 本单核心出口 (known-regression 清零)
5. capstone 回读: callgate handler 前后 diff 仅窗口算术两处 + 探针 mov; rollback 立即数 = 0x230+0x1000 派生值实测可读 (如 1230); 贴机器码
6. host_rsp 以下无消费者: grep 全 runtime 生成文本 rsp 移动点清单作证据 (§A 事实 3 的静态复核)
7. 冻结契约: 改动仅 asmgen.cpp + 4 样本新文件 + CMakeLists + multiseed_e2e.sh; 分支 `mit-e1-callee-window` 基于 2f1bcec, 未 push 未 merge
8. 深帧证据: deepcall 样本调用树总深静态推导 (帧数×帧大小) ≥0x400 且 cdb/实测确认穿透了旧 0x1D0 预算 (即: 修复前该样本必崩, 修复后必过 — 提供修复前反证跑一次并粘贴)
9. 报告实测粘贴齐全 (#29); ≥30 分钟 (#38); 完工 `git checkout main`; 报告按 §F 模板

## §F 报告模板

```
# MIT-E1 报告 — CallGate callee 专用栈窗口
## 一、改动清单 (文件:行 + 前后 diff 摘要 + rollback 新值推导)
## 二、§B.4 同族 grep 排查表
## 三、验证 9 项逐条 (实测输出粘贴; 验收 8 的修复前反证必含)
## 四、capstone 回读 diff
## 五、wvmpTest 转绿证据 (protect 日志 + 双跑 SUMMARY + diff 空)
## 六、决策与披露 (§A 若修正处; D6 新问题)
## 七、遗留
```

## §G known compromise

- 0x1000 窗口是"预算派生常量"而非动态适配; 若未来真实目标出现 >4KB 单调用树 (极罕见, CRT 深链+递归), 症状从"砸穿 ctx"变为"砸穿窗口下的 guard page"→ 明确崩溃非静默, 可诊断
- 线程栈总预算: 目标 PE 默认 1MB 栈, host_rsp−0x1028 远在安全区; 若目标自带极小栈段自定义 (`.stack` 自定义 SizeOfStackReserve < 8KB) 理论可能触底 — §F.7 遗留登记, 非本单面
- v4 (VM 区域栈) 向下深推与 ctx 碰撞的既有潜在约束 (405 §2.4) 不在本单修, 契约注释中登记

## §H close-out (项目主侧)

报告 → 项目主独立复验 §E 1-4+8 → `.multica/mit-e1-ruling.md` → done → ff-merge → **基线刷新 130/130 + wvmpTest 红灯摘除** → 随即派发 D2 (ExitNative, §A 素材 = 405 triage §6 八条 + 新增"callgate 窗口已修"事实)。

== 派活单完 ==
