# WVmp MIT-X1b 派活单 — ret imm16 清栈语义（🔴1，兼修 x64 现网同类地雷）+ SEH/FS gate 文档（🔴2）+ CLI arch 字段最小基建

> 派活单生成: 2026-09-01, 接手人 (项目主)
> 关联: 多目标平台 X1b（X0=436 triage §7 两枚🔴实施输入之二在此收口）| main `f7a865c` | 与 MIT-X1a（marker_scan/sdk 面）**改面互斥可并行**；x87 三路线 D1 悬置**不动**（X2a 拍板）
> 交付形态: **main 之外的命名分支 `mit-x1b-ret-imm16`**（硬条款，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main f7a865c, 2026-09-01 01:1x)

### A.1 地雷机制链（项目主源码直读钉死——X0 🔴1 升级定性）
- lifter **已正确 lift**：x86_translate.cpp:290-301 `translate_ret` op_count==1 → `out.src = Operand::imm_(operands[0].imm)`（ret imm16 值入 IR，双 arch 共享代码路径）
- **translator 丢弃**：translator.cpp:886-890 `case ir::Op::Ret: em.emit(VmOp::Ret, None,0, None,0,0, size_field)`——**in.src 无人消费**，imm 直接蒸发
- asmgen：`VmOp::Ret` handler 无清栈概念（grep `VmOp::Ret` 生成侧未读 imm 参数——你复核）
- **⚠️ 项目主升级定性（X0 报告未点破的一层）**: x86_translate 是双 arch 共享翻译路径——**`ret imm16` 在 x64 也是合法编码**（第三方手写汇编/非 MSVC 编译器产物可出现），故这枚地雷**不止 x86 战役需要，是现网 x64 既有正确性缺口**——与 433 P1 同族（"230/240 全绿≠通路已验"的又一实例：现样本集无任何 ret imm16 形态）。X0 §7 计数（msvbvm60 82% of ret）证明 x86 侧不修则 stdcall 函数虚拟化必栈失衡（pop 返回址后 rsp 不加上移参空间 → caller 栈错乱），**行为错误级非 gate 级**。

### A.2 参数槽现状（选型输入）
`emit(VmOp, a_kind, a, b_kind, b, aux, tail)`——Ret 现用 `None,0,None,0,0`，**aux/tail 槽闲置**；isa size_field 占 1 字节——X0 triage §3.1 引用面：VM 内 pop-ret-addr+jmp 的 handler 在 asmgen（Ret case，你定位行号）
### A.3 SEH/FS 现状（🔴2 素材，X0 §7）
seg_fs 语料 0.32%（Delphi 0.68/vmwarecui 1.7%）；x86 的 `mov reg,[fs:0]` = SIB 编码形——**实测 capstone x86 模式下 mem.base=X86_REG_FS 的报法**（lifter 现 map_reg 对段寄存器的判据=拒? 你实测钉现状再写文档）；callgate callee 自装 SEH 无碍（原生栈上执行）——文本区分两情形
### A.4 CLI/config 现状
`cli/include/wvmp/cli/config.hpp`（无 arch 字段，412 实测）；pe_loader pass 层硬拒在位（414，X0 §B.5 亲验 rc=2）——**本单不回退硬拒**（X 波全程保持，解禁时点=X4 asmgen 收口单拍板）

## §B 任务

1. **B.1 ret imm16 语义（核心）**: translator/asmgen 落地"pop ret-addr 后 rsp += imm"。选型 D2 两路实测对照: (i) **VmOp::Ret 扩 aux 载 imm + asmgen handler 加 `add rsp,imm`**（零新 VmOp，A.2 闲置槽现成——首选评估）/ (ii) translator 折条 Ret+Add(sp)（sp 是否可作 Op::Add dst——实测，若 ctx 虚拟栈语义不支持即弃）/ (iii) 新 VmOp（预算 97→98，最后手段）。x64/x86 双语义统一（imm16 宽度=arch 指针宽? SDM: ret imm16 的 imm 是字节数且 x64 下同样按字节加 rsp——实测对账）
2. **B.2 x64 面反证（同 406 纪律）**: 新样本/单测用 **x64 `ret 8` 真形态**（stdcall-仿 C++ 不可产→MASM `ret 8` 直写，x64 可全管道 E2E！）——修复前 VM 栈失衡可观察（call 后 caller 用 rsp 的断言崩/错值）→ 修复后 byte-exact：**本单在 x64 现管道即可全链反证，不等 x86 管道**——样本 `wvmp_retimm_sample`（区1 caller-ret imm8 链+参数消费断言 / 区2 ret 0（ret imm 0 ≡ ret? 边界）/ 区3 大 imm 边界）REQUIRE_REAL；multiseed 48→**49 = 245/245**
3. **B.3 x86 面 lift 断言（纸面级）**: lifter 双 arch 会话下 `ret imm16`（含 66 前缀形 `66 C2 xx xx` 16-bit imm）lift 值正确进 IR.src（现码已 lift——**钉回归断言防 X2 重构回退**）+ translator 层单测双 arch 派发
4. **B.4 SEH/FS gate 文档（🔴2）**: 实测 A.3 现状报法 → GAPS 增 x86 支持面节：**FS:[0] 段寻址显式 gate**（"扫得到≠放得进"——map 拒→unsupported→C1 整函数原生，零逃逸同构论证）+ callgate 自装 SEH 无碍情形文本 + "x86 战役已知 gate 清单"首块（为 X 波后续单立模板）
5. **B.5 CLI arch 字段最小基建**: config.hpp arch 枚举（auto/x64/x86，**auto=machine 推导现状行为不变**；声明与目标不符 → rc=2 显式拒，含 unknown machine 不回退 D4）——仅 CLI/config+pe_loader 校验挂点，**不开 x86 通行**
6. **B.6 文档**: GAPS 地雷收口行（含"x64 现网同类缺口修复"定性+样本集盲区教训第二例引用 433）+ STATUS 里程碑

## §C 决策点（项目主已拍板）

- **D1 本单不回退 414 硬拒**（✅）: x86 全管道解禁=X4 收口时单独拍；X1b 交付后 x86 输入仍 rc=2
- **D2 选型 (i)>(ii)>(iii)**（✅）: 闲置参数槽优先，**新 VmOp 最后手段**（跳表余量 30 留给真需要）；两路实测对照进报告
- **D3 imm 语义逐条实测**（✅）: `ret imm16` 的 imm < 返回地址区间的病态形（imm=0 合法等价 ret；imm 覆盖 ret-addr 本身 SDM 未定义——gate/跟随 native? 实测 native 行为钉 + 单测边界）；`retf` 不在面（16-bit 远返回，语料未现——文档一句）
- **D4 x64 反证为硬项**（✅）: B.2 全链反证跑不出来=设计错——退回讨论；此单**不只是 x86 铺路，是现网正确性修复**（对齐 433 地位）

## §D 验收标准
1. build 0 新警 / ctest 16/16（+ret imm16 语义矩阵 ≥6：x64/x86 lift、双 arch translator、imm0/边界大值、D3 病态形）/ **multiseed 245/245**（49 样本）
2. **x64 全链反证**: rettimm 样本 main 旧 CLI（f7a865c）packed → **栈失衡可观察**（rc/输出分叉，贴两侧）→ 分支 CLI PASS byte-exact；REQUIRE_REAL 真虚拟化
3. SEH 现状实测表（capstone x86 模式段寄存器报法 + lifter 判据直读）+ GAPS gate 文本落位
4. CLI arch 字段: x86 输入仍 rc=2（硬拒不回退亲验）+ 声明不符 rc=2 + x64 正常路径 48 样本零回踩全绿
5. 冻结契约: runtime.hpp/backend.hpp/callgate/kCtxSize/载体域 0..22 零触; kVmOpMax 97 不动 (D2(i) 路径) 或 +1 披露 (iii); **X1a 面 (marker_scan/sdk) 零 diff** (互斥审计)
6. 硬条款: 命名分支 `mit-x1b-ret-imm16` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离 / wvmpTest 禁覆写 / `cmd /c` 查时间戳 / MASM 手编纪律（x64 `ret 8` 样本直写形；66 C2 前缀形双验——423/428）/ #33: A.1 机制链与 D2 闲置槽可用性全实测兜底（aux 若被 handler 既有读路径隐式消费即踩雷——grep 对账先）/ 观察纪律（427 callee-saved）。

## §F known compromise 预判
1. x86 面本单只到 lift/translator 断言（真 x86 E2E 待 X4 管道），B.3=纸面级——如实标注
2. CLI arch 字段在 X 波中期是"摆设"（无 x86 通行能力）——B.5 定位=校验基建预铺，解禁单前不启用
3. `ret imm16` 的栈深假设（VM 内 rsp=ctx 栈顶连续区）若 E1 ExitNative 栈窗口交互有形态分叉——asmgen 侧实测，有雷即披露并 D 点上报别硬拍

时间预算: ~1-1.5 天。== MIT-X1b 派活单完 ==
