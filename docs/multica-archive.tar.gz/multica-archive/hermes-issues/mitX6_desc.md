# WVmp MIT-X6 派活单 — x86 残 gate 双面包：push-imm 开面（lifter 单点，wvmpTest 11 处）+ SSE 32 handler x86 批迁（G7 面翻正）——两族一批一读数

> 派活单生成: 2026-09-02, 接手人 (项目主)
> 性质: **并单（A=X3d SSE32 / B=X5d push-imm, 面正交审计通过后合并）** | main `4083b1f`（453 X5c 合入后, 基线 64 样本 **320/320**, x64 dump 底稿 `ffd47289`）| 素材 = 453 裁定 §5 残面清单 + 452 §5 + GAPS X5c 收口节（whitelist gate 机制）+ X0 §7（SSE 编码双平台同/x86 仅 xmm0-7）
> 交付形态: **main 之外的命名分支 `mit-x6-pushimm-sse`**（硬条款二十二连；**新规显式句: 禁自行 merge 进 main, 合入权在项目主——453 越权事件入档**）

---

## §A 基线实测事实 (项目主 fresh verify @ main 4083b1f, 2026-09-02 22:1x)

### A.1 push-imm 卡点定位（本单 B 族主锚, 行号=本轮亲钉）
- **卡点在 lifter 不在 translator**: `x86_translate.cpp:216-227 translate_push` → `:219 is_data_operand(*d)` 拒 imm 形（`unsupported`）→ translator `:1569` 注释自证"push imm：lifter 不产出"（该 skip 分支实际不可达）
- **运行时已就绪**: `VmOp::Push` a_kind **Reg/Imm 双形 446/X3b 设计预留**（asmgen :4799 build_push_x86 注"此路径恒 Reg 形"——Imm 形分支存在性你实测核, 缺则补——x86 4B handler 面）
- **现场读数**: wvmpTest x86 残 gate = push-imm 11 + 间接 jmp 1（aebb 0xBAE3）+ stack-depth 1（mul64hi, 451 永久 gate **不动**）+ Div 族 b59b（G8 白名单 **不动**, 另单）; x64 侧 wvmpTest 0 gate——但 **push imm 在 MSVC x64 真产物同样高频**（push 常量/small offset）——D2 给双 arch 裁决题
- **ir::Op::Push 载体**: dst=Imm 新形——lifter Operand::Kind::Imm 入 dst 槽的链路面 translator（emit VmOp::Push OpKind::Imm + imm 值域: 64 位 imm32 sext 语义, x86 恒 32 位值——**载体域/编码面先 grep 对账再动**）

### A.2 SSE 批迁面（本单 A 族主锚）
- x86 表现 60 登记（GAPS X5c 节）; SSE 32 op 名单=X0 triage §7/446 白名单 gate 实测面（Add/Sub/Mul/Div 标量+packed/Mov 系/Logic/Max/Min/Sqrt/Unpck/Shuf/Cvt/Comiss 折叠…以 x64 表对账补集为准, **别数"32"粗数**——434/444 补集纪律）
- **X0 §7 先验（实测兜底）**: SSE2 基础编码 x86/x64 同（无 REX 依赖）; xmm 物理寄存器 **x86 仅 xmm0-7**（ctx 槽 `kCtxXmmBase=0x140` 8×16B=128B——stub xmm 同步 Win64 ABI 面 371）——x86 侧 guest 只见 xmm0-7, 槽偏移公式按 x86 帧重核（446 交接原文）
- 现状兜底=stub_link x86 白名单闸整函数保原生（C1 显式, 446 顺路收益）——**翻正机制: asmgen 表加行即自动放行（单一来源 x86_handler_table）, stub_link 零改动**; 表未加齐的函数继续 gate（半迁移态安全）
- **池现状**: `wvmp_x86_sse_sample` 以 **gate 负例形态**在池（446 设计性负例: SSE 函数整函数原生+helper 虚拟化 stub=1）——翻正后该样本读数变化=**A 族首验收点**（sample 输出 byte-exact 不变, stub 数/gate note 变化如实翻案, 428 翻转先例流程）
- Div/Sqrt 系注意: SSE divsd/divss 与 GP Div(78) 不同 op——G8 例外语义**不适用**（X3b 已迁 GP div 折叠 Halt 面）, SSE 除法 handler 在 x64 本就是真 handler（除零=IEEE inf 语义非 #DE——x64 有电池先例, 平移即可, 别自造异常）

### A.3 六件套基线
build 0 / ctest 16/16 / multiseed 320/320 / wvmpTest x64 14/17/0 双跑 diff 0 / x86 103 kernel: **stubs=9 en=17 残面 13** / 电池 37 dump 门 60 / x64 dump `ffd47289`。

## §B 任务（三批, 每批全绿独立读数再推下批）

1. **B.1（批一·X5d 族）push-imm 开面**: lifter `is_data_operand` push 形定向放行（imm→Op::Push dst=Imm）+ translator Imm 形 emit（x86 单 op Push/Imm; **x64 裁决题= D2**）+ 载体/编码对账 + 单测（lifter/translator/电池 Push-Imm 真执行 esp 步进+值断言）+ 新样本 `x86_pushimm_sample`（多宽 imm 形+push 0+边界; x64 对称样本视 D2 裁决）+ **wvmpTest x86 读数 B 列**: push-imm 11→? （aa18/b678 等函数翻正预期; 残余归因逐项）+ multiseed 精确数自算
2. **B.2（批二·X3d 基础族）SSE 传送/算术/逻辑批迁**: 补集清单先入报告（每 op: x64 模板函数/编码双平台核对结论/电池用例名）→ asmgen x86 表加行（复用 x64 模板按 X0 §7 差异点参数化——xmm 0-7 限定/槽偏移 x86 帧公式）→ 电池扩面（真执行语义+5 seed）+ dump 门 BATTERY_HANDLERS 同步 + `wvmp_x86_sse_sample` 翻案（gate→真虚拟化, 输出串 byte-exact 不变断言）
3. **B.3（批三·X3d 扩展族）比较/转换/洗牌系**: 同 B.2 模式（Cvt/Comiss 折叠族 flags 面/Unpck/Shuf 面）; **x64 侧零扰动每批复验**（B.5）
4. **B.4 病态与边界**: push imm S16/S8 形（66 前缀+imm——gate 维持口径对 442 push 位宽面）; SSE 涉 ymm=白名单 gate 天然拦（428/432 面, 实测钉一条）; 间接 jmp aebb 处**不在本单**（挂账维持, 别顺手做）
5. **B.5 x64 零扰动铁证**: 每批复验 dump `ffd47289` 逐字节 + multiseed x64 250 + wvmpTest x64 读数不变（**例外**: 若 D2 选 x64 同开 push-imm=x64 行为增强单——独立批+442/453 imul 先例流程: 逐 handler 对账披露 delta+新 stub 读数; 默认 D2=x86-only 起步, x64 扩面证据充分再评论请示）
6. **B.6 文档**: GAPS（残面清单刷新: 13→? 逐项归因 + SSE x86 行 gate→支持翻正 + X6 收口节）+ STATUS + 支持矩阵 x86 覆盖读数（103-kernel 真虚拟化率 9→? ）

## §C 决策点（项目主已拍板）

- **D1 一批一读数**: 三批各自 multiseed+六件套全绿才推下批; 报告读数表 **B 列（push-imm 族）/ A 列（SSE 族）分栏归因**, 混列=不合格（453 残面 13 逐项归因标准延续）
- **D2 push-imm 默认 x86-only**: lifter 放行按 arch 参数化（x64 维持 gate 现形=dump 恒等零风险）; 若实测证明 x64 同开零成本（如 handler 双形俱在+x64 multiseed 50 样本无该形即读数不变）→ 独立批给 x64 扩面证据, **不并进 x86 批**（行为增强与缺陷修复分账——453 imul 教训反向应用）
- **D3 冻结面**: kVmOpMax=97（Push/SSE 全既有 op, 禁新 op）/ 载体域 0..28 对账（push imm 走 imm 值非新载体; SSE 复用既有）/ kCtxSize/runtime.hpp/判定链/ExitNative/协议面零触碰; 解禁清单: x86_translate.cpp（B.1 单点）+ translator（限 Push 通路）+ asmgen（x86 表区）+ runtime_x86.hpp（如需）+ 测试/样本/脚本/docs
- **D4 缺陷归属标注**: 电池/E2E 当场炸当场修——每处实录必须标"X5d 族/X3d 族"归属（并单特有风险=归因混淆, D1 配套条款）
- **D5 sse 样本翻案纪律**: 输出串 byte-exact 不变是第一铁（gate→真虚拟化=路径变值不变）; 若有值差=新缺陷当场查（453 md5 先例）
- **D6 禁自行 merge**（453 事件显式句）: 分支交付即止, 合入裁定全在项目主

## §D 验收标准
1. 三批各自读数绿 + 总读数表: **wvmpTest x86 stubs 9→X（A/B 列分栏归因）/ push-imm gate 11→残? / SSE 函数翻正数 / 残面清单逐项闭合**（我亲手复跑对账）
2. multiseed 全绿（64+新样本, 精确数披露）+ 六件套 + dump 门/静态扫描同步
3. x64: dump `ffd47289` 恒等（D2 默认路径下）; 若 x64 扩面批=该批独立 delta 对账表
4. sse 样本翻案前后输出串逐字节恒等亲验证据
5. 冻结契约（D3）+ 硬条款二十二连（含 D6 显式句）+ worktree 自拆 + .deps 主仓零命中 + ≥30 分钟 + 时间对账

## §E 纪律
worktree 隔离（**独立 .deps, 1.1G 拷贝可接受——453 先例**）/ 分批 commit 三批 × 每批全绿 / wvmpTest 只读 / **#33 主战场**: A.1 handler Imm 形存在性、A.2 补集数（32 粗数）、xmm0-7 限定实测、"编码双平台同"逐 op 反汇编对账（capstone CS_MODE_32/64 双解同 text 断言, 别整体信 X0）/ 卡壳 ≥2h 评论 / 交付报告第一页=两族读数分栏表。

## §F known compromise 预判
1. 并单=报告面大; 但三批独立全绿可分三节自证, 验收仍单轮——项目主接受此节奏换省一整个派发/验收循环
2. SSE 扩展族（Cvt/Comiss 折叠形）若某 op 在 x86 帧公式有硬伤 → 该 op 维持白名单 gate 如实披露（半翻正合格, 别硬凑 32 全绿）
3. push-imm x64 扩面证据不足则挂 X6b——不为并单牺牲 x64 恒等铁证

时间预算: ~3 天（X5d 0.5 + X3d 2.5）。交报后 x86 残面 = 间接jmp/stack-depth/Div 族 + x87 永久——再下一战役拍 410(M3) 或客户态重扫。== MIT-X6 派活单完 ==
