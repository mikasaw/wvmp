# WVmp MIT-G1c 派活单 — movd/movq GP↔xmm 桥 + SSE2 整数算术档②（paddq/psubq）+ multiseed harness 崩溃盲区修

> 派活单生成: 2026-08-30, 接手人 (项目主)
> 关联: G 线 | main `b8dbde4` (426 G6a 合入后, 基线 42 样本 **210/210**, wvmpTest 14/14, 硬条款五连满分) | 425 §F.1 砍面登记（docs/GAPS.md:164-166 "砍面留 G1c"）| 425-D3: movd 桥是后续通用前置（x87 fst 域、VEX vmovd 镜像均依赖同类原语）| 426 §4 登记: harness segfault 假 PASS 盲区 → **本单搭载修复**
> 交付形态: **main 之外的命名分支 `mit-g1c-movd-bridge`**（硬条款，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main b8dbde4, 2026-08-30 20:5x)

### A.1 现网
- main = `b8dbde4`; build 0 错 / ctest 16/16 / **multiseed 42 样本 × 5 = 210/210**（REQUIRE_REAL=1）/ wvmpTest 14/14 + jump-table@0xDD84 + ExitNative 17 + 双跑 103/103
- kVmOpMax = **95**（vm_op.hpp:555, 426 后不动）; 跳表容量 128 → 余量 33（x87 L0 ~80 与 G7 扩容统裁仍在议, 本单预算见 §B.4）
- 426 后白名单含: legacy SSE 全家（38 id 含 mul/pand/andnps 425 面）+ 38 V-对（零新 VmOp）

### A.2 缺口面现状（本单 grep 亲验）
- lifter `X86_INS_MOVD/MOVQ/PADDD/PADDQ/PSUBQ/PMOVMSKB` 白名单 = **0**
- GAPS:164-166 登记行 = 425 原文："SSE2 整数档② movd/movq GP↔xmm 桥（66 0F 7E / 0F 7E / REX.W）与 paddq/psubq 系（66 0F D4/5C）——跳表预算 kVmOpMax=95 顶格，砍面留 G1c；movdqa/movdqu（66 0F 6F/7F）；pcmpeq/pcmpgt 系"
- **⚠️ 派单方编码自错纠正（#33 预登记, 你实测复核优先）**: 上引 "paddq/psubq 系（66 0F D4/5C）" 是**我 425 期手写错值**——66 0F D4=**EMMS**、0F 5C=**SUBPD**; SDM 真值 **paddq = 66 0F FC、psubq = 66 0F FB**。你按 SDM 复核后**顺带修 GAPS 该行**（413 教训: 派单方自拟公式必须实测对账, 推翻我优先）。movdqa/movdqu 66 0F 6F/7F 同段一并核对（0F 6F 无 66=movq load / 0F 7F 无 66=movq store——**与 66 前缀族撞 opcode 仅靠前缀区分, capstone 已解形但 operand.size 判据你要逐形钉**）。
- 既有原语锚: **XmmLoad/XmmStore VmOp 在位**（408, translator:2093-2114 `emit(VmOp::XmmStore, ...)` 宽度参数 4/8/16）——**方向=mem↔xmm**; **GP↔xmm 桥=本单缺口**（load 方向需新"gp→xmm 槽含高位清零"写路径, store 方向需新"xmm 槽→gp 含宽度截取"读路径——triage/426 已证既有 handler 无此原语, 见 §B.1）

### A.3 MSVC 真产物先验（425 惯例: agent 实测复核, 推翻优先）
- `_mm_cvtsi32_si128` / `_mm_set_epi32` 单 lane → **movd xmm, r32**（66 0F 6E）
- `_mm_cvtsi64_si128` / `_mm_set_epi64x` → **movq xmm, r64**（REX.W 66 0F 6E）
- `_mm_cvtsi128_si32` → **movd r32, xmm**（66 0F 7E）; `_mm_cvtsi128_si64` → **movq r64, xmm**（REX.W 66 0F 7E）——**int↔SIMD 互转/CRC 哈希/序列化代码高频**, 真实语料 python314 vpxor 同族惯用法（424 §2.3 "vpxor 清零惯用法"的标量面）
- paddq/psubq: `_mm_add_epi64` 直产 66 0F FC（预期, 频率低于 movd 族——**D1 授权你实测后砍留**）

## §B 任务

1. **B.1 movd/movq GP↔xmm 桥（核心必做）**: 新 VmOp 对（建议名 XmmFromGp/GpFromXmm, 宽度语义 aux 承载）——load 方向含 **高位清零**（movd→高 96 清 / movq→高 64 清; **legacy 无 66 前缀 movq xmm,xmm/m64 亦清高位, 与 66 全宽拷贝区分**——426 §F.4 假 Mov 家族纪律延续）, store 方向宽度截取读回。lifter 面: MOVD/MOVQ 全部合法编码形（§A.2 表 + VEX 变体**是否入面按 D2**）逐形 operand.size/方向判据实测钉
2. **B.2 paddq/psubq 算术族（档②, 频率驱动授权）**: `_mm_add_epi64`/`_mm_sub_epi64` 实测真产物频率 + 424 语料（smartscreen/onnxruntime 的 vpaddd 系是 packed **整型加法常客**）——入面则 64-bit lane 加/减 = 新 VmOp 对（handler 模板=既有 XmmLoad/Store 16B 通路 + GP Add 语义拼接 or native 直执行, 你实测选）；**若实测爆面/低频, 砍面留档不算失败**（425 同款双向授权, 披露计数证据）
3. **B.3 VEX 镜像随本体（426 §F.4 ④ 挂账清偿）**: vpaddq/vpsubq（+ 若入面）经 426 `vex_desc_of` 映射表扩挂——**位宽闸/三地址折叠/标量高位语义陷阱全部继承 426 框架, 零重复建设**; vmovd/vmovq（VEX）随 B.1 桥原语可顺手入, **但 ymm 形态禁入**（426 §B.4 同闸）
4. **B.4 enum 预算（跳表余量守护）**: 预算上限 kVmOpMax **95→≤101**（B.1 桥 2 + B.2 族 2 + B.3 若独立 2——尽量复用 aux 宽度位压到 +4）；**>101 即设计错误**（x87 L0 ~80 / G7 扩容统裁空间不许挤）。报告附最终计数 + 跳表余量核算行
5. **B.5 harness segfault 盲区修（426 §4 搭载, 小改）**: `scripts/multiseed_e2e.sh` 对 rc ≥ 0x80000000（或负值 rc）显式 FAIL——**先复现盲区**（临时注入一个 native 即 segfault 的样本→现 harness 假 PASS 实证）→ 修复 → 反证（同样本变 FAIL）→ 全量 210 重跑证明零误伤; 修复后该注入样本删除
6. **B.6 验收样本**: 主样本 `wvmp_sse_bridge_sample`（C++ intrinsic 真产物 movd/movq 双向四形 + _mm_add_epi64 + 负例区: movdqa/pmovmskb/pcmpeqd——**函数级分区** 426 惯例）+ 影子（#79 全套: 桥 handler 进 dump 注册表 + ctx.xmm 读回钉高位清零位级语义——**movd 后 xmm[15:4] 必为 0 类断言**）; multiseed 42→**44**（主/影配对 425/426 惯例）→ 预计 **220/220**
7. **B.7 GAPS/文档联动**: :164-166 行改写（movd 桥+paddq 面摘除/或砍面精确化 + **编码错值修正**）+ G6a 节 ④ 挂账行同步 + STATUS 里程碑

## §C 决策点（项目主已拍板）

- **D1 B.2 频率驱动双向授权**（✅）: 425 你砍过 movd 留 G1c, 本单 paddq 族同权利——实测证据说话, 砍/留都不算失败, 无证据拍脑袋才算
- **D2 legacy（无 66）MMX 形态禁入**（✅）: `mm` 寄存器操作数（MMX 状态）= 与 x87 共享 MMX/X87 状态域——418 永久 gate 面, **capstone 报 mm 操作数一律 unsupported**（operand 判据钉死, 单测负例）; 无 66 前缀的 movq xmm,xmm/m64 SSE 形态（0F 6F/7E/7F）入面随 B.1
- **D3 pmovmskb 不本单**（✅）: 需 GPR 写回 + 位图提取新语义面, 且 kCtxSize/flags 无涉但独立族小单更干净——GAPS 精确登记（426 后整数残余仅剩此 + pcmpeq 族）
- **D4 B.1 桥 handler 用 native 直执行先例**（✅ 建议非强制）: 419 xadd/bts 的"单 VmOp native 直执行"模板对桥语义（纯 ctx 内拷贝, 无 EFLAGS）干净适用; 但既有 XmmLoad handler 若改造更省 op 数, 你实测选——两路均须 D1 预算达标

## §D 验收标准

1. build 0 新警 / ctest 16/16（+新用例: 桥双向四形各 ≥2、高位清零位级断言、D2 mm 负例、paddq 若入面 lane 进位边界 [0xFFFF...F + 1]、C4/C5 movd 若入面双编码）/ **multiseed 220/220**（44 样本）
2. **harness 盲区修反证链**: 注入 segfault 样本 修复前 PASS（假）→ 修复后 FAIL → 删除注入 → 全量零误伤重跑绿（§B.5 三步全实证, 报告附 rc 值）
3. 新样本真虚拟化 + 桥语义值（int↔SIMD 往返恒等 + movd 后高位=0）+ 影子 byte-exact + 负例区逐条 gate note
4. 实汇编对照表: intrinsic → MSVC 字节（实测, 与 §A.3 先验对账, 推翻披露）→ capstone id/operand.size → VmOp 链; /arch:AVX 档 vmovd 形态 ≥2 行（若入面）
5. 零回踩: 210 既有全绿 + wvmpTest 14/14 + jump-table/ExitNative 17 + lock/string/425/426 面 note 原样 + 双跑 103/103 diff 0
6. **kVmOpMax ≤ 101** + 冻结契约全套（runtime.hpp/ir::Op/backend.hpp/callgate/419/423 载体域 5..13/425 域 14..18/426 TranslateResult.extra 语义不动）
7. 硬条款: 命名分支 `mit-g1c-movd-bridge` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账
8. dump/static 双门 PASS（新桥 handler 进注册表; 既有 handler 集合不回归——426 #79 同款）

## §E 纪律

worktree 隔离（分支签出自建）/ wvmpTest 禁覆写 / `cmd /c` bat（禁 `cmd //c` 静默空跑, 查 build log 时间戳）/ vendored capstone id 实测（`.deps/capstone-src/include/capstone/x86.h`:764-765 MOVD/MOVQ 已亲验在位, 但 **operand 形态细节=capstone 5 probe 实测**）/ MASM 手编 F7 组纪律（423 §7.4 教训: ModRM 手算双验, 误编即 cdb 反查禁猜）/ **#33 铁律**: §A.2 我的编码纠错 + §A.3 intrinsic 产物先验 + D4 模板建议 **全部实测兜底, 推翻项目主优先**（本单派单方已知自错 1 处, 后续以你复核实测为准入 GAPS）。

## §F known compromise 预判

1. paddq 若砍面: 整数 SIMD 算术残余=本族+pmovmskb+pcmpeq, GAPS 精确文本兜底, 后续按频率单开
2. movd 桥 handler 若走 GP 双槽中转折法（非新 op）: 字节码 +2 条/每次桥（性能非正确性, 425/426 §F 同款）
3. VEX vmovd xmm8..15 跟踪区外同 legacy 口径 gate（426 §F.3 同款, xmm8-15 扩展=档B/kCtxSize 冻结面议）
4. harness 修复对"native 正常但 packed segfault"单向崩已覆盖, 反向（native 崩 packed 不崩）理论不可达——披露即可

时间预算: ~1-2 天。== MIT-G1c 派活单完 ==
