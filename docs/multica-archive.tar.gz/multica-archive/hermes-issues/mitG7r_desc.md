# WVmp MIT-G7r 派活单 — C5 x86 (16/32-bit 目标) 支持侦察：全管道改造面审计 + 实施拆单蓝图

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: GAPS 收口计划 (G 线) W1 侦察单 (与 G1 实施并行, 零代码冲突) | GAPS.md C5 节 | STATUS.md:99 "marker_scan 仅 x64"
> 先例与质量基线: MIT-405/D1 triage (`.multica/mit-D1-triage.md`) — 五路互证 / 纠正派单方事实错误 / PE 直读复算
> 侦察者: WVmpVerifier — 你是唯一交付者, 不落主仓代码

---

## §A 基线事实 (项目主 fresh verify @ main c04ca49, 2026-08-29)

### A.1 现网
- main `c04ca49`; multiseed 30 样本 150/150 (全 x64); wvmpTest 14/14 (x64)
- GAPS C5 原文主张: "x86 目标实际不可用" (GAPS.md:117); STATUS.md:99: "marker_scan: 仅 x64 (GAPS C5); O2 尾调用编成 E9 jmp (不产生 E8) 不覆盖"
- **GAPS 写于早期, 其主张本身可能部分过时 (C4 先例: GAPS 声称 rip 拒绝、实测早已全线实现) — 你的第一职责: 以 main 代码为准逐条审计 C5 主张, 标 真缺口/已支持/过时**

### A.2 x64 实现的位宽耦合点 (项目主已知, 供你起点而非全表)
- runtime.hpp VmContext: xmm 借槽 regs[24..31], ctx+0x110 image_base, flags 槽 ctx+0x98 — **RIP/EIP 与 8 通用寄存器 vs 32 位 8 通用**
- asmgen: x64 机器码直出 (keystone CS_MODE_64? 实测), syscall ABI 假定
- stub_gen: 入口 stub x64 编码 + push-ctx 布局 + callgate step4-8 (x64 参数寄存器 RCX/RDX/R8/R9)
- translator/lifter: X86_MODE_* 与 `Size::S64` 假定链 (lifter 有 `arch` 参数, 实测其 x86 分支是否存在半成品)
- pe_loader/pe_writer: `IMAGE_FILE_MACHINE` 探测? OptionalHeader PE32 vs PE32+ 处理 (rva_to_offset/节表/重定位基数字节宽度 4 vs 8)
- marker_scan: 只扫 E8 (call) 于 x64 文本? 32 位相对寻址 E8 rel32 同款但基址语义差
- CLI/config: 目标架构字段存在? (`wvmp_cli.exe --help` 与 config schema 实测)
- **16-bit 目标基本可判定超界** (保护壳生态: Win32 PE 才是现实需求) — 你的报告按 **32 位优先, 16 位仅登记不可行性证据**

## §B 任务 (四问矩阵, 逐子系统)

对 {pe_loader, marker_scan, lifter, translator, backend/asmgen 运行时, stub_gen, runtime.hpp 布局, pe_writer, CLI/配置, 测试基建 multiseed/e2e.bat}:
1. **B.1 现状**: x86/32 位形态支持/拒绝/崩溃证据 (grep + 代码直读, 行号引用)
2. **B.2 32 位最小可用改动集**: 不改什么就"安全拒绝 32 位输入" (当前对 PE32 输入的实际行为: 拒绝还是产出错壳? **必须实测**: 编一个 32 位测试 exe 跑 wvmp_cli, 观察行为链 — 这决定本侦察 GO/NO-GO 风险)
3. **B.3 全支持工作量分级**: S/M/L/XL 按子系统 + 依赖序 (e.g. pe_loader 位宽 → lifter arch 分叉 → asmgen CS_MODE_32 → stub ABI)
4. **B.4 关键设计决策预案**: 双架构 VM 一套 vs 分叉 (先例: ir::Op 冻结 → 32/64 共用 op 用 Size aux 的可行性实测), REX vs 无 REX 编码表复用度, VM 寄存器数/栈帧差异, EFLAGS 共享位差异

### B.5 32 位样本工程可行性
- 本机工具链: `where cl` + vcvars64 环境只有 64 位 cl? **host vs target 区分**: VS Insiders 装 x86 tools 组件? 实测 `cl /B1` 或 vcvars_amd64_x86; **msvs 若不可得, 找 MinGW-w64 -m32 / 已有仓内测试产物** — 给出可复现产 32 位测试 exe 的完整命令 (实施单 §A 要照抄)
- multiseed/e2e 基建: 32 位样本入池需要脚本哪些参数化 (现硬编码 x64 路径/`/MACHINE`/dumpbin)

### B.6 输出与裁决
交付 `.multica/mit-G7r-triage.md` (先例格式): ① GAPS C5 逐条审计 (真缺口/过时表) ② 现状矩阵 ③ 工作量分级+依赖图 ④ 三选一路线建议: (P1) 全量 x86 对齐实施拆单蓝图 (按 W6 排波) / (P2) 最小可用=安全拒绝面修复+文档化 (32 位输入明确 gate 非静默坏壳) / (P3) 判定 ROI 不足不投入 ⑤ 项目主拍板所需的全部证据 (④ 每条路线附前置单草案)

## §C 硬纪律

1. **不落主仓代码, 不碰 main**; 实验 (编 32 位 exe/跑 CLI) 全在 `%TEMP%` 或自建 worktree, 不覆写 wvmpTest 基线产物, 不改仓内 build/
2. **#33**: 项目主 §A 的"已知耦合点"列表不完整是常态, 发现新耦合必须列出; 主张推翻处给文件:行+复跑命令
3. 每个"已支持"判定 = 实测证据 (拒绝/崩溃/通过三态明确); 每个"工作量"分级 = 锚点清单支撑 (禁拍脑袋)
4. **≥30 分钟**; 交付前 `git status --short` tracked 零脏 + 切回 main (硬条款首次对侦察单生效)
5. cdb=`C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe`, dumpbin/capstone 路径见先例, 工具缺失如实报告不硬凑

## §D 报告质量参考 (405/D1 验收过的标准)

互证 (代码直读 + 实跑行为 + PE 直读 Python struct 复算) ≥3 路; 事实错误纠正明示 (项目主 §A 错了直接说); 数字给"分母+命中+例外逐条"。

时间预算: ~半天 (侦察)。== MIT-G7r 派活单完 ==
