# WVmp MIT-G8a 派活单 — BMI1/2 折条款目：andn/bzhi 零新 VmOp 折条 + rorx/shlx/sarx/shrx flagless 变体（P1 机制首个客户）

> 派活单生成: 2026-08-31, 接手人 (项目主)
> 关联: 选A 收官波第二单 | **硬前置已毕**: MIT-433 (P1) 合入 main `cdc218d`（flags_tail_partial @ asmgen:587 + G8a 接口预留注释 :583——本单即其首个客户）| 蓝图 = `.multica/mit-G9r-triage.md` §2.5 G8a + §2.1 flags 表 + §2.2 形态分布（动手前通读）| 基线 47 样本 **235/235**，wvmpTest 14/14，硬条款八连满分
> 交付形态: **main 之外的命名分支 `mit-g8a-bmi-fold`**（硬条款，违者退回重交）

---

## §A 基线实测事实 (项目主 fresh verify @ main cdc218d, 2026-08-31 14:0x)

### A.1 现网
- main = `cdc218d`; build 0 / ctest 16/16 / **multiseed 47×5 = 235/235**; kVmOpMax=97（跳表余量 30——本单目标 **flagless 走既有 handler 变体，预算 ≤+2 op 或零新增**）
- P1 遗产（本单直接复用）: `flags_tail_partial`（CF/OF setcc5 装配 + ZF/SF/PF 经 flags_ 活镜像 `and 0x19` 原位保留——**rorx/shlx/sarx/shrx 的"全五位保留"语义 = partial 的极端形：连 CF/OF 都不写**，见 §B.3 载体辨析）
- 折叠原料白名单在位亲验: Op::Not/And/Shl/Sub GP 形 8 命中; ROL/ROR :2338; VEX 三地址折叠框架 `vex_desc_of` Fam 表（:1633+，现全 SSE 族）

### A.2 频率与范围（432 定版，本单不再复议）
- 入面: **andn**（smartscreen 168/ClipUp 48）、**bzhi**（python314 8——低频但折条近零成本）、**rorx**（1088+288 高频头部）、**shlx/sarx/shrx**（ucrtbase 41+6/ntdll 28/python314 30）
- 不入面: mulx/pdep/pext = **G8b**（L 后置：native 直执行 + CPUID gate 基建 + 厂商分叉决策）；blsr/blsi/blsmsk = **语料 0 裁掉**（432 §6.4 裁决，文档化 gate）
- 形态主路径: BMI dst 独立 **91-100%**（432 §2.2——比 VEX SIMD 的 26-70% 更高，前置 Mov 是常态不是边角）

### A.3 ⚠️ 项目主预登记的三个陷阱（本单翻车点，逐条实测处置）

**陷阱① translate_vex128 位宽闸不放 GP**: 426 入口 `:1546-1551` 要求寄存器操作数 `op.size==16`——**GP 寄存器 4/8B 直落 unsupported**。BMI 不能硬挤 426 入口，需 `translate_bmi` 独立入口（或 Fam::Gp 分支绕闸），但**三地址折叠逻辑（dst 独立→前置 Mov / d==s1 直走）应提取共用而非复制**。操作数归一化实测钉: capstone 对 rorx 报 op_count=3 (r,r,imm8)、shlx (r,r,r)——cnt 源在 reg（shlx 族）≠ 既有 translate_shift 的 imm/cl 形态，**"cnt-in-reg" 是 GP 域新操作数形态**（既有 Shl 载体 cnt 来自哪里——实测核 map 通道，禁假设）。

**陷阱② 载体域 22.. 与 shift count 立即数碰撞（432 蓝图"src2=imm(22..)"方案存疑，项目主自查）**: ror/shl 的 src2=imm 合法值域 **0..255 全覆盖标记域**——`ror eax, 24` 与"kFlagless 24"**不可区分**。419 lock 靠 `is_lock_carrier_op` op 限定挡住 imul，但 **ror/shl 本身就是被标记 op**，op 限定失效。候选出路（你实测选型，D1）: (a) Size 域标记（GP shift 仅 S32/S64——借 `Size::S128` 等不可能值，425 Andnps cond_or_size 先例）; (b) ir Operand aux/其他闲置字段（实测核字段余量）; (c) 独立 Op 枚举不可行（ir::Op 冻结）。**选定后全域对账清单（419 D1 铁律）+ `ror eax,24 不误拦` 回归用例必钉**。

**陷阱③ flagless ≠ P1 partial**: rorx 全五位不写（CF/OF 也保留）——**flags_tail_partial 仍写 CF/OF**。需要的是"flags 零写回"极端形: 直通 = 跳过 flags_tail 全程（值写回+advance 即可），或 partial 掩码扩至 0x00。**别照抄 :746 的 partial_flags 布尔**——先 SDM+probe 复核（432 §2.1 已双验 rorx/shlx 全保留，引用注明）。

### A.4 flags 语义事实（432 §2.1，引用非自测——实施前 probe 复核义务）
rorx/shlx/sarx/shrx: 全五位 unaffected（Zen5 probe ✓）; andn: CF=0/OF=0/ZF/SF/PF 按结果——**Op::And 尾行天然全集**（Not 无 flags→And 写回=语义精确，零特判）; bzhi: 尾行 And 覆盖=全集（432 表注）。count=0 语义（BMI 与 shift 不同！rorx count=0 仍写?——SDM: rorx/shlx count 无 0-短路差异，与原生 ror 的 "count=0 不动 flags" 路径**不一样**，§B.2 实测钉）。

## §B 任务

1. **B.1 andn 折条（零新 VmOp）**: `Op::Not(src1)→temp→Op::And(temp,src2)→dst`——temp 来源实测选（xmm8 类比 GP scratch: 413 v18..v23 双槽先例？还是 (Op,aux) 融合——你定，**禁新增 VmOp**）; dst==s1/d==s2 三态（426 折叠框架提取共用 §A.3①）
2. **B.2 bzhi 折条（零新 VmOp）**: Mov+Shl+Sub+And 四连（432 §2.5②尾行 And flags 全集成立）——中间行 flags 覆写链逐条核对（每行 Op::Shl/Sub 都写 flags，中间覆写被尾行覆盖=最终正确，但**性能+字节码膨胀披露**）; count>=64 的 bzhi 边界语义（SDM: index>=op_size→结果 0, ZF…）实测钉进单测
3. **B.3 rorx/shlx/sarx/shrx flagless**: 载体按 §A.3② 实测选型（域对账清单一票否决项同 419）; handler 侧 = 既有 Ror/Shl/Sar/Shr native 执行体 + **flags 零写回尾**（§A.3③ 极端形，可 flags_tail_partial 掩码参数化 0x00——asmgen 改造量最小路径，但 D1 零新 VmOp 下"同 op 分 flagless 尾"的 dispatch 机制你实测设计）; count=0 与原生 shift 语义差异实测（§A.4）
4. **B.4 shlx cnt-in-reg 操作数通路**: cnt 从 GP 槽直读（既有 shift 的 cl/imm 通道对照）——**新操作数形态全链实测**（lifter map→IR→translator 字节码→handler 取 cnt），禁假设复用
5. **B.5 E2E 样本**: 主样本 `wvmp_bmi_sample`（MASM 直写: andn/bzhi/rorx/shlx/sarx/shrx × {d==s1, d 独立 91% 主形态, reg-mem src(BioIso mulx 先例说明 mem 形惯用)} + 负例区: mulx/pdep/pext/blsr/evex）——**影子样本必须单基本块**（432 §6.3 前向分支块硬约束）+ REQUIRE_REAL; multiseed 47→**48 = 240/240**
6. **B.6 文档**: GAPS BMI 行更新（G8a 落地面 + G8b/blsr 残余精确化，432 §5.2 草案为底）+ STATUS 里程碑

## §C 决策点（项目主已拍板）

- **D1 flagless 载体与 handler 分尾机制 = agent 实测选型**（✅）: §A.3② 三候选都评估；handler 侧两种实现（(i) 同 op 双尾分叉字节码 vs (ii) 4 个新 VmOp FlaglessRor.. ——**预算: (i) 零新增 > (ii) +4 ≤101**，两路字节码尺寸/复杂度实测对照后选，报告披露）
- **D2 mulx/pdep/pext/blsr 禁入**（✅）: G8b/文档化 gate 已裁——出现"顺手也就 +3 op"的诱惑时记住 432 §4 反方数字（客户态 14/14 全零），G8a 的价值上限=覆盖 /arch:AVX2 编译器自然产物，BMI intrinsic 手写面留 G8b 拍板
- **D3 P1 接口是复用不是重写**（✅）: flags 装配改动优先落在 partial 机制的延长线上; 若实测发现 flagless 需要 flags_tail 第三形，**共享函数零扰动纪律沿用 P1 D2(ii) 手法**（新函数不改旧）
- **D4 andn 与 SIMD andnps 命名撞车处置**（✅）: capstone id ANDN=412/ANDNPS=414 分裂（432 亲验），lifter case 层面互染不可能；**单测钉 `andn r,r,r`（BMI）与 `andnps xmm`（SSE）双正例并存零串扰**

## §D 验收标准

1. build 0 新警 / ctest 16/16（+矩阵: 6 指令×三态 ≥12 用例、shlx cnt-reg 通路、bzhi 边界、count=0 差异形、D4 双 andn 串扰钉、`ror eax,24 不误拦` 载体回归）/ **multiseed 240/240**（48 样本）
2. 新样本真虚拟化（REQUIRE_REAL）+ 影子单基本块 + 负例区 mulx/pdep/pext/blsr 全 gate note + 双跑 byte-exact
3. 实汇编对照表: MASM 字节→capstone id/op_count/操作数形态→载体标记→折叠 IR→VmOp 链，六指令各 ≥2 行; **flags 五位列 native probe vs VM 读回对照**（影子样本 ctx.flags 或 Store 通路落盘值）
4. 零回踩: 235 既有全绿 + wvmpTest 14/14 + **P1 新样本 flags_rol 5/5 原样** + rot handler 逐字节不变（本单不得再动 P1 面——asmgen diff 若触碰 build_shift/flags_tail_partial 函数体即违规，新增函数允许）+ 逐 handler 对账口径（**禁 packed sha 恒等**——433 教训入册）
5. enum: 预算内（D1 选型对应 97 或 ≤101）+ 冻结契约（runtime.hpp/ir::Op/backend/callgate/既有载体域 0..21 零重排）
6. 硬条款: 命名分支 `mit-g8a-bmi-fold` + main 未动 + tracked 零脏 + 切回 main + ff-safe + ≥30 分钟 + 时间对账
7. dump/static 双门 PASS（handler 集合变化与 D1 选型一致披露）

## §E 纪律

worktree 隔离 / wvmpTest 禁覆写 / `cmd /c` 查 log 时间戳 / MASM 手编双验（BMI 全 C4/E3 前缀形——428 pp 位教训，vvvv 编码手算必 probe 反查）/ 观察纪律: flags 消费走区内 Store（427）/ 432 §2.1 引用数字标"引用 G9r probe"、重叠形态自测对账 / **#33**: §A.3 三陷阱与 §A.4 语义事实**全部实测兜底**，尤其陷阱② 若你发现 aux/Size 通道也不干净（第四条出路）——**先评论披露再动手**。

## §F known compromise 预判

1. andn/bzhi 折条字节码 2-4 倍膨胀（低频面可接受，415 串指令微程序先例）
2. shlx 族 flagless 若走 (i) 双尾分叉——dispatch 表不膨胀但 handler 生成器分支+1; (ii) 新 op——跳表余量 30→26; 两路都留痕，收官后按实际客户痛点点单
3. bzhi 中间行 flags 覆写序列与 native"原子 bzhi"在中断可见性上理论差（VM 单线程无异步标志观测者，等价性论证一段文本）

时间预算: ~2-3 天（432 §2.5 G8a 估 M）。== MIT-G8a 派活单完 ==
