# WVmp MIT-G7p2 派活单 — x86 安全拒绝面：pe_loader PE32 bug 修复 + 显式 gate + 文档收口

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: G 线 W1.5 (412/G7r 侦察 P2 裁决采纳) | main `1734829` (411 合入) | 完整证据链: `.multica/mit-G7r-triage.md` (139 行, 项目主亲验复现其 §3.1/§3.3 关键行为)
> 前置阅读: 本单 → triage §0/§2/§3.3/§4 (S 级两行)/§7 P2 节/§8 新耦合 #1#2

---

## §A 基线实测事实 (项目主 fresh verify @ main 1734829, 2026-08-29 21:5x)

### A.1 现网
- main = `1734829`; multiseed **160/160** (32 样本); wvmpTest 14/14; 411/G1 刚合入 (lifter 折叠, 与本单文件面零重叠)
- 环境: 412 侦察留样全在 `%TEMP%\mit412_x86\` (hello32/marker32/craft32 + 36 变异体) — **项目主已亲验**: 新鲜 main CLI × hello32 → protect rc=0、warning"桩未找到"、输出仅 0x140/0x141 两字节差 = CheckSum。"PE32 静默无操作"= 当前真实行为, 用户风险主张成立

### A.2 本单四挂点 (triage 锚 + 项目主复核)
| # | 锚 | 事实 |
|---|---|---|
| 1 | **pe_image.cpp:74-78 PE32 分支** | 项目主直读证实: `r.skip(4)/*BaseOfCode*/; img.image_base = r.read_u32()` — PE32 真实布局 = BaseOfCode(4)+**BaseOfData(4)**+ImageBase(4)，**漏读 BaseOfData → image_base/section_alignment/file_alignment 三字段错位 4B** (PE32+ 分支正确: skip4+read_u64)。后果链 triage §3.3: section_alignment 误读 = 0x400000 → stub_link 把 .wvmp RVA 对齐到 0x400000 → 加载器节 VA 连续性拒绝 (WinError 193) |
| 2 | **marker_scan_pass.cpp:173** | `fr.arch = ir::Arch::X64` 硬编码一行; PeImage.machine 已解析可用 |
| 3 | **静默无操作面** | PE32 输入 → magic 不连续"未找到" → 全链空转 → 输出≈输入 → 用户以为受保护。显式拒绝必须**响亮度语义** (非零退出或 ERROR 级 + 文档) |
| 4 | **section_builder.cpp:99-110** | 只查节重叠不查空洞 (triage 新耦合 #2) → 加防御校验 |

## §B 任务 (P2 四件套)

1. **B.1 pe_loader PE32 bug 修复**: PE32 分支补读 BaseOfData (或显式 skip 后 image_base 改 read_u32 — 你选型, 注释写明布局证据); `test_pe_loader.cpp` +PE32 fixture 逐字段断言 (image_base/section_alignment/file_alignment + BaseOfData 本身若入结构则一并); **回归硬底线**: 160/160 + wvmpTest 14/14 全绿 (PE32+ 路径零扰动——x64 一切字节不变, 抽 3 样本 packed.exe sha256 前后 diff 证明)
2. **B.2 x86 显式 gate**: machine==0x014C 输入在**合适单点** (你按 framework pass 契约实测选型: pe_loader 标记后 virtualize/stub_link 跳过 or 直接 pipeline 错误) 输出 **ERROR 级 diag**: `"32 位目标 (x86) 未支持 (GAPS C5); 不产出保护壳"` + **非零退出码** (响亮度: 静默 0 退出=同罪); x64 行为零变化
3. **B.3 marker_scan arch 预备** (可选加餐, S): :173 改从 PeImage.machine 推导 (X86→Arch::X86); 本单 gate 在前, 此改动仅为未来 P1 铺路且必须零行为变化 (x64 路径恒 X64); 若你判定与 B.2 纠缠则**放弃并披露**, 不强做
4. **B.4 节 VA 连续性防御**: section_builder 追加节时校验 RVA 与前一节无空洞 (对齐后 start == prev end), 违反 → 显式 fail 非静默; 单测覆盖 (手工构造空洞布局断言拒绝)
5. **B.5 文档收口**: GAPS C5 节按 triage §1 审计表改写 (真缺口/过时四行分明) + 16-bit 不可行登记 (§4 末行证据) + STATUS.md:99 同步 + README/CLI 文档"支持目标 = x64 PE" 明示; triage §8 新耦合 #4 (CRT E8 误归属) 转录 GAPS 观察清单

## §C 决策点 (项目主已拍板)

- **D1 gate 语义 = 硬失败** (✅): protect 遇 32 位输入返回非零 + ERROR diag。**不做"尽力而为静默透传"** — 消灭欺骗态是本单存在理由; 若你实测认为某用户流程 (批量脚本) 会因此断裂, 披露后提供 `--skip-unsupported` 类开关 (默认仍硬失败)
- **D2 BaseOfData 不新增字段** (✅ 先验): img 结构若加 base_of_data 则动 pe_image.hpp 公共面; 除非 B.1 需要, 优先仅修读取序不扩结构 (你实测, 扩了披露字段用途)
- **D3 B.3 可选自弃** (✅): 见任务原文
- **D4 连续校验只严不松** (✅): 真产物 (对齐恒连续) 零触发; 若你构造测试发现任何合法 PE 布局被误拒 → 校验条件放宽到实测正确集并披露

## §D 验收标准

1. build rc=0 (0 新警) / ctest **17/17 或 16/16+扩既有** (PE32 fixture + 连续性校验用例必新增)
2. **multiseed REQUIRE_REAL=1 = 160/160 零变化** + wvmpTest 14/14 + 双跑 103/103 + jump-table@0xDD84 + ExitNative 17 全数原样 (x64 零扰动抽 3 样本 packed sha256 前后 diff 表)
3. **行为三态新表** (你实测断言): PE32 无 marker → **硬失败非零退出** (旧: rc=0 静默); PE32+magic 变体 (craft32 类) → 同样硬失败 (旧: 产 193 坏壳); x64 全路径逐字节不变。留样命令: `%TEMP%\mit412_x86\hello32.exe` + `craft32.exe` + 任一 x64 样本
4. B.1 修复证明: 修复前 craft32 → .wvmp RVA 0x400000 (复现 triage); 修复后 (gate 前若走解析路径) 字段实测正确值 (image_base=0x400000/sec_align=0x1000 类) — 报告给修复前后 CLI 日志/PE 直读对照
5. 冻结契约: backend.hpp/ir::Op/runtime.hpp/callgate/jump-table 比较链零触碰
6. **硬条款**: tracked 零脏附输出 + 完工切回 main (无并发占用时; 被占用如实披露——412 例外注记); 单分支 ff-safe
7. ≥30 分钟; 数据主张附复跑命令 (412 教训: 时间报告与 run 对账, 禁自相矛盾)

## §E 纪律 (407 v2 版全文继承)

worktree 隔离 / wvmpTest 基线禁覆写 / `cmd /c` / PE 直读复算用 Python struct (405/412 先例脚本思路) / **#33**: §A 锚点行号基于 main 1734829 项目主复核, 你实测若有出入按实测。

## §F known compromise 预判

1. 拒绝非支持——32 位用户仍无保护 (P1 全量对齐另 6-8 单 backlog, W6 排期, asmgen XL 锚)
2. gate 点在解析后, 32 位输入仍完成 pe_loader 解析才拒 (可接受: 修复 bug 后解析本身无害且必要)
3. x86 真产物 (SDK magic 拆分) 锚点方案 (§6) 不在本单 (属 P1 G7x-1)

时间预算: ~半天 (S+M 混合四件套)。== MIT-G7p2 派活单完 ==
