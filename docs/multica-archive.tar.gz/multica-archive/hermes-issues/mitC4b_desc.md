# WVmp MIT-C4b 派活单 — SSE 指令族 memory 形式（含 rip-relative 全局访问）lifter+translator+asmgen 支持

> 派活单生成: 2026-08-29, 接手人 (项目主)
> 关联: MIT-407/D2 v2 done (main `eaa73af`, ExitNative 启用, wvmpTest 13/14) + MIT-248 (GP rip 读/写路径先例: LoadRva/StoreRva/LeaRva) + MIT-371~376 (SSE 五连单, 当年明文"不支持 MEM form"——本单补此缺口) + GAPS.md C4 (本轮实测修正, 见 §A.1)
> 前置阅读: 本单全文 → `docs/GAPS.md` C4 节 → asmgen.cpp `build_storerva`(:845) / `build_loadrva` 一对 GP 模板 → translator.cpp `emit_address`(:120-135 rip→RVA 通道)

---

## §A 基线实测事实 (项目主 fresh verify @ main eaa73af, 2026-08-29 18:0x)

### A.1 重要方向修正: GAPS C4 已过时
- **GP(整数) rip 读/写路径已全线实现**: translator 五处 dst-rip→`StoreRva`(:496/636/707/1345/1461) + src-rip→`LoadRva`(:209/468/630/703/1338) + `LeaRva`(:447) + asmgen `build_storerva`(:845)/loadrva 双 handler 在位; movzx/movsx/alu-mem/单目全走 `emit_address`; MIT-248 双样本 + **404 起已注册 multiseed**。GAPS :79-86 "翻译器明确拒绝" 描述作废
- **C4 真残余 = SSE 族 memory 形式**（本单任务面）:
  | 层 | 实测位置 | 现状 |
  |---|---|---|
  | lifter | `x86_translate.cpp:970-973` (add) 及 sub/div/mov/bitwise/ucomis 同构五处 | `operands[1].type != X86_OP_REG → unsupported()` — mem 形式**进不了 IR** |
  | translator | `:1057-1066/1089/1115/1139-1141/1171/1199-1201` | `src.kind != Reg → skip("SSE 浮点X 操作数形态未支持")` — 双保险 gate |
  | asmgen | 无 xmm↔[mem] 原语 | 需新 handler (或组合) |
- **需求真实性**: MSVC x64 /Od 对全局浮点/数组 (`double g_x; g_x+=1;` / `arr[i]`) 常直接 emit `movsd xmm0,[rip+g_x]` / `addsd xmm0,[rip+rax*8]`——SSE mem 形式是真实函数高频形态, Block C 阶段 3 当年按派活单限定砍掉, 本单补回

### A.2 现网基线 (main eaa73af, 项目主 407 收口时全量亲测)
build 0 错 / ctest 16/16 / **multiseed 27 样本×5=135/135** / wvmpTest 13/14 + 双跑 103/103 byte-exact
- VmOp 锚: `ExitNative=80, kVmOpMax=80` (#34 append-only 在其后, 本单 +1~2 值 <128)
- **xmm 槽体系**: translator 用 `ir::Reg 0..7 借用 + 24 偏移` → `VmContext.regs[24..31]` (= xmm 区 @ kCtxXmmBase, asmgen `movups` 16B 读写); stub 入口/HALT 双同步 xmm0-7
- verifier 工具链: `dump_handler_xmm_check.py` (SSE_HANDLERS 表 12 handler ctx.xmm 写回实证) — 新 handler 若写 xmm 槽必须注册进该表
- rip→RVA 通道细节: `emit_address` 负越界返回 false → caller skip→C1 gate (保守底线, 本单沿用)
- ExitNative/CallGate 刚收口的面**不得回踩**: asmgen dispatch 表 / callgate step 4-8 / kExitSlotDepth 消费点

### A.3 形式全集 (本单支持面, 与 MIT-371~376 五连单对偶)
- 读: `addss/addps/addpd/divss/.../xorps/andps/ucomiss/ucomisd xmm1, [mem]` (src=mem)
- 写: `movss/movsd/movaps/movups/movapd/movupd [mem], xmm1` (dst=mem; **movaps/movapd 对齐版 dst=mem 须 16B 对齐保证, 见 D2**)
- 读写: `add/sub [mem], xmm1` 形态 (StoreRva+LoadRva 双 emit 或专用) — **若首轮实测过深可披露后砍, 留 D3**
- mem base 两类都要: rip 全局 (`[rip+disp]`) 与 **非 rip (`[rax]`, `[rbx+rcx*8]` 数组下标)** — 后者 MSVC 循环体高频, emit_address 通道现成
- 宽度语义 (SDM Vol.2): ss=4B / sd=8B / ps=16B 全量 / pd=16B 全量; 非对齐访存一律 `movups` 语义 (见 D2)
- 不支持面 (越界即披露): AVX、x87、`movaps` 对齐保证缺失场景的强行虚拟化、SSE2 整数族 (movd/movdqa p 形式)

## §B 任务 (六件套)

1. **B.1 lifter**: 五处 translate_sse_* 放开 `X86_OP_MEM` → `mem_operand()` (:37 通用通道) 构造 IR (dst/src 之一 Kind::Mem + base/index/scale/disp 齐全); unsupported 面收窄后, 旧派活单 "派活单限定不支持 MEM form" 注释同步改写 (文档-代码漂移教训, MIT-B2)
2. **B.2 translator**: translate_sse_* 支持 mem 操作数 → `emit_address` 得地址 → 新 VmOp 读写 xmm 槽 (D1 授权选型); GP regs 槽与 xmm 槽不得互踩
3. **B.3 VmOp + asmgen**: 新增 handler (候选形态见 D1); 全部立即数 `imm()` (#78); 新 handler 若写 xmm 槽 → 注册 `dump_handler_xmm_check.py` SSE_HANDLERS + 影子样本 ctx.xmm 读回 (#79 纪律: byte-exact 对 SSE 写 GPR 槽形态不可见)
4. **B.4 E2E 样本**: 新 `wvmp_sse_rip_sample` (+ 按需影子): 全局 `double`/`float` 标量 + 对齐数组, 覆盖 §A.3 读/写/数组下标 base 非 rip 三类形态; 值打印 byte-exact; **__declspec(align(16)) 显式对齐** (对齐语义见 D2)
5. **B.5 注册**: CMakeLists + multiseed (27→28 样本, 预计 140/140)
6. **B.6 文档**: `docs/GAPS.md` C4 节更新 (GP 已 done + SSE mem 本单收口, 引用本 MIT 号); §A.1 的过时描述一并修正。**#33 兜底**: 任一 §A 假设实测推翻 → disclosure 优先按实测定
7. **B.7 (顺带)**: lifter note 日志 hex 已修 (407); 若 SSE unsupported note 有十进制残留一并修

## §C 决策点 (项目主已拍板 2026-08-29)

- **D1. handler 形态**: 授权 agent 二选一并披露理由 — (a) 新增 `XmmLoadRva/XmmStoreRva`(+非 rip 版) 专用 VmOp (movups/movss/movsd 直连 [VA], 干净); (b) 复用 GP `LoadRva` 到临时槽 + `movq/movdqa` GP↔xmm 搬运 (不加 VmOp 但多两条指令)。(a) 为先验推荐, 若 (a) 实测撞编码墙改 (b) 不算失败
- **D2. 对齐安全**: 运行时一律 **movups 非对齐语义** (含 movaps/movapd mem 形式——PE 不保证全局 16B 对齐, 用对齐版指令=埋 #GP 雷, MIT-406 对齐案先例); 样本必须另含 align(16) 与非对齐全局各一组证明无差异
- **D3. 首轮范围**: 读 (src=mem) + 写 (dst=mem) 两类必做; `addss [mem],xmm` 读写双访存形态若 lift→emit 链路首轮过深, **可诚实披露砍出范围**留 C4c, 不算失败
- **D4. ucomis src=mem**: 必做 (比较读内存是全局浮点判等高频形态); NaN 语义沿用 SDM 真值表 (MIT-376 已对齐)

## §D 验收标准

1. build rc=0 (0 新警) / ctest 16/16 / **multiseed REQUIRE_REAL=1 全绿** (26 既有+exitnative+新样本, 预计 **140/140**)
2. 新样本真虚拟化 PASS (stub≥1 且 `PASS（虚拟化后行为与原生一致）` 字样, 非 gate 绿) + 值 byte-exact; 对齐/非对齐两组输出一致 (D2 证明)
3. **零回踩**: wvmpTest 13/14 + 双跑 103/103 不变; ExitNative/callgate/五连单 SSE reg-reg 行为逐字节一致 (135 既有 runs 全绿即证)
4. enum append-only 括号自查 (#34); imm() 全走 + static_scan PASS (#78); 新 handler 注册 dump_handler_xmm_check.py 且 PASS (#79)
5. 冻结契约: 不动 callgate step4-8 / kExitSlotDepth 三消费点 / runtime.hpp 既有布局常量 / 130+5 既有样本
6. 报告含: 支持形式矩阵 (助记符×mem/rip×读/写 → PASS/gate 逐格) + D1/D3 选型披露 + §A 被推翻项 (如有)
7. **硬条款 (407 v2 起生效)**: 完工报告前主工作区 `git status --short` tracked 零脏 + 附输出; 交付 = 基于 main eaa73af 的单分支 commit 链 (ff-safe); 切回 main

## §E 纪律

≥30 分钟 / #38 红线 / build/ 占用自开 worktree / wvmpTest 基线产物禁覆写 (protect 输出落 %TEMP%) / `cmd /c` 单斜杠 / cdb=`C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe` / **反证类主张须附固定二进制可复跑命令** (406 教训) / honest disclosure 优先。

## §F known compromise 预判

1. SSE mem 形式的 scale/index 形式若撞 emit_address 边界 (scale 非法等) → false→C1 gate, 保守兜底不算失败
2. D3 砍面后 ucomis/mov 系仍全达 = 本单核心目标达成
3. 新 VmOp 若 +2 值, kVmOpMax 82<128 余量充足; 越界风险零

时间预算: ~1 天。== MIT-C4b 派活单完 ==
