# MIT-452 (X5cr 跳转目标块侦察) 裁定 — ACCEPT；裁决 (a) 接线级缺口实锤：x86 ExitNative 上界恒 nullopt（.pdata 硬绑）——一个 lambda 分支翻正 17 处；二十连

> 裁定人: 项目主 — 2026-09-02 18:5x | 处置: ff-merge main=`9647a13`, done | X5c 实施立项输入已齐（见 §4 待拍板）
> 复验: 纯侦察单（424/432/436 先例）——triage 163 行 + 只读脚本落盘亲点, 零产品代码 diff, agent worktree 自拆切回 main

## 1. 独立复验（判据链我亲手三点复做）
| 项 | 实测 |
|---|---|
| **T1 点位直读** | `regvm_backend.cpp:98` lambda 首行 `if (pe == nullptr || pe->pdata_empty) return std::nullopt;`——注释自证"407 越区跳转 ExitNative 上界接线=该函数 .pdata RUNTIME_FUNCTION EndAddress, .pdata 缺失返回 nullopt→维持原 C1 gate"。**x86 恒 nullopt → 判定链条件 D 恒失败 → 全落 skip:1671**——机制成立 |
| **x86 PE 无 .pdata 亲验** | 我直读 DataDirectory[3]: PE32 Exception **RVA=0x0 count=0** vs x64 RVA=0x10D000 count=21,660——设计事实钉死 |
| **双 arch 对照锚复跑** | x64: **en=17 / jtbn=0 / stubs=14** 我亲手复跑逐位吻合（x86 侧 en=0/17 处/总面 30 系派单前我亲跑+agent 复测双确认）|
| **17↔17 配对** | triage 表: 双 arch 逐站点操作码 0 失配（jmp/jne/jae/jg/je/ja/jge 逐对同构）——"两个 17"确为同一批源级跳转, 我派单的猜想坐实 |
| x86 runtime 就绪 | `asmgen.cpp:5299 build_x86_exitnative`（X3c 445 协议面）直读在位——修后无 runtime 障碍 |
| 回跳 BFS | 复刻 lifter 回跳检测 0/17——exit_native_blocked 无干扰 |
| 锚失配披露 | 我 §A.2 草记"aebb×2"实为 jtbn×1+间接 jmp×1——agent 点名（#33 第 N 次兑现, 我的现场草记也会错）; 行号重钉 :1644-1669/:1671 |
| 硬条款 | 命名分支+纯文档脚本+零脏+切回 main+worktree 自拆+ff-safe+42 分钟——**二十连** |

## 2. (b)(c) 排除合格
(b) "skip 即正确设计"——被"目标全落 [end_rva, 下一区域 begin) 函数尾 gap/end 桩 call, x64 同类正由 ExitNative 消化"否定; (c) "未 lift"——17/17 条件 C 全真（都在区域外）否定。裁决 (a) 三组对照实验+判定链模型 x64 17/17 复验 emit=True（模型可信性自证）——**侦察成色: 单型零杂, 教科书级**。

## 3. 泛化结论（比 wvmpTest 本身更值钱）
"任何无 .pdata 目标的 ExitNative 现状恒不可达 = **接线级缺口非 wvmpTest 特有**"——即: x86 全客户面上区外跳转 ExitNative 从未工作过（407 面在 PE32 上是哑的）。真实客户占比待 X5c 落地后 436 方法学重扫（agent 未编造, 口径合格）。

## 4. X5c 立项待拍板（本裁定的决策输入）
- **F1（报告推荐, S 级）**: backend 上界 lambda `pdata_empty` 分支补 `ub = min{下一区域 begin_rva}`, 无后继回退 .text 节尾; 不动 translator, x64 恒等。预期: en 0→17 / **stubs 0→10**（14 区−push-imm×2−间接jmp−stack-depth）/ 总 skip 面 30→13
- **F1-lite（保守）**: 纯 next-begin 无 .text 兜底 → 末区 0xC972 一处维持 gate, 16/17, stubs 预期 9
- 我倾向: **F1 全量 + 末区 .text 兜底行为在验收中单独反证**（stubs=10 读数+该处双跑 byte-exact 专项）——兜底正确与否恰是最该被测试钉住的边界, 躲开它反而留盲点。
