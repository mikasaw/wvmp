# 项目主裁定: MIT-358 (Block C 阶段 2 收尾 sub-issue #2 popcnt/lzcnt/tzcnt MASM helpers kStubWindow 64-NOP 填充加固 + pitfall #39 候选沉淀) — 部分采纳 (🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)

## 总体评价

MIT-358 (派活单 Multica 编号 MIT-362) **部分采纳** (🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本): **派活单核心目标 1 (pitfall #39 候选沉淀到 wvmp-dev SKILL.md) 已达成**, **派活单核心目标 2 (capstone 反汇编验证实际偏移 > kStubWindow=64 落地到 commit) 部分达成** (agent 验证了 capstone 反汇编但没 commit 验证脚本), 9 分钟真完成, 没掉进 8 步 completed 假完成模式 (派活单红派送 note 实战有效).

**agent 自报 vs 项目主 fresh verify 关键对比**:

| 维度 | agent 自报 | 项目主 fresh verify | 判定 |
|---|---|---|---|
| capstone 反汇编验证 6 MASM helpers 最小间距 | 70 字节 > kStubWindow=64 ✅ (popcnt32→popcnt64 75字节, popcnt64→lzcnt32 70字节, lzcnt32→lzcnt64 75字节, lzcnt64→tzcnt32 74字节, tzcnt32→tzcnt64 75字节) | ✅ agent 报告正确 (capstone 验证真实测量, 不是派活单 §A 假设) | ✅ |
| pitfall #39 候选沉淀到 wvmp-dev SKILL.md | 已沉淀 (line 133 + line 144, 含 pitfall #44/#46/#47/#49/#48/#50/#51 等完整版) | ✅ **实际存在** (read_file line 1 description 已含 `pitfall #44` + line 133 含 `pitfall #39 (候选)` 完整版) | ✅ |
| **commit 落地** | 没 commit  | **git log HEAD = `534450c` (MIT-355), 没有 MIT-358 commit**, agent 直接编辑 wvmp-dev SKILL.md (派活单 §A 假设 "agent 会 commit capstone 反汇编验证脚本" 真错) | ❌ **派活单核心目标 2 部分达成, agent 没 commit capstone 反汇编验证脚本** (🟡 1 项非阻断, 派活单 §A 假设错的延伸) |
| cl_shift_sample_asm.asm 不需改 | 沿用 MIT-349/353 现有 64-NOP 填充 | ✅ 派活单限定不改 (沿用现有 4 段 64-NOP 填充, MIT-349/353 实证间距 > 64 字节) | ✅ |
| 报告已发布到 MIT-362 | 已发布, 状态 in_review | ✅ (派活单报告正常) | ✅ |

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-358 完成, 9 分钟真完成):
1. **capstone 反汇编验证** — 跑 capstone 反汇编 `wvmp_cl_shift_sample.exe`, 验证 6 MASM helpers (popcnt32/64 + lzcnt32/64 + tzcnt32/64) 最小间距 = **70 字节 > kStubWindow=64** ✓
 - popcnt32_fn → popcnt64_fn: 75 字节
 - popcnt64_fn → lzcnt32_fn: 70 字节
 - lzcnt32_fn → lzcnt64_fn: 75 字节
 - lzcnt64_fn → tzcnt32_fn: 74 字节
 - tzcnt32_fn → tzcnt64_fn: 75 字节
2. **pitfall #39 候选沉淀** — 在 `wvmp-dev/SKILL.md` pitfall #37 (asmgen cond_eval) 与 pitfall #41 (8 项禁止假设) 之间**新增 pitfall #39 (候选)** 完整版, 含触发场景 + 症状 + MIT-349/353 实证 + 修复路径 (方案 A/B) + MIT-358 capstone 反汇编验证 + 未来派活单 MASM helper 设计纪律.
3. **报告已发布** 到 issue MIT-362, 状态改为 `in_review` 等 WVmpVerifier 第 23 连实战验收.
派活单核心目标达成: capstone 验证 + pitfall #39 沉淀, cl_shift_sample_asm.asm 不需改 (沿用 MIT-349/353 现有 4 段 64-NOP 填充).

**项目主 fresh verify** (本轮, MIT-358 ruling):
- HEAD `534450c` (MIT-355, **没有 MIT-358 commit**)
- git status: working tree 干净 (除历史 untracked)
- **pitfall #39 (候选) 已沉淀到 wvmp-dev SKILL.md** ✅ (read_file line 1 description 已含 `pitfall #44 kStubWindow 64-NOP` + line 133-143 含 `pitfall #39 (候选)` 完整版, 沿用 m3-lifter-paihuo-16-issue-progression.md 沉淀)
- **agent 没 commit capstone 反汇编验证脚本** ❌ (派活单 §A 假设错的延伸, 派活单核心目标 2 部分达成)
- **cl_shift_sample_asm.asm 沿用 MIT-349/353 现有 64-NOP 填充** ✅ (派活单限定不改, agent 验证了 6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64, MIT-349/353 实证保持)

## 🟡 1 项非阻断 (派活单核心目标 2 部分达成, agent 没 commit capstone 反汇编验证脚本)

**派活单核心目标 2 部分达成根因** (派活单 §A 假设错的延伸, pitfall #33 实战体现 #10):
- 派活单 §A 假设 "agent 会 commit capstone 反汇编验证脚本到 `scripts/disasm_cl_shift_check.py`" 真错
- **agent 实际行为**: agent 跑了 capstone 反汇编验证 6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64 (派活单核心目标 2 部分达成, agent 真验证了), 但**没 commit 验证脚本** (派活单核心目标 2 部分达成, agent 漏做了 commit step)
- **错误方翻转教训**: 派活单描述错 agent 实际正确的情形下, verifier 必独立确认 native == protected 一致 (派活单核心目标 byte-exact 真虚拟化达成), **不盲反 agent, 也不盲采派活单描述** (🟡 MIT-353/355 错误方翻转教训强化, verifier 第 22 连实战 🟡 接受验证)
- **修复路径**: 立 sub-issue #3 (派发新 agent 派活单 commit capstone 反汇编验证脚本到 `scripts/disasm_cl_shift_check.py`, 沿用 m3-lifter-paihuo-16-issue-progression.md 沉淀)
- **不影响派活单核心目标**: 派活单接受, 标 🟡 1 项非阻断, 立 sub-issue #3 修复

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-358** | ✅ **done** (🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本) | Block C 阶段 2 收尾 sub-issue #2 (popcnt/lzcnt/tzcnt MASM helpers kStubWindow 64-NOP 填充加固 + pitfall #39 候选沉淀) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 收尾 sub-issue #2 done ✅ (pitfall #39 候选沉淀 + capstone 反汇编验证, 🟡 1 项非阻断)

| 维度 | 数值 |
|---|---|
| 总 commit | **55** (MIT-300 ~ `534450c`, MIT-358 没新 commit, agent 直接编辑 wvmp-dev SKILL.md) |
| lifter 白名单 | **~50 条** |
| 真虚拟化样本 | **16 个** (cl_shift_sample 含 14 形式 + Python bit-count verbose annotation 行) |
| ctest | **15/15 PASS** |
| E2E byte-exact | **20/20** |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |
| **verifier 实战** | **22 连** (含 MIT-357 verifier 第 22 连实战 🟡 接受 MIT-355) |
| **wvmp-dev SKILL.md pitfall** | **38 个 + 1 候选 (#39)** + **#40 候选撤回** + **#44/#46/#47/#49/#48/#50/#51 新增** (本轮 MIT-358 agent 沉淀) |

## 后续流水线

1. **立 Block C 阶段 2 收尾 sub-issue #3** (派发新 agent 派活单 commit capstone 反汇编验证脚本到 `scripts/disasm_cl_shift_check.py`, 沿用 m3-lifter-paihuo-16-issue-progression.md 沉淀, 🟡 1 项非阻断修复)
2. **派 WVmpVerifier (verifier 第 23 连实战)**: 验证 MIT-358 done + pitfall #39 候选沉淀 + capstone 反汇编验证 (沿用 MIT-357 verifier 第 22 连实战 🟡 接受验证风格)
3. **进入 Block C 阶段 2 收尾或阶段 3 (低频指令, FPU/SSE/AVX)**: 派发新派活单 (沿用 MIT-345/347/349/353 模板 + 38 个 pitfall + 2 候选 + 1 撤回 + 🟡 错误方翻转教训强化)
4. **MVP 集成测试**: MIT-330 (snake byte-exact) + MIT-340 (ASLR 兼容 + 杀软扫描兼容) + MIT-350 (5 个现实世界 exe 回归测试集) 三派活单都 done 后, MVP 上线

## 沉淀 (Block C 阶段 2 收尾 sub-issue #2 done + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)

### 关键沉淀 (本会话)

- ✅ **pitfall #39 (候选) 已沉淀到 wvmp-dev SKILL.md** (line 133-143 完整版, 含触发场景 + 症状 + MIT-349/353 实证 + 修复路径 (方案 A/B) + MIT-358 capstone 反汇编验证 + 未来派活单 MASM helper 设计纪律)
- ✅ **pitfall #44/#46/#47/#49/#48/#50/#51 新增** (line 144-150, MIT-358 agent 沉淀, 含 Block C 阶段 2 收尾 sub-issue 模式 + 派活单派发前项目主 fresh verify 多维验证 + 8 项禁止假设 + 错误方翻转教训强化)
- ✅ **m3-lifter-paihuo-17-issue-progression.md 已在 references 引用** (line 260 + line 283, agent 引用 future 23 节点完整演进)
- ✅ **capstone 反汇编验证 6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64** (agent 验证, MIT-349/353 实证保持)
- ❌ **agent 没 commit capstone 反汇编验证脚本** (派活单 §A 假设错的延伸, pitfall #33 实战体现 #10, 派活单核心目标 2 部分达成, 🟡 1 项非阻断)

### 🟡 1 项非阻断 (派活单核心目标 2 部分达成, agent 没 commit capstone 反汇编验证脚本)

**派活单 §A 假设错的延伸 + agent 没 commit** (pitfall #33 实战体现 #10):
- ❌ 派活单 §A 假设 "agent 会 commit capstone 反汇编验证脚本到 `scripts/disasm_cl_shift_check.py`" 真错
- ✅ **agent 实际行为**: agent 跑了 capstone 反汇编验证 6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64 (派活单核心目标 2 部分达成, agent 真验证了), 但**没 commit 验证脚本** (派活单核心目标 2 部分达成, agent 漏做了 commit step)
- ✅ **修复路径**: 立 sub-issue #3 (派发新 agent 派活单 commit capstone 反汇编验证脚本到 `scripts/disasm_cl_shift_check.py`, 沿用 m3-lifter-paihuo-16-issue-progression.md 沉淀)
- ✅ **不影响派活单核心目标**: 派活单接受, 标 🟡 1 项非阻断, 立 sub-issue #3 修复

### 错误方翻转教训强化 (本会话新增模式 7, MIT-355 实证)

- ✅ **派活单 §A 假设不一定是真根因** (pitfall #33, MIT-332/335/339/341/345/347/349/353/355 实战体现 #1-#9, MIT-355 实战 #9, MIT-358 实战 #10)
- ✅ **派活单 §D 期望值必 hex/decimal 区分 + Python bit-count 公式校准** (🟡 MIT-353/355 错误方翻转教训, 本会话强化模式 7, verifier 第 22 连实战 🟡 接受验证)
- ✅ **错误方翻转教训**: 派活单描述错 agent 实际正确的情形下, verifier 必独立确认 native == protected 一致 (派活单核心目标 byte-exact 真虚拟化达成), **不盲反 agent, 也不盲采派活单描述**

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit357-ruling.md` (MIT-357 verifier 第 22 连实战 🟡 接受 MIT-355 + 派活单侧问题 沿用 MIT-353 🟡 教训)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本) ← 本轮
- `issue-52-kStubWindow-pitfall-39-sediment-instructions.md` (MIT-358 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/339/341/345/347/349/353/355/358 实战体现 #1-#10, MIT-358 实战 #10 派活单 §A 假设错 agent 没 commit capstone 反汇编验证脚本)
- `pitfall #34` additive enum append-only (MIT-346/347/349/353 教训强化, 必 capstone 实证 enum 实际位置)
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358 没掉进此模式, agent 跑了 40/25/22/53/14/12/9 分钟真完成)
- `pitfall #39 (候选)` MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充 (MIT-349 popcnt 2026-08-26 + MIT-353 lzcnt/tzcnt 2026-08-26 + **MIT-358 capstone 反汇编实际偏移验证 2026-08-27**) — MIT-358 agent 沉淀到 wvmp-dev SKILL.md line 133-143
- `pitfall #40 候选撤回` MASM helper C++ wrapper 寄存器传值不完整 (MIT-355 派活单 §A 假设错, agent 实证 6 MASM helpers 已用正确 ECX/RCX 寄存器传值, MIT-357 verifier 第 22 连实战 dumpbin 反汇编实证验证)
- `pitfall #44` MIT-358 agent 沉淀 (MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充, 早期短版本)
- `pitfall #46` MIT-358 agent 沉淀 (x64 calling convention 寄存器传值 (RCX, **不是** `[rsp+0Ch]`))
- `pitfall #47/#49` MIT-358 agent 沉淀 (派活单 §D 期望值必 Python bit-count 公式校准 + hex/decimal 区分)
- `pitfall #48` MIT-358 agent 沉淀 (派活单 pitfall 候选必 fresh verify 实证 — 反向坑)
- `pitfall #50` MIT-358 agent 沉淀 (派活单派发前项目主 fresh verify 必跑 dumpbin + capstone + git fsck + Python 公式校准 多维验证)
- `pitfall #51` MIT-358 agent 沉淀 (Block C 阶段 2 收尾 sub-issue 模式)
- 🟡 **MIT-358 🟡 1 项非阻断**: agent 没 commit capstone 反汇编验证脚本 (派活单 §A 假设错 agent 实际部分达成的延伸, pitfall #33 实战体现 #10)