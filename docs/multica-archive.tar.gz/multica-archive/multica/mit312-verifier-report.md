# MIT-307 (派单标 MIT-312) verifier 报告

## 总体评价

MIT-307 提交（lifter 接 movsxd 32→64 位符号扩展）**实现完整、测试覆盖到位**。所有 4 种字节形式（REG-REG、REG-REG REX.B、REG-MEM RSP+disp8、REG-MEM base+disp8）均被 lifter 接住；新增 VmOp::Movsxd + MovsxdMem handlers 在语义测试 + 5 万条 fuzz 中零退化；6 单测 + 4 interpreter 测试全绿。

snake 仍 C1 gate 的**根因已确认是 snake_sample 设计缺陷**（3 个 WVMP_END），非 movsxd —— agent 主动披露准确，与派活单独立核查一致。

**建议接受**。MIT-307 自身目标达成，snake 真虚拟化闭环需后续 issue fix snake_sample 区域配对或 marker_scan 支持命名空间 BEGIN。

## 1) git state

- HEAD: `8e88881` MIT-307: lifter 接 movsxd (32→64 位符号扩展)
- Branch: main
- Status: clean
- 提交者: wvmp-dev (本地)
- Author date: 2026-08-25 15:32:59 +0800

> 派活单标题 "MIT-312" 与实际 commit 标识 "MIT-307" 不一致（属派活单编号错位），commit 内容与派活单 §A 反汇编 4 种 movsxd 形式一致。

## 2) build

- `scripts\build.bat` rc: 0
- 0 错误 0 警告
- 292/292 steps（链接 13 E2E 样本 + 15 单测二进制 + cli + tool）
- grep "warning\|error" build.log → 0 / 0

## 3) ctest

- 15/15 PASS（含 6 新 movsxd 单测 + 4 新 interpreter movsxd 测）
- Total Test time: 29.79 sec

```
 1/15 framework_tests              Passed   1.57
 2/15 regvm_isa_tests              Passed   1.14
 3/15 regvm_translator_tests       Passed   0.95
 4/15 regvm_runtime_tests          Passed  13.69
 5/15 pe_loader_tests              Passed   1.52
 6/15 pe_writer_tests              Passed   0.76
 7/15 section_builder_tests        Passed   0.73
 8/15 marker_scan                  Passed   0.71
 9/15 lifter_tests                 Passed   0.84
10/15 virtualize_tests             Passed   2.30
11/15 stub_link_tests              Passed   2.32
12/15 cli_config_and_args          Passed   0.54
13/15 cli_default_config           Passed   1.10
14/15 p0_smoke                     Passed   0.69
15/15 pass_registration            Passed   0.90
100% tests passed, 0 tests failed out of 15
```

新增测试覆盖：
- **lifter 单测 (6)**:
  - `MovsxdRegToReg` (`48 63 D2` movsxd rdx, edx — REG-REG 同寄存器)
  - `MovsxdRegToRegDifferentReg` (`48 63 C1` movsxd rax, ecx)
  - `MovsxdRexB` (`49 63 E8` movsxd rbp, r8d — REX.B 覆盖)
  - `MovsxdMemRspDisp8` (`48 63 44 24 24` movsxd rax, [rsp+0x24] — REG-MEM + SIB)
  - `MovsxdMemBaseDisp8` (`48 63 40 3C` movsxd rax, [rax+0x3c] — REG-MEM 无 SIB)
  - `MovsxdMemRspDispDifferent0x68` (SIB 路径 disp 不同回归测试)
- **interpreter 单测 (4)**:
  - `MovsxdSemantics` — Reg-Reg 语义 + 真执行
  - `MovsxdMemSemantics` — Reg-Mem 语义 + 真执行
  - `MovsxdFuzzTenThousand` — 5 Rng 种子 × 10000 iter fuzz
  - `MovsxdMemFuzzTenThousand` — 5 Rng 种子 × 10000 iter fuzz

## 4) E2E 15/15 byte-exact

跑了全部 15 个 E2E 样本（含 snake）：

| 样本 | 状态 | 含义 |
|---|---|---|
| wvmp_marker_sample | PASS 虚拟化 | 9 个已虚拟化函数 |
| wvmp_whitelist_sample | PASS 虚拟化 | 白名单路径 |
| wvmp_sar_sample | PASS 无 stub | sar 已虚拟化但本次未生成 stub（C1 早期 sample） |
| wvmp_virt_sample | PASS 无 stub | 早期 sample |
| wvmp_adc_sample | PASS 无 stub | 早期 sample |
| wvmp_sbb_sample | PASS 虚拟化 | |
| wvmp_rol_sample | PASS 虚拟化 | |
| wvmp_rip_relative_sample | PASS 虚拟化 | |
| wvmp_rip_relative_simple_sample | PASS 虚拟化 | |
| wvmp_call_gate_simple_sample | PASS 虚拟化 | |
| wvmp_imul_sample | PASS 虚拟化 | MIT-309 imul 真虚拟化 |
| wvmp_cl_shift_sample | PASS 无 stub | movzx 仍未支持（C1 gate, 派活单遗留风险） |
| wvmp_call_gate_sample | PASS 虚拟化 | |
| wvmp_lifter_skip_sample | PASS 无 stub | lifter skip 路径 |
| **wvmp_snake_sample** | **PASS 无 stub** | **C1 gate（区域配对错，非 movsxd）** |

TOTAL: 15 pass / 0 fail byte-exact。

## 5) E2E snake movsxd 真虚拟化核查（核心）

直接跑 `wvmp_cli protect` 完整输出（seed=12345）：

```
[wvmp] [warning] marker_scan: end@0x6c4 没有配对的 begin（区域被丢弃）
[wvmp] [warning] marker_scan: end@0x81d 没有配对的 begin（区域被丢弃）
[wvmp] [note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化（保持原生）:
              跳转目标块未找到（区域外/未 lift） (rva=0x11E1)
[wvmp] [warning] virtualize: 没有任何函数被虚拟化
[wvmp] [warning] stub_link: 无已虚拟化函数，跳过 stub 生成
```

**关键事实**:
- ✅ grep "未支持指令 'movsxd'" 警告数: **0**
- ✅ grep "未支持指令" 全量: **0**
- ❌ snake 仍 C1 gate（真虚拟化闭环未达成）
- ❌ 但根因**不是 movsxd**：C1 gate 触发原因是 `跳转目标块未找到（区域外/未 lift）`，而非任何未支持指令。

## 6) snake 区域配对核查（核心）

### 6.1 snake_sample_main.cpp 真实 WVMP_END 数

```
grep -n "WVMP_BEGIN\|WVMP_END" passes/marker_scan/tests/snake_sample_main.cpp
  92:    WVMP_BEGIN(tick);
 116:        WVMP_END(tick);
 136:        WVMP_END(tick);
 176:    WVMP_END(tick);
```

- **BEGIN 数**: 1（line 92, 在 tick() 函数体开头）
- **END 数**: 3（line 116 撞墙早返回 / line 136 撞自己早返回 / line 176 正常出口）

**实测 3 个 WVMP_END**（与 agent 主动披露一致）。
**期望 1 个 WVMP_END 在函数末尾**（派活单设计原则被违反）。

### 6.2 marker_scan 配对逻辑核查（`passes/marker_scan/src/scan_core.cpp`）

```cpp
PairResult pair_regions(std::vector<size_t> begin_nexts, std::vector<size_t> end_addrs) {
    PairResult res;
    std::vector<size_t> open; // 未闭合 begin 的区域起点栈
    size_t bi = 0, ei = 0;
    while (bi < begin_nexts.size() || ei < end_addrs.size()) {
        const bool take_begin = ei >= end_addrs.size() ||
            (bi < begin_nexts.size() && begin_nexts[bi] <= end_addrs[ei]);
        if (take_begin) {
            open.push_back(begin_nexts[bi++]);
        } else {
            const size_t end_off = end_addrs[ei++];
            if (!open.empty()) {
                res.regions.push_back(Region{open.back(), end_off});
                open.pop_back();
            } else {
                res.unmatched_ends.push_back(end_off);
            }
        }
    }
    res.unmatched_begins = std::move(open);
    return res;
}
```

**这是栈式配对**：
- BEGIN 入栈 → END 出栈
- END 比 BEGIN 多 → 多余 END 进 `unmatched_ends`（**不是**"忽略后续 END"）
- **不支持嵌套 END**——一旦首个 END 闭合区域，后续 END 必 unmatched

### 6.3 实测 END RVA（独立反汇编 + E8 目标解码）：

`.text` section: RVA 0x1000-0x4BFD, raw offset 0x400-0x4000

python 扫描 E8 call 目标，找 WVMP_END stub 被多个 E8 调用：

```
WVMP_END stub @ RVA 0x1670 ← 3 个 callers at:
  0x11ED  ← 1st END (matched, closes region)
  0x12C4  ← 2nd END (unmatched, file offset 0x6c4)
  0x141D  ← 3rd END (unmatched, file offset 0x81d)
```

**精确匹配 agent 报告的 RVAs**：
- 1st END @ RVA 0x11ED → 配对闭合区域 [0x1101, 0x11ED)
- 2nd/3rd END @ RVA 0x12C4, 0x141D → 进 unmatched_ends

### 6.4 `je 0x11E1 → 0x11F8` 在区域外核查

virtualize 警告: `(rva=0x11E1)` 是 je 指令位置（在区域内），其跳转目标 0x11F8 > 0x11ED（区域结束位置），落在区域外。

源码对应：
```cpp
// Line 114-118
if (wall != 0) {
    g_alive = 0;
    WVMP_END(tick);    // <-- 0x11ED
    return;            // <-- 0x11F2 左右
}
```

je 0x11E1 是 `if (wall != 0)` 的条件跳，目标 0x11F8 是早返回块**之后**的代码开头。第一个 END 闭合区域后，跳转目标落在区域外 → 虚拟化无法保持控制流 → C1 gate 触发。

### 6.5 结论

snake 仍 C1 gate 是 **snake_sample 设计缺陷 + marker_scan 不支持嵌套 END** 两个因素叠加：
1. snake_sample tick() 写了 3 个 WVMP_END（设计原则违反）
2. marker_scan pair_regions 栈式配对，首 END 闭合区域后余下 END unmatched

**movsxd lifter 完全无关**（0 条 movsxd 警告）。这不是 agent commit 缺陷，是**派活单设计缺陷**（派活单没反汇编 snake_sample 检查 WVMP_END 数，应在派活前核查）。

## 7) multiseed REQUIRE_REAL=1 (snake 行为)

跑 `REQUIRE_REAL=1 bash scripts/multiseed_e2e.sh`：

| 样本 | 1 | 12345 | 99999 | 0xDEADBEEF | 0xCAFEBABE | 总结 |
|---|---|---|---|---|---|---|
| wvmp_call_gate_sample | ✅ | ✅ | ✅ | ✅ | ✅ | 5/5 PASS |
| wvmp_call_gate_simple_sample | ✅ | ✅ | ✅ | ✅ | ✅ | 5/5 PASS |
| wvmp_rol_sample | ✅ | ✅ | ✅ | ✅ | ✅ | 5/5 PASS |
| **wvmp_snake_sample** | ❌ | ❌ | ❌ | ❌ | ❌ | **0/5 FAIL (C1 gate, 正确原因)** |
| wvmp_cl_shift_sample | ❌ | ❌ | ❌ | ❌ | ❌ | 0/5 FAIL (C1 gate, movzx 未支持) |
| wvmp_imul_sample | ✅ | ✅ | ✅ | ✅ | ✅ | 5/5 PASS |

TOTAL: **20 pass / 10 fail**

- ✅ call_gate 系列: 15/15 真虚拟化
- ✅ imul: 5/5 真虚拟化（MIT-309 修复不破坏）
- ✅ rol: 5/5 真虚拟化
- ❌ snake: 0/5 失败原因明确 = "C1 gate, not real virtualization"
- ❌ cl_shift: 0/5 失败原因 = movzx 未支持（派活单遗留）

**snake 失败原因非 multiseed bug**——验证脚本正确识别 C1 gate 与真虚拟化的区别。snake 的 C1 gate 根因已确认是 marker_scan 区域配对问题（6.5 节），不是种子/伪 PASS 假象。

## 8) imul 回归零退化

`wvmp_imul_sample` 5/5 真虚拟化（multiseed REQUIRE_REAL=1）：

```
[multiseed] PASS seed=1 sample=wvmp_imul_sample.exe
[multiseed] PASS seed=12345 sample=wvmp_imul_sample.exe
[multiseed] PASS seed=99999 sample=wvmp_imul_sample.exe
[multiseed] PASS seed=3735928559 sample=wvmp_imul_sample.exe
[multiseed] PASS seed=3405691582 sample=wvmp_imul_sample.exe
```

MIT-309 imul 修复（lifter 接 imul 三形式 + mul 单操作数）**未被 MIT-307 破坏**。imul 仍真虚拟化，lifte 0 条 imul 警告（movsxd commit 仅新增 enum 值不影响 imul 路径）。

## 9) 冻结契约核查

`git show HEAD --stat` 改动 8 文件：

| 文件 | +/- | 评价 |
|---|---|---|
| `ir/include/wvmp/ir/insn.hpp` | +9 | ✅ 仅新增 `ir::Op::Movsxd` enum 值 |
| `ir/src/insn.cpp` | +3 | ✅ to_string 加 "movsxd" |
| `passes/lifter/src/x86_translate.cpp` | +41 | ✅ translate_movsxd (REG-REG + REG-MEM) |
| `passes/lifter/tests/test_lifter.cpp` | +102 | ✅ 6 新单测 |
| `vm/regvm/isa/include/wwvmp/regvm/isa/vm_op.hpp` | +19 | ✅ VmOp::Movsxd + MovsxdMem |
| `vm/regvm/runtime/src/asmgen.cpp` | +46 | ✅ build_movsxd + build_movsxd_mem |
| `vm/regvm/runtime/tests/test_runtime.cpp` | +168 | ✅ 4 新 interpreter 测 |
| `vm/regvm/translator/src/translator.cpp` | +44 | ✅ Movsxd case |

**关键核查**：
- ❌ common/ 未改
- ❌ framework/ 未改
- ❌ vm/include/wvmp/vm/backend.hpp 未改
- ✅ Operand 结构体**未追加 src3/src4**——`ir/insn.hpp` 仅新增 enum 值
- ✅ 沿用 MIT-309 src2 additive 兼容模式
- ✅ 改动范围严格在白名单内（lifter + ir + vm/regvm + tests）

## 10) 派活单 §A 反汇编列出的 4 种形式核查

派活单 `.multica/issue-18-movsxd-instructions.md` 列出 25 条 movsxd，4 种字节形式：

| 形式 | 字节 | 单测 |
|---|---|---|
| REG-REG (3B) | `48 63 xx` | `MovsxdRegToReg` + `MovsxdRegToRegDifferentReg` |
| REG-REG REX.B (3B) | `49 63 xx` | `MovsxdRexB` |
| REG-MEM RSP+disp8 (5B) | `48 63 44 24 xx` | `MovsxdMemRspDisp8` + `MovsxdMemRspDispDifferent0x68` |
| REG-MEM base+disp8 (4B) | `48 63 40 xx` | `MovsxdMemBaseDisp8` |

**4 种形式全部被 lifter 接住**（grep "translate_movsxd" 验证），6 单测 byte-precise 来自派活单 §A 反汇编。

我独立 python 扫描蛇样本 .text 段 REX.W+0x63 字节序列，发现 26 处 movsxd（agent 报 25，差 1 因反汇编+扫描器精度差异）。无论 25 还是 26，**lifter 均已接住，0 条 movsxd 警告**。

## 11) 风险点与发现

### 11.1 🟡 派活单设计缺陷（**不算 agent commit 缺陷**）

snake_sample_main.cpp 写了 3 个 WVMP_END（line 116, 136, 176），违反派活单设计原则"1 个 WVMP_END 在函数末尾"。派活单派活前**没有反汇编 snake_sample 检查 WVMP_END 数**，这是派活单设计缺陷。

**改进建议**: 下次派活前，不仅反汇编 codegen 还要读样本源文件，看 API 调用模式。

### 11.2 🟡 marker_scan pair_regions 不支持嵌套 END

当前栈式配对：首个 END 闭合区域后，余下 END 全部 unmatched。snake_sample 3 个 END 触发了这一限制。

**改进路径**（任选一）：
- A) snake_sample 改造：删除早返回路径的 WVMP_END，让函数体末尾 1 个 WVMP_END（最简）
- B) marker_scan 支持命名空间 BEGIN：`WVMP_BEGIN_xxx(name)` + `WVMP_END_xxx(name)` 配对（更通用）
- C) snake_sample 重构：把早返回改成统一出口路径

**派活单下次应明确**："区域内**只能有 1 个 WVMP_END 在函数末尾**，早返回路径不允许 WVMP_END"。

### 11.3 🟢 cl_shift 仍 C1 gate（派活单遗留）

movzx 未支持，cl_shift 5/5 仍 C1 gate。**与 MIT-307 无关**，是派活单派活前已点出的遗留风险。

## 12) 验收结论

### 派活单核心目标判定

**派活单核心目标 A: snake 真虚拟化闭环** — **❌ 未达成**
- movsxd lifter 实现完整（25/25 全接住）✅
- snake 仍 C1 gate（根因：snake_sample 3 个 WVMP_END + marker_scan 配对不支持嵌套）❌

**派活单核心目标 B: movsxd lifter 接住 25 条** — **✅ 达成**
- 4 种字节形式全部 lifter 处理 ✅
- 6 单测 + 4 interpreter 测全绿 ✅
- snake 0 条 movsxd 警告 ✅

### 建议给项目主

1. **MIT-307 自身验收**：建议接受 MIT-307（movsxd lifter 部分 done）。
2. **MIT-300 snake 闭环**：snake 真虚拟化闭环需后续 issue 处理：
   - 立 sub-issue: snake_sample 改造（1 个 WVMP_END） **或** marker_scan 支持嵌套/命名空间 END
   - 派活单下次设计样本明确"1 个 WVMP_END 在函数末尾"
3. **派活单流程改进**：派活前**反汇编+读样本源文件**，不仅看 codegen 还看 API 调用模式，避免 snake 派活单这种"派活前没核查 WVMP_END 数"的设计缺陷。
4. **派活单编号错位**：本次派活单标题"MIT-312"但实际 commit "MIT-307"——下次派活前应对齐编号。

---

## 沟通风格备注

- 验证人: WVmpVerifier (0326c8dd-7869-4e04-b6c1-f945746aac29)
- 验证日期: 2026-08-25
- 验证时长: ~1.5 小时
- 置信度: 高（独立 python 反汇编 + E8 目标解码 + multiseed 5 种子 + ctest 完整）