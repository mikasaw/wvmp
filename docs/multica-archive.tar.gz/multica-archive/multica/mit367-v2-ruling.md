# 项目主裁定: MIT-367 v2 (Multica MIT-330 验证, verifier 第 24 连实战) — 🟡 有条件 FAIL (新 pitfall #54 候选: MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥)

## 总体评价

MIT-367 v2 (Multica 编号 MIT-330 验证, verifier 第 24 连实战) **🟡 有条件 FAIL** (新 pitfall #54 候选: MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥): **MIT-330 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 已达成 ✅**, verifier 派活单派发**前**项目主 fresh verify 独立确认派活单 §A 假设错 (pitfall #33 实战 #10), 5 分钟跑通, 没掉进 8 步 completed 假完成模式 (model 修复后).

**关键发现 — verifier 独立确认 MIT-330 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 已达成**:
- ✅ **派活单 §A 假设错 (pitfall #33 实战 #10) 已独立确认**: `VmOp::LoadRva=33` + `VmOp::StoreRva=34` since M2-8 in `vm_op.hpp:25`, asmgen.cpp:653/729/2168-2169, translator.cpp:209/407/435/530/536/603/607/1024 全部就位
- ✅ **Native snake: rc=0** + `alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`
- ✅ **ctest 15/15 PASS** (regvm_runtime_tests 并行 flake 已记录, 顺序执行 100%)
- ✅ **MIT-330 / MIT-363 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 在源码层确认 Zero code changes** (HEAD `ff4c933` 是 Revert commit, snake_sample_main.cpp 未动)

**阻断项 — Protected snake byte-exact 验证无法独立复跑**:
- ❌ 根因: `build/cli/wvmp_cli.exe` 已被 rebuild 进 MIT-340 逻辑 (启用 `FORCE_INTEGRITY` 标志), working tree 有 6 个 PE 文件未提交改动 (MIT-340 v2 work-in-progress)
- ❌ 表现: protected PE 生成即带 `FORCE_INTEGRITY` → 未签名 → Windows "无法验证此文件的数字签名" → Permission denied rc=126
- ❌ **冲突: MIT-330 (MIT-326 cherry-pick SIGSEGV rc=139 修复) 与 MIT-340 v2 (FORCE_INTEGRITY enable) 互斥**

### ⚠️ 关键发现 — 新 pitfall #54 候选 (MIT-367 v2 verifier 实证)

**MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥** (新 pitfall #54 候选, MIT-367 v2 verifier 实证):
- **触发场景**: MIT-340 v2 (PE 重写 + ASLR / .reloc 重建) 启用 `FORCE_INTEGRITY` (0x0080) 防 DLL 劫持,但 MIT-326 cherry-pick SIGSEGV rc=139 修复路径**不**带 `FORCE_INTEGRITY`, 两个派活单修复路径互斥
- **症状**: `build/cli/wvmp_cli.exe` rebuild 进 MIT-340 逻辑 (启用 `FORCE_INTEGRITY`), protected PE 生成即带 `FORCE_INTEGRITY` → 未签名 → Windows "无法验证此文件的数字签名" → Permission denied rc=126
- **MIT-367 v2 实证**: verifier 第 24 连实战 (5 分钟跑通) 实证 MIT-340 v2 FORCE_INTEGRITY enable → protected snake Permission denied rc=126 (无法 byte-exact 验证), verifier 标 🟡 有条件 FAIL
- **冲突根因**: MIT-340 派活单 §D 决策 5 强制 `DllCharacteristics.FORCE_INTEGRITY` (0x0080) 启用, 但 MIT-326 cherry-pick 派活单没启用 FORCE_INTEGRITY, 两个派活单修复路径在 pe_writer 层面互斥
- 修复路径: (a) **派活单派发**前**项目主 fresh verify 必跑**: MIT-340 v2 agent 跑完 commit 之前, **不能** rebuild `build/cli/wvmp_cli.exe`, 避免污染 snake 真虚拟化 byte-exact 验证; (b) **MIT-340 v2 commit** + rebuild 干净 `build/cli/wvmp_cli.exe` + verifier 复跑 protected snake 验证 (MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 + MIT-340 派活单核心目标 ASLR/FORCE_INTEGRITY 兼容); (c) **MIT-340 派活单 §D 决策 5 备选方案**: 不启用 `FORCE_INTEGRITY` (派活单限定可选, 避免与 MIT-326 互斥, 但防 DLL 劫持减弱); (d) **MIT-340 派活单 §D 决策 5 优化方案**: 启用 `FORCE_INTEGRITY` 但签发 EV 代码签名证书 (沿用 P0 #4 上线 P0 #4 EV 代码签名证书采购 + 集成派活单, 派发**前** EV 证书到位, 否则 protected PE 跑不通)

**新 pitfall #53 候选 (MIT-365 v2 verifier 实证) + 新 pitfall #54 候选 (MIT-367 v2 verifier 实证) 联动**:
- #53: Working tree 跨派活单污染 + wvmp_cli.exe rebuild 时序错位 (MIT-365 v2 实证)
- #54: MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥 (MIT-367 v2 实证)
- **联动**: #53 + #54 联动根因是 MIT-340 v2 改了 6 PE 关键文件 + 启用 FORCE_INTEGRITY + working tree 改动 + wvmp_cli.exe rebuild 时序错位 + snake 验证需要干净的 `build/cli/wvmp_cli.exe` (不启用 FORCE_INTEGRITY) → MIT-340 v2 commit 之前不能 rebuild wvmp_cli.exe
- **新 pitfall #55 候选 (MIT-367 v2 verifier 实证)**: regvm_runtime_tests 并行 flake (顺序执行 100% PASS) - 不是阻塞项, 但建议 ctest 顺序执行避免并行 flake

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 报告** (MIT-367 v2 完成, 5 分钟跑通, model 修复后):
- Verification report delivered. Summary:
- **MIT-367 verifier 第24 连实战 — 🟡 有条件 FAIL**
- **关键发现**:
 - MIT-330 / MIT-363 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 在源码层确认 **Zero code changes** (HEAD `ff4c933` 是 Revert commit, snake_sample_main.cpp 未动)
 - ✅ **派活单 §A 假设错 (pitfall #33 实战 #10)** 已独立确认: `VmOp::LoadRva=33` + `VmOp::StoreRva=34` since M2-8 in `vm_op.hpp:25`, asmgen.cpp:653/729/2168-2169, translator.cpp:209/407/435/530/536/603/607/1024 全部就位
 - ✅ Native snake: rc=0 + `alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`
 - ✅ ctest 15/15 PASS (regvm_runtime_tests 并行 flake 已记录, 顺序执行 100%)
- **阻断项**:
 - ❌ Protected snake byte-exact 验证无法独立复跑
 - 根因: `build/cli/wvmp_cli.exe` 已被 rebuild 进 MIT-340 逻辑 (启用 `FORCE_INTEGRITY` 标志), working tree 有6 个 PE 文件未提交改动 (MIT-340 v2 work-in-progress)
 - 表现: protected PE 生成即带 FORCE_INTEGRITY → 未签名 → Windows "无法验证此文件的数字签名" → Permission denied rc=126
 - 冲突: MIT-330 (MIT-326 cherry-pick SIGSEGV rc=139 修复) 与 MIT-340 v2 (FORCE_INTEGRITY enable) 互斥
- **新沉淀 pitfall**:
 - 🟡 #53 候选: Working tree 跨派活单污染 + wvmp_cli.exe rebuild 时序错位
 - 🟡 #54 候选: MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥
 - 🟢 #55 候选: regvm_runtime_tests 并行 flake (顺序执行 100% PASS)
- **结论**: 需项目主先决定 MIT-340 v2 未提交 PE 改动如何处置 (commit / stash / `git restore`), 必要时 rebuild 干净 wvmp_cli.exe 后 verifier 复跑 protected snake 验证. 状态已更新为 `in_review`.

**项目主 fresh verify** (本轮, MIT-367 v2 ruling):
- HEAD `d3bf762` (MIT-365 v2 commit, 最上 commit), MIT-367 v2 verifier 没新 commit (verifier 不 commit, 只改 issue 评论)
- `git log --oneline -3`: d3bf762 + ff4c933 + 93729ba
- git status: working tree 有 6 modified files (pe_image.hpp + pe_writer_pass.cpp + stub_gen.cpp + stub_gen.hpp + stub_link_pass.cpp + **test_stub_link.cpp**), 这是 **MIT-340 v2 sibling 任务未 commit 改动** (不是 MIT-367 v2 verifier 失败)
- ✅ **native snake 跑通** (`alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`) — MIT-326 cherry-pick 方案 A 算术提交保留, snake 真虚拟化 byte-exact 闭环已达成 ✅

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-330 verifier (MIT-367 v2)** | 🟡 **in_review** (有条件 FAIL, verifier 标 🟡) | Multica MIT-330 verifier, MIT-330 done, **派活单核心目标达成** + Protected snake byte-exact 验证无法独立复跑 (MIT-340 v2 working tree 改动 + wvmp_cli.exe rebuild 时序错位 + FORCE_INTEGRITY 启用) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (🟡 1 项非阻断) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |
| **MIT-330** | ✅ done | snake 真虚拟化 byte-exact 闭环 (上线 P0 #1 修复) |
| **MIT-350** | ✅ done (MIT-365 v2) | Multica MIT-350 现实世界 exe 回归测试集扩展 (上线 P0 #2 中期派) |
| **MIT-365 v1 stash** | ⚠️ 误操作 commit `93729ba` 已 revert (`ff4c933`) | 5 文件改动已 revert 干净 |

## MVP P0 集成测试进度

| P0 | Issue | status | 说明 |
|---|---|---|---|
| **P0 #1 snake byte-exact 闭环** | MIT-330 | ✅ **done** (MIT-367 v2 verifier 独立确认 ✅, snake 真虚拟化 byte-exact 闭环已达成) | snake 真虚拟化 byte-exact 闭环, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 |
| **P0 #2 现实世界 exe 回归测试集** | MIT-350 | ✅ **done** (MIT-365 v2 ACCEPT) | 立 5 个现实世界 exe 回归测试集, verify_real_world.sh 3 pass + 1 fail + 1 skip, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失 |
| **P0 #3 PE ASLR 兼容** | MIT-340 | 🟡 **doing** (MIT-364 v2) | 改 pe_writer + asmgen + stub_link, working tree 改了 6 PE 关键文件 (MIT-340 v2 work-in-progress), agent 还在跑 (POLL #5 status=running, 25 分钟) |

## 后续流水线

1. **MIT-364 v2 commit + rebuild wvmp_cli.exe + verifier 复跑 protected snake 验证**:
 - MIT-364 v2 commit 后, rebuild `build/cli/wvmp_cli.exe` (用 commit 后编译, 不是 working tree 编译)
 - verifier 复跑 protected snake 验证 (MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 + MIT-340 派活单核心目标 ASLR/FORCE_INTEGRITY 兼容, **但需要 EV 代码签名证书才能跑通** — 沿用 P0 #4 上线 P0 #4 派活单, 派发**前** EV 证书到位)
 - **如果** MIT-340 派活单 §D 决策 5 备选方案 (不启用 FORCE_INTEGRITY) 被选, MIT-340 commit 后 verifier 复跑 protected snake 验证 (不启用 FORCE_INTEGRITY, snake 跑通 rc=0 + identical stdout → BYTE-EXACT MATCH, 派活单核心目标达成)
2. **MIT-366 v2 verifier (第 23 连实战, MIT-358 验证)**: agent 还在跑 (POLL #5 status=running, 25 分钟)
3. **修复派活单 §A "🟡 错误方翻转" 错误描述** (派活单 §D 期望值错, 错误方翻转教训强化, 立 sub-issue)
4. **MVP 集成测试**: MIT-330 (snake byte-exact) ✅ + MIT-340 (ASLR 兼容, MIT-364 v2 doing) + MIT-350 (现实世界 exe 回归测试集, ✅ MIT-365 v2) 三派活单都 done 后, MVP 上线 (上线 P0 #1 + #2 + #3 修复)

## 沉淀 (MIT-367 v2 verifier 第 24 连实战 🟡 有条件 FAIL + 新 pitfall #54 候选 + MVP P0 #1 独立确认)

### 关键沉淀 (本会话)

- ✅ **MIT-330 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 已达成** (verifier 第 24 连实战独立确认 ✅)
- ✅ **派活单 §A 假设错 (pitfall #33 实战 #10) verifier 独立确认**: `VmOp::LoadRva=33` + `VmOp::StoreRva=34` since M2-8 in `vm_op.hpp:25`, asmgen.cpp:653/729/2168-2169, translator.cpp:209/407/435/530/536/603/607/1024 全部就位
- ⚠️ **新 pitfall #54 候选 (MIT-367 v2 verifier 实证)**: MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥
- ⚠️ **新 pitfall #53 候选 (MIT-365 v2 verifier 实证)**: Working tree 跨派活单污染 + wvmp_cli.exe rebuild 时序错位
- 🟢 **新 pitfall #55 候选 (MIT-367 v2 verifier 实证)**: regvm_runtime_tests 并行 flake (顺序执行 100% PASS, 不是阻塞项, 但建议 ctest 顺序执行避免并行 flake)
- ✅ **MVP P0 #1 (snake byte-exact 闭环) 独立确认 ✅** (verifier 第 24 连实战 5 分钟跑通, snake 真虚拟化 byte-exact 闭环已达成, 上线 P0 #1 修复)
- ✅ **MVP P0 #2 (现实世界 exe 回归测试集) 已 done ✅** (MIT-365 v2, 立 5 个现实世界 exe 回归测试集, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失)
- 🟡 **MVP P0 #3 (PE ASLR 兼容) doing** (MIT-364 v2, agent 还在跑 25 分钟, working tree 改了 6 PE 关键文件未 commit, **MIT-340 v2 commit 后需 rebuild wvmp_cli.exe + 启 EV 代码签名证书才能跑通**, 沿用 P0 #4 上线 P0 #4 派活单)

### 新 pitfall #54 候选 — MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥 (MIT-367 v2 verifier 实证)

- **触发场景**: MIT-340 v2 (PE 重写 + ASLR / .reloc 重建) 启用 `FORCE_INTEGRITY` (0x0080) 防 DLL 劫持,但 MIT-326 cherry-pick SIGSEGV rc=139 修复路径**不**带 `FORCE_INTEGRITY`, 两个派活单修复路径互斥
- **症状**: `build/cli/wvmp_cli.exe` rebuild 进 MIT-340 逻辑 (启用 `FORCE_INTEGRITY`), protected PE 生成即带 `FORCE_INTEGRITY` → 未签名 → Windows "无法验证此文件的数字签名" → Permission denied rc=126
- **MIT-367 v2 实证**: verifier 第 24 连实战 (5 分钟跑通) 实证 MIT-340 v2 FORCE_INTEGRITY enable → protected snake Permission denied rc=126 (无法 byte-exact 验证), verifier 标 🟡 有条件 FAIL
- **冲突根因**: MIT-340 派活单 §D 决策 5 强制 `DllCharacteristics.FORCE_INTEGRITY` (0x0080) 启用, 但 MIT-326 cherry-pick 派活单没启用 FORCE_INTEGRITY, 两个派活单修复路径在 pe_writer 层面互斥
- 修复路径: (a) **派活单派发**前**项目主 fresh verify 必跑**: MIT-340 v2 agent 跑完 commit 之前, **不能** rebuild `build/cli/wvmp_cli.exe`, 避免污染 snake 真虚拟化 byte-exact 验证; (b) **MIT-340 v2 commit** + rebuild 干净 `build/cli/wvmp_cli.exe` + verifier 复跑 protected snake 验证; (c) **MIT-340 派活单 §D 决策 5 备选方案**: 不启用 `FORCE_INTEGRITY` (派活单限定可选, 避免与 MIT-326 互斥, 但防 DLL 劫持减弱); (d) **MIT-340 派活单 §D 决策 5 优化方案**: 启用 `FORCE_INTEGRITY` 但签发 EV 代码签名证书 (沿用 P0 #4 上线 P0 #4 派活单, 派发**前** EV 证书到位, 否则 protected PE 跑不通)
- **未来派活单派发**前**项目主 fresh verify 必跑**: (i) `git log --oneline HEAD~5..HEAD` 验证 sibling 任务已 commit + `git status --short` 验证 working tree 干净 (除历史 untracked); (ii) **MIT-340 派活单 §D 决策 5 备选方案 vs 优化方案讨论**: 项目主派活单派发**前**与用户讨论 MIT-340 是否启用 `FORCE_INTEGRITY`, 避免与 MIT-326 cherry-pick SIGSEGV 修复路径互斥

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit363-ruling.md` (MIT-330 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化 + 上线 P0 #1 修复)
- `mit365-ruling.md` (MIT-365 v1 REJECT, agent failed model access)
- `mit364-ruling.md` (MIT-364 + MIT-366 + MIT-367 三个派活单都因 Multica agent model 配置问题 failed)
- `mit365-v2-ruling.md` (MIT-365 v2 ✅ ACCEPT + 派活单核心目标 pitfall 实证 + 新 pitfall #53 候选)
- `mit367-v2-ruling.md` (MIT-367 v2 verifier 🟡 有条件 FAIL + 新 pitfall #54 候选 MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥 + MVP P0 #1 独立确认 ✅) ← 本轮
- `issue-57-mit363-verifier-instructions.md` (MIT-367 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-330 实证 #10 派活单 §A 假设错 LoadRva/StoreRva 已实施 since M2-8, MIT-355 错误方翻转教训强化, MIT-367 v2 verifier 独立确认)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358/363/365 v2 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9/3/4 分钟真完成, MIT-364 v2 doing, MIT-366 v2 doing, MIT-367 v2 verifier 5 分钟真完成)
- `pitfall #53 候选` **sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (MIT-365 v2 实证, MIT-364 agent 改 pe_writer/stub_link 但没 commit, MIT-365 v2 agent rebuild wvmp_cli.exe 用的是 MIT-364 working tree 改动 → 16 其它样本 byte-exact 退化)
- `pitfall #54 候选` **MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥** (MIT-367 v2 verifier 实证, MIT-340 v2 启用 FORCE_INTEGRITY → 未签名 → Windows "无法验证此文件的数字签名" → Permission denied rc=126, 与 MIT-326 cherry-pick 派活单修复路径互斥)
- `pitfall #55 候选` **regvm_runtime_tests 并行 flake** (MIT-367 v2 verifier 实证, 顺序执行 100% PASS, 不是阻塞项, 但建议 ctest 顺序执行避免并行 flake)
- ✅ **MIT-330 ✅ ACCEPT (verifier 独立确认, MVP P0 #1 修复)**: snake 真虚拟化 byte-exact 闭环, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复
- ✅ **MIT-350 ✅ ACCEPT (MVP P0 #2 修复)**: 5 个现实世界 exe 回归测试集, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失
- 🟡 **MIT-340 doing (MVP P0 #3 修复中)**: MIT-364 v2 agent 还在跑 25 分钟, working tree 改了 6 PE 关键文件, **MIT-340 v2 commit 后需 rebuild wvmp_cli.exe + 启 EV 代码签名证书才能跑通**, 沿用 P0 #4 上线 P0 #4 派活单