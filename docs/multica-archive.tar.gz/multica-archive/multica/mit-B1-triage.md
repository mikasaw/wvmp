# MIT-B1 triage 报告 — multiseed 5 坏样本共享 runtime 崩溃根因

- verifier: WVmpVerifier (独立复跑, 未采纳开发侧任何结论)
- 基线: main `fb66b98` (MIT-376), 全量重建 rc=0 (322/322, 0 error), 本机 VS 18 Insiders v145
- 采集时间: 2026-08-29 09:00–09:35 (+0800), 全部数字来自实测输出粘贴
- 结论置信度: 高 (静态源码 + git 溯源 + 崩溃现场内存实测 + 最小复现四路互证)

## §0 结论(裁定)

**单一根因, H2 成立**: MIT-371 (23f0e25) 把 `VmContext`/kCtxSize 从 0x140 扩到 0x1C8 (stub_gen.cpp:30), 入口 stub 的栈帧随之加深 0x88; 但 callgate handler 的栈回退常量 **`sub rsp, 0x1A8` (vm/regvm/runtime/src/asmgen.cpp:1042)** 仍按旧 0x140 时代推导, 未同步更新。后果:

```
step 3 push ctx_     写入 native_sp - 0x258   (= host_rsp - 8, host_rsp = native_sp - 0x250)
step 7 sub rsp,0x1A8 + step 8 pop ctx_
                     读到 native_sp - 0x1D0   ← 比正确槽位高 0x88 (= 0x1C8 - 0x140)
                     该地址 = stub VmContext 帧 + 0x38 = regs[5] = 保存的宿主 RBP
```

本组样本宿主 RBP = 0 (cdb 现场 rbp=0) → ctx_ = 0 → step 9 `mov pc_, [ctx_+0x8]` 即崩溃指令
`mov r14, qword ptr [rsi+8]` (ctx_=rsi, pc_=r14), 归一化崩点 .wvmp+0x37C0, 5 坏样本 5/5 共享。

**假设裁决: H1 ✗ / H2 ✓ / H3 ✗** (§3)。
**修复方向(D2.1 一句话)**: asmgen.cpp:1042 常量按当前入口栈链重推 = **0x230 (= kCtxSize + 0x68)**, 且必须由 kCtxSize 派生而非硬编码 (Phase 2 派单的 §A 假设可直接采用)。

## §1 B.1 独立复现 (fresh fb66b98 全量重建)

构建: `scripts\build.bat` → Ninja 全链 322/322, `build/cli/wvmp_cli.exe` 10,188,288 B。
CLI md5 `8fa6d8d747a64d6b087e8b75b8ac3d25` (镜像至 build/vs/cli/Debug/, 旧二进制备份于 .hermes/triage/mit393/, 见 §8)。

5 坏样本 + 1 对照, seed=12345, protect → 双跑 → cdb (`.cxr; r; u @rip-0x20 L0x30; q`):

| 样本 | stub 数 | .wvmp RVA | 崩溃 RIP | 归一化偏移 | 崩溃指令 |
|---|---|---|---|---|---|
| wvmp_call_gate_sample | 1 | 0xB000 | 0x14000E7C0 | +0x37C0 | `4c8b7608 mov r14,[rsi+8]` |
| wvmp_call_gate_simple_sample | 1 | 0xB000 | 0x14000E7C0 | +0x37C0 | 同 |
| wvmp_rol_sample | 2 | 0xB000 | 0x14000E7C0 | +0x37C0 | 同 |
| wvmp_cl_shift_sample | 16 | 0xD000 | 0x1400107C0 | +0x37C0 | 同 |
| wvmp_bswap_sample | 3 | 0xB000 | 0x14000E7C0 | +0x37C0 | 同 |
| wvmp_sse_add_sample (对照) | 3 | 0xC000 | — 不崩 — | — | byte-exact PASS |

实测粘贴 (bswap): `rsi=0000000000000000 rdi=000000014000b000` …
`00000001`4000e7c0 4c8b7608  mov r14,qword ptr [rsi+8] ds:00000000`00000008=????????????????`
5/5 与派单 §A 完全一致 (stub 数 / 崩点 / 归一化偏移), **无 D3 披露项**。

全量矩阵复跑 (fresh CLI, `scripts/multiseed_e2e_real.sh`, REQUIRE_REAL=1, 20 样本 × 5 seeds):

```
[multiseed] TOTAL: 75 pass / 25 fail          (real 1m36.9s)
FAIL 集合 (uniq):  bswap / call_gate / call_gate_simple / cl_shift / rol × 5 seeds = 25
```

与 §A 的 75/25 及坏样本集合完全一致。

## §2 B.2 崩点 → handler 定位

三路互证: WVMP_RUNTIME_DUMP 发射序列 (asmgen 自身文本) ↔ cdb 实机反汇编 ↔ capstone 切片。

1. runtime dump: `; ---- handler callgate @ +0x3704 ----` — **崩溃指令属于 callgate handler**, handler 内偏移 0xBC (下一 handler divss @ +0x37DF)。
2. capstone 切片 (protected.exe .wvmp RVA=0xB000 VSize=0x6182, C:/Python314 capstone):

```
+0x378A: 56                push rsi                      ; step 3  asmgen.cpp:1024
+0x378B: 4c 8b 8e 20 01..  mov r9,[rsi+0x120]            ; step 4  asmgen.cpp:1026  (native_sp)
+0x3792: 49 83 e9 28       sub r9,0x28
+0x3796: 4c 89 cc          mov rsp,r9
+0x3799..: mov rcx/rdx/r8/r9,[rsi+0xD0/0xD8/0xE0/0xE8]   ; step 5  asmgen.cpp:1035-1038
+0x37B5: 41 ff d5          call r13                      ; step 6  asmgen.cpp:1040
+0x37B8: 48 81 ec a8 01..  sub rsp,0x1a8                 ; step 7  asmgen.cpp:1042  ★陈旧常量
+0x37BF: 5e                pop rsi                       ; step 8  asmgen.cpp:1044  ★弹出 0
+0x37C0: 4c 8b 76 08       mov r14,[rsi+8]               ; step 9  asmgen.cpp:1046  ←崩溃点
+0x37C4: mov r10,[rsi+0x98] / +0x37CB: mov rdi,[rsi+0x130] / +0x37D2: mov [rsi+0x10],rax
+0x37D6: add r14,1 / +0x37DA: jmp 0x2b                   ; step 11 advance→dispatch
```

3. 寄存器分配印证 (seed=12345 roll()): ctx_=rsi, pc_=r14, flags_=r10, base_=rdi, t_[0]=r13, t_[5]=r12。r11 (VM insn word) = 0x0000456200000023 — **高 32 位 = aux = 目标 RVA 0x4562** ✓。

**rsi 应装什么**: callgate 全程以 rsi=ctx_ 寻址 VmContext (跨 native call 的持久基址, roll() 强制 callee-saved 池, asmgen.cpp:220-228)。

## §3 B.3 三假设裁决

### 现场内存实测 (cdb, bswap protected.exe, 崩点 rsp=0x15FBD8)

模型推导: native_sp = rsp+0x1C8 = 0x15FDA0; stub ctx 帧 (=ctx 指针) = rsp-0x40 = 0x15FB98;
push 槽 = rsp-0x90 = 0x15FB48; pop 实读槽 = rsp-0x8 = 0x15FBD0。

```
dq @rsp-0x90 L1   → 00000000`0015fb48  00000000`0015fb98   ★push ctx 槽内容 = ctx 指针本体 (rsp-0x40) ✓
dq @rsp-0x8  L1   → 00000000`0015fbd0  00000000`00000000   ★pop 实读槽 = 0 (= regs[5] = 宿主 RBP)
dq [rsp-0x40]+0x120 → 00000000`0015fcb8  00000000`0015fda0   = native_sp 预测值 ✓
dq [rsp-0x40]+0x128 → 00000000`0015fcc0  00000000`0015fb50   = host_rsp = native_sp-0x250 ✓
dq [rsp-0x40]+0x8   → 00000000`0015fba0  00000000`00000003   = 崩点前 pc = 3 (第 4 条 VM insn = call) ✓
```

**两槽实测差 = 0x15FBD0 − 0x15FB48 = 0x88 = kCtxSize 漂移量 (0x1C8−0x140)。**

### git 溯源 (git log -S)

```
0x1A8 常量:   b880720 (MIT-249 [C3] call gate 引入) → 最后改动 9ac3d53 (MIT-299)
kCtxSize:     b880720 (0x140 时代) → 23f0e25 (MIT-371 改 0x1C8)
MIT-371 改动范围: stub_gen.cpp kCtxSize 0x140→0x1C8 + lea 0x180→0x208 (stub 侧自洽),
              runtime.hpp +xmm[8]; 但 `git show 23f0e25 -- asmgen.cpp | grep callgate|0x1A8`
              = 无命中 → build_callgate 的栈回退常量**未被触碰**。
```

### 裁决

- **H1 (特定 handler 指针装载缺陷) ✗ (机制层面)**: 命中的确是 5 样本共享的同一 handler (callgate), 但 ctx 并非"从未装入"——step 3 push 正确落槽 (现场 0x15FB48 = 0x15FB98 实证); 也非 callee 覆写 (push/pop 成对设计本就防 clobber)。真实机制 = **pop 读错槽**。
- **H2 (ctx 布局漂移) ✓**: kCtxSize 0x140→0x1C8 (MIT-371) 未同步 callgate step 7 常量。漂移量 0x88 与现场两槽差精确相等。注: ctx 内**字段偏移** (0x120 native_sp / 0x128 host_rsp / 0x140 xmm) 本身无漂移, 漂移的是"栈回退常量"对 kCtxSize 的隐式依赖——精确表述为 **callgate 栈回退算术对 kCtxSize 的隐式耦合在 MIT-371 断裂**。
- **H3 (样本过期) ✗**: 本验证以 fb66b98 全量重建 + 全新样本二进制复现 5/5, 与 §A 逐项一致。

### 为什么恰好这 5 个样本 (callgate op 判别式)

崩在 callgate 的前提 = 虚拟化区域字节码含 CallGate op (translator.cpp:551, E8 直接 call):
- call_gate / call_gate_simple: **设计如此** (C3 样本, 区域含 call helper)。
- bswap: 区域内 `_byteswap_ulong` 在 VS 18 Insiders + /MDd (ucrtbased) 下**未内联**, 编译为 call thunk → 目标 = ucrtbased.dll!_byteswap_ulong (IAT 0x5200 解析实证; 源码注释"codegen 为真 bswap 指令"的假设在本工具链不成立)。
- rol: 同上 → ucrtbased.dll!_rotl64。
- cl_shift: 区域内 call 本地辅助函数 (目标 RVA 0x2320, `sub rsp,0x28` 真函数序言)。
- 15 个 PASS 样本区域均无 call → 永不进入 callgate handler。

## §4 B.4 最小复现 (已做)

两个临时样本 (C:\Users\www\AppData\Local\Temp\mit393_b4\, **未进仓库**), cl /Od /Ob0 /MDd /Zi + wvmp sdk 静态链接, seed=12345:

| 样本 | 区域内容 | stub | 结果 |
|---|---|---|---|
| mit393_a | 纯 shl/shr/or, **无 call** | 1 | **byte-exact PASS** |
| mit393_b | `unsigned r = x+1; helper();` **单个直接 call** | 1 | **崩, 签名与 5 坏样本完全相同** |

```
mit393_b: native rc=0 out=[called=305419897 sink=0]; protected rc=139 out=[]
(612c.352c): Access violation - code c0000005
00000001`4000c7c0 4c8b7608  mov r14,qword ptr [rsi+8]  ; rsi=0, rdi=0x140009000
归一化: 0x14000C7C0 - 0x140009000 = +0x37C0  ✓ 同一处
```

→ **根因锁定到 handler 粒度**: 区域含 call 即崩 (无论 call 目标是 CRT 还是本地函数), 不含 call 即好。rol/bswap/cl_shift 的算术 handler 本身无恙。

pitfall 记录: 首次构建未加 `/link /INCREMENTAL:NO` → ILT E9 跳板 → marker_scan 配对失败 → C1 兜底 "没有任何函数被虚拟化" → byte-exact 假 PASS。与 CMakeLists.txt:15-19 注释所述一致, 独立编译样本必须复刻该链接选项。

## §5 修复方向与影响面 (D2.1: 只给方向, 不写 patch)

**一句话**: asmgen.cpp:1042 `sub rsp, 0x1A8` 必须改为按当前入口栈链推导的 **`sub rsp, 0x230`**, 且实现上应从 kCtxSize 派生 (step7 = kCtxSize + 0x40[stub 8 push] + 0x8[call ret] + 0x40[entry 8 push] + 0x8[ctx push] − 0x28[native_sp 摆位]) 而非硬编码, 消除对 kCtxSize 的第二次隐式耦合。

- 推导核对: 旧 kCtxSize=0x140 → 0x1A8 ✓ (与现存常量吻合); 新 kCtxSize=0x1C8 → 0x230。
- 影响面: `vm/regvm/runtime/src/asmgen.cpp:1042` (常量) + 注释块 :979-985 (含旧"sub 0x140"算术) 与 :225-235 (MIT-299 时代算术) 同步更新; 其余步骤 (1-6, 8-11) 语义不变。
- 验收口径 (可直接写入 Phase 2 派单): multiseed REQUIRE_REAL=1 **100/100**; 5 坏样本 byte-exact; A.1/A.3 门不回归 (0x230 为 0x 前缀显式立即数, A.1 应 PASS)。
- Phase 2 §A 假设 (§G): "callgate step 7 常量 = f(kCtxSize) 断裂" — 本单已给出函数式与实测值, 可直接采用。

## §6 GAPS C2/C3 真实状态刷新 (§G)

- **C2 (handler 匹配) 定论**: rol/bswap/cl_shift 等算术 handler **已真接管且语义正确**。铁证: bswap 样本崩点 rax=0x78563412 = bswap32(0x12345678) 的正确结果 — VM 已正确执行完区域内的 bswap handler 才死在后续 call op 上。multiseed 持续 FAIL 与 "handler 已接管" 的矛盾**全部**由 callgate 缺陷解释, 不存在 C2 缺口。
- **C3 (call gate) 定论**: 协议设计正确 (push/pop ctx + native_sp 摆位 + 阴影区对齐全部自洽, 见 §3 实测), 但被常量漂移杀死 → **当前 callgate 全红**。修复 step 7 单点常量后 C3 应转绿。
- 🟢 建议: bswap/rol/cl_shift 样本"区域纯净性"已破 (intrinsic 未内联 → 区域含 CRT/本地 call)。Phase 2 修复 callgate 后它们会 PASS, 但虚拟化质量口径 (区域内含出调用) 建议另立小单治理 (inline asm / 显式 bswap 指令或验收 codegen), 不阻断 Phase 2。

## §7 方法论沉淀 (§G, 可入 wvmp-dev skill)

1. 崩点归因: cdb `-g -G -c ".cxr; r; u @rip-0x20 L0x30; q"` → 归一化节偏移 (crash_rip − .wvmp 基址) 跨样本对齐。
2. handler 归属: `WVMP_RUNTIME_DUMP=<win 路径>` (不影响产物字节) 拿 asmgen 发射文本, 与 cdb/capstone 逐字节对位 — 比 capstone 单独反汇编多出"发射器语义"维度。
3. push/pop 错位类 bug: 由 stub/entry 链逐层列栈帧算术, 在崩点用 `dq @rsp±delta` 实测预测槽位内容 (本单 5 项实测全中), 一次性钉死。
4. 常量漂移: `git log -S <常量>` 找"谁改了 A 没改 B"的 commit 对。
5. 独立编译样本三件套: /Od /Ob0 + **/link /INCREMENTAL:NO** (否则 ILT 吞 E8 → C1 兜底假 PASS) + /MDd 与仓库样本对齐。

## §8 披露 (honest disclosure)

1. **D3 无差异**: 复现与 §A 逐项一致 (崩点 +0x37C0 / stub 数 / 75:25), 无需披露偏差。
2. build/vs/cli/Debug/wvmp_cli.exe 为旧 multiseed 路径, 已按 §C 用 fresh CLI 镜像替换 (md5 8fa6d8d7...), 旧二进制备份: `.hermes/triage/mit393/wvmp_cli_old_backup.exe`。
3. cdb 验证脚本一处表达式笔误 (`? @rsp-0x48` 应为 `? @rsp-0x88`, host_rsp 表达式), 实测值 0x15FB50 = native_sp−0x250 与模型一致, 不影响结论。
4. 仓库零改动: HEAD = fb66b98 不变, `git status --short` 被跟踪文件改动数 = 0 (前后一致)。新增未跟踪: `.hermes/triage/mit393/*` (脚本/日志/dump/旧 CLI 备份), 与派单 §C 授权口径一致。
5. 产物/临时物: build/ 全量重建 (Ninja 322/322); %TEMP%\mit393_b4\ (B.4 样本, 未进仓库)。
6. 首次 protect 尝试因 TOML 误用 POSIX 路径被 pe_writer 拒绝 (§C 约定), 修正后无影响。
7. 未覆盖项: 本单未逐一验证 15 个 PASS 样本区域"确无 call"的源码级扫描 (以 multiseed 5-seed 全绿 + callgate op 判别式反推, 置信度高); Release|x64 矩阵未跑 (派单 §阶段3 第 6 条为"时间允许", 本单结论不受影响, 因常量与配置无关)。

== MIT-B1 triage 完 ==
