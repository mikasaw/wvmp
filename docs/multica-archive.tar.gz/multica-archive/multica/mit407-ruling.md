# MIT-407 (MIT-D2) 裁定 — PARTIAL 交付：启用面 ACCEPT + ff-merge；ExitNative 启用遗留 segfault → 继任单 MIT-D2b

> Author: 接手人 (项目主) — 2026-08-29 16:10 UTC+8
> Status: **PARTIAL ACCEPT, push to `done`** (partial 达成先例: MIT-379), 继任单 **MIT-D2b** 负责启用
> Verdict: build rc=0 / ctest 16/16 / multiseed **130/130** 全绿 (全部项目主 worktree 复验)
>          / wvmpTest 仍 2/14 (**§D.4 验收锚未达**, stub 间接 jmp segfault 阻断, 运行时路径全 DISABLED)

## 0. 交付物定性

agent 报告诚实 (自标 PARTIAL + §3 完整排查记录 + §4 验收回条逐条对账 + §D.9 自曝未执行)。
**启用面** (.pdata 解析 / lifter hex log 修复 / ExitNative enum+handler 脚手架 / CMake 链接) 门禁全绿;
**禁用面** (backend 不接线 / dispatch 注释 / stub 回退直跳) 保证 main 行为与 8a3d510 语义等价。

## 1. 项目主独立复验 (worktree wvmp-mit407-wip @ 687855b, 抢救提交后)

| 项 | agent 自报 | 实测 |
|---|---|---|
| build | rc=0 / 0 新警 | ✅ BUILD_EXIT=0, CLI 产出 |
| ctest | 16/16 | ✅ **16/16** |
| multiseed REQUIRE_REAL=1 | 130/130 | ✅ **TOTAL: 130 pass / 0 fail** |
| wvmpTest 双跑 | (未声称变化) | ✅ stub=2 覆盖不变; **103/103 双方程绿**; 唯一 stdout diff = image 路径行 (我 tmp 产物, 非真实差异) |
| DISABLED 三处声称 | §3.4/§1.6/§1.4 | ✅ 逐处实读: backend :92 单参调用 + dispatch 表 :2971 注释 + stub_gen :96 直跳 `jmp <resume_rva>` — 报告与盘面一致 |

## 2. 抢救过程 (agent 违规留主仓 14 个未 commit 文件, 已如实披露)

主工作区检出 14 tracked M 文件、零分支零 commit (§E 环境红线"改动必须落分支")。项目主处置:
`git checkout -b mit-d2-exitnative` → add 全部 → commit `415c2f0` (后 amend 收编漏网第 14 文件 lifter_core → **`687855b`**) → 主工作区恢复 CLEAN。

**⚠️ 未披露改动登记 (D2b 必改)**: stub_gen.cpp 的 diff 显示 agent 顺手**删除了大片文档注释**
(MIT-249 native_sp 语义 / MIT-371 xmm 同步说明 / MIT-B2 派生纪律注释块) — 报告通篇未提, 属 #79 式
"diff 里的隐性改动"。这些注释是 B2/B3 轮的沉淀载体, **D2b 第一个任务 = 恢复全部被删注释**。

## 3. segfault 根因候选 (项目主代码审读新增, agent 三假设均未命中要害)

agent §3.2 试遍 slot 偏移 (8/0x10/0x50/0x80/0x1000/0x10000) 全崩 → 说明**根因与偏移无关**。我实读两条铁证:

- **候选 A (最高): RVA/VA 混淆**。全仓访存约定是 "RVA + image_base = VA" (Load/Store handler 统一 `add t1, [ctx+0x110]`, asmgen.cpp:749-834)。而 handler 写槽 `mov [rsp-0x50], t_[5]` 写入的是**裸 RVA**; 终态直跳 `jmp <resume_rva>` 之所以今天能工作, 是 keystone 链接期以 image_base 为装配基址算 rel32。运行时 `jmp qword ptr [slot]` 拿到裸 RVA ≈ 0x104D → **恰好命中 §3.1 实测签名"crash 地址远低于 image base 的无意义地址"**。修复 = 写槽前 `add reg, [ctx+0x110]`; stub 入口预写应为生成期常量 `image_base + resume_rva`。
- **候选 B (与 A 叠加): 写/读槽不同址**。handler 在 VM 内层帧写 `[handler_rsp-0x50]`, 终态在 entry_rsp 读 `[rsp-0x288]` — **两个时刻两种基准, 写的根本不是读的地方** (§1082 注释自证: "handler rsp 视角 / 终态视角" 两个偏移)。修复 = 以 native_sp (ctx+0x120, callgate 同款稳定基准) 定位槽位, 或 handler 不写槽——把 aux+image_base 暂存 ctx 字段, 统一在终态 epilogue 处合成。
- 候选 C: keystone 负 disp 截断 (agent §3.2.4 实测 0x10000→0x1000) — 真实存在, 但 0x80 档正确编码仍崩, 证明非主因。

**D2b §A 纪律**: 以上为项目主静态推断 (可错, #33), 启用面第一步必须实测: WVMP_STUB_DUMP 落盘 + cdb 抓 crash 现场寄存器, 三候选逐个证实/证伪后再修。

## 4. 验收回条最终账

| §D | 状态 |
|---|---|
| 1-3 build/ctest/multiseed | ✅✅✅ (独立复验) |
| 4 wvmpTest ≥13/14 | ❌ 2/14 — **本单未达成, 移交 D2b** |
| 5 r06 维持 gate 逐字节 | ✅ (全 DISABLED, 结构性成立) |
| 6 enum/imm()/静态扫描 | ✅ (ExitNative=80, kVmOpMax 80<128) |
| 7 冻结契约 | ✅ (callgate/样本/runtime.hpp 未动) |
| 8 RVA 映射表 | ⚠️ N/A (未启用, 无救回可测) |
| 9 git checkout main | ❌ 违规, 项目主抢救入库 (§2); 但披露诚实 |

## 5. 处置

1. ✅ WIP 分支 `mit-d2-exitnative` @ `687855b` 保留 (抢救 commit message 注明 partial)
2. ✅ **ff-merge main** (启用面门禁全绿 + DISABLED 面语义等价, 先例: 脚手架入库可接受; 消除 rebase 漂移风险)
3. ✅ MIT-407 → done (partial 达成入账, 先例 MIT-379)
4. → **MIT-D2b 新单**: segfault 三候选实测定位 → 修复 → 启用 backend 接线 + dispatch 取消注释 + stub 槽方案定稿 → 验收锚继承 §D.4 (wvmpTest ≥13/14) + §3 注释恢复任务
5. 基线不变: **130/130** (D2b 交付后目标 ~145/145)

## 6. 沉淀

- **新增 pitfall 素材**: 运行时生成码里任何 jmp/访存用 RVA 必须先 +image_base (ctx+0x110) — 与"链接期汇编基址"是两套地址体系, 混用即 #3 型崩溃; 建议 D2b 收口时正式编号入 wvmp-dev skill
- **agent 诚实 PARTIAL = 正例**: 与 MIT-375 v1-v6 假完成对照, 本单"实现写完-实测受阻-主动禁用-完整披露"是理想失败交付形态; 但"改动留主仓未 commit"连续第 4 单违规 (393/403/404/407), **派单模板应加硬条款: 报告前 `git status --short` 必须 CLEAN 并附输出**
- triage 预测 17 站点/13/14 未受本单影响 (素材仍有效), D2b 直接复用
