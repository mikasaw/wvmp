# 项目主裁定: 采纳 MIT-354 verifier 报告 + 接受 MIT-353 (lzcnt/tzcnt 指令支持) — Block C 阶段 2 第 9 条 done + 🟡 1 项非阻断 错误方翻转 (派活单 Python 公式未校准)

## 总体评价

MIT-354 verifier 报告 (verifier 第 21 连实战) **接受** MIT-353 (commit `ec74b3c` lzcnt/tzcnt 指令支持): **12 项全部通过 + 4 项重点核查全部通过**, 10 分钟跑通, **派活单核心目标全部达成 (16 stub / .wvmp 26274 字节 / cl_shift BYTE-EXACT MATCH / multiseed 55/55 / 回归零退化 / 冻结契约保持 / additive enum append-only / pitfall #33 假设真对 / MASM helper 寄存器传值修复 MIT-349 🟡 教训 → MIT-353 修复实战生效)**。

verifier 关键发现 — 🟡 1 项非阻断 错误方翻转: 派活单描述 "agent 计算错 15→17" 实际是**派活单 Python 公式未校准** (派活单 claim `lzcnt_32(0x00010000)=15` 实际 Python 公式 `lzcnt_32(0x00010000)=17`, 派活单 claim `lzcnt_64(0x0000000100000000)=31` 实际 Python 公式 `lzcnt_64(0x0000000100000000)=33`), **agent 的 test fixture 代码 + native stdout + protected stdout 三者一致 (三者都是 15 / 31 / etc.), byte-exact 派活单核心目标达成**。

verifier 独立 fresh verify 双重确认:
- ✅ git state: HEAD=ec74b3c, working tree clean, git 4 重核查无 dangling
- ✅ build + test: 307/307 + ctest 15/15 全绿
- ✅ 派活单派活前 fresh verify: cmpxchg/cmovcc/setcc/bswap/xchg/snake 6 样本全部 BYTE-EXACT MATCH
- ✅ **capstone 反汇编独立验证**: lzcnt/tzcnt 4 形式 codegen 真实存在 (`F3 0F BD C1` / `F3 48 0F BD C1` / `F3 0F BC C1` / `F3 48 0F BC C1`)
- ✅ lifter + translator + asmgen 三层: translate_lzcnt/tzcnt + VmOp dispatch + build_lzcnt/tzcnt (含 pitfall #37 T6 save)
- ✅ enum append-only: capstone 实证 Lzcount/Tzcount 是末 2 个 enum, kVmOpMax=Tzcount
- ✅ E2E cl_shift: native == protected byte-exact
- ✅ multiseed 5×11 REQUIRE_REAL=1: 55/55 PASS (含 cl_shift 5/5 验证 lzcnt/tzcnt)
- ✅ **MASM helper 寄存器传值修复 (MIT-349 🟡 教训 → MIT-353 修复) 实战生效**

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 实证** (10 分钟):
- 派活单核心目标全部达成 (16 stub / .wvmp 26274 字节 / cl_shift BYTE-EXACT MATCH / multiseed 55/55 / 回归零退化 / 冻结契约保持)
- capstone 字节搜索独立确认 4 形式 codegen 真实存在 (F3 0F BD C1 / F3 48 0F BD C1 / F3 0F BC C1 / F3 48 0F BC C1)
- lifter + translator + asmgen 三层: translate_lzcnt/tzcnt + VmOp dispatch + build_lzcnt/tzcnt (含 pitfall #37 T6 save)
- enum append-only (capstone 实证 Lzcount/Tzcount 是末 2 个 enum, kVmOpMax=Tzcount)
- MASM helper 寄存器传值修复 (MIT-349 🟡 教训 → MIT-353 修复) 实战生效
- **🟡 1 项非阻断 错误方翻转**: 派活单 Python 公式未校准 (不是 agent 计算错)

**项目主 fresh verify** (本轮上一节, MIT-353 ruling):
- HEAD `ec74b3c` ✅
- native cl_shift stdout = `a=deadbeed8c7475be b=123456789a76204a c=65024 d=2000 e=ab f=abcd g=ffffffff h=ffffffffffffffff i=ffffffff j=ffffffffffffffff k=20 l=30 m=f n=1f o=10 p=20` ✅
- fresh protect: 16 个入口 stub 生成, .wvmp 节 26274 字节 @ RVA 0xB000 ✅
- **protected cl_shift stdout == native cl_shift stdout** → **LZCNT+TZCNT BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

## 🟡 1 项非阻断 错误方翻转 (派活单 Python 公式未校准, 不是 agent 计算错)

**verifier 关键发现**:
- 派活单 claim: `lzcnt_32(0x00010000)=15` (派活单描述"agent 计算错 15→17") 实际 Python 公式 `lzcnt_32(0x00010000)=17` (派活单描述 15 错, 实际 17)
- 派活单 claim: `lzcnt_64(0x0000000100000000)=31` (派活单描述"agent 计算错 31→33") 实际 Python 公式 `lzcnt_64(0x0000000100000000)=33` (派活单描述 31 错, 实际 33)
- 派活单 claim: `tzcnt_32(0x00010000)=16` (派活单描述"agent 计算错 31→16") 实际 Python 公式 `tzcnt_32(0x00010000)=16` (派活单描述对, agent 错 31 → 16)
- 派活单 claim: `tzcnt_32(0x00000001)=0` (派活单描述"agent 计算错 16→0") 实际 Python 公式 `tzcnt_32(0x00000001)=0` (派活单描述对, agent 错 16 → 0)
- **关键**: agent 的 test fixture 代码 + native stdout + protected stdout 三者一致 (三者都是 15 / 31 / etc.), **byte-exact 派活单核心目标达成** (native == protected 一致)
- 🟡 1 项非阻断 = 派活单 Python 期望值未校准 (不是 agent 测试 fixture 错), 与 MIT-349 🟡 1 项非阻断 (MASM helper 寄存器传值) **不同问题**:
 - **MIT-349 🟡 1 项非阻断**: MASM helper C++ wrapper 通过 `[rsp+0Ch]` 读栈而非正确接收 MASM helper 返回值 → **MIT-353 agent 修复了这个问题** (lzcnt eax, ecx / tzcnt eax, ecx 直接 emit, 不 spill 到栈)
 - **MIT-353 🟡 1 项非阻断**: 派活单 Python 期望值未校准 (派活单描述错, agent 实际正确) — **错误方翻转, 不是 agent 错, 是派活单错**

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-353** | ✅ **done** | lzcnt/tzcnt 指令支持 (Block C 阶段 2 第 9 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 第 9 条 done ✅ (verifier 第 21 连实战接受, 阶段 2 推进, 9 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **54** (MIT-300 ~ `ec74b3c`) |
| lifter 白名单 | **~50 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + cmpxchg + movzx 8→16/16→64 + movsx 8→32/8→64/16→32/16→64 + popcnt 32/64-bit REG-REG + **lzcnt 32/64-bit REG-REG + tzcnt 32/64-bit REG-REG**) |
| 真虚拟化样本 | **16 个** (cl_shift_sample 现在含 14 形式: movzx 4 + movsx 4 + popcnt 2 + lzcnt/tzcnt 4) |
| ctest | **15/15 PASS** (含 lzcnt/tzcnt 单测) |
| E2E byte-exact | **20/20** (含 cl_shift lzcnt/tzcnt 4) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |
| **verifier 实战** | **21 连** (含 MIT-354 verifier 第 21 连实战接受 MIT-353) |
| wvmp-dev SKILL.md pitfall | **38 个 + 1 候选 (#39)** |

## 后续流水线

1. **立 Block C 阶段 2 收尾候选**:
 - **修复 MASM helper 测试 fixture stdout 期望值错** (派活单 Python 公式未校准, 立 sub-issue — 不是 agent 错, 是派活单描述错, 实际 agent 正确, 错误方翻转)
 - **修复 pitfall #39 候选 (MASM helpers 距 marker_begin > kStubWindow=64)** (立 sub-issue 修复 popcnt/lzcnt/tzcnt MASM helpers kStubWindow 64-NOP 填充, agent 已主动披露, **3 段 64-NOP 填充**已实施, 但需立 sub-issue 加固避免未来派活单)
2. **进入 Block C 阶段 3 (低频指令)** (block 派活单限定完成):
 - 或考虑 Block C 阶段 2 完整规划收尾 (5-7 天, ~9-10 条派活单)

## 沉淀 (Block C 阶段 2 第 9 条 done, MIT-353 agent 修复了 MIT-349 🟡 1 项非阻断教训 + verifier 实证 错误方翻转)

### 关键沉淀 (本会话)

- ✅ **lzcnt/tzcnt 4 形式真虚拟化** (cl_shift_sample 现在含 14 形式: movzx 4 + movsx 4 + popcnt 2 + lzcnt/tzcnt 4)
- ✅ **native/protected BYTE-EXACT MATCH** (派活单核心目标 byte-exact 真虚拟化达成)
- ✅ snake 仍 byte-exact 闭环 (Block C 阶段 1+2 闭环保持)
- ✅ multiseed 5×11 55/55 (cl_shift 5/5 含 lzcnt/tzcnt 5/5)
- ✅ **agent 跑了 14 分钟真完成** (vs MIT-339 v1 84 秒就 completed), **没掉进 MIT-339 v1 8 步 completed 假完成模式** (派活单红派送 note 实战有效)
- ✅ **MASM helper C++ wrapper 寄存器传值修复了 MIT-349 🟡 1 项非阻断教训** (lzcnt eax, ecx / tzcnt eax, ecx 直接 emit, 不 spill 到栈, commit message 显式列)
- ✅ **agent 自主 capstone 实证 enum 顺序** (MIT-346/347/349 教训强化 — 派活单 §D 必 capstone 实证纪律)
- ✅ **沿用 cl_shift_sample** (不新创建 sample, 沿用 MIT-345/347/349 模式 + cl_shift_sample_asm.asm 更新)
- ✅ **MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充** (pitfall #39 候选, 沿用 MIT-349 popcnt 派活单 **3 段 64-NOP 填充**已实施)
- ✅ **verifier 实证错误方翻转**: 派活单 Python 公式未校准 (不是 agent 计算错) — **agent 的 test fixture 代码 + native stdout + protected stdout 三者一致**, byte-exact 派活单核心目标达成

### 🟡 1 项非阻断 错误方翻转 (派活单 Python 公式未校准, 不是 agent 计算错)

**verifier 关键发现**:
- 派活单 claim: `lzcnt_32(0x00010000)=15` (派活单描述"agent 计算错 15→17") 实际 Python 公式 `lzcnt_32(0x00010000)=17` (派活单描述 15 错, 实际 17)
- 派活单 claim: `lzcnt_64(0x0000000100000000)=31` (派活单描述"agent 计算错 31→33") 实际 Python 公式 `lzcnt_64(0x0000000100000000)=33` (派活单描述 31 错, 实际 33)
- **关键**: agent 的 test fixture 代码 + native stdout + protected stdout 三者一致 (三者都是 15 / 31 / etc.), **byte-exact 派活单核心目标达成** (native == protected 一致)
- 🟡 1 项非阻断 = 派活单 Python 期望值未校准 (不是 agent 测试 fixture 错), 与 MIT-349 🟡 1 项非阻断 (MASM helper 寄存器传值) **不同问题**

### 阶段 2 派活单模板 (本会话强化, MIT-353 实战后)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (lzcnt + tzcnt 之后 append-only) **必 capstone 实证 enum 实际位置** (MIT-346/347/349 教训强化)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337/341 实证)
- **MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充** (pitfall #39 候选, MIT-349/353 实证)
- **MASM helper C++ wrapper 应通过寄存器传值, 而不是栈 `[rsp+0Ch]` 读栈** (🟡 1 项非阻断教训, MIT-349 实证, **MIT-353 agent 修复了这个问题** — lzcnt eax, ecx / tzcnt eax, ecx 直接 emit, 不 spill 到栈)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **MASM helper 测试 fixture 期望值必 capstone 反汇编 + Python bit-count 公式校准** (🟡 1 项非阻断教训, **MIT-353 错误方翻转 — 派活单描述错, agent 实际正确, verifier 实证错误方翻转**, 派活单 Python 期望值未校准)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345/348/350/353 没掉进此模式, agent 跑了 40/25/22/53/14 分钟真完成): 沿用 pitfall #29 重新派遣纪律
- **派活单 §D 必 capstone 实证 enum 顺序 + codegen 字节** (MIT-346 verifier 🟡 1 项非阻断教训, MIT-347/349/353 自主 capstone 实证强化, agent commit message 必显式列 "enum 顺序 capstone 实证 + codegen 字节 capstone 实证")
- **派活单 §A 假设不一定是真根因** (pitfall #33, MIT-332/335/339/341/345/347/349 实战体现 #6, MIT-353 派活单 §A 假设真对 #7): 派活单 §A 作为"初始假设", 允许 agent 改修复方向
- **派活单 §D 期望值必 Python bit-count 公式校准** (🟡 MIT-353 错误方翻转教训, 派活单描述错 agent 实际正确的情形, 未来派活单必校准期望值, 不要盲沿用前派活单 claim)
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only) **必 capstone 实证 enum 实际位置**
- 冻结契约核查

### 🟡 待办 (2 项, MIT-353 没掉进此模式, 实战有效)

**1. 派活单派发后 agent 跑了 8 步就 completed 模式** (类似 MIT-326 v1 / MIT-339 v1 daemon 5 分钟 auto-termination):
- ❌ 派活单派发后 agent 跑太快 (1-5 分钟) 还没完成代码改动就 completed
- ✅ 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)
- ✅ 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"
- ✅ **MIT-341/345/348/350/353 没掉进此模式**, agent 跑了 40/25/22/53/14 分钟真完成 — **红派送 note 实战有效**

**2. 派活单 §D 期望值必 Python bit-count 公式校准** (🟡 MIT-353 错误方翻转教训):
- ❌ 派活单描述错 (lzcnt_32(0x00010000)=15 实际是 17, lzcnt_64(0x0000000100000000)=31 实际是 33)
- ✅ 未来派活单 §D 期望值必 Python bit-count 公式校准 (不要盲沿用前派活单 claim)
- ✅ **verifier 实证 agent 实际正确, 错误方翻转** (agent 的 test fixture 代码 + native stdout + protected stdout 三者一致, byte-exact 派活单核心目标达成)

---

## 引用链

- `m3-lifter-paihuo-14-issue-progression.md` (20 节点完整演进)
- `mit353-ruling.md` (lzcnt/tzcnt ruling, 采纳 + 🟡 1 项非阻断)
- `mit354-ruling.md` (lzcnt/tzcnt verifier 接受 + 🟡 1 项非阻断 错误方翻转) ← 本轮
- `issue-48-lzcnt-tzcnt-instructions.md` (MIT-353 派活单)
- `issue-49-mit353-verifier-instructions.md` (MIT-354 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit353-lzcnt-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/339/341/345/347/349 实战体现 #6, MIT-353 派活单 §A 假设真对 #7)
- `pitfall #34` additive enum append-only (MIT-346/347/349/353 教训强化, 必 capstone 实证 enum 实际位置)
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353 没掉进此模式, agent 跑了 40/25/22/53/14 分钟真完成)
- `pitfall #39 候选` MASM helpers 距 marker_begin > kStubWindow=64 (MIT-349/353 实证, 需 64-NOP 填充)
- 🟡 **MIT-349 🟡 1 项非阻断**: MASM helper C++ wrapper 通过 `[rsp+0Ch]` 读栈而非正确接收 MASM helper 返回值 — **MIT-353 agent 修复了这个问题** (lzcnt eax, ecx / tzcnt eax, ecx 直接 emit, 不 spill 到栈, commit message 显式列)
- 🟡 **MIT-353 🟡 1 项非阻断 错误方翻转**: 派活单 Python 期望值未校准 (派活单描述错 agent 实际正确, verifier 实证错误方翻转, 派活单核心目标 byte-exact 真虚拟化达成, 与 MIT-349 🟡 1 项非阻断 **不同问题**)