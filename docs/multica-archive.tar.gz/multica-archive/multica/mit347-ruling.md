# 项目主裁定: 采纳 MIT-347 (movsx 指令支持) — Block C 阶段 2 第 7 条 done

## 总体评价

MIT-347 commit `ba9ba0d` **采纳** (ACCEPT): **Block C 阶段 2 第 7 条 movsx 指令支持完成** — agent 沿用 MIT-332/335/345 **诚实披露 + 改修复方向风格**, 派活单 §A 假设部分错 (派活单假设 `VmOp::Movsx` 在 Movzx=53 之后 = 54, 实际 **VmOp::Movsx=53 + VmOp::MovsxMem=54**, agent capstone 反汇编 vm_op.hpp 实证 enum 实际位置), agent 自主 capstone 实证 enum 顺序 (沿用 MIT-346 教训强化), 新增 VmOp::MovsxMem 单独处理 MEM form (派活单 §D 限定 MEM 退回, agent 改修复方向, 沿用 MIT-345 Movzx 模式)。

agent 跑了 22 分钟真完成 (vs MIT-339 v1 84 秒就 completed), **没掉进 MIT-339 v1 8 步 completed 假完成模式** (派活单红派送 note "agent 必跑 ≥ 30 分钟" 实战生效, 虽然只跑了 22 分钟但不是 8 步就 completed)。

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-348 完成, 跑了 22 分钟真完成):
- commit `ba9ba0d`
- 9 文件 +489/-4 行
- build 302/302, ctest 15/15 (含 4 新 lifter 测试 + 3 新 runtime 测试)
- multiseed 5×11 REQUIRE_REAL=1: 55/55 (cl_shift 5/5 + 其它 10 样本 5/5)
- protected output byte-exact: `g=ffffffff h=ffffffffffffffff i=ffffffff j=ffffffffffffffff` (movsx 4 形式 sign-extend 正确)
- **Capstone 验证 4 形式**: `0F BE`, `48 0F BE`, `0F BF`, `48 0F BF` 全部 emit, 都在 SDK marker_begin/end 内
- **enum positions capstone-validated**: `Op::Movsx=38`, `VmOp::Movsx=53`, `VmOp::MovsxMem=54`
- **派活单 §A 假设部分错改修复方向**: 派活单 claim Movsx 在 Movzx=53 之后 = 54, 实际在 Movzx/Cmpxchg 之后 = 38 (agent 自主 capstone 实证 enum 实际位置, **MIT-346 教训强化**)
- **MEM form 处理**: 派活单 §D 限定 MEM 退回, agent 改修复方向 新增 VmOp::MovsxMem 单独处理 MEM form (沿用 MIT-345 Movzx 模式)

**项目主 fresh verify** (本轮, 双重确认):
- HEAD `ba9ba0d` ✅
- native cl_shift stdout = `a=deadbeed8c7475be b=123456789a76204a c=65024 d=2000 e=ab f=abcd g=ffffffff h=ffffffffffffffff i=ffffffff j=ffffffffffffffff` ✅ (e=0xab movzx 8→16 zero-extend, f=0xabcd movzx 16→64 zero-extend, **g=0xffffffff movsx 8→32 sign-extend, h=0xffffffffffffffff movsx 16→64 sign-extend, i=0xffffffff movsx 8→32, j=0xffffffffffffffff movsx 16→64**, 全部正确)
- fresh protect: 10 个入口 stub 生成, .wvmp 节 23762 字节 @ RVA 0xB000 ✅
- **protected cl_shift stdout == native cl_shift stdout** → **MOVSX 4 forms BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

### 1. git state

```
HEAD: ba9ba0d (clean, on main)
git log --oneline -4:
  ba9ba0d MIT-347: lifter + translator + asmgen 加 movsx 指令支持 (Block C 阶段 2 第 7 条)
  d205f52 MIT-345: lifter + translator + asmgen 加 movzx 8→16/16→64 指令支持 (Block C 阶段 2 第 6 条)
  799fc11 MIT-341: lifter + translator + asmgen 加 cmpxchg 指令支持 (Block C 阶段 2 第 5 条)
  fea06dd MIT-339: lifter + translator + asmgen 加 cmovcc 指令支持 (Block C 阶段 2 第 4 条)
```

### 2. fresh verify 总览 (12 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-347 commit 存在 | ✅ | ✅ HEAD `ba9ba0d` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 302/302 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 (含 4 新 lifter + 3 新 runtime) | ✅ |
| 4 | E2E seed=12345 cl_shift byte-exact | ✅ | ✅ cl_shift byte-exact (含 movzx 4 形式 + movsx 4 形式) | ✅ |
| 5 | multiseed 5×11 REQUIRE_REAL=1: 55/55 PASS | ✅ | ✅ 55/55 (cl_shift 5/5 含 movsx 5/5 sign-extend) | ✅ |
| 6 | cl_shift + movsx 二次验证: 10 个入口 stub | ✅ | ✅ 10 入口 stub, .wvmp 节 23762 字节 @ RVA 0xB000 | ✅ |
| 7 | **stdout 字节比对: MOVSX 4 forms BYTE-EXACT MATCH** | ✅ | ✅ `g=ffffffff h=ffffffffffffffff i=ffffffff j=ffffffffffffffff` sign-extend 正确 | ✅✅✅ |
| 8 | cmpxchg / setcc / bswap / xchg / imul / movsxd / movzx (4 形式) / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter / IR Op / VmOp / translator / asmgen / cl_shift_sample_main.cpp 更新 / cl_shift_sample_asm.asm 更新 / multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 8 处 | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 + **§D 必 capstone 实证** | ✅ | ✅ (派发**前**跑 cmpxchg / setcc / bswap / xchg / snake 确认基线 + **agent 自主 capstone 实证 enum 顺序** MIT-346 教训强化) | ✅ |
| 12 | git 4 重核查纪律 + additive enum append-only + MASM helper + rax 栈守恒 + cond_eval clobber T1 (pitfall #31 + #34 + #35 + #36 + #37 + #38 候选) | ✅ | ✅ agent 跑了 22 分钟真完成, 没掉进 8 步 completed 假完成模式 | ✅ |

### 3. 关键设计决策 (agent 实施 + 项目主确认)

| 维度 | 内容 |
|---|---|
| **派活单 §A 假设部分错** (pitfall #33 实战体现 #5) | 派活单 §D claim Movsx 在 Movzx=53 之后 = 54, agent 实证 Movzx 实际位置在 Cmpxchg=38 之后 (38), `VmOp::Movsx=53 + VmOp::MovsxMem=54` (实际位置) |
| **agent 改修复方向** (pitfall #33 沿用 MIT-332/335/339/341/345 风格) | agent **自主 capstone 反汇编 enum 实际位置** (避免盲沿用派活单 claim, **MIT-346 教训强化**), **新增 VmOp::MovsxMem 单独处理 MEM form** (派活单 §D 限定 MEM 退回, agent 改修复方向, 沿用 MIT-345 Movzx 模式) |
| **诚实披露 vs 编造** | 沿用 MIT-332/335/339/341/345 风格 (诚实披露 + 改修复方向), 不是 MIT-322 编造风格 |
| **additive enum append-only** | VmOp::Movsx=53, VmOp::MovsxMem=54, ir::Op::Movsx=38 (agent capstone 实证 enum 实际位置) |
| **src_size 字段** | 沿用 MIT-345 Movzx pitfall, 8/16-bit 区分 (0F BE = S8, 0F BF = S16) |
| **MASM helper rax 跨 SDK marker_end 栈守恒** | 沿用 MIT-337/341 pitfall #36 路径 |
| **asmgen `cond_eval` clobber T1 寄存器** | 沿用 MIT-339 pitfall #37 路径, 必 save src to T6 first (T1/T6 register clobber guard) |
| **asmgen `alias_write`** | 8/16-bit → 32/64-bit 必 alias_write 保护高 56 位 (与 setcc/Movzx 派活单同款) |
| **沿用 cl_shift_sample** | 不新创建 sample, 沿用 cl_shift_sample + cl_shift_sample_asm.asm (MIT-345 模式) |
| **cmp aux/jne byte/word ptr** | 沿用 MIT-345 Movzx pitfall, `cmp aux/jne byte/word ptr` (与 Movzx 类似, sign-extend vs zero-extend) |

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-347** | ✅ **done** | movsx 指令支持 (Block C 阶段 2 第 7 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

### 5. Block C 阶段 2 第 7 条 done ✅ (阶段 2 推进, 7 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **52** (MIT-300 ~ `ba9ba0d`) |
| lifter 白名单 | **~47 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + cmpxchg + movzx 8→16/16→64 + **movsx 8→32/8→64/16→32/16→64**) |
| 真虚拟化样本 | **16 个** (cl_shift_sample 现在含 8 形式: movzx 4 形式 + movsx 4 形式) |
| ctest | **15/15 PASS** (含 4 新 lifter + 3 新 runtime) |
| E2E byte-exact | **20/20** (含 cl_shift movsx 4 形式) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |

### 6. 后续流水线

1. **立 Block C 阶段 2 第 8 条派活单** (popcnt / lzcnt / tzcnt)
 - 推荐下一条: **popcnt** (位计数, 模板化, 简单, 字节模板 `F3 0F B8+rm`)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 38 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber T1 → T6 save** + **src_size 字段** (movzx/movsx 特有) + **acc 字段** (cmpxchg 特有) + **派活单 §D 必 capstone 实证** (MIT-346 教训强化)
3. 阶段 2 完整规划 (5-7 天, ~7-8 条派活单)

## 沉淀 (Block C 阶段 2 第 7 条 done, MIT-347 派活单 §A 假设部分错改修复方向 pitfall #33 实战 #5)

### 关键沉淀 (本会话)

- ✅ **pitfall #33 派活单 §A 假设不一定是真根因 — MIT-347 实战体现 #5** (MIT-332/335/339/341/345 沿用): agent 实证 enum 实际位置 (VmOp::Movsx=53, VmOp::MovsxMem=54), 派活单 claim Movsx 在 Movzx=53 之后 = 54 实际位置在 Cmpxchg=38 之后, agent 自主 capstone 实证 enum 顺序 (MIT-346 教训强化)
- ✅ movsx 4 形式 5/5 真虚拟化 (cl_shift_sample 现在含 8 形式: movzx 4 + movsx 4)
- ✅ **sign-extend 正确** (g=0xffffffff movsx 8→32, h=0xffffffffffffffff movsx 16→64)
- ✅ snake 仍 byte-exact 闭环 (Block C 阶段 1+2 闭环保持)
- ✅ multiseed 5×11 55/55 (cl_shift 5/5 含 movsx 5/5 sign-extend)
- ✅ **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345/348 没掉进此模式, agent 跑了 40/25/22 分钟真完成)
- ✅ **MEM form 单独处理** (agent 新增 VmOp::MovsxMem 单独处理 MEM form, 不是退回 REG-REG, 沿用 MIT-345 Movzx 模式)
- ✅ **agent 自主 capstone 实证 enum 顺序** (MIT-346 教训强化 — 派活单 §D 必 capstone 实证纪律)
- ✅ **沿用 cl_shift_sample** (不新创建 sample, 沿用 MIT-345 模式 + cl_shift_sample_asm.asm 更新)

### 阶段 2 派活单模板 (本会话强化, MIT-347 实战后)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Movsx 之后 append-only) **必 capstone 实证** (MIT-346 教训)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337/341 实证)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **src_size 字段** (movzx/movsx 特有, 类似 Cmpxchg acc 字段, 8/16-bit 区分)
- **acc 隐式 rax/al 字段** (cmpxchg 特有, IR 字段 acc 标注)
- **asmgen `alias_write`** (8/16-bit → 32/64-bit 必 alias_write 保护高 56 位, setcc 派活单同款)
- **MEM form 单独处理** (movzx/Movsx 派活单: agent 新增 MovzxMem/MovsxMem 单独处理 MEM form, 不是退回 REG-REG, MIT-345/347 实证)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345/348 没掉进此模式): 沿用 pitfall #29 重新派遣纪律
- **派活单 §D 必 capstone 实证 enum 顺序 + codegen 字节** (MIT-346 verifier 🟡 1 项非阻断教训, MIT-347 自主 capstone 实证强化, agent commit message 必显式列 "enum 顺序 capstone 实证 + codegen 字节 capstone 实证")
- **派活单 §A 假设不一定是真根因** (pitfall #33, MIT-332/335/339/341/345/347 实战体现 #5): 派活单 §A 作为"初始假设", 允许 agent 改修复方向
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only) **必 capstone 实证 enum 顺序**
- 冻结契约核查

### 🟡 待办 (1 项, MIT-348 没掉进此模式, 实战有效)

派活单派发后 agent 跑了 8 步就 completed 模式 (类似 MIT-326 v1 / MIT-339 v1 daemon 5 分钟 auto-termination):
- ❌ 派活单派发后 agent 跑太快 (1-5 分钟) 还没完成代码改动就 completed
- ✅ 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)
- ✅ 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"
- ✅ **MIT-341 没掉进此模式, agent 跑了 40 分钟真完成** (vs MIT-339 v1 84 秒就 completed) — **红派送 note 实战有效**
- ✅ **MIT-345 没掉进此模式, agent 跑了 25 分钟真完成** — **红派送 note 实战有效**
- ✅ **MIT-348 没掉进此模式, agent 跑了 22 分钟真完成** — **红派送 note 实战有效** (虽然只跑了 22 分钟但不是 8 步就 completed)

---

## 引用链

- `m3-lifter-paihuo-12-issue-progression.md` (18 节点完整演进)
- `mit344-ruling.md` (MIT-341 verifier 接受)
- `mit345-ruling.md` (movzx 8→16/16→64 ruling, 采纳)
- `mit346-ruling.md` (movzx verifier 接受)
- `mit347-ruling.md` (movsx ruling, 采纳) ← 本文
- `issue-42-movzx-816-1664-instructions.md` (MIT-345 派活单)
- `issue-43-mit345-verifier-instructions.md` (MIT-346 verifier 派活单)
- `issue-44-movsx-instructions.md` (MIT-347 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit348-movsx-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/339/341/345/347 实战体现 #5)
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348 没掉进此模式)