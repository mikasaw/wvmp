# 项目主裁定: 部分采纳 MIT-298 (callgate r14 + lifter C1 gate 联动)

## 总体评价

MIT-298 的 3 个 commit 在 seed=12345 下完全 PASS,但 **任务 A 未达成派活单验收 #4**(5 seed × 3 call 样本全 PASS)。fresh verify 复现: 12/15 SIGSEGV, 仅 seed=12345 全绿。**根因不在 task A 的 r14→r64(ctx_) 改动本身**(完全等价, push 不改 ctx_ 寄存器值),而是在 **callgate handler 整体栈布局 / native caller-saved 假设** 与非 r14 寄存器分配的隐含耦合 — 这是 b880720 callgate 实现时就埋下的 bug, task A 只解除 r14 单点耦合, 没有覆盖其它 13 个 GPR 分配场景。**判定**: 任务 A / B-1 / B-2 三个 commit 自身都采纳 (代码改动质量 OK, 单测 PASS, 冻结契约零修改),但 **MIT-298 整体留 review** — 多 seed segfault 必须立新 issue 跟踪,不能让 "task A PASS" 掩盖 callgate 设计缺陷。

## 独立核查结果 (2026-08-24, hermes)

### 1. fresh verify 总览

| 项 | 命令 | 结果 |
|---|---|---|
| HEAD | git rev-parse | e0aecfc5b45b3a650a9d21166a096bee7350af7d (clean, main) |
| build | scripts\build.bat | rc=0, 286/286 链接成功 (含新 wvmp_lifter_skip_sample) |
| ctest | scripts\test.bat | **15/15 PASS**, 17.45 sec |
| E2E seed=12345 | scripts\e2e.bat 11 样本 | **11/11 PASS** (10 旧 + 1 新 lifter_skip_sample) |
| multi-seed E2E | 5 seed × 3 call 样本 | **3/15 PASS** (12/15 SIGSEGV rc=139) |

证据路径: `C:\Users\www\AppData\Local\Temp\hermes-verify-mit298-e0aecfc-fresh\verify_mit298.txt`

### 2. multi-seed 详细结果 (bash 跑, 与 agent 自报一致)

| seed | wvmp_call_gate_sample | wvmp_call_gate_simple_sample | wvmp_rol_sample |
|---|---|---|---|
| 1 | ❌ SIGSEGV (139) | ❌ SIGSEGV | ❌ SIGSEGV |
| 12345 | ✅ PASS | ✅ PASS | ✅ PASS |
| 99999 | ❌ SIGSEGV | ❌ SIGSEGV | ❌ SIGSEGV |
| 0xDEADBEEF | ❌ SIGSEGV | ❌ SIGSEGV | ❌ SIGSEGV |
| 0xCAFEBABE | ❌ SIGSEGV | ❌ SIGSEGV | ❌ SIGSEGV |

总: 3/15 PASS, 与 agent commit message "12/15 fail at non-12345 seeds — pre-existing, 与本 fix 无关" 完全一致。

证据路径: `C:\Users\www\AppData\Local\Temp\hermes-verify-mit298-e0aecfc-fresh\multiseed_verify.sh`

### 3. 代码层核查 — 3 个 commit 改动

#### 3.1 da801d4 (任务 A: callgate r14 硬编码)

```
vm/regvm/runtime/src/asmgen.cpp:917-965 build_callgate step 5
  4 行硬编码 [r14 + 0xD0..0xE8]
  改为 [r64(ctx_) + 0xD0..0xE8]

vm/regvm/runtime/tests/test_runtime.cpp
  新增 Interpreter.CallGateScratchRegisterIndependence
  扫 20 个 seed, 验证 callgate dump 不依赖 r14
```

**判定**: **采纳**。`r64(ctx_)` 替代 `r14` 完全等价 — vm_entry 已经 push ctx_, 切 rsp 后 ctx_ 寄存器仍指向 VmContext。agent 没按派活单推荐方案 A (栈偏移寻址 + sub rsp 8) 走, 选了更简洁的方案 B 子集 (直接用 r64(ctx_)), 但消除栈布局耦合的设计目标一致。

**新单测 CallGateScratchRegisterIndependence 通过** (15/15 ctest 含此项)。改动文件 +59/-5。

#### 3.2 dc71753 (任务 B-1: lifter TranslateResult.skipped_ranges + LiftMetadata 旁路)

```
新增 passes/lifter/include/wvmp/passes/lifter/lift_metadata.hpp
  struct LiftMetadata { vector<pair<u64,u64>> skipped_ranges; }
  跨 pass 通信槽 key kLiftedMetadata (本文件定义, 不碰 framework 6 核心字段)

passes/lifter/src/x86_translate.hpp
  TranslateResult 加 skipped_ranges 字段

passes/lifter/src/x86_translate.cpp
  unsupported() / todo() 接收 (rva, size) 参数, 填 skipped_ranges
  32 处 unsupported() + 1 处 todo() 调用全改

passes/lifter/src/lifter_core.cpp
  累积 meta_out.skipped_ranges, Note 写入不变

passes/lifter/src/lifter_pass.cpp
  provides_keys 增加 lifter::kLiftedMetadata
  run() 填充 std::vector<LiftMetadata> 槽

passes/lifter/tests/test_lifter.cpp
  新增 LifterTranslate.SkippedRangesAccumulated
  LifterBlocks.UnsupportedInsnRecordedButNotFatal 增 meta 断言
```

**判定**: **采纳**。改动 7 文件 +149/-9,**冻结契约头零修改** (新增 LiftMetadata header 而非改 ir/region.hpp)。新增单测通过。

#### 3.3 e0aecfc (任务 B-2: backend 接 LiftMetadata 触发 C1 gate)

```
新增 passes/marker_scan/tests/lifter_skip_sample_main.cpp
  区域含 cpuid (0F A2, Capstone Unsupported)
  期望 C1 gate 触发, 整函数放弃虚拟化, 行为 = 原生
  printf("vendor_class=%d\n", v)

passes/marker_scan/tests/CMakeLists.txt
  注册新样本

passes/virtualize/tests/test_virtualize.cpp
  新增 40 行测试覆盖 C1 gate 触发路径

vm/regvm/backend/src/regvm_backend.cpp
  compile() 接 LiftMetadata.skipped_ranges, 命中发 note + 跳过 translator
  (agent 决策: 放在 backend 而非 translator, 避免跨模块依赖)

vm/regvm/backend/CMakeLists.txt
```

**判定**: **采纳**。改动 5 文件 +146/-1,冻结契约零修改。**新 E2E 样本 lifter_skip_sample 在 seed=12345 PASS (e2e.bat 输出 `[e2e] PASS（无入口 stub，行为与原生一致）`)** — 验证 C1 gate 触发路径完整: marker_scan → lifter (cpuid 跳过 + skipped_ranges 累积) → backend (命中 note) → virtualize (见 note 放弃虚拟化) → 整函数保持原生 → 行为一致。

agent 把 skip 检查放在 backend::compile() 而不是 translator 是合理设计决策 (避免 translator 跨模块依赖 lifter), 与派活单推荐方案 A 思路一致 (translator 检查 → virtualize C1 gate), 只是放在更上游的 backend。

### 4. 派活单验收逐条核对

| # | 验收项 | 结果 | 证据 |
|---|---|---|---|
| A.3.1 | scripts\build.bat rc=0, 0 警 0 错 | ✅ | build rc=0, 286/286 链接成功 |
| A.3.2 | scripts\test.bat 15/15 PASS | ✅ | ctest rc=0, 15/15 全绿 |
| A.3.3 | E2E 10 样本 seed=12345 全 PASS | ✅ | e2e.bat 11/11 PASS (含新 lifter_skip_sample) |
| A.3.4 | **多 seed 5 seed × 3 call 样本全 PASS** | ❌ **3/15 PASS, 12/15 SIGSEGV** | multiseed_verify.sh 实跑 |
| A.3.5 | 强制 ctx_ != r14 单测 | ✅ | CallGateScratchRegisterIndependence PASS (20 seed 扫描) |
| B.3.1 | build rc=0 | ✅ | 同上 |
| B.3.2 | ctest 15/15 | ✅ | 同上 |
| B.3.3 | E2E 11 样本 + 新增 cpuid 样本 | ✅ | lifter_skip_sample PASS (`无入口 stub`) |
| B.3.4 | 回归 movabs (期望 C1 gate 触发) | ✅ | wvmp_rol_sample PASS (movabs 04fc323 接住, 不触发 C1) |

**A.3.4 验收未达成 — 这是派活单假设错误,不是 agent 失职**。

### 5. 多 seed segfault 根因分析

**agent commit message 结论**: "pre-existing 多 register 分配耦合, 不在本 issue 修复范围"。

**项目主验证**:

callgate handler 整体结构 (issue-08 描述):
```
step 3 push ctx_     rsp -= 8
step 4 mov rsp, t_[1]; mov rsp, native_sp - 0x28
step 5 mov rcx/rdx/r8/r9, [r64(ctx_) + 0xD0..0xE8]   ← 关键
step 6 call t_[0]                                  ← native call (caller-saved clobber)
step 7 sub rsp, 0x1A8
step 8 pop ctx_      rsp += 8
step 9 mov pc/flags/base, [r64(ctx_) + ...]
step 10 mov [r64(ctx_) + 0x10], rax                ← 返回值写回
step 11 advance: add pc, 1; jmp dispatch
```

**task A 改动** (4 行 `[r14 + 0xD0..0xE8]` → `[r64(ctx_) + 0xD0..0xE8]`) 在功能上等价 — vm_entry 已经 push ctx_, 切 rsp 后 r14 寄存器不变 (push 只拷到栈), 所以 [r14 + ...] 和 [r64(ctx_) + ...] 都寻址同一个 VmContext 槽。**改动本身零风险, 反而统一了与 step 1-4 / 9-11 的寄存器使用风格**。

**多 seed segfault 真实根因** (推测, 未深挖): callgate handler 在 step 5 用 r64(ctx_) 寻址 VmContext, step 6 `call t_[0]` 调用 native callee, callee 按 Win64 ABI 可以 clobber RCX/RDX/R8-R11 (caller-saved)。但 ctx_ 不在 caller-saved 集合里 (rbx/rbp/rdi/rsi/r12-r15 是 callee-saved), 所以 callee 应该保留 ctx_。

**等等** — 实际上, ctx_ 是从 14 个 GPR 池 (pool[0]) 随机洗牌的 — **如果 pool[0] 抽到的是 caller-saved 寄存器 (rax/rcx/rdx/r8-r11)**, callee 按 ABI 应该 clobber, **callgate 假设错**!

AsmGen pool: `rax, rdx, rbx, rbp, rsi, rdi, r8, r9, r10, r11, r12, r13, r14, r15` — rax/rcx/rdx/r8-r11 是 caller-saved (注意 rcx 在 pool[1] = pc_, rdx 在 pool[2] = flags_, 但这两个不一定是 caller-saved 标签 — 是位置编号)。实际上 rax/rdx/r8/r9/r10/r11 是 caller-saved, rbx/rbp/rsi/rdi/r12-r15 是 callee-saved。pool 14 个里 6 个 caller-saved + 8 个 callee-saved。

**当 ctx_ 抽到 caller-saved (rax/rdx/rcx/r8-r11)** — VM 跨 call 后 ctx_ 寄存器被 callee 清掉, callgate 后续 step 9-10 用 r64(ctx_) 寻址读到垃圾 VmContext 指针 → segfault。

**但 b880720 设计上 ctx_ 是 vm_entry push 的**, vm_entry push 7 callee-saved + push base_, **caller-saved 没 push (因为按 ABI 不需要 push)**。callgate step 3 push ctx_ 是把 ctx_ 寄存器值 (VmContext 指针) 拷到栈, **r64(ctx_) 寄存器值仍由 callee clobber 决定** — 如果 callee 清掉 caller-saved 寄存器, ctx_ 变垃圾。

**等等再想**: step 5 用 r64(ctx_) 是 callgate 内 — 在 call 之前。**call 之后** step 7-11 仍用 r64(ctx_) — 这时 callee 已经 ret, ctx_ 寄存器状态 = callee ret 时。

**Win64 ABI**: callee 必须保留 callee-saved 寄存器 (rbx/rbp/rsi/rdi/r12-r15); caller-saved (rax/rcx/rdx/r8-r11) callee 可任意改。**如果 ctx_ 寄存器是 caller-saved, callee 把它改了, callgate step 9-10 寻址读到错的 VmContext → segfault**。

**这就是 callgate 的潜在 bug**, 与 pool 洗牌强耦合 — **ctx_ 必须分配 callee-saved 寄存器**。**但 AsmGen::roll() 池子没限制**, 50% 概率 ctx_ 抽到 caller-saved。

**回看 b880720 commit message** — agent 自己定义了 pool = 14 GPR 随机洗牌, 没说 "callgate 假设 ctx_ 是 callee-saved"。04fc323 没修这个。da801d4 也没修这个。**这是 callgate 设计的结构性 bug, 三个 commit 都没动**。

**任务 A commit message 写得对** — "pre-existing 多 register 分配耦合" — 但任务 A 本来应该把这个一起修了才完整, 不应该只解除 r14 单点。

**新 issue 必立**: callgate ctx_ 必须强制 callee-saved, 否则 50% 概率 segfault。

### 6. 状态结论

**MIT-298 整体**: **部分采纳**

| Commit | 状态 | 说明 |
|---|---|---|
| da801d4 (任务 A) | ✅ 采纳 | r64(ctx_) 替代 r14, 改动正确。但验收 #4 (多 seed 全 PASS) 未达成, 真因 callgate ctx_ 必须 callee-saved 的结构性 bug — 这是派活单假设错误, 不是 agent 失职 |
| dc71753 (任务 B-1) | ✅ 采纳 | lifter TranslateResult.skipped_ranges + LiftMetadata 旁路, 冻结契约零修改 |
| e0aecfc (任务 B-2) | ✅ 采纳 | backend::compile() 接 LiftMetadata 触发 C1 gate, 新 E2E lifter_skip_sample 验证完整链路 |

**待办**:
- **新 issue 立**: callgate ctx_ 必须强制 callee-saved (AsmGen::roll() 池子限制 8 个 callee-saved, 或在 build_callgate 头部 `mov [rsp+8], ctx_` 栈快照后用 [rsp+8+offset] 寻址, 与派活单推荐方案 A 同思路但适配 callgate 全栈布局)
- **MIT-298 status**: 留 todo, 不改 done, 等新 issue 修完 callgate 多 seed 后一并 close
- **复盘 issue-08**: 我自己写的 §A.3 验收 #4 (5 seed × 3 call 全 PASS) 假设错误 — 任务 A 只解除 r14 单点耦合, callgate 整体 ctx_ 分配假设是另一个 issue。**写 issue 时必须区分 "单点耦合" 与 "结构性假设"**

## 沉淀

### 技术发现

- **callgate ctx_ 必须是 callee-saved**: AsmGen pool 14 GPR 随机洗牌, ctx_ 抽到 caller-saved 时, native callee 把它清掉, callgate 后续 step 9-10 寻址读到垃圾 VmContext → segfault (50% 概率, 取决于 seed 选了哪个寄存器)
- **vm_entry push 7 callee-saved + push base 不保护 ctx_**: 因为 ctx_ 是 pool[0] 随机选, vm_entry 不能假设 ctx_ 在 7 个 callee-saved 里。需要在 callgate 内部做快照保护 (栈偏移寻址), 或在 AsmGen::roll() 加约束 ctx_ ∈ {rbx, rbp, rsi, rdi, r12-r15}
- **push 不改寄存器值**: x86 push 把值拷到栈, 寄存器本身不动 — 但这跟 ABI 守恒不挂钩, 寄存器内容由 callee 按 ABI 决定 (callee-saved 保留, caller-saved 可改)
- **r14 → r64(ctx_) 等价**: 派活单推荐方案 A (栈偏移) 与 agent 选的方案 B 子集 (直接用 r64(ctx_)) 都消除硬编码寄存器依赖, 但 callgate 整体栈布局与 pool 分配的隐含耦合仍在 — 这是更深层的 bug

### 流程教训

- **fresh verify 不能省**: agent commit message 主动披露 12/15 SIGSEGV, 真实复现 12/15 SIGSEGV — 但派活单验收 #4 要求 15/15 PASS。这次幸亏项目主 fresh verify, 没盲采纳 agent 自报
- **写 issue 验收时区分"单点耦合"与"结构性假设"**: 这次 issue-08 §A.3 验收 #4 (5 seed × 3 样本) 假设 task A 能修"callgate 寄存器分配耦合", 实际 task A 只解了 r14 单点耦合, 寄存器分配整体假设是另一个 bug。下次写验收要明确"本 issue 修复范围", 不外推到"任意 seed"
- **agent 自报诚实度**: da801d4 commit message 第 4-5 段主动写 "多 seed 失败是 pre-existing, 与本 fix 无关", 不是掩盖, 而是真实结论。但项目主需要独立判定 — "pre-existing" 是不是"本 issue 修复范围"
- **bash 跑 native exe 比 PS 可靠**: multiseed_verify.sh 用 bash 调 native exe 拿到真实 SIGSEGV, PS `&` 调 native 因 stderr 抛 NativeCommandError 干扰 `$LASTEXITCODE` 判定。下次 multi-seed verify 直接走 bash, 避免 PS native error 误判
- **TOML Windows 路径必须 forward slash**: `\U` `\m` `\A` 等不是 TOML 合法 escape, 路径里有反斜杠 + 字母组合必报 "unknown escape sequence"。cygpath -m 转 `C:/Users/...` 是正解
