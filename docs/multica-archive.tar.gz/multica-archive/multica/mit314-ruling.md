# 项目主裁定: 采纳 MIT-314 (lifter movzx 支持) + MIT-301 (cl_shift 真虚拟化) 闭环

## 总体评价

MIT-314 commit `f2e3275` (git commit message 标 "MIT-315", Multica 派单标 MIT-314) **采纳** (ACCEPT): **派活单核心目标达成** — `wvmp_cl_shift_sample` 5/5 seed 真虚拟化, 4 个入口 stub per seed, 87 条 movzx 全部被 lifter 接住。

**MIT-301 (cl_shift 真虚拟化闭环) 同时达成** — 派活单 §A 反汇编列 4 种 movzx 字节编码 (REG-REG 8→32 / REG-REG 8→64 / REG-MEM 8→32 / REG-MEM 复杂 SIB), lifter 全接住。

## 独立核查结果 (2026-08-25, hermes)

### 双重确认 (verifier + 项目主 fresh verify)

- **verifier 报告** (MIT-315 完成): 9/9 派活单验收通过, cl_shift 5/5 真虚拟化, 4 个入口 stub, 87 条 movzx 全接住
- **项目主 fresh verify** (bash 跑): build rc=0, ctest 15/15, cl_shift 5/5 真虚拟化 (`已生成` + `stub` 全部命中)

### 1. git state

```
HEAD: f2e3275 (clean, main)
MIT-314 commit: f2e3275 (git message 标 MIT-315, Multica 标 MIT-314)
改动: 7 文件
- passes/lifter/src/x86_translate.cpp: translate_movzx (REG-REG + REG-MEM)
- passes/lifter/tests/test_lifter.cpp: 6 lifter 单测
- ir/include/wvmp/ir/insn.hpp: ir::Op::Movzx (新增 enum, 不改字段)
- vm/regvm/isa/include/wvmp/regvm/isa/vm_op.hpp: VmOp::Movzx / MovzxMem
- vm/regvm/translator/src/translator.cpp: translate_movzx
- vm/regvm/runtime/src/asmgen.cpp: build_movzx + build_movzx_mem handlers
- vm/regvm/runtime/tests/test_runtime.cpp: MovzxSemantics + 100K fuzz
```

### 2. fresh verify 总览 (与 verifier 一致)

| 项 | 结果 |
|---|---|
| HEAD | f2e3275 (clean, main) |
| build | rc=0, **292/292** (0 警 0 错) |
| ctest | **15/15 PASS** (24.69s, 含 6 lifter movsxd + 5 runtime movsxd + 100K fuzz) |
| E2E | **15/15 byte-exact** (verifier 跑全 15 sample, 含 cl_shift) |
| **cl_shift 真虚拟化** | ✅ **5/5 seed, 4 个入口 stub per seed, 87 条 movzx 全接住** |
| imul 回归 | ✅ imul sample 5/5 真虚拟化 (MIT-309 不破坏) |
| movsxd 回归 | ✅ snake 0 条 movsxd 警告 (MIT-312 不破坏) |
| call-bearing 回归 | ✅ call_gate / call_gate_simple / rol 15/15 byte-exact |
| multiseed REQUIRE_REAL=1 | ✅ cl_shift 5/5 PASS (从 FAIL 改 PASS), imul 5/5, call-bearing 15/15 |
| snake 仍 C1 gate | ⚠️ 根因独立: RVA 0x11E1 跨区域外跳 (snake_sample 3 WVMP_END 设计缺陷, 留 sub-issue-20) |
| 冻结契约核查 | ✅ 仅改 7 个白名单文件, Operand 不追加 src3/src4 |

### 3. cl_shift 真虚拟化硬证据 (bash 跑)

```
$ bash verify_clshift.sh
PASS seed=1 (real virtualization)
PASS seed=12345 (real virtualization)
PASS seed=99999 (real virtualization)
PASS seed=3735928559 (real virtualization)
PASS seed=3405691582 (real virtualization)
---
Real: 5/5, C1 gate: 0/5
```

### 4. 派活单预先双核查纪律生效 (本派活单设计)

派活单 §A 反汇编 + 读源文件核查双纪律 (MIT-313 verifier 提出, 本次落实):
- ✅ capstone 反汇编 codegen (§A 列 78 条 movzx 字节编码, 4 形式)
- ✅ 读 `cl_shift_sample_main.cpp` 核查 WVMP 数量 (4 对 BEGIN/END, 无早返回)
- **派活单设计安全** (避免 MIT-300/312 snake_sample 3 WVMP_END 缺陷复发)

### 5. 派活单验收逐条核对 (9 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-314 commit 存在 | ✅ | ✅ HEAD `f2e3275` | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E 14/14 byte-exact | ✅ | ✅ 15/15 (verifier 全跑) | ✅ |
| 5 | **E2E cl_shift 真虚拟化** | ✅ 5/5 seed | ✅ 5/5 seed, 4 stub each | ✅ |
| 6 | multiseed REQUIRE_REAL=1 | cl_shift 从 FAIL 改 PASS | ✅ cl_shift 5/5 PASS | ✅ |
| 7 | imul / movsxd / call-bearing 回归零退化 | ✅ | ✅ 全 PASS | ✅ |
| 8 | 冻结契约核查 | 仅改 lifter + ir + translator + asmgen + tests | ✅ 7 文件, 未追加 src3/src4 | ✅ |
| 9 | cl_shift_sample 设计安全 | 4 对 BEGIN/END, 无早返回 | ✅ 派活单派活前已双核查 | ✅ |

### 6. 派活单设计累积教训 (派活前双核查纪律)

| 派活单 | 派活前核查 | 失败模式 | 教训 |
|---|---|---|---|
| MIT-300 snake | ❌ 仅看 issue 描述 | imul + movsxd 跳出 | 应反汇编 + 读源文件 |
| MIT-301 cl_shift | ❌ 仅看 issue 描述 | movzx 跳出 | 应反汇编 |
| MIT-305 imul REG-REG | ❌ 仅看 issue 描述 | lifter 仅接 REG-REG | 应反汇编 |
| MIT-309 imul MEM | ✅ 仅反汇编 (没读源文件) | 派活单设计 OK, agent commit OK | 应**反汇编 + 读源文件** |
| MIT-312 movsxd | ✅ 仅反汇编 (没读源文件) | snake_sample 3 WVMP_END (派活单设计缺陷) | 应反汇编 + 读源文件 |
| **MIT-314 movzx** | ✅ **反汇编 + 读源文件 (双核查)** | **派活单设计 OK + agent commit OK** | **双核查纪律生效** |

**MIT-314 是第一次派活单派活前双核查纪律完整落实, 派活单设计 + agent commit 双重成功**。

### 7. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-314** | ✅ **done** (本 commit 采纳) | lifter movzx 完整, cl_shift 真虚拟化闭环 |
| **MIT-301** | ✅ **done** | cl_shift 真虚拟化闭环 (依赖 MIT-314) |
| MIT-300 | ⏸ in_review (snake 真虚拟化未达, 等 snake 改造 sub-issue-20) |
| MIT-305 | ⏸ in_review (imul REJECT) |
| MIT-309 | ✅ done (imul MEM) |
| MIT-312 | ✅ done (lifter movsxd) |
| MIT-313 | ✅ done (MIT-312 verifier) |
| MIT-315 | ✅ done (MIT-314 verifier, 9/9 通过) |
| issue-20 | 🕒 todo (snake 改造 sub-issue, 待派) |

### 8. 后续行动

1. **派 issue-20 (snake 改造)** — 1 小时工作量, 改 snake_sample 移除 2 个 WVMP_END, 验证 snake 真虚拟化闭环
2. **snake 闭环后**: 改 MIT-300 → done
3. **Block C 阶段 1 完成**: lifter 白名单 ~39 条, 12 真虚拟化 sample + 15 字节一致
4. **进入 Block C 阶段 2** (中频指令): xchg / bswap / movzx / movsx / cmpxchg / xadd / setcc / cmovcc (~5-7 天)

## 沉淀 (Block C 阶段 1 完整闭环经验)

### 派活单设计累积教训 (5 次派活 + 1 个 sub-issue)

| # | 派活单 | 派活前双核查 | 结果 |
|---|---|---|---|
| 1 | MIT-300 snake | ❌ | 失败 (imul + movsxd 跳出) |
| 2 | MIT-301 cl_shift | ❌ | 失败 (movzx 跳出) |
| 3 | MIT-305 imul REG-REG | ❌ | REJECT (lifter 仅 REG-REG) |
| 4 | MIT-309 imul MEM | ⚠️ 仅反汇编 | ✅ (派活单 OK, agent OK) |
| 5 | MIT-312 movsxd | ⚠️ 仅反汇编 | ⚠️ (snake_sample 3 WVMP_END 派活单设计缺陷) |
| 6 | **MIT-314 movzx** | ✅ **反汇编 + 读源文件** | ✅✅ (派活单 OK, agent OK) |

**MIT-314 是第一次派活单派活前双核查纪律完整落实**:
- capstone 反汇编 codegen (§A 列 78 条字节编码, 4 形式)
- 读源文件核查 WVMP 数量 (4 对 BEGIN/END, 无早返回)

### verifier 实战 4 次确认

- **MIT-308 verifier**: 抓 4 个隐藏问题 (核心目标 / 冻结契约 / 测试盲区 / multiseed 误导)
- **MIT-311 verifier**: 9/9 通过 + REQUIRE_REAL=0 默认合理改进建议
- **MIT-313 verifier**: lifter 达成 + snake_sample 设计缺陷 + 派活单反汇编+读源文件建议
- **MIT-315 verifier**: 9/9 通过 + cl_shift 真虚拟化闭环确认

**verifier 四连实战**:
1. 隐藏 4 类缺陷
2. 改进建议 (REQUIRE_REAL)
3. 派活单设计缺陷 (snake_sample 3 WVMP_END) + 派活单双核查纪律建议
4. 派活单双核查纪律生效, 9/9 通过

**verifier 是项目主 fresh verify 之外的独立验收** — 比项目主 fresh verify 更**无利益冲突**, 比项目主 fresh verify 更**敢于指出派活单设计缺陷**(因为 verifier 不参与派活单设计)。

### 流程改进累积 (派活单派活前)

1. **派活单派活前反汇编** (MIT-309 引入)
2. **派活单派活前读源文件** (MIT-313 verifier 提出, MIT-314 落实)
3. **派活单派活前双核查纪律完整** (MIT-314 第一次完整落实)
4. **完成后必派 WVmpVerifier** (MIT-308 引入, 4 次连续验证)
5. **multiseed REQUIRE_REAL=1** 区分真虚拟化 vs C1 gate (MIT-309 引入)
6. **冻结契约白名单扩展** additive 兼容字段不撤回 (MIT-305 引入)

### 阶段 1 进度总结

**完成**:
- ✅ MIT-243~249 Block B (C1~C4)
- ✅ MIT-298/299 follow-up (callgate ctx_ + C1 gate 联动)
- ✅ MIT-309 (imul MEM 修复)
- ✅ MIT-312 (lifter movsxd 部分)
- ✅ **MIT-314 (lifter movzx)** + **MIT-301 闭环** (本次)

**in_review**:
- ⏸ MIT-300 (snake 真虚拟化, 等 snake 改造 sub-issue-20)
- ⏸ MIT-305 (imul REJECT, 已派 sub-issue MIT-309)

**待派**:
- 🕒 snake_sample 改造 sub-issue (issue-20-snake-region-pair.md)
- 🕒 Block C 阶段 2 中频指令 (xchg / bswap / movzx / movsx / cmpxchg / xadd / setcc / cmovcc)

### 简短答案

**MIT-314 采纳, MIT-301 闭环** — cl_shift 真虚拟化达成 (5/5 seed), lifter 白名单扩到 ~39 条, Block C 阶段 1 接近完成 (snake 闭环待 issue-20)。要立刻派 issue-20 (snake 改造) 吗?