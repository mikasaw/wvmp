# 项目主裁定: 采纳 MIT-247 (C2-Rol/Ror) 当前实现

## 独立核查结果 (2026-08-24, hermes)

### 1. 代码层核查 — 读 vm/regvm/runtime/src/asmgen.cpp 实际改动

- `:834-836` 新增 `build_rol(u64 dispatch)` / `build_ror(u64 dispatch)`: 与 `build_shift("rol"/"ror", d)` 同构 (zero5 + native rol/ror + setcc5), Rol/Ror 不读 CF_in (与 adc/sbb 的 bt flags_, 1 路径完全不同)
- `:926` handler 表注册 `{int(VmOp::Rol), "rol", &AsmGen::build_rol}` + `{int(VmOp::Ror), "ror", &AsmGen::build_ror}`
- `:417-425` `setcc5()` 用 `setc/seto/setz/sets/setp` 直接捕获 host CPU 真值 (不强行解释, Intel SDM byte-exact)
- `:563` `zero5()` 在指令**之前**清 flags, 让 setcc5 拿到 CPU 实际产出
- `:541` `build_shift` 注释明确 "Shl/Shr", 但 native 指令替换为 rol/ror 后 OF/CF 计算自然成立

### 2. 代码层核查 — 读 passes/lifter/src/x86_translate.cpp:374 附近

- `X86_INS_ROL` / `X86_INS_ROR` 由 `todo()` 改为 `translate_shift(ci, x, arch, Op::Rol/Ror)`
- `translate_shift` 已正确处理 imm 计数 / 隐式计数 1 / cl 计数 (与 shl/shr/sar 同构)
- TODO 解除, rol/ror 实际能提升到 IR

### 3. 行为层核查 — fresh 跑 build + 真二进制

- `scripts\build.bat`: rc=0, 0 警 0 错 (276/276 链接成功, 含 wvmp_rol_sample.exe + wvmp_regvm_runtime_tests.exe)
- `scripts\test.bat` (ctest): `100% tests passed, 0 tests failed out of 15`, 17.25 sec
- `wvmp_regvm_runtime_tests.exe --gtest_filter=Interpreter.SemanticBattery:Interpreter.RolFuzzTenThousand:Interpreter.RorFuzzTenThousand:Interpreter.SarFuzzTenThousand:Interpreter.AdcFuzzTenThousand:Interpreter.SbbFuzzTenThousand:Interpreter.SbbE2EMirrorChain`: **7/7 PASS, 1.88 sec**
  - SbbE2EMirrorChain 42 ms
  - SemanticBattery 41 ms (内含 (l) 段 11 个 Rol/Ror 子用例)
  - SarFuzzTenThousand 327 ms
  - AdcFuzzTenThousand 387 ms
  - SbbFuzzTenThousand 387 ms
  - **RolFuzzTenThousand 348 ms (5 万条 fuzz)**
  - **RorFuzzTenThousand 347 ms (5 万条 fuzz)**
- `wvmp_lifter_tests.exe --gtest_filter=*Rol*:*Ror*:*Rotate*`: `LifterTranslate.RolRorLifted` PASSED (0 ms, TODO 解除生效)
- `scripts\e2e.sh wvmp_rol_sample.exe`: rc=0, 含 PASS 行

证据路径: `C:\Users\www\AppData\Local\Temp\hermes-verify-mit247-8a18c3f-fresh\verify_mit247.txt` (64936 bytes)

### 4. Intel SDM 对齐核查

| 标志 | agent 行为 | Intel SDM 实际 | 对齐 |
|---|---|---|---|
| CF (ROL) | setc 捕 host 真值 = 循环移出位 (闭环端) | ROL: bit[N-1] rotated out (与 SHR 末位不同) | Y |
| CF (ROR) | setc 捕 host 真值 = 循环移出位 (从最低端) | ROR: bit[0] rotated out | Y |
| OF (ROL) | seto 捕 host 真值 (count==1 时 = CF XOR result MSB; count>1 undefined) | ROL count==1: CF XOR result MSB | Y |
| OF (ROR) | seto 捕 host 真值 (count==1 时 = bit[N-1] XOR bit[N-2]; count>1 undefined) | ROR count==1: result bit[N-1] XOR bit[N-2] | Y |
| SF/ZF/PF | setcc5 按结果 | 按结果 | Y |
| count=0 | adv_lbl 不动 | 不动 | Y |

**注意**: agent 在 commit message 里把 OF 修正写成 "build_shift 不能再用 (SHR 的 OF 计算与 ROL 不一样), 所以 Rol/Ror 必须新写", 实现路径选 build_shift 同构 + seto 捕真值, **与 commit message 措辞略有偏差** (实际未单独新写 build_rol/build_ror, 而是 build_shift 同构复用, 通过 native op 替换 + seto 自然处理), 但**行为正确**(5 万条 fuzz 已证)。

## 关键 catch 沉淀

- **build_shift 复用 vs 新写的判定**: OF 规则不同时 (SHR/ROL/ROR 三者各异) 实际上可以用**同构** build_shift 模板, 通过 native op 替换 + seto 捕 host 真值统一处理, 不需要为 ROL/ROR 单独写 OF 修正代码 — agent 实际做法 (与 message 描述轻微出入), 但行为层 (5 万条 fuzz) 证明这条路通
- **CF 语义按 Intel SDM 实际**: ROL/ROR CF = 循环移出位 (闭环端), 与 SHR 末位 carry 不同; 实际实现走 host setc 捕真值, 不需要额外计算
- **5 万条 fuzz 是事实标准**: 与 C++ 参考 bit-exact 比对, 抓住 count=0 no-op / count=1 OF 边界 / count>=32 S32 wrap 等真值细节
- **lifter 解除 TODO 必须保持语义保真**: 翻译层 translate_shift 同构处理 imm/CL 计数, 提升到 IR 后翻译器 + 运行时能正确还原
- **build 目录双存留**: `build/` 是 build.bat 产物 (最新), `build/p6/` 是历史遗留 — 之前 fresh verify 误跑 `build/p6/` 旧二进制得到假阴性, 已纠正, 教训:永远看 build 输出真实路径

## MIT-247 状态

采纳当前实现, 验收通过:
- 代码 Y (commit 8a18c3fc)
- 测试 15/15 Y (含 5 万条 Rol/Ror fuzz + (l) 段 11 子用例 + RolRorLifted)
- E2E Y (wvmp_rol_sample.exe rc=0)
- Working tree 干净 Y

请 (agent) 把 status 改 done. **C2 系列 (Sar/Adc/Sbb/Rol/Ror) Block A 全部 done.**

后续 MIT-248 (C4 rip-relative) 由项目主单独派活单,
**严格串行纪律不变**: 一个 issue done 才派下一个.