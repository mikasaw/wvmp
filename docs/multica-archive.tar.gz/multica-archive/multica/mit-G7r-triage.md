# MIT-G7r triage 报告 — C5 x86 (16/32-bit) 目标支持侦察：全管道改造面审计 + 实施拆单蓝图

- verifier: WVmpVerifier (裁定型 / 纯侦察, 零产品代码改动, 未采纳开发侧任何结论)
- 静态分析基线: main `c04ca49` (MIT-409, 2026-08-29 19:57); CLI = `build/cli/wvmp_cli.exe` (mtime 20:52 > HEAD, 新鲜 main 产物)
- 实验环境: `%TEMP%\mit412_x86\` (hello32 / marker32 / craft32 三样本 + 12 个变异体 + 4 路 cdb), **主仓零写入、零 git 操作**
- 采集时间: 2026-08-29 20:33–21:25 (+0800), 全部数字来自实测输出/脚本粘贴
- 结论置信度: **高** (代码直读 + 实跑行为 + Python struct PE 直读 + 变异体二分定位, 四路互证)
- ⚠️ **并发状态披露**: 本侦察期间共享 checkout 被并发运行 (MIT-411/G1) 从 main 切到 `mit-411-sse-tail` 且有 5 个 tracked 文件未提交修改 (GAPS.md / x86_translate.cpp / test_lifter.cpp / marker_scan tests CMakeLists / multiseed_e2e.sh, mtime 20:42–20:45)。本侦察未做任何 git 操作、未切回 main——切回会把并发运行的未提交改动带到 main 上, 风险更高; 该状态由并发运行的收尾义务恢复。

## §0 结论 (裁定)

**GAPS C5 主张逐条审计结果: 1 条实证成立, 2 条过时/归因不完整**。x86 支持的真实断层**不在扫描环节, 而在运行时与 stub 两大块 (asmgen/stub_gen 硬编码 KS_MODE_64 + Win64 ABI)**; 且 pe_loader 存在一个**全新的 PE32 解析 bug** (BaseOfData 漏读, 3 字段错位), 派单 §A.2 未知, 是当前 PE32 输入"产出被加载器拒绝的坏壳"的直接根因。

**B.2 实测行为链 (三态明确, 全部有输出证据)**:
1. **PE32 无 marker** → 管道静默跑完全程, 输出 = 输入 + CheckSum 两字节 (0x140/0x141), 运行行为不变 → **静默无操作** (用户以为保护了, 实际零虚拟化)
2. **PE32 + 真 SDK marker (x86 编译)** → 同样静默无操作。SDK magic 拆两条 imm32 实证成立 (`c7 45 f8 57 56 4d 50` / `c7 45 fc 42 45 47 31`), marker_scan 报 "magic 未找到" → GAPS C5 第一主张 **✅ 成立**
3. **PE32 + 连续 magic (手造锚点)** → marker_scan 找到锚点, **x64 管道在 32 位 PE 上完整跑通**: lifter CS_MODE_64 解 32 位代码碰巧全译, 26,253 字节 x64 解释器 + x64 stub 写入 `.wvmp`, 入口 E9 跳板就位 → 输出被 Windows 加载器**直接拒绝** (WinError 193 / STATUS_INVALID_IMAGE_FORMAT, cdb 实证) → **产错壳, 但失败是响亮的 (加载即拒), 不是静默**
4. 拒绝根因 (变异体二分钉死): pe_loader PE32 bug → section_alignment 误读为 0x400000 → stub_link 把 `.wvmp` 放在 RVA 0x400000 → **加载器要求节 VA 连续** (实测: `.wvmp` VA 0x5000 可加载, 0x6000 起全部拒绝, 与 SizeOfImage/raw 布局无关)
5. 把 pe_loader bug 修复后的等价布局 (`.wvmp` @0x5000) → 镜像**能加载**, 运行时在 E9 跳板处 **0xC0000005 崩溃** → 坏壳在"修复后"路径实证
6. x64 对照: rol 样本 protect + 运行均正常 (本机 sanity) → 问题确实是 x86 专属

**路线建议: P2 先行 (安全拒绝面, 1 个 S 级派活单), P1 保留 backlog (XL 依赖 asmgen 重写, 拆 6-8 单), P3 不推荐单独选** (静默无操作是真实风险, 不投入也至少要 P2 的文档化)。详见 §7。

## §1 GAPS C5 逐条审计 (真缺口 / 已支持 / 过时)

| # | GAPS 原文主张 | 判定 | 证据 |
|---|---|---|---|
| 1 | "marker_scan 仅支持 x64：magic 在 x86 上被拆成两条 imm32，不连续 (marker_scan_pass.cpp:172)" | ✅ **真缺口 (实证成立)** | marker32.exe 反汇编: `c7 45 f8 57 56 4d 50 / c7 45 fc 42 45 47 31` (两条 `mov dword ptr [ebp-8/-4], imm32`), 8 字节 needle 不连续 → CLI 日志 "begin 桩 magic 未找到"; marker_scan_pass.cpp:173 硬编码 `fr.arch = ir::Arch::X64` |
| 2 | "ISA/lifter 层有 X86 枚举与部分支持" | ⚠️ **过时 (程度低估)** | lifter 不是"部分支持"而是真参数化: capstone_session.cpp:9-10 (`arch==X86 → CS_MODE_32`), x86_translate.cpp:12 (`pointer_size` S32/S64 分叉), `map_reg` EAX..EDI/EIP→ir::Reg Rax..Rip (:221-236), movsxd 显式拒 x86 (x86_translate.cpp:411, :866, :884) |
| 3 | "扫描这一环断了, 双架构承诺目前只在底层兑现" | ⚠️ **过时 (归因不完整)** | 真实断层除扫描外还有两大块: asmgen.cpp:85 `ks_open(KS_ARCH_X86, KS_MODE_64)`, stub_gen.cpp:155 同款; 而 pe_loader 双架构解析已就位 (pe_image.cpp:49-51 接受 0x014C) |
| 4 | 标题 "x86 目标实际不可用" | ⚠️ **部分过时** | "不可用"的一部分原因是 pe_loader PE32 解析 bug (见 §3), 而非纯设计缺口; 且 PE32 输入当前行为 = 静默无操作或加载拒绝, 不是"拒绝"语义 |

## §2 现状矩阵 (B.1 四问, 逐子系统, 行号引用)

| 子系统 | 现状 (支持/拒绝/崩溃证据) | 关键代码 | 32 位最小改动面 |
|---|---|---|---|
| pe_loader | **双架构解析已实现**: machine 白名单 x86/x64 (pe_image.cpp:14-15, 49-51), PE32/PE32+ Magic 双判 (:63-66), 节表/rva_to_offset/headers_raw_size 全 arch 无关 | pe_image.cpp:63-78 | **发现 bug**: PE32 分支忘读 BaseOfData → image_base/section_alignment/file_alignment 三字段全部错位 4 字节 (见 §3) |
| marker_scan | E8 rel32 扫描 arch 无关 (scan_core.cpp:38-58, `next+5+rel32` 双架构同公式); 锚点 = 8 字节 needle; `fr.arch` 硬编码 X64 (marker_scan_pass.cpp:173); kStubWindow=64 (scan_core.hpp:24) | marker_scan_pass.cpp:104-173 | arch 改从 PeImage.machine 读 (一行); SDK x86 锚点方案 (见 §6); 扫描器本身零改动 |
| lifter | **已参数化 (实测 x86 分支真实存在)**: 双 CapstoneSession 并存 (lifter_pass.cpp:54-55,77), CS_MODE_32/64 (capstone_session.cpp:9-10), pointer_size 分叉 (x86_translate.cpp:12), EIP→Rip map, movsxd/SSE 双 MEM 规则均有 arch 分支 | lifter_pass.cpp:54-77 | 无代码改动; 需 x86 样本实测 lift 质量 (验证级) |
| translator | arch 经 `fn.arch` 流入 blob 头 (translator.cpp:1982 `make_blob(fn.arch,…)`); S64 硬编码点 5 处: rip 地址拼装 (:328-346), mem disp (:370, :403), 跳转表模式 (:127-145), imm64 split (:316-323) | translator.cpp:316-403 | x86 分支: 地址类改发 S32 (RVA 恒 u32, fits_aux 已限 u32); S64 IR 拒 → C1 gate; 跳转表表项 u32 双架构同款 |
| asmgen 运行时 | **x64 专属 (最大断层)**: KS_MODE_64 (:85), 14 物理寄存器池 (16-rsp-rcx), Win64 ABI (8 callee-saved 保存, rcx=ctx 参数, shadow 0x28, 16 对齐), REX.W 驱动 S64 语义, callgate 按 RCX/RDX/R8/R9, 128 项跳表 (arch 无关) | asmgen.cpp:1-62 (设计头), :85, :160-194, :235-315 | **XL**: 整个代码生成器需 x86 形态 (6 寄存器池 + spill 纪律, cdecl, 无 REX) |
| stub_gen | **x64 专属**: KS_MODE_64 (:155), push 8 callee-saved (:56-57), `mov rcx,rsp` Win64 传 ctx (:117), `lea rax,[rsp+…]` image_base 中转 (:92-93), movups xmm 同步 (:109-114) | stub_gen.cpp:54-147 | M: x86 版 5 callee-saved (ebx/esi/edi/ebp), ctx 栈传参, image_base u32 直接 mov (PE32 ≤ 4GB), xmm movups 语义保留 |
| runtime.hpp VmContext | **布局 arch 共享**: u64 regs[32] (低 32 位承载 x86 GP), v16=rip/eip 占位, v17=flags, xmm[8]@0x140, kCtxSize 派生式 | runtime.hpp:20-100 | **零改动** (槽位模型天然双架构) |
| pe_writer | **双架构字段偏移已正确** (实测): CheckSum@opt+64, DllChars@opt+0x46, SizeOfImage@opt+56 均 PE32/PE32+ 同款; 头保留式写出; 节表追加 + SizeOfImage 更新 arch 无关 | pe_writer_pass.cpp:22-27, 64-97; section_builder.cpp:145-168 | 无改动; 注意: 无节 VA 连续性校验 (见 §8 新耦合 #2) |
| CLI/config | **无 arch 字段** (config.hpp 仅 seed/output/input/passes; 实测 `--help` 不存在, 只有 protect/version) | cli/include/wvmp/cli/config.hpp:25 | P2 需显式拒 + 提示; 全支持需 arch 字段 + 校验 |
| 测试基建 | 样本清单硬编码 x64 产物路径 (multiseed_e2e.sh:75-130), 无 /MACHINE 参数化 (grep 零命中), e2e.bat 是 bash 委托壳 (arch 无关) | scripts/multiseed_e2e.sh:75+; scripts/e2e.bat | M: 32 位样本需独立 x86 CMake 目录 + 清单参数化; REQUIRE_REAL 断言 (日志 grep "已生成 N 个入口 stub") arch 无关 |

## §3 B.2 实测行为链 (三样本 + 变异体二分, GO/NO-GO 核心依据)

### §3.1 样本工程 (可复现命令见 §6)

| 样本 | 构造 | 意图 |
|---|---|---|
| hello32.exe | cl /O1 /MD, 纯 printf, 无 marker | PE32 基线 |
| marker32.exe | cl /O1 /MD + 真 SDK (sdk.cpp x86 编译), WVMP_BEGIN/END | GAPS C5 SDK 主张验证 |
| craft32.exe | 手造连续 magic: `__declspec(naked)` + `__asm { jmp skip; _emit 0x57..0x31; skip: ret }` | 打通扫描链, 暴露 x64 管道对 32 位输入的行为 |

### §3.2 行为链 (wvmp_cli protect, seed 12345, 同 e2e.sh 管道装配)

| 输入 | CLI 行为 | 输出 | 运行 |
|---|---|---|---|
| hello32 | `[warning] marker_scan: begin 桩 magic 未找到` → virtualize/stub_link 空转 | 与输入**仅 CheckSum 2 字节不同** (0x140/0x141, Python 逐字节 diff) | ✅ 行为不变 (rc=7, stdout 一致) |
| marker32 | 同上 ("magic 未找到") | 同上 | ✅ 行为不变 |
| craft32 | 找到锚点; **2 个误归属 begin** (CRT 初始化区 E8 落入 ≤64B 窗口, 日志 `begin@0x474`/`begin@0x6c1` 无配对); 1 个真区域被虚拟化: `stub_link: 已生成 1 个入口 stub，.wvmp 节 26253 字节 @ RVA 0x400000` | +.wvmp 节 (40960 B vs 9216 B), SizeOfImage 0x800000 | ❌ **WinError 193 加载拒绝** (python/cdb/32 位 cdb 三路一致) |
| x64 对照 (rol 样本) | 2 stubs, `.wvmp @ RVA 0xB000` | 正常 | ✅ rc=0, 输出正确 |

### §3.3 拒绝根因链 (变异体二分钉死, 每步有 PE 直读 + 运行证据)

1. **pe_loader PE32 bug** (pe_image.cpp:74-78): PE32 分支只 skip BaseOfCode (4B) 就读 image_base, **漏读 BaseOfData (4B)** → 三字段错位: image_base=BaseOfData(0x2000), section_alignment=ImageBase(0x400000), file_alignment=SectionAlignment(0x1000)。(DataDirectory skip 0x3C 恰巧落位正确, .pdata 读取不受影响 — 逐字节核对)
2. stub_link_pass.cpp:76 取 `pe->section_alignment` = 0x400000 → `.wvmp` 节 RVA 对齐到 **0x400000** (正确值应为 0x5000)
3. 产物被 Windows 加载器拒绝 (STATUS_INVALID_IMAGE_FORMAT)。**变异体二分**: 仅改 `.wvmp` VirtualAddress → 0x5000 **可加载**, 0x6000/0x7000/0x8000/0x9000/0xF000/0x100000/0x400000 **全部拒绝**; SizeOfImage、raw 布局、characteristics 均不影响 → **加载器要求节 VA 与前一节连续 (无空洞)**
4. **修复后路径实证**: 正确布局变异体 (`.wvmp`@0x5000 + E9 跳板) → **能加载**, 执行到 E9 跳入 x64 解释器 → 0xC0000005 (32 位 CPU 解码 x64 字节) → 坏壳定义实证
5. `.wvmp` 节首 32 字节字节级证据 (x64 机器码在 PE32 内): `57 48 8d 3d f8 ff ff ff 53 55 56 41 54 41 55 41 56 41 57` = `push rdi; lea rdi,[rip-8]; push rbx…` (REX 前缀 0x48/0x41 密集)

## §4 工作量分级 (B.3, 每级附锚点清单)

| 子系统 | 分级 | 锚点清单 (禁拍脑袋依据) |
|---|---|---|
| pe_loader PE32 bug 修复 | **S** | 4 字节读取顺序改动 (pe_image.cpp:68-78) + 单测加 PE32 字段断言 (现有 test_pe_loader.cpp 10 套) |
| marker_scan arch 驱动 + SDK x86 锚点 | **S** | marker_scan_pass.cpp:173 一行 + sdk.cpp x86 锚点构造 (§6 已验证形态) |
| lifter | **S** (已就绪, 仅验证) | 双会话已存在 (lifter_pass.cpp:54-77); x86 样本 lift 质量实测 |
| translator x86 分支 | **M** | 5 处 S64 硬编码点 (translator.cpp:127-145, :316-323, :328-346, :370, :403) 改 arch 分叉 + S64 IR gate |
| stub_gen x86 | **M** | stub_gen.cpp:54-147 重写 ABI 段 (5 callee-saved / 栈传参 / imm32 image_base), keystone mode :155 |
| asmgen 运行时 x86 | **XL** | KS_MODE_64 (:85); **物理寄存器池 14→6** (x86 8 GPR - esp - ecx) → 5 个持久寄存器 + 1 个临时 vs 现有 T0..T9 全池分配, 需 spill 纪律重构整个 codegen; callgate Win64→cdecl (asmgen.cpp:1012-1080); S64 路径无 REX 对等 (拒或双槽仿真); 全部 handler 的 32 位编码核验 |
| pe_writer | **S** (无改动) | 实验已验证节表/SizeOfImage/字段偏移双架构正确 |
| CLI/config | **S** | 加 arch 字段 (config.hpp) 或显式拒; 无 --help 子命令 (实测) |
| 测试基建 | **M** | 样本清单参数化 (multiseed_e2e.sh:75-130) + 独立 x86 CMake 目录 + 双架构断言 |
| 16-bit | **不可行 (登记)** | PE 格式只支持 0x014C/0x8664 (pe_image.cpp:49-51 白名单); 16 位 NE/LE 文件过不了 PE 签名检查 (pe_image.cpp:44-46); 保护壳生态无 16 位 PE 现实需求 |

**依赖图**: pe_loader 修复 (S) → marker_scan arch (S) ∥ lifter 验证 (S) → translator (M) → stub_gen (M) → asmgen (XL) → callgate (XL 子块) → CLI/基建 (M)。asmgen 为唯一 XL 且无并行替代, 是 P1 的排期锚点。

## §5 关键设计决策预案 (B.4)

1. **双架构 VM 一套 vs 分叉**: **一套**。ir::Op 冻结先例 (vm_op.hpp 注释 "ir::Op 冻结不可增枚举 → (op,Size) 双语义") 支持用 Size aux 表达位宽; VmContext 槽位模型 u64 天然承载 32 位 (低半); blob 头已带 arch (make_blob(fn.arch)); x86 仅用 v0..v7 + v16/eip + v17/flags + scratch, v8..v15 闲置不冲突。
2. **REX vs 无 REX 编码表复用度**: S32 路径无 REX.W — x64 handler 的 S32 编码段可直接复用 (指令字节相同); S64 路径 x86 无对等指令 → 翻译期 gate (S64 IR 在 x86 上除 64 位用户代码外不会产生) 或双槽仿真 (C2-Sar/Adc/Sbb 已有 128 位双寄存器先例)。
3. **VM 寄存器数/栈帧差异**: 虚拟寄存器文件不变 (32 槽, 8/16 GPR 共用低槽); **物理池 14→6 是唯一结构性难点** — 5 持久 (CTX/PC/FLAGS/BYTE/BASE) 已占满, 需 handler 局部 push/pop spill 或把 BYTE/BASE 降为每指令重载。栈帧: kCtxSize 派生式不变; stub 保存集 8→5 (x86 无 r12-r15)。
4. **EFLAGS 共享位差异**: VM flags 槽 64 位共享, 位布局 (ZF/CF/OF/SF/PF = bit0..4, vm_reg.hpp:30-37) 双架构一致; 机器 flags 宽度差异由 handler 编码承担 (32 位运算写 EFLAGS), VM 缓存语义不变。
5. **callgate ABI**: Win64 RCX/RDX/R8/R9 + shadow 0x28 + 16 对齐 → x86 cdecl 全栈传参 + 4/16 对齐; 现 asmgen.cpp:1012-1080 注释链整体需 x86 变体。
6. **rip-relative 处置**: x86 无 RIP 相对 → 现有 C4 机制 (翻译期 RVA + 运行时 image_base 还原, LeaRva/LoadRva/StoreRva) **天然适配** x86 的 `[disp32]` 绝对寻址 (base 寄存器可省) — C4 的既有投入是 x86 的最大红利。
7. **ExitNative/.pdata**: x86 通常无 .pdata → find_function_end_rva 退 nullopt (pe_image.cpp:161-172) → ExitNative 上界退化 → 保守 gate (regvm_backend.cpp:98-105) — 行为差异而非缺陷。

## §6 B.5 32 位样本工程可行性 (已实测, 命令可复现)

- **工具链**: VS Insiders (v145) 装了 x86 组件, `vcvarsamd64_x86.bat` 存在且可用 (实测 cl 产出 0x14C machine 32-bit word image)。`where cl` 裸调用不可用 (需 vcvars), MinGW 未装, 不需绕路。
- **可复现命令** (实施单 §A 照抄):
  ```
  call "C:\Program Files\Microsoft Visual Studio\18\Insiders\VC\Auxiliary\Build\vcvarsamd64_x86.bat"
  cl /nologo /O1 /MD /utf-8 /std:c++17 /TP /I <wvmp>\common\include /I <wvmp>\sdk\include marker32.c <wvmp>\sdk\src\sdk.cpp /Fe:marker32.exe /link /SUBSYSTEM:CONSOLE /MACHINE:X86
  ```
- **坑 (必须写进实施单)**: ① `/utf-8` 必须 — UTF-8 中文注释在 GBK 代码页下触发 C1018 "意外的 #elif" (实测; 主仓 cmake/CompilerWarnings.cmake:15 已带 /utf-8, 手工命令行容易漏); ② `__declspec(naked)` + `__asm _emit` 构造连续 magic 时, 编译器会吞掉块尾的 `ret` (实测: 函数体只剩 magic + int3 垫), 且 magic 字节被执行会破坏栈 (push/push/dec/inc… 序列) — **必须 `jmp skip` 跳过 magic** (实测形态见 §3.1, 运行 rc=0 输出正确); ③ 真 SDK x86 形态 (mov eax,imm32 ×2) magic 不连续 — 这是 SDK 侧设计事实, 不是构建问题。
- **multiseed 基建参数化**: 现有脚本无 /MACHINE/dumpbin 硬编码 (grep 零命中); 唯一 arch 耦合 = 样本清单 (multiseed_e2e.sh:75-130 硬编码 x64 产物路径) + 样本的构建工具链。32 位入池 = 独立 x86 构建目录 + 清单参数化; REQUIRE_REAL 断言 (grep "已生成 N 个入口 stub") 与 e2e.bat 委托壳均 arch 无关。

## §7 路线建议 (B.6 三选一 + 前置单草案)

**推荐: P2 先行 (安全拒绝面, 1 个 S 级派活单), P1 保留 backlog; 不选纯 P3**。

- **(P2) 最小可用 = 安全拒绝 + 文档收口** — 前置单 `MIT-G7r-P2` (S 级, 1 单):
  1. 修 pe_loader PE32 分支 BaseOfData 漏读 (pe_image.cpp:74-78) + test_pe_loader 加 PE32 字段断言 (image_base/section_alignment/file_alignment 逐字段)
  2. x86 gate: 对 machine==0x014C 的输入在 pe_loader 或 stub_link 显式拒绝 + diag "32 位目标未支持 (GAPS C5), 不产出保护壳", 消除静默无操作与坏壳两态
  3. GAPS C5 节改写 (现主张 3/4 过时) + STATUS.md:99 同步
  4. CLI 文档/输出提示 (可选: config 加 `target_arch` 字段预埋)
- **(P1) 全量 x86 对齐** — 前置单草案 (按依赖序, W6 排波): `G7x-1` marker_scan arch 从 machine 读 + SDK x86 锚点 (S); `G7x-2` translator x86 分支 + S64 gate (M); `G7x-3` stub_gen x86 (M); `G7x-4` asmgen x86 运行时 v1 — 核心 ALU/访存/dispatch/跳表, 无 callgate/SSE (XL); `G7x-5` callgate x86 (M); `G7x-6` SSE/xmm x86 核验 (M); `G7x-7` CLI/config arch + multiseed 参数化 (M); `G7x-8` 双架构 E2E 矩阵 (M)。**G7x-4 为唯一 XL, 无并行替代 — 排期以它为锚**。
- **(P3) 不投入** — 单列风险声明: 今天实测 "PE32 无 marker 输入 → 静默无操作" (输出仅 CheckSum 不同), 用户无从得知未受保护; 至少需 P2 的文档/提示面。

## §8 新发现耦合点清单 (§C #33, 派单 §A.2 未列)

1. **pe_loader PE32 分支 3 字段错位** (pe_image.cpp:74-78): 漏读 BaseOfData → image_base/section_alignment/file_alignment 全错; 是 §3.3 坏壳链的源头。**本项目最优先修复点** (独立于 x86 支持本身 — x64 流程不受影响, 但任何 PE32 输入都踩)。
2. **Windows 加载器要求节 VA 连续** (实测: 0x5000 OK / 0x6000+ 拒): section_builder.cpp:99-110 只查重叠、不查空洞; 正常路径 (sec_align 正确) 恒连续, 属防御性缺口。
3. **SDK marker 桩 x86 形态缺失**: sdk.cpp 注释已披露 (magic 拆分) 但无 x86 替代构造; 连续锚点方案 (§6) 已验证可行。
4. **CRT 初始化区 E8 误归属** (实测 craft32 最终构建: 2 个误归属 begin, 日志 `begin@0x474`/`begin@0x6c1` 无配对, 均来自 32 位 CRT 初始化代码的回调, 目标落入 begin 锚点前 ≤64B 窗口): 规则内设计行为 (kStubWindow=64 归属), x86 上 32 位 CRT 初始化近距调用密集, 误命中概率高于 x64; 低危 (误归属只产生多余 warning + 潜在空区域), 建议未来归属规则加"目标须位于锚点之前且锚点与目标间无可执行指令"类强校验或降窗口。
5. **"syscall ABI 假定" 不成立 (派单 §A.2 纠正)**: asmgen 全文件 grep syscall 零命中 — 运行时是纯生成代码 + Win64 call ABI, 无 syscall 依赖; 派单此条过时。
6. **ExitNative .pdata 依赖在 x86 天然失效** → 保守 gate 兜底 (regvm_backend.cpp:98-105), 行为差异非缺陷, 但文档需明示。
7. **CLI 无 arch 表达面**: config 无 arch 字段、无 --help 子命令 (实测), 32 位支持需要配置面扩口。

## §9 结论

✅ 推荐 **P2 (安全拒绝面) 先行**: 1 个 S 级派活单 (pe_loader PE32 修复 + x86 gate + 文档收口), 消除今天实测的"静默无操作"与"加载拒绝坏壳"两态; P1 全量 x86 按 §7 拆 6-8 单 backlog 排期, asmgen (XL) 为唯一关键路径。16-bit 目标判定不可行 (PE 格式白名单 + 生态无需求), 仅登记证据。

== MIT-G7r triage 完 ==
