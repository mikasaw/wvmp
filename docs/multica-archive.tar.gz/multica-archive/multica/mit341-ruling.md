# 项目主裁定: 采纳 MIT-341 verifier 报告 + 接受 MIT-339 (cmovcc 指令支持) + 沉淀 pitfall #37

## 总体评价

MIT-341 verifier 报告 (verifier 第 16 连实战) **接受** MIT-339 (commit `fea06dd` cmovcc 指令支持): **9 项全部通过** (含 capstone 反汇编独立验证 6 cmovcc variants 真字节 + protected `jmp 0xFAD0` 跳入 .wvmp 节替代原 cmovcc + pitfall #37 候选 T1 clobber via T6 save 注释验证 + additive enum append-only pitfall #34 验证 + 3 个 catch 全部真实可验证)。

verifier 独立 fresh verify 双重确认:
- ✅ Build 300/300 0 errors (verifier 独立复跑)
- ✅ Unit tests 15/15 全绿
- ✅ E2E cmovcc byte-exact (6 stubs, .wvmp 21538 bytes @ RVA 0xB000)
- ✅ multiseed 5×10 REQUIRE_REAL=1: 50/50 + 全真虚拟化 (含 cmovcc 5/5)
- ✅ Block C 阶段 1+2 零退化 (setcc/bswap/xchg/snake/imul/cl_shift 全部 BYTE-EXACT)
- ✅ Capstone 验证 native 6 cmovcc REG-REG (mod=3) 字节全部存在; protected 用 `jmp 0xFAD0` 跳入 .wvmp 节替代原 cmovcc, 真虚拟化已发生
- ✅ 代码核验: lifter 16 variants + translator translate_cmovcc + asmgen build_cmovcc + **T6 save (pitfall #37 候选)** 全部到位
- ✅ 冻结契约: 0 frozen header 改动, 仅 ir/include additive enum append-only
- ✅ **3 个 catch 全部真实可验证**: size/cond dual semantics, HOST FLAGS clobber via flags_=r10, T1 clobber for L/G/LE/BE/A via T6 save — 注释 (asmgen.cpp:1120) 已显式标记 pitfall #37 候选

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 实证** (9 项 + 3 项重点):
- capstone 反汇编独立确认 cmovcc codegen 真实存在 (6 cmovcc REG-REG mod=3 字节全部存在)
- **protected 用 `jmp 0xFAD0` 跳入 .wvmp 节替代原 cmovcc** — 真虚拟化已发生 (不是 C1 gate 兜底)
- **MASM helper rax 栈守恒 pitfall #36 验证**: T6 save (pitfall #37 候选) 全部到位
- **aditive enum append-only pitfall #34 验证**: Cmovcc=51 correctly appended after Setcc=50
- **three-layer integration 实证**: lifter 16 variants + translator translate_cmovcc + asmgen build_cmovcc + T6 save

**项目主 fresh verify** (本会话上一轮, MIT-339 ruling):
- HEAD `fea06dd` ✅
- native cmovcc stdout = `cmovcc e_eq=10 ne_eq=20 e_12=20 ne_12=10 b_12=10 g_12=20 l_12=10 ge_12=20 ge_55=10 b_neg=20` ✅
- fresh protect: 6 个入口 stub 生成, .wvmp 节 21538 字节 @ RVA 0xB000 ✅
- **protected cmovcc stdout == native cmovcc stdout** → **CMOVCC BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

## 🟢 1 项绿 (verifier 报, 非阻断, 沉淀 pitfall #37)

verifier 给绿点: agent 3 个 catch 全部**真实可验证** (vs 编造),且 pitfall #37 候选 (`T1 clobber for L/G/LE/BE/A via T6 save`) **在 asmgen.cpp:1120 显式注释标记** — 这是非常优秀的实现,verifier 沉淀 pitfall #37。

**项目主处理**: ✅ 沉淀到 wvmp-dev SKILL.md (pitfall #37 正式加入), 派活单派活单模板沿用。

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-339** | ✅ **done** | cmovcc 指令支持 (Block C 阶段 2 第 4 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 第 4 条 done ✅ (verifier 第 16 连实战接受, 阶段 2 推进, 4 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **49** (MIT-300 ~ `fea06dd`) |
| lifter 白名单 | **~44 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + **cmovcc 16 variants**) |
| 真虚拟化样本 | **15 个** (call_gate 系列 + rip_relative + sar/adc/sbb/rol/whitelist/virt + imul + cl_shift + snake + bswap + xchg + setcc + **cmovcc**) |
| ctest | **15/15** PASS |
| E2E byte-exact | **19/19** (含 cmovcc) |
| **E2E REQUIRE_REAL=1** | **19/19 真虚拟化** |
| multiseed 5×10 REQUIRE_REAL=1 | **50/50 真虚拟化** |
| **verifier 实战** | **16 连** (含 MIT-341 verifier 第 16 连实战接受 MIT-339) |
| wvmp-dev SKILL.md pitfall | **37 个** (本会话新增 pitfall #37 cond_eval clobber T1 寄存器) |

## 后续流水线

1. **立 Block C 阶段 2 第 5 条派活单** (movzx 8→16/16→64 / movsx / cmpxchg / popcnt 等)
 - 推荐下一条: **movzx 8→16/16→64** (cl_shift 已覆盖部分, 补全) 或 **cmpxchg** (原子, 有市场需求)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 37 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber T1 → T6 save**
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (verifier 第 16 连实战, 36 → 37 个 pitfall, MIT-339 v1 → v2 重新派遣模式)

### 关键沉淀 (本会话)

- ✅ verifier 第 16 连实战接受 MIT-339 (9 项 + 3 项重点核查全部 PASS)
- ✅ **pitfall #37** 正式加入 wvmp-dev SKILL.md (cond_eval clobber T1 寄存器, MIT-339 agent 主动披露 + verifier 注释验证 asmgen.cpp:1120)
- ✅ **MIT-339 v1 → v2 重新派遣模式实战**: 派活单派发后 agent 跑了 8 步就 completed (daemon 5 分钟 auto-termination), 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor), v2 跑了 44 分钟真完成 cmovcc 5/5 真虚拟化
- ✅ **3 个 catch 主动披露 (vs 编造)**: size/cond dual semantics + HOST FLAGS clobber via flags_=r10 + T1 clobber for L/G/LE/BE/A via T6 save (MIT-332/335/336/337/339 风格, vs MIT-322 编造)

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Cmovcc=51 之后 append-only)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337 实证)
- **asmgen `cond_eval` clobber 寄存器 (T1) — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **asmgen `dispatch cmp` clobbers HOST FLAGS — 用 `cond_eval` + bitwise assign** (MIT-339 实证)
- **asmgen `build_setcc`-style alias_write**: 8-bit 结果 dst 必须 alias_write 保护高 56 位 (MIT-337 实证)
- **size/cond dual semantics** (setcc 用 `cond` 字段, cmovcc 用 `cond_or_size=size + aux[31..28]=cond`, 沿用 MIT-337/339)
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only)
- 冻结契约核查

### 🟡 待办 (1 项, MIT-339 v1 → v2 重新派遣模式)

派活单派活后 agent 跑了 8 步就 completed (类似 MIT-326 v1 daemon 5 分钟 auto-termination):
- ❌ 派活单派发后 agent 跑太快 (1-5 分钟) 还没完成代码改动就 completed
- ✅ 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)
- ✅ 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"
- ✅ **新 pitfall #38 候选**: 派活单派发后 agent 跑了 8 步就 completed, daemon 5 分钟 auto-termination 模式 (MIT-339 v1 实证, 类似 MIT-326 v1 实证, 沿用 pitfall #29 重新派遣纪律)

---

## 引用链

- `m3-lifter-paihuo-10-issue-progression.md` (15 节点完整演进)
- `mit337-ruling.md` (setcc ruling)
- `mit338-ruling.md` (setcc verifier ruling, 接受)
- `mit339-ruling.md` (cmovcc ruling, 采纳 + 3 个 catch + pitfall #37 候选)
- `issue-39-mit339-verifier-instructions.md` (MIT-341 verifier 派活单)
- `issue-38-redispatch-note.md` (MIT-339 v1 → v2 重新派遣 note)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit339-cmovcc-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证, 本会话沉淀)
- **pitfall #38 候选** (本会话新增): 派活单派发后 agent 跑了 8 步就 completed, daemon 5 分钟 auto-termination 模式 (MIT-339 v1 实证, 沿用 pitfall #29 重新派遣纪律)