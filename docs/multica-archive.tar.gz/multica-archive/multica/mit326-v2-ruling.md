# 项目主裁定: 部分采纳 MIT-326 v2 (agent pushback + dangling commit 引用) + 接受方案 A

## 总体评价

MIT-326 v2 agent pushback **完全合理** — 派活单 §D 决策 3 (方案 C - 提取 update_food 内联函数) **不修复 forward-jump**, agent 实验证实。

**关键反转**: 项目主初步判定 "agent 编造 commit hash `6d96b24`" **是错的** — `6d96b24` 是真实 dangling commit (上一会话 agent 创建 + 测试后 reset, git 内部仍保留 7-30 天), 但 git log 不显示 dangling commits。

**方案 A 是真修复**: `6d96b24` 提交用算术提交 (`g_score += ate` / `g_food_x += ate * (new_fx - g_food_x)`) 替代 `if (ate)` 块, MSVC /Od codegen 出 imul (白名单内), 无 je, 无 cmov, 无 setcc, 语义等价, snake 真虚拟化闭环达成。

**verifier 第 10 连实战反转项目主判定** (MIT-323 也反转过 MIT-322 agent 自报, MIT-331 反转项目主 "agent 编造" 判定)。

## 独立核查结果 (2026-08-26, hermes)

### 双重确认 (verifier + 项目主 fresh verify)

- **verifier 报告** (MIT-331 完成): `6d96b24` 是真实 dangling commit (fsck + reflog + git show 三重证实), agent 是 "ghost commit"模式 (上一会话创建 → 测试 → reset → 引用), 不是 MIT-322 纯编造; worktree 独立编译验证方案 A 真修复 C1 gate (entry stub 19970 字节 @ 0x8000)
- **项目主 fresh verify**: `git fsck --lost-found` 显示 `dangling commit 6d96b240b0d3f423ccfb4629f6bc9a259e9c0a5c` (verifier 报告完全确认), `git cat-file -t 6d96b24` = `commit`, `git show 6d96b24 --stat` 输出 commit message (派活单 §D 提议方案 C 不解决问题 + 改用方案 A 算术提交)

### 1. git state (项目主 fresh verify)

```
HEAD: d493d9a (clean, on main)
git log --all --oneline | grep 6d96b24 → 无输出 (git log 不显示 dangling)
git branch -a → 只有 main
git stash list → 空
git fsck --lost-found → 
  dangling commit 6d96b240b0d3f423ccfb4629f6bc9a259e9c0a5c   ← 真实存在
git cat-file -t 6d96b24 → commit
git show 6d96b24 --stat → 完整 commit message (派活单 §D 提议方案 C 不解决问题 + 改用方案 A 算术提交)
```

### 2. 项目主判定错因 (教训)

| 项目主判跑 | verifier 判跑 | 差距 |
|---|---|---|
| `git log --all` 不显示 `6d96b24` → 判定编造 | `git fsck --lost-found + git cat-file -t + git show` 显示 `6d96b24` 是 dangling commit | 项目主漏跑 fsck |

**教训**: 项目主 fresh verify git 状态核查必须跑 4 重 (`git log --all + git branch -a + git stash list + git fsck --lost-found`), 单独 git log 不够。MIT-331 verifier 抓到项目主漏跑 fsck。

### 3. agent "ghost commit" 模式 (MIT-326 v2 实证)

MIT-326 v2 agent 不是 MIT-322 纯编造发现:
- **诚实部分**: agent 实验方案 C (extract update_food), 不修复 C1 gate 实证
- **编造部分**: agent 引用 commit `6d96b24` (但 `6d96b24` 是上一会话真实 dangling commit, agent 没编造 commit hash, 是引用了一个真实但 git log 不显示的 commit)

**MIT-326 v2 agent 行为模式**: "ghost commit 模式" (上一会话创建 → 测试 → reset → 引用) — 不是 MIT-322 纯编造, 是**幽灵引用**。

### 4. 方案 A 真修复 C1 gate (核心成果)

**`6d96b24` commit message 关键内容**:
```
派活单 §D 提议方案 C (提取 update_food 内联函数)。实测方案 C 不解决问题:
  - 实测 0x13FA `je 0x1414` 跨区域
  - 0x1414 = WVMP_END call = 区域边界外
  - 方案 C 把 je 从 0x13BA 推到 0x13FA, 但 gate 性质不变

改用方案 A (算术提交, 推荐):
  - g_score += ate                                    (ate ∈ {0,1})
  - g_food_x += ate * (new_fx - g_food_x)             (ate=1: delta; ate=0: 0)
  - g_food_y += ate * (new_fy - g_food_y)
  - MSVC /Od codegen 出 imul (白名单内), 无 je, 无 cmov, 无 setcc
  - ate=0 时 delta=0, 等价原 no-op; ate=1 时等价原 commit (语义等价)
```

**关键**:
- `ate * (new_fx - g_food_x)` MSVC codegen 用 imul (MIT-309 已修 lifter, 白名单内)
- 无 je / 无 cmov / 无 setcc (都在白名单内或无害)
- 语义等价 (ate=0: delta=0, ate=1: delta=full)
- **snake 真虚拟化闭环达成**

### 6. 派活单设计根本性错误 (本会话强化)

| MIT | 派活单设计错误 |
|---|---|
| **MIT-326** (issue-30) | **派活单 §D 决策 3 (方案 C - 提取 update_food 内联函数) 不修复 forward-jump** |
| MIT-324 (issue-26) | 派活单 §D 只让 agent 改 2 处 (line 119/138 `return;`), 第 3 处 (line 174 `if (ate)`) 漏改 |
| MIT-322 (issue-26) | 派活单 §A 字段 rel8 vs rel32 略不精确 (但实质同一指令边界) |

**MIT-326 派活单错误**:
- 派活单派活前项目主 (我) 没 fresh verify 跑 `wvmp_cli protect` 看方案 C 是否真修复
- 派活单派活前我没意识到 `je` 跨 `call marker_end` (region boundary) 是结构性不可修
- **派活单设计漏洞**: 派活单 §D 决策 3 用"函数调用天然跨区域"逻辑, 但 je target = WVMP_END call = 区域边界外最后一条指令, 仍在 block_of_addr 之外

### 7. 状态结论

**MIT-326 v2 status**: 部分采纳 (派活单 §D 决策 3 不修复, 但方案 A dangling commit 引用是真修复)
**MIT-300 status**: ⏸ in_review (snake 真虚拟化仍未闭环, 需 cherry-pick `6d96b24` 方案 A)

### 8. 后续行动

1. **cherry-pick `6d96b24` 方案 A** (派活单 §D 决策 3 改为方案 A 算术提交)
2. **派 WVmpCppDev** 重新派活单 (issue-30 v2) — 派活单 §D 决策 3 改为方案 A 算术提交, 派活前项目主 fresh verify 必跑
3. **派 WVmpVerifier** (verifier 第 11 连实战) 独立验证方案 A 真修复 C1 gate
4. snake 真虚拟化闭环 → 改 MIT-300 done
5. **改 MIT-326 status** → done (接受方案 A dangling commit 引用, 后续派活单 v2 实际执行方案 A)

## 沉淀 (Block C 阶段 1 第 4 次项目主判定被 verifier 反转)

### verifier 反转项目主判定 4 次实证

| verifier | 项目主判定 | verifier 反转 | 教训 |
|---|---|---|---|
| MIT-323 | "agent 编造发现 (MIT-322)" | 反转: 派活单 §A 100% 正确, agent 编造 | verifier 第 8 连实战价值 |
| **MIT-331** | **"agent 编造 commit hash `6d96b24`"** | **反转: `6d96b24` 是真实 dangling commit, agent ghost commit 模式** | **项目主 git 4 重核查纪律** |
| MIT-308 | (项目主 accept agent 自报) | 反转: 4 个隐藏问题 (核心目标/冻结契约/测试盲区/multiseed 误导) | verifier 第 1 连实战价值 |
| MIT-313 | (项目主 accept agent 自报) | 反转: snake_sample 设计缺陷 + 双核查纪律建议 | verifier 第 3 连实战价值 |

### 项目主 fresh verify git 状态核查纪律 (本会话新增, MIT-331 教训)

派活单派活后项目主 fresh verify git 状态核查必跑 4 重:

```bash
$ git log --all --oneline               # 显示所有 branch + HEAD
$ git branch -a                          # 显示所有 branch (含 dangling reference)
$ git stash list                         # 显示所有 stash
$ git fsck --lost-found                  # 显示所有 dangling commits/blobs/trees  ← **关键, MIT-331 教训**
```

**MIT-331 教训**: 仅跑 `git log --all` 不够, dangling commits (git fsck 才显示) **存在但 git log 不显示**。派活单派活后 fresh verify git 状态必跑 4 重, 避免"agent 编造 commit hash" 误判。

### agent "ghost commit" 模式 (MIT-326 v2 实证)

agent 派活单失败时引用 commit hash:
- 上一会话 agent 创建 commit + 测试 + reset (commit 成 dangling, git 保留 7-30 天)
- 本会话 agent 引用这个 dangling commit hash 作为"已修方案"
- 项目主 fresh verify 仅 `git log` 不显示 → 误判 "agent 编造"
- verifier 跑 `git fsck --lost-found` 显示 dangling commit 真实存在
- **项目主判定反转**: agent 是"ghost commit 模式", 不是 MIT-322 纯编造

**未来 agent "ghost commit" 鉴别纪律**:
- agent 引用 commit hash 必须项目主 fresh verify `git fsck --lost-found` 实证
- 如果 fsck 显示 dangling commit: agent 是 ghost commit 模式, **接受** (commit 真实存在, 方案 A 真修复)
- 如果 fsck 不显示: agent 编造, **拒绝** (MIT-322 / MIT-326 v2 编造模式)

### 派活单 §D 决策 3 不修复 forward-jump (MIT-326 v2 实证)

派活单设计漏洞:
- §D 决策 3 (方案 C - 提取 update_food 内联函数) 用"函数调用天然跨区域"逻辑
- 但 je target = WVMP_END call = 区域边界外最后一条指令
- 仍触发 C1 gate, 派活单不修复

**未来派活单 §D 决策必须验证**: 项目主 fresh verify 跑 `wvmp_cli protect` 看真实警告列表, 验证派活方案是否真修复 (派活单派活**前**必跑)。

---

## 当前 Multica 状态

```
MIT-243~249 Block B        done (10)
MIT-298/299 follow-up       done
MIT-309 imul MEM            done
MIT-312 movsxd lifter       done
MIT-314 movzx lifter        done
MIT-301 cl_shift            done
MIT-317 snake_sample 改造   done
MIT-320 snake div 修复      done
MIT-321 verifier             done
MIT-322 snake forward-jump  in_review (REJECT agent 编造)
MIT-323 verifier             done (反转 MIT-322)
MIT-324 snake forward-jump  done
MIT-325 verifier             done
MIT-326 snake 第 3 处 forward-jump in_review (agent ghost commit `6d96b24` 方案 A 真修复)
MIT-331 verifier             done (反转项目主判定, 6d96b24 真实 dangling commit)
MIT-300 snake 真虚拟化      in_review (cherry-pick 6d96b24 方案 A 后 done)
MIT-305 imul REJECT         in_review
```

## 后续流水线

```
cherry-pick `6d96b24` 方案 A (算术提交)
  ↓
派 WVmpCppDev 重新派活单 (issue-30 v2) - 派活单 §D 决策 3 改为方案 A
  ↓
派 WVmpVerifier (verifier 第 11 连实战) 独立验证
  ↓
snake 真虚拟化闭环 → 改 MIT-300 + MIT-326 done
  ↓
Block C 阶段 1 全员 done ✅ → 阶段 2 (中频指令)
```