# MIT-415 (G3) + MIT-416 (G5r) 合并裁定 — 双 ACCEPT；416 揪出全项目首例"静默坏壳"级 P0（项目主独立复现成立）

> 裁定人: 项目主 — 2026-08-30 00:4x | 基线影响: main = `fa08d50` (415 直提), multiseed **170/170** (34 样本)

# 裁定 A: MIT-415 (G3 串指令族) — ACCEPT 内容 / 形态违规登记

## A.1 独立复验 (@main fa08d50 全链实测)
| 项 | 自报 | 实测 |
|---|---|---|
| build/ctest/multiseed | 170/170 | ✅ rc=0 / 16/16 / **TOTAL: 170 pass / 0 fail** (34 样本×5) |
| 新样本真虚拟化 | 7 stub + string-op note×7 | ✅ 亲跑 protect: **stub=7 + note×7** + packed/native **stdout 全等 rc 等** |
| 零回踩 wvmpTest | 14/14 原样 | ✅ stubs=14 + jump-table `@0xDD84 entries=8 reg-4B-delta` 原样 + ExitNative 17 + **双跑 103/103 diff 0** + wvmpTest 区 string-op 误报=0 (三元组白名单精度证据) |
| D1 零 DF 位冻结面 | kFlagsMask/runtime.hpp/ir::Op 零触碰 | ✅ diff 文件面核实 (lifter/translator/backend/样本/测试/文档) |
| 413 纪律执行 | string-op note 进过滤白名单对账 | ✅ backend 白名单含 `string-op @` (命中不触发 gate), 上一单教训 40 分钟内落地 |

## A.2 #33 三处实测推翻（全部合格且高价值）
1. **repnz 早退副作用**: SDM 不回滚终止迭代 → 早退出口同样推进指针/计数 (strlen `lea rax,[rdi-1]` 惯用法同证)——**我派单 §B.4 设计的 `lock rep movsb` E2E 负例被实测判不可执行 (F0 F3 A4 原生 #UD)**, 降为 lifter 单测覆盖, 派单方设计错误被推翻 (406/D2 先例家族, 第 N 次)
2. **capstone REX.W 缺陷**: `48 F3 A5` 误读 dword, Q 形按字节流含 REX.W 修正 (popcnt 同纪律)
3. 微程序 flags 保全/末次比较恢复路径用单测逐断言固化

## A.3 ⚠️ 形态违规: main 直提
交付 = commit `fa08d50` **直接落在 main**, 无独立分支 (报告自称"单分支 ff-safe"——把 main 当分支的口径不成立)。后果: 验收流程被先斩后奏 (若复验红则 main 需 reset)。处置: **本次全绿实测通过, 不回滚 (回滚负生产力), 违规登记本裁定 + 工单评论; 新硬条款入后续派单**: "交付 commit 必须落 main 之外的命名分支, main 只接受项目主 ff-merge; 违者一票否决退回重交"。

# 裁定 B: MIT-416 (G5r x87 侦察) — ACCEPT, 质量并列 D1/G7r 最高档

## B.1 复验
- triage 139+ 行全读, 频率数字带样本集/方法/反例 (26 真实二进制+30 探针, 点检 4/4 伪影剔除)
- **§A 先验两处被推翻 (合格, #33)**: ② volatile/O1 无 x87 涌出 (全矩阵 0–2.2%); ③ "x86 浮点必走 x87" 过时——v145 x86 **默认 /arch:SSE2**, x87 集中在 OS 运行时/CRT/msys
- 时间对账 57 分钟合规 (412 教训吸收✅); 并发披露: 主工作区未扰动✅
- ⚠️ 小瑕疵: 留样目录 %TEMP%\mit416_x87 已空 (证据不可原样复跑), 但 P0 主张由项目主**独立重建复现** (下节), 证据链闭环不依赖 agent 留样

## B.2 🚨 P0 新缺陷 — 项目主独立复现成立 (本裁定最高潮)
自建 noinline SSE FP callee 样本 (fp_add/fp_mul 带 double 参): 原生 `fp_sum=15.00 last=7.00 rc=0` → protect 1 stub 真虚拟化 → packed **`fp_sum=3.00 last=2.00 rc=1` 静默错乱**。根因代码直读证实: `asmgen.cpp:1189-1265` callgate step0/5 只搬 RCX/RDX/R8/R9 (ctx+0x18/0x20/0x48/0x50), step10 只回写 `[ctx+0x10]` RAX——**xmm0..3 零触碰**。
**定性: 这是本项目第一个"gate 哲学之外"的静默坏壳面**——此前所有缺口 (C1-C5/G1-G7) 最坏行为=保守 gate 保持原生; callgate FP 是"真虚拟化后行为错且无告警", 严重度高于全清单。为何 165/170 样本从未抓到: 所有既有 callgate 样本 (bswap/rol/sha256/deepcall) 恰好全整型参数——**回归盲区**, 416 补上。
且非新引入: 该缺口与 callgate 同寿 (GAPS C3 仍 pre-M2-9 旧文), 属历史债务被侦察照亮。

## B.3 路线裁决采纳 (项目主拍板 2026-08-30)
- **P0 (callgate FP 修复) → 立即派单 MIT-417** (asmgen 级, 我项目主简化方案见派单 D1: 无条件 ctx.xmm[0..3]→物理入 + xmm0→ctx 回, **零 aux 改动** — 416"translator 传 FP aux"预判可能被更简方案推翻, 授权实测择优)
- **R3 (文档化+gate 回归样本) → 并行派单 MIT-418** (S 级)
- **R2 挂 G7 P1 捆绑评估** ✅; **R1 不排波蓝图留档** ✅ (x64 频率 ≈0 数字支撑)
- 新耦合 #2 跳表容量 (128 项已用 80, x87 全族会撑爆→需扩 256) 入 G 计划 W6 前置; #3 fldcw 0x27F 降精度、#4 /arch:SSE2 分档、#5 _controlfp 走 MXCSR 全部登记

# 3. 处置与战线
1. 415 保留 main=fa08d50 (不回滚), 违规评论上单; 416 done+裁定上单; 双单 done
2. **multiseed 基线 = 34 样本 170/170**
3. 417/418 并行派发 (417 改面 asmgen+callgate 测试, 418 改面 GAPS/STATUS+新 MASM 样本文件, multiseed 行若冲突收口方按堆叠序 rebase——413/414 先例)
4. 416 复现样本 %TEMP%\g5r_p0\ (fp_caller.cpp/build.bat/fp.toml) 保留作 417 验收反证基线: 修复前必错 (3.00/rc1), 修复后必对 (15.00/rc0), **项目主亲手用固定样本复跑, 不采信单方粘贴** (406 铁律)
