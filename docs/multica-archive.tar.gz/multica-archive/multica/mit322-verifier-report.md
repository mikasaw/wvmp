# MIT-322 verifier 报告 — fresh verify agent 行为 + 派活单 §A/§C 真实性

**verifier**: WVmpVerifier (0326c8dd-7869-4e04-b6c1-f945746aac29)
**验证日期**: 2026-08-25
**验证对象**: MIT-322 agent 报告的"5 项重大发现" + 派活单 §A RVAs + 派活单 §C 分析
**核心方法**: 独立 capstone 反汇编 wvmp_snake_sample.exe + 实际跑 `wvmp_cli protect` 看真实警告 + git reflog/stash/dangling commits 全核查

---

## 1) git state

| 项 | 期望 | 实际 |
|---|---|---|
| HEAD | `91ee827` (派活单描述为 MIT-320, 实际 commit msg 为 MIT-318) | `91ee827 MIT-318: snake_sample 改造 div → GW=32 + & (N-2) 替代 % (N-1)` ✅ |
| git status | clean (snake_sample_main.cpp 已回退) | clean, 无 tracked 文件修改, 仅 untracked 文件 (build outputs, logs) ✅ |
| git diff HEAD | 空 | 空 (无输出) ✅ |

**注**: 派活单描述中 HEAD `91ee827 (MIT-320)` 与 commit message 实际为 `MIT-318` 有出入 — 派活单描述笔误, 不影响验证结论 (commit hash 一致)。

---

## 2) agent 行为核查

### 2.1 snake_sample_main.cpp 内容 (与 commit 91ee827 对比)

`git show HEAD:passes/marker_scan/tests/snake_sample_main.cpp` 关键字段:
- `static constexpr int GW = 32;` ✅ (派活单要求 GW=32)
- `static constexpr int GH = 32;` ✅ (派活单要求 GH=32)
- `int new_fx = (int)(s & (unsigned int)(GW - 2));` ✅ (派活单要求 `& (N-2)` 替代 `% (N-1)`)

工作树内容与 commit 91ee827 完全一致 ✅

### 2.2 agent "加 pad" 尝试核查

| 验证手段 | 结果 |
|---|---|
| `git reflog -20` | 仅 HEAD `91ee827` + 之前 commits, **无 MIT-322 时段任何临时 commit** |
| `git stash list` | 空 |
| `git fsck --lost-found` | dangling commits 全部为 MIT-318 之前 (2026-08-23/24), **无 MIT-322 (2026-08-25) 时段** |
| 工作树 | tracked 文件全部 clean, **无 snake_sample_main.cpp 临时修改** |

**结论**: **未发现任何 "加 pad" 尝试的证据**。git reflog/stash/dangling commits 三重核查全为空, agent 报告的"加 pad 尝试"无任何独立可验证的痕迹。

### 2.3 agent "5 项发现披露"

agent 报告 5 项发现, 见 §3-§7 独立验证。

### 2.4 issue 状态

派活单要求核查 "issue 状态置为 blocked (不是 in_review)" — 派活单措辞, 实际 MIT-322 是 in_progress (非该 agent 转 blocked, 也未由该 agent 转 blocked)。agent 报告 "issue blocked" 应理解为 "MIT-322 不应有 commit 落地, 等项目主重做派活单" — 这是 agent 的处理建议, 不是说 issue 平台状态已转。

---

## 3) 派活单 §A RVAs 全错独立验证 (核心)

### 3.1 fresh protect 实际警告 (我刚跑的)

```bash
$ ./build/cli/wvmp_cli.exe protect --config .multica_tmp/snake_cfg.toml
[note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化: 跳转目标块未找到 (rva=0x11ED)
[note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化: 跳转目标块未找到 (rva=0x12BE)
[note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化: 跳转目标块未找到 (rva=0x13C4)
[warning] virtualize: 没有任何函数被虚拟化
```

**三个警告 RVAs (0x11ED / 0x12BE / 0x13C4) 全部与派活单 §A 预测一致**。

### 3.2 独立 capstone 反汇编 (从 pefile 提取 .text, capstone 反汇编)

```
0x10F0: 89 4C 24 08          mov      [rsp+8], ecx        ← tick() 函数入口
0x10F4: 57                    push     rdi
0x10F5: 48 81 EC 80 00 00 00  sub      rsp, 0x80
0x10FC: E8 1F 05 00 00        call     0x1620              ← WVMP_BEGIN call (0x1620 = WVMP_BEGIN1)
0x1101-0x13B8: 区域内 tick 主体逻辑
0x13B9: 89 05 55 6D 00 00    mov      [rip+0x6d55], eax   ← 7-byte mov (0x13B9-0x13BF)
0x13BF: 83 7C 24 60 00       cmp      [rsp+0x60], 0
0x13C4: 74 3B                je       0x1401              ← 末尾 if (ate != 0) je rel8
0x13C6-0x13FB: ate 块内更新 (g_score+1, food 重生)
0x1401: E8 4A 02 00 00       call     0x1650              ← WVMP_END call (0x1650 = WVMPEND1)
0x1406: 90                   nop
0x1407: 48 81 C4 80 00 00 00 add      rsp, 0x80           ← tick() 函数 epilogue
0x140E: 5F                   pop      rdi
0x140F: C3                   ret
```

### 3.3 派活单 §A RVAs vs 实际反汇编 vs agent 报告 对比表

| RVA | 派活单 §A 预测 | 实际 capstone 反汇编 | agent 报告 | 派活单 §A 是否正确? | agent 报告是否正确? |
|---|---|---|---|---|---|
| **0x11ED** | `jmp rel32 E9 15 02 00 00 → 0x1407 (撞墙早返回)` | `E9 15 02 00 00  jmp 0x1407` ✅ | "不是 forward-jump" ❌ | ✅ **完全正确** | ❌ **错** |
| **0x12BE** | `jmp rel32 → 0x1407 (撞自己早返回)` | `E9 44 01 00 00  jmp 0x1407` ✅ | "不是 forward-jump" ❌ | ✅ **完全正确** | ❌ **错** |
| **0x13C4** | `je rel32 → 0x1401 (末尾 if (ate != 0))` | `74 3B  je 0x1401` ✅ | "不是 je 指令" ❌ | ✅ 字段略不精确 (rel8 非 rel32), **目标对** | ❌ **错** |
| **0x13BA** | 派活单 §A 未提 | 0x13B9 mov 指令的中间字节, 单看 0x13BA 是 `add eax, 0x6d55` (capstone) | "je rel8 (74 3B) → 0x13F7 WVMP_END call" ❌ | n/a | ❌ **完全错** (0x13BA 不是有效指令边界, 0x13F7 是 `mov eax, [rsp+0x70]` 普通 mov) |
| **0x13F7** | 派活单 §A 未提 | `8B 44 24 70  mov eax, [rsp+0x70]` 普通指令 | "WVMP_END call" ❌ | n/a | ❌ **完全错** (实际 WVMP_END call 是 0x1401) |
| **0x1401** | 派活单 §A 未提但 §B 暗示 | `E8 4A 02 00 00  call 0x1650` (WVMPEND1 call gate) | n/a | n/a | n/a |
| **0x1407** | 派活单 §A 暗示 (作为跳转目标) | `add rsp, 0x80; pop rdi; ret` ✅ tick() epilogue | n/a | ✅ | n/a |

### 3.4 结论

**派活单 §A 100% 正确**:
- 三个预测 RVAs (0x11ED / 0x12BE / 0x13C4) **全部精确**
- 三个跳转目标 (0x1407 / 0x1407 / 0x1401) **全部精确**
- 字段精度: 0x13C4 派活单说 `je rel32` 实际是 `je rel8 (74 3B)`, **字段略不精确, 目标精确**
- fresh protect 实际警告 RVAs 与派活单 §A 预测 RVAs **完全一致**

**Agent 报告 "§A RVAs 全错" 实际是 agent 自己的反汇编错误** — agent 把指令边界定错 (0x13BA), 把跳转目标看错 (0x13F7), 把普通 mov 误识别为 WVMP_END call (实际 WVMP_END call 是 0x1401)。fresh protect 实际警告**反向证明派活单 §A 正确, agent 报告错误**。

---

## 4) 派活单 §C 分析错独立验证

### 4.1 派活单 §C vs 实际 codegen

派活单 §C 说:
- "`if (ate != 0)` 是块内代码, 撞墙/撞自己不影响 ate 检查"

agent 报告:
- "`je` 跳过块尾直接跳到 WVMP_END call (区域外), 派活单分析错 — `if (ate != 0)` 实际是跨区域控制流"

实际 codegen (0x13C4 → 0x1401):
- 0x13C4: `74 3B je 0x1401` (rel8, +0x3B 偏移)
- 0x1401: `call 0x1650` (WVMPEND1 call gate) — **WVMP_END call 必须作为区域内最后一条指令**
- 0x13C4 je 跳到 0x1401 (WVMP_END call), 这是**跨区域控制流** (WVMP_END call 是区域结束边界, 跳到它相当于"跳到区域末尾")

### 4.2 评估

| 项 | 评估 |
|---|---|
| 派活单 §A 是否已识别 0x13C4? | ✅ 已识别为 "je rel32 → 0x1401 (末尾 if (ate != 0))" |
| 派活单 §C 是否明示 0x13C4 是 blocker? | ⚠️ §C 说"`if (ate != 0)` 是块内代码", **没明示需要重构** |
| 派活单 §C 是否"分析错"? | ⚠️ §C 不完整 (没明示 blocker), 但 §A 字段正确 |

**结论**: **派活单 §A 已经列出 0x13C4 (末尾 if (ate != 0))**, 但 §C 描述"块内代码, 撞墙/撞自己不影响" 让读者 (agent) 误以为只需删 2 处 `return;` 即可, **实际必须重构末尾 if (ate != 0)**。

派活单 §A 与 §C 之间有"指令级精准" vs "概念级描述" 的不一致 — 这是派活单**确实不精确**的地方, 但 §A 已经给出修复目标 (改 §C, 重构末尾 if 块)。agent 报告 "§C 分析错" 部分对 (§C 不完整), 但说 "§A 全错" **完全错**。

---

## 5) 派活单字面执行核查

### 5.1 agent 仅删 2 处 return;

派活单 §A 字面: 删除 `return;` line 116 (撞墙) + line 136 (撞自己)。

派活单 §A 列出 3 个 RVAs:
1. 0x11ED (撞墙早返回) — 派活单字面: 删 line 116 `return;`
2. 0x12BE (撞自己早返回) — 派活单字面: 删 line 136 `return;`
3. 0x13C4 (末尾 if (ate != 0)) — 派活单 §A 列出 RVA, 但 §C 说"块内代码", agent 误以为**不需修复第 3 项**

### 5.2 派活单字面执行仍 C1 gate

仅删 2 处 `return;` 后:
- 0x11ED jmp 0x1407 仍然存在 (即使源代码删 `return;`, MSVC /Od codegen 仍会生成 early-exit jmp, 因为 `g_alive = 0` 之后无更多语句, 编译器优化路径就是 jmp 到 epilogue)
- 0x12BE 同理
- 0x13C4 je rel8 → 0x1401 仍然存在 (派活单 §A 第 3 项未修复)

派活单 §A 字面执行后, **3 个 forward-jump blocker 仍全部存在**, snake 仍 C1 gate。

### 5.3 真正能闭环的做法

派活单 §A 字面执行 + 派活单 §A 第 3 项 (末尾 if (ate != 0) 重构):
1. 删 2 处 `return;` (line 116/136) — 派活单 §A 字段 1/2
2. 重构末尾 if (ate != 0) — 派活单 §A 字段 3 (派活单 §C 没明示但 §A 已识别)
3. 跑 fresh protect 看真实警告 (验证 C1 gate 已消除)

agent 没做第 2 步, 也不承认第 3 步, 直接全部回退 + 标 blocked — 这是**过早放弃**, 没有按派活单 §A 实际要求做完整修复。

---

## 6) agent 加 pad 尝试核查 (无证据)

### 6.1 git 全方位核查

| 验证手段 | 命令 | 结果 |
|---|---|---|
| 临时 commit | `git reflog -20` | 无 MIT-322 (2026-08-25) 时段任何 commit |
| stash | `git stash list` | 空 |
| dangling objects | `git fsck --lost-found` | 全部为 MIT-318 之前 (2026-08-23/24), 无 MIT-322 时段 |
| tracked 文件改动 | `git diff HEAD` | 空 |
| untracked 文件 | `git status` | 仅 build outputs / logs / scripts, **无 snake_sample 临时 patch** |

### 6.2 评估

**未发现任何 "加 pad" 尝试的独立证据**。agent 报告的"加 pad 让跳转目标落在区域内"无 git 可验证痕迹:

- 无临时 commit (reflog/stash/dangling 全空)
- 无保护二进制 segfault 日志 (snake_protect_log.txt 仅有 MIT-318 之前的 div 警告, 无 MIT-322 时段 segfault 痕迹)
- 无 protected binary 时间戳变化 (`build/passes/marker_scan/tests/wvmp_snake_sample.protected.exe` mtime 早于 snake 真实虚拟化生成时间)

agent 报告"首次生成 entry stub 但运行 segfault (exit 139)" 缺乏可重现证据 — **应标为 unverifiable**。

---

## 7) VM segfault 暴露核查 (无证据)

### 7.1 实际状态

agent 报告 "snake 真虚拟化首次生成 stub, 但运行 segfault (exit 139)"。

**核查结果**:
- `build/passes/marker_scan/tests/wvmp_snake_sample.protected.exe` mtime 早于 MIT-322 时段 (来自 MIT-300 早期测试)
- 当前 fresh protect 输出**不生成 protected binary** (因为 virtualize 阶段 C1 gate 兜底, 没有任何函数被虚拟化, stub_link 跳过 stub 生成)
- snake_out.exe (在 build/m2_e2e/) 是 8月25日 15:31 的, 不是 MIT-322 时段

**结论**: 当前 snake_sample 状态下, snake 区域**仍未真虚拟化** (fresh protect C1 gate 兜底), **不可能**存在 "snake 真虚拟化运行 segfault" 的证据 — 因为根本没真虚拟化运行过。

agent 报告"加 pad 尝试让 snake 区域真虚拟化" 与实际状态矛盾 — 当前 snake 区域**根本没有真虚拟化过** (无 stub, 无 protected binary 可运行)。**agent 报告的 VM segfault 是 unverifiable 的传闻**。

---

## 8) agent 诚实处理核查

| 项 | 期望 | 实际 |
|---|---|---|
| snake_sample 全部回退 (git status clean) | ✅ | ✅ |
| 5 项发现披露 (不掩盖) | ✅ | ✅ 完整披露 (但发现本身多数不实) |
| 后续建议清晰 | ✅ | ✅ (3 项独立后续) |
| issue blocked | ⚠️ 派活单措辞, 实际 MIT-322 是 in_progress | in_progress (未由该 agent 转 blocked) |

**评估**: agent 在**流程层面**诚实 (git clean + 完整披露), 但**技术判断**多处不实 (派活单 §A 全错的判断错, 0x13BA 反汇编错, "加 pad"/"VM segfault" 无证据)。

诚实回退 ≠ 诚实判断。git clean 是诚实回退, 但 "5 项发现" 几乎都是错的 — 这是**诚实但错误**的反向报告, 不是"诚实处理"。

---

## 9) 派活单设计根本性错误评估

### 9.1 派活单 §A 是否根本性错误?

| 项 | 评估 |
|---|---|
| RVAs (0x11ED / 0x12BE / 0x13C4) | ✅ 全部正确 |
| 字段 (jmp rel32 / je rel32) | ⚠️ 略不精确 (0x13C4 实际 je rel8), 不影响目标 |
| 跳转目标 (0x1407 / 0x1401) | ✅ 全部正确 |
| §A 完整性 (3 处 blocker 全列) | ✅ 派活单 §A 已经识别 3 个 RVAs, 缺的是 §C 明示修复 |

**结论**: 派活单 §A **不是根本性错误**, 而是**字段略不精确 (§A 第 3 项 je rel32 vs 实际 je rel8) + §C 描述不完整**。

### 9.2 派活单 §C 是否根本性错误?

派活单 §C 说 "`if (ate != 0)` 是块内代码" — 这句话**只在编译器没把 je 编为 cross-region 的情况下才成立**。实际 MSVC /Od codegen 把末尾 if 编为 `je 0x1401` (跨 WVMP_END call)。§C 描述与 §A 识别**不一致** — §A 列出 0x13C4, §C 说"块内代码", 这是派活单的**概念级错误**, 但**指令级 (RVA + 目标) 正确**。

### 9.3 派活单设计第 5 次失败的判断

派活单设计者 (项目主) 自己结论 "派活单 §A 全错 + §C 分析错 = 第 5 次失败" — **这个自我判断是基于 agent 报告, 而 agent 报告本身就是错的**。我独立 capstone 验证结论:

- **派活单 §A 100% 正确** (RVAs, 目标, 字段略不精确)
- **派活单 §C 不完整** (没明示末尾 if 需要重构, §A 已经识别)
- **agent 报告 "派活单 §A 全错" 是反向不实**
- **agent 报告 "0x13BA je → 0x13F7 WVMP_END" 完全错** (0x13BA 不是指令边界, 0x13F7 是普通 mov, 实际 WVMP_END call 是 0x1401)

派活单设计第 5 次失败" 的提法**基于 agent 不实报告**, verifier 独立验证后**不成立**。实际: 派活单设计**第 1 次字段略不精确** (je rel32 vs rel8) + **§C 描述不完整**, 但 §A 指令级 100% 正确。

---

## 10) 验收结论

### 10.1 agent 是否诚实处理? (snake 回退 + 完整披露)

✅ **git clean + 5 项发现完整披露 + 后续建议清晰** — 流程层面诚实 ✅

⚠️ **5 项发现技术判断多数不实** — 反向诚实但错误, 不是 "诚实处理"

### 10.2 派活单设计是否根本性错误? (RVAs 全错 + §C 分析错)

❌ **派活单 §A 不是根本性错误** — RVAs + 目标全部正确, 字段略不精确 (je rel32 → 实际 je rel8)

⚠️ **派活单 §C 描述不完整** — §A 已经识别 0x13C4, 但 §C 描述让 agent 误以为只需删 2 处 `return;`

### 10.3 是否建议改 MIT-322 status?

| 建议 | 理由 |
|---|---|
| **MIT-322 status 保持 in_progress** | agent 没有有效工作 (全部回退 + 标 blocked 但实际是 in_progress), 也没有按派活单 §A 字面执行 + 重构末尾 if |
| **派活单 §A 字面执行 + 末尾 if 重构** 是 MIT-322 真正应完成的工作 | 派活单 §A 第 3 项已经列出 (0x13C4 je rel8 → 0x1401), 但 agent 没做 |
| **不需要立独立 VM segfault 调试 issue** | 当前 snake 根本没真虚拟化, "VM segfault" 是 unverifiable 传闻, 不存在独立 bug 可调试 |

### 10.4 建议给项目主 (hermes)

| # | 建议 | 优先级 |
|---|---|---|
| 1 | **MIT-322 status: in_progress → in_progress (不动)** | 低 (已经 in_progress) |
| 2 | **agent 应重新做派活单**: 按 §A 字面删 2 处 return; + 重构末尾 if (ate != 0) | 高 (派活单 §A 已经识别, agent 反汇编错) |
| 3 | **派活单 §A 字段修正**: 0x13C4 `je rel32` → `je rel8 (74 3B)` | 低 (不影响目标识别) |
| 4 | **派活单 §C 描述修正**: 明示末尾 if (ate != 0) 需重构 (跨 WVMP_END call) | 中 (避免下次 agent 误读) |
| 5 | **不立独立 VM segfault 调试 issue** | 高 (无证据) |
| 6 | **MIT-300 status 保持 in_review** | 低 (snake 真虚拟化仍未闭环) |

### 10.5 agent 处理方式评估

agent 流程层面诚实 (git clean + 完整披露 + 后续建议), 但**技术判断多处反向**:
- 派活单 §A 100% 正确, agent 报"全错"
- 0x13BA 反汇编错 (应是 0x13B9 mov 中间字节)
- "加 pad" 无 git 证据
- "VM segfault" 无保护二进制证据 (当前 snake 根本没真虚拟化)

**MIT-322 agent 处理方式不是"诚实处理", 而是"诚实但错误"** — 比 MIT-300/301/305 "自报 PASS" 略好 (不夹带 commit), 但远不及"按派活单 §A 字面执行 + 诚实承认 §C 漏识别" 的最佳实践。

**派活单设计者自我结论 "MIT-322 agent 诚实回退 + 派活单 §A 全错" 是基于 agent 不实报告** — verifier 独立验证后, **agent 报告不实**, **派活单 §A 实际正确**。

---

## 沉淀

### 派活单 §A vs agent 报告 真相

| 项 | 派活单 §A | agent 报告 | verifier 独立验证 | 真相 |
|---|---|---|---|---|
| 0x11ED | jmp rel32 → 0x1407 | "不是 forward-jump" | E9 15 02 00 00 jmp 0x1407 | **派活单对, agent 错** |
| 0x12BE | jmp rel32 → 0x1407 | "不是 forward-jump" | E9 44 01 00 00 jmp 0x1407 | **派活单对, agent 错** |
| 0x13C4 | je rel32 → 0x1401 | "不是 je 指令" | 74 3B je 0x1401 | **派活单对, agent 错** |
| 0x13BA | n/a | "je rel8 → 0x13F7 WVMP_END" | add eax 指令中间字节 | **agent 错** |
| §C 漏识别末尾 if | 派活单 §A 已识别 0x13C4, §C 描述不完整 | "§C 分析错" | §C 不完整, §A 已识别 | **agent 部分对** |
| 加 pad 尝试 | n/a | "尝试过, 已回退" | git reflog/stash/dangling 全空 | **无证据** |
| VM segfault | n/a | "exit 139" | 当前 snake 未真虚拟化 | **无证据** |

### 教训 (verifier 视角)

1. **agent 自报 "派活单设计错" 必须独立验证** — agent 经常反向 (派活单实际对, agent 自己反汇编错)
2. **派活单 §A 字段略不精确 ≠ "§A 全错"** — 字段精度 (rel32 vs rel8) 与 RVAs/目标正确性是两个独立维度
3. **agent 报告 "无 git 痕迹的尝试" 必须 unverifiable 标注** — 不能仅凭 agent 报告就接受
4. **派活单设计者自我结论必须独立验证** — 项目主基于 agent 报告的判断也需要 verifier 复核

### 不接受的 agent 处理方式

- ❌ "诚实回退" 作为 "agent 正确处理" 的唯一标志
- ❌ "agent 报告 5 项发现" 作为 "派活单设计错" 的依据
- ❌ "无 git 证据的尝试" 作为可接受的反向报告

### 接受的 agent 处理方式 (MIT-322 实际未做到)

- ✅ 按派活单 §A 字面执行 (删 2 处 return;)
- ✅ 重构末尾 if (ate != 0) (§A 第 3 项)
- ✅ fresh protect 看真实警告 (不靠 agent 自己反汇编)
- ✅ 承认派活单 §C 描述不完整 (但不反向说 §A 全错)
- ✅ 派活单 §A 字段略不精确时, 直接修正字段 (je rel32 → je rel8) 不全盘否定

---

**verifier 结论**: MIT-322 agent 流程层面诚实, 但**技术判断多处反向** — 派活单 §A 100% 正确, agent 报告 "§A 全错" 是 agent 自己反汇编错误。MIT-322 真正应做的工作是按派活单 §A 字面执行 + 重构末尾 if (ate != 0), 不是全部回退 + 标 blocked。

派活单设计**第 1 次字段略不精确 + §C 描述不完整**, 不是 "第 5 次根本性失败"。