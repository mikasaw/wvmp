# MIT-407 (MIT-D2 v2) 裁定 — ExitNative 启用修复完成, wvmpTest 覆盖 2/14 → 13/14 历史峰值

> Author: 接手人 (项目主) — 2026-08-29 17:4x UTC+8
> Status: **ACCEPT (COMPLETE 达成), push to `done`**, ff-merge main
> Verdict: build rc=0 / ctest 16/16 / multiseed **135/135** / wvmpTest **13/14 覆盖 + 双跑 103/103 byte-exact**
>          / r06 维持 gate 唯一 ✓ / 17 站点 17/17 与 triage 静态清单全等 / **deepcall 反证闭环 (项目主亲手复跑崩 rc=0xC0000005)**

## 0. 一句话

v1 未竟的 ExitNative 启用在本单完成: segfault 根因 = **候选 A 证实 (槽内容裸 RVA, 缺 +image_base)** + 一个叠加缺陷 (handler rsp 基准错位 0x48) + 两个"启用即炸"隐性雷 (0xFF sentinel 不可编码 / .pdata 解析恒空 / 站点 note 误杀虚拟化), 全部实测定位并修复; wvmpTest 真实函数覆盖达 **13/14** (11 ExitNative 救回 + 2 真虚拟化), 剩余 r06 间接 jmp 属未来独立棒次。

## 1. 项目主独立复验 (worktree wvmp-mit407v2-verify @ eaa73af)

| 项 | agent 自报 | 实测 |
|---|---|---|
| build / ctest | rc=0 0 新警 / 16/16 | ✅ BUILD_EXIT=0 / **16/16** |
| multiseed REQUIRE_REAL=1 | 135/135 (27×5) | ✅ **TOTAL: 135 pass / 0 fail** (含新 pos 样本) |
| **wvmpTest 13/14 (硬锚)** | stubs=13 | ✅ protect 实测 **stubs=13** + **exit-native 站点 17** (与 triage 预测 17/17 全等) |
| 双跑 byte-exact | 103/103 | ✅ native/packed rc=0 + SUMMARY 103/103 + **真实 diff 0 行** (excl image 路径行) |
| §D.7 注释恢复 | 0 缺失 | ✅ diff main..eaa73af stub_gen 被删注释行 **0** |
| 硬条款 git 卫生 | CLEAN | ✅ 主工作区 tracked 零脏 + 在 main + 交付 = 分支 commit 链 (4 连踩后首次满分) |
| §D.4 r06 维持 gate | ✅ | ✅ gate lines=1 (唯一被拦即 r06) |
| 代码抽查 | — | ✅ 入口预写 `mov rax, image_base+resume_rva` (:103); kExitSlotDepth runtime.hpp 单一来源+三消费点注释; a_kind=Imm 无条件通道; backend exit-native note 前缀过滤 (:119) |

## 2. deepcall 反证闭环 (E1 ruling §4 疑云摘除, L1 完成)

项目主自建 pre-E1 (2f1bcec) worktree CLI 亲手复跑: 加深后的 deepcall 样本 protect rc=0 / **stub=1 真虚拟化** → packed **rc=0xC0000005 崩** (agent 报的 139 = bash 对同一 AV 的信号化表示, 两者同物), native rc=0 正常输出。post-E1 (本分支) 同样本 135/135 全绿。**MIT-406 时"deepcall 样本无区分度"的遗留正式了结**——E1 窗口修复的因果链现在有了第二个独立样本证据。
(附: 我第一次复跑用了 `[pe]` 段头 toml 被 CLI 拒 (必填字段缺失), 按 multiseed 模板顶层字段格式重跑即中——非产品问题, 记录避免后人踩)

## 3. B.0 实测质量评价

- **候选 A 证实证据链合格**: cdb 第二 chance 现场 (rip=0xEBD9 = 裸 resume RVA, rsp 正常 → 目标取指违例) + WVMP_STUB_DUMP 双体系对照 (0x140000000 VA vs 0xEBD9 裸 RVA)——§A.3 静态推断获实证, 但**证据是 agent 自己 cdb 抓的**, 流程合规
- **候选 B 裁决优于我的推断**: 我猜"写/读不同址", agent 实测更精确——stub-only 路径同址, 真叠加缺陷在 handler rsp 基准 (ns-0x250 ≠ ns-0x208, 错位 0x48); 新设计 handler 只写槽+弹 push+ret, 写回链留 stub HALT 段一字不动, 全链路单基准 native_sp——**比我的两个候选都干净**
- **三个"启用即炸"隐性雷** (0xFF 4 位字段拒 / .pdata 文件边界恒空 / 站点 note 误 gate) 是 v1 DISABLED 掩盖的真宝藏, 全部修复并注释登记 keystone 大负 disp 坑

## 4. known compromise / 遗留 (继承报告 §6)

1. ExitNative 契约 (落点不消费 EFLAGS / rsp==entry) 是本语料实测非普适——注释已写明适用边界
2. 回跳 walker call 目标不跟 (语料 0 出现, 防递归假阳性设计)
3. r06 duff 间接 jmp → 未来棒次 (间接目标解析/C 双向分段)
4. **新派生**: multiseed 基线 27 样本 × 5 seeds = **135/135**; wvmpTest 板面: 13/14 覆盖, 双跑 103/103 byte-exact

## 5. 处置

1. ff-merge `eaa73af` → main (merge-base 8a3d510 直接子代, 含 687855b 抢救链)
2. MIT-407 → done (v1 partial + v2 complete 同单闭环, 先例: 原单重开模式首例全绿)
3. 清理: wvmp-mit407v2-verify / wvmp-preE1-cli worktree + agent 留的 wvmp-pree1 worktree (核实后)
4. MEMORY/基线刷新 135/135 + 13/14
5. 证据文件 `C:\Users\www\AiCode\mit407-evidence\` 保留 (agent 留档, 待 D3 后可归档)

## 6. 沉淀

- **RVA/VA 双体系纪律** (建议正式编号入 wvmp-dev): 运行时生成码任何 jmp/访存的地址必须 `RVA + image_base (ctx+0x110)`; 链接期 `jmp <rva>` 能工作是 keystone 装配基址假象, 直跳→间跳改造时裸 RVA 进槽即 #3 型野跳。本案从崩溃签名 (rip≈小地址) 到修复 30 分钟内可完成, 若早立此纪律 v1 少走 3 小时弯路
- **原单重开改派模式实战验证成功**: v1 partial 抢救分支 + v2 §A 三候选 + 硬条款 → 一棒达标; "§A 给候选+判别实验设计, 禁照抄" 的写法应进 conductor 模板
- **硬条款"报告前 git status CLEAN 附输出"首次生效** (403/404/407-v1 三连违规后)
