# MIT-411 (G1) 裁定 — ACCEPT: SSE 尾扫包收口, 160/160, 派单方先验被实测推翻 (#33 又一正例)

> 裁定人: 项目主 — 2026-08-29 21:4x | 处置: ff-merge main=`1734829`, done
> 复验 worktree: ../wvmp-mit411-verify (build 0 错 / ctest 16/16 / **multiseed 160/160**)

## 1. 独立复验表

| 项 | 自报 | 实测 |
|---|---|---|
| build/ctest/multiseed | 160/160 (32 样本) | ✅ rc=0 / 16/16 / **TOTAL: 160 pass / 0 fail** |
| wvmpTest 零回踩 | 请项目主复验 | ✅ **stubs=14 满贯保持 + exit-native 17 + jump-table@0xDD84 命中 + gated=0 + 双跑 103/103 diff 0 行** (sha bdbfff91 亲验) |
| 改面诚实 | translator/asmgen/vm_op/runtime.hpp 零触及 | ✅ diff --name-only 9 文件实读核对; **enum 零新增 kVmOpMax=86** |
| lifter 折叠 | +5 case | ✅ COMISS/COMISD→ucomis、XORPD/ORPD/ANDPD→ps 位运算, 纯折叠 |
| 样本数 | 30→32 (主+影子双注册, 408 先例修正我预估 31/155) | ✅ 实测 32 样本入 multiseed 数组; 注释头对齐 (**408 尾巴清偿**) |
| 硬条款 | CLEAN+ff-safe | ✅ tracked 0 脏 + 单分支 (⚠️ 主工作区签出尾巴又现——412 报告披露并发运行期 checkout 在 mit-411 分支, 项目主切回 main 完成收尾; 验收第 8 条"完工切回 main"执行不彻底, 连续第 5 次踩, 派单纪律文字再升级已无意义——**改为收口时项目主无条件先查 branch --show-current**, 已入 MEMORY 纪律) |

## 2. 最大价值: G1-a 先验被三重证据判伪 (#33 教科书案例)

我派单 §A.2 假定存在 `addsd [mem],xmm` (dst=MEM) 双访存缺口。**agent 实测推翻**: Intel SDM (SSE ALU/位运算/比较目标恒 XMM 寄存器)、ml64 直拒 (`error A2000: memory operand not allowed`)、capstone 解码三重证据 → "C4c 双访存"**根本是幻影缺口**, 真实语义 = 读/算/写三连 (每条 408 起已支持)。交付诚实转向: B.1 无 translator 改动, 改为三连语义样本固化证明 (11 helper stubs 主样本 + 7 探针影子 byte-exact + MASM 直写 66-prefix 全形态)。**GAPS C4c 行已按此改判收口**。教训: GAPS"砍面留 C4c"条目本身就是未验证臆断——派单把文档主张当基线是本项目 #70 铁律的反面教材, 今后缺口立项前先问"这个形态在目标 ISA 编码表上真实存在吗"。

## 3. G1-b/G1-c 折叠设计判定

comiss↔ucomis flags 逐位同真值表 (SDM) + MSVC 对 `_mm_and_pd` 自身直出 andps (编译器互认) → 折叠复用既有 VmOp/通路 = 维护面最小且 #79 真写 flags 保留。andnps 负例 gate 固化留后。**known compromise 接受**: ① comiss #IA-on-QNaN 不模拟 (VM v1 无浮点异常面, 一致); ② mul 族不在本单。

## 4. 基线与 W2 影响

基线刷新 **32 样本 × 5 = 160/160**。G1 改面 (lifter+x86_translate) 与 G2 (translator 跳转表) 零重叠 → **W2 可派**。
