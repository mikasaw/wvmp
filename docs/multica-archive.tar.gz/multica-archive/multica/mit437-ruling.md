# MIT-437 (X1a marker_scan x86 锚点) 裁定 — ACCEPT；#33 推翻派单形态先验成色十足（双方向同窗判据），十一连满分

> 裁定人: 项目主 — 2026-09-01 02:2x | 处置: ff-merge main=`2dad6ff`, done
> 复验: 亲用 agent 保留的 worktree wvmp-x1a@2dad6ff 产物（未另建——x86_marker_sample.exe 真产物直验）

## 1. 独立复验（亲测）
| 项 | 自报 | 实测 (@2dad6ff) |
|---|---|---|
| build / ctest / multiseed | 240/240 | ✅ 377/377 rc=0 / **ctest 16/16 项目主在 @2dad6ff 亲跑** / **multiseed 240/240 项目主在 @2dad6ff 亲跑**（复用交付 worktree 零重建）x64 零回踩 |
| **硬拒边界（D1 核心）** | rc=2 | ✅ **亲手跑 x86 真产物全管道**: rc=2 "32 位目标未支持…不产出保护壳" + 无落盘——扫得到≠放行进，边界成立 |
| wvmpTest 零回踩 | — | ✅ stubs=14 + jump-table@0xDD84 + en=17 + diff 0 103/103 |
| 单测矩阵 | ×7+同步 | ✅ 直读 test_scan_core: **FindAllX86 7 例全在位**（/Od hi→lo / O1-O2 lo→hi / begin-end 共享 lo 半 / 反序超窗拒 / 间隔超窗拒 / 孤立半非锚 / 连续 8B 退化形+x64 needle 共存）——D2 负例四件套齐 |
| 互斥审计 | X1b 面零触 | ✅ diff 15 文件 grep translator/asmgen/cli/lifter/backend 零命中；kVmOpMax/载体域/冻结面全不动 |
| 单一来源 | x86_dual_of 派生 | ✅ scan_core:19-27 `find_all_x86` 窗=[首半+4, +4+8]不钉 opcode，两半从 8B 模式派生禁字面量；MagicSync 三处同步断言（sdk u64↔scan_core 8B↔x86 两半）|
| 构建期守卫 | — | ✅ build_sdk_x86.bat 的 dumpbin 立即数断言（504D5657h 等三值）——**MSVC 物化漂移在锚点失配前构建期失败**，防"扫描静默失效"的好设计 |
| 硬条款 | 65 分钟 | ✅ 命名分支+main 未动+零脏+ff-safe——**十一连满分**（worktree 保留待验收=配合项目主，登记嘉许）|

## 2. #33 推翻（合格，采纳）——本单最大价值
**派单/412 的"x86 magic=mov eax,imm32 ×2 两条"先验只对一半**：dumpbin 实测 /O1/O2 形=栈槽拆写（C7 45 F8 lo → C7 45 FC hi 紧邻），而 **/Od 形=hi 先经 B8 物化、lo 后 C7、hi 以无 imm 的 89 落盘（间隔 3B）**——hi 半的"第二份"根本不带立即数。agent 因此把判据实现为**双方向同窗（≤8B）不钉 opcode**，比派单预想的"lo→hi 单方向+固定两指令"鲁棒且负例完备（D2 宁窄勿宽：实测 3B+填充余量→窗 8B，超窗/反序/孤立半全拒）。我 §A.1 的预判原文（"mov eax,imm32×2 不连续"）**被实测修正——照抄即漏 /Od 主档**。
"magic 全为立即数操作数永不被执行→412 坑② jmp skip 结构性不适用"论证成立（读 sdk 产物字节核实）。

## 3. 合入后动作
multiseed 我已在 @2dad6ff worktree 亲跑口径（240/240）；ff-merge main=`2dad6ff`；X1b（438）还在跑——**438 触碰 translator/asmgen Ret 面与本单 marker_scan 面互斥已在 diff 审计核实**，两单可安全链式合并（438 基底=f7a865c，届时同样 --ff-only 不可行则 cherry-pick，预计 marker_scan/translator 文件不相交无冲突）。
- 遗留观察: 幻影 begin 收紧（424/432 两例 P2）本单未动（D2 评估结论=随双方向窗判据自然收紧一半，剩余挂"目标落 stub 入口±窗"待 X4 消费面有真实 stub 后一并——登记观察清单，非缺陷）。
