# 项目主裁定: 部分采纳 MIT-320 (snake_sample div 修复) + 立 forward-jump sub-issue

## 总体评价

MIT-320 commit `91ee827` **部分采纳** (CONDITIONAL ACCEPT): **派活单核心目标 (div 修复) 完全达成** — `GW=32 + GH=32 + & (N-2)` 替代 `% (N-1)`, div 指令从 snake 区域消除, lifter 不再报 div 警告。

但 **snake 真虚拟化仍未闭环** — 派活单设计漏识别 2 类 blocker (派活单漏识别第 4 次实证, pitfall #23 累积):
1. **2 处 `return;` 早返回跨 epilogue 跳转** (RVA 0x11ED/0x12BE)
2. **1 处末尾 `if (ate != 0)` 跨 WVMP_END call 跳转** (RVA 0x13C4)

verifier 主动披露:
- forward-jump 字节是 `jmp rel32 (E9 xx xx xx xx)` 跳到 epilogue (不是 `ret C3`)
- agent 报告 RVA 目标地址错 0x1000 (0x2407/0x2401 → 实测 0x1407/0x1401)
- 派活单 §C stdout 预测 head=32/ticks=17 错, 实测 head=31/ticks=16

**MIT-320 status 改 done** (div 修复部分), **MIT-300 status 保持 in_review** (snake 真虚拟化闭环未达), **立 sub-issue** 处理 snake forward-jump (移除 2 处 return + 重构 if (ate))。

## 独立核查结果 (2026-08-25, hermes)

### 双重确认 (verifier + 项目主 fresh verify)

- **verifier 报告** (MIT-321 完成): 有条件接受, div 修复达成, snake forward-jump blocker 未修, 3 处 forward-jump 警告明确 (RVA 0x11ED/0x12BE/0x13C4)
- **项目主 fresh verify**: GW=32/GH=32 ✅, `s % ` 仅 2 处 (注释行, 不是代码) ✅, div 警告消失 ✅, forward-jump 警告 3 处 (RVA 与 verifier 一致) ✅

### 1. git state

```
HEAD: 91ee827 (clean, main)
MIT-320 commit: 91ee827
改动: 1 文件 (snake_sample_main.cpp, GW/GH + `&` 替代 `%`)
```

### 2. fresh verify 总览| 项 | 结果 |
|---|---|
| HEAD | 91ee827 (clean, main) |
| build | rc=0, 292/292 |
| ctest | 15/15 PASS |
| **snake_sample GW/GH=32** | ✅ grep "GW = 32, GH = 32" |
| **snake_sample `s % ` 注释行 2** | ✅ (派活单清掉代码 div, 仅留注释) |
| **div 警告消失** | ✅ grep "未支持指令 'div'" = 0 (派活单核心目标) |
| **forward-jump 警告 3 处** | ✅ RVA 0x11ED/0x12BE/0x13C4 (派活单漏识别 blocker) |
| snake stdout byte-exact | ✅ (native vs protected) |
| multiseed byte-exact 30/30 | ✅ |
| multiseed REQUIRE_REAL=1: snake 5/5 FAIL (forward-jump), 其它 25 真虚拟化 | ✅ |
| imul / movsxd / cl_shift / call-bearing 回归零退化 | ✅ |
| 冻结契约核查 | ✅ 仅改 snake_sample (1 文件) |

### 3. div 警告消失硬证据

```
$ grep "s % " passes/marker_scan/tests/snake_sample_main.cpp
Count: 2   ← 仅注释行 (派活单核心目标: div 从代码清掉)

$ wvmp_cli protect snake
[note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化（保持原生）: 
   跳转目标块未找到（区域外/未 lift） (rva=0x11ED)
[note] virtualize: ... 跳转目标块未找到（区域外/未 lift） (rva=0x12BE)
[note] virtualize: ... 跳转目标块未找到（区域外/未 lift） (rva=0x13C4)
[warning] virtualize: 没有任何函数被虚拟化
```

✅ div 警告消失 (派活单核心目标达成)
❌ forward-jump 警告 3 处 (派活单漏识别 blocker)

### 4. 派活单漏识别第 4 次实证 (pitfall #23 累积)

| MIT | 漏识别 blocker | 性质 |
|---|---|---|
| MIT-300 | imul + movsxd 跳出 | 单条指令 |
| MIT-312 | div (snake 改造前) | 单条指令 |
| MIT-317 | WVMP_END 数量 (3→1) | API 调用模式 |
| **MIT-320** | **forward-jump 跨 epilogue 跳转** | **跨区域控制流 (return + if (ate))** |

**MIT-320 漏识别模式**: 派活单 §A 只列单条指令 (`div`), 但漏掉跨区域控制流 (`return` 跨 epilogue 跳转 / `if (X) { ... }` 跨 WVMP_END call 跳转)。verifier 抓到 `jmp rel32 (E9 xx xx xx xx)` (不是 `ret C3` 误识别)。

**派活单 §A 完整性扩展** (本会话强化):
- 单条指令 (capstone 反汇编列)
- **跨区域控制流** (`return` / `if (X) { ... }` / `break` / `continue` / `goto` / `jmp` 跨 epilogue)
- 函数调用 (call std::* / Win32 API)
- 类型转换 / 除法 / 算术 / 指针算术

### 5. 派活单 stdout 预测错承认

派活单 §C 预测: `head=32, ticks=17` (派活单作者算错, 撞墙 `return` 不更新 head)
实测 (agent): `head=31, ticks=16` (撞墙时 head_x = GW-1 = 31)

**E2E byte-exact 仍 PASS** (native vs protected 字节一致), **不卡 stdout 预测值**。

### 6. 派活单验收逐条核对 (13 项, 11 通过 + 2 派活单漏识别)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-320 commit 存在 | ✅ | ✅ HEAD `91ee827` | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E 15/15 byte-exact | ✅ | ✅ 15/15 | ✅ |
| 5 | **snake_sample GW/GH=32** | ✅ | ✅ grep "GW = 32, GH = 32" | ✅ |
| 6 | **`s % ` 注释行 (代码 div 清掉)** | ✅ | ✅ 2 处 (注释) | ✅ |
| 7 | **div 警告消失** (派活单核心目标) | ✅ | ✅ grep "未支持指令 'div'" = 0 | ✅ |
| 8 | **forward-jump 警告明确** | ⚠️ 派活单漏识别 | ✅ RVA 0x11ED/0x12BE/0x13C4 | ✅ (verifier 抓到) |
| 9 | **snake stdout byte-exact** | ✅ | ✅ native vs protected 一致 | ✅ |
| 10 | imul / movsxd / cl_shift / call-bearing 回归零退化 | ✅ | ✅ 全 PASS | ✅ |
| 11 | multiseed byte-exact 30/30 | ✅ | ✅ 30/30 | ✅ |
| 12 | multiseed REQUIRE_REAL=1: snake 仍 FAIL (forward-jump), 其它 PASS | ✅ | ✅ 25/30 | ✅ |
| 13 | **派活单设计缺陷确认**: §A 漏列 forward-jump blocker | ⚠️ 派活单漏 | ✅ verifier 抓到 | ✅ (派活单缺陷, 不算 agent) |

### 7. 状态结论

**MIT-320 status**: ✅ **done** (派活单核心目标 div 修复达成)
**MIT-300 status**: ⏸ **in_review** (snake 真虚拟化仍未闭环, 等 forward-jump sub-issue)
**MIT-305 status**: ⏸ in_review (imul REJECT)

### 8. 后续行动

1. **立 sub-issue: snake_sample forward-jump 改造** (推荐方案 A: 移除 2 处 `return;` + 重构 `if (ate != 0)`, 派活前项目主 capstone 反汇编 + 读源文件 + 追溯源触发源)
2. **派活后 → 派 WVmpVerifier** (沿用流程)
3. **snake 真虚拟化闭环 → 改 MIT-300 done**
4. **MIT-320 stdout 预测错**: 派活单作者计算错误 (撞墙 `return` 不更新 head), 承认下次派活单派活前 fresh verify 跑一遍 `wvmp_cli protect` 看真实 stdout

## 沉淀 (Block C 阶段 1 教训累积 — MIT-300/301/305/309/312/314/317/320 8 次完整演进)

### 派活单设计漏识别 blocker 完整表 (pitfall #23 强化)

| MIT | blocker 性质 | 派活单 §A 列 | 漏识别 |
|---|---|---|---|
| MIT-300 | 单条指令 | ❌ | imul + movsxd 跳出 |
| MIT-312 | 单条指令 | ❌ | div 跳出 |
| MIT-317 | API 调用模式 | ❌ | WVMP_END 数量 (3→1) |
| **MIT-320** | **跨区域控制流** | ❌ | **forward-jump 跨 epilogue** |

### 派活单 §A 完整性完整清单 (本会话强化)

派活单派活前必须列:

1. **单条指令** (capstone 反汇编列): mov/add/div/imul/movzx/movsxd/cdq/cqo/xchg/...
2. **跨区域控制流** (return / if/break/continue/goto/jmp 跨 epilogue)
3. **函数调用** (call std::* / Win32 API 触发 C1 gate 因内部 rip-relative)
4. **类型转换** (movzx / movsxd)
5. **除法 / 算术** (div / idiv / Magic Number 乘法)
6. **指针算术** (`s[i]++` 等)
7. **派活单 §"所有未支持指令列表"** 明示 哪些修复 / 哪些不修复 / 哪些是 blocker
8. **派活单派活前项目主 fresh verify** 跑 `wvmp_cli protect` 看真实 [note] 警告列表

### 派活单 §C stdout 预测纪律 (本会话新增)

派活单派活前 fresh verify:
- 跑 `wvmp_cli protect --dry-run --config <toml>` 看 stdout 预测
- 派活后跑 `wvmp_cli protect` 看实测 stdout
- **承认预测错**: 撞墙 `return` 不更新 head, head_x = GW-1 (派活单作者算错为 GW)
- **byte-exact 仍 PASS** (native vs protected 一致), **不卡 stdout 预测值**

### verifier 7 连实战价值 (本会话持续扩展)

- MIT-308: 4 个隐藏问题
- MIT-311: REQUIRE_REAL 改进建议
- MIT-313: snake_sample 设计缺陷 + 派活单双核查纪律
- MIT-315: cl_shift 真虚拟化闭环
- MIT-319: div 派活单漏识别 + lifter RVA bug
- **MIT-321 (本次)**: forward-jump 派活单漏识别 + agent RVA 错 0x1000 + 派活单 stdout 预测错

### 派活单设计纪律扩展 (本会话强化)

派活单作者 (项目主) 派活前必做 5 件事:

1. **capstone 反汇编 codegen** (§A) — 列所有指令 + 字节编码 + RVA + 形式
2. **读源文件** (§B) — 列 API 调用模式
3. **追溯源文件触发源** (§C) — 列每条触发源
4. **派活单 §"所有未支持指令列表"** 明示 哪些修复 / 哪些不修复 / 哪些是 blocker
5. **派活前项目主 fresh verify** 跑 `wvmp_cli protect` 看真实 stdout + 警告列表

### 当前 Multica 状态

```
MIT-243~249 Block B        done (10)
MIT-298/299 follow-up       done
MIT-309 imul MEM            done
MIT-312 movsxd lifter       done
MIT-314 movzx lifter        done
MIT-301 cl_shift            done
MIT-317 snake_sample 改造   done
MIT-320 snake div 修复      done ← 本次
MIT-321 verifier             done (有条件接受, 派活单设计缺陷)
MIT-300 snake 真虚拟化      in_review (等 forward-jump sub-issue)
MIT-305 imul REJECT         in_review
沉淀: m3-lifter-paihuo-6-issue-progression.md
pitfall #23 强化: 派活单漏识别 blocker 4 次实证
```

### 后续流水线

```
立 issue-26 (snake forward-jump 改造 sub-issue)
  ↓
派 WVmpCppDev → 派 WVmpVerifier
  ↓
snake 真虚拟化闭环 → 改 MIT-300 done
  ↓
Block C 阶段 1 全员 done ✅ → 阶段 2 (中频指令)
```