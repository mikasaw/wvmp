# MIT-450 (X5 多目标平台收口波) 裁定 — ACCEPT；🏁 M2.5-X 里程碑收档；§F.1 反向条款完美兑现：真实语料探测器挖出 C2 缺陷不伪全绿；十八连满分

> 裁定人: 项目主 — 2026-09-02 14:0x | 处置: ff-merge main=`df6b751`, done
> 复验: agent worktree 自拆（junction 先摘防递归误删——446 教训吸收）；项目主另建 `wvmp-x5`@df6b751 双 arch 独立重建全链亲跑
> 平台事故注记: attempt-1/2 `Connection refused` + attempt-3 工具集缺失秒弃（事故族第 6 起, 434 同款）→ rerun attempt-4 即愈, 派单正文未动

## 1. 独立复验（全部亲测）
| 项 | 实测 (@df6b751) |
|---|---|
| 双 arch 构建 / ctest / 电池 / dump 门 | rc=0 ×2 / 16/16 / **36/36**（WOW64 亲手）/ PASS 60 项 |
| **multiseed（我亲手全池）** | **TOTAL: 305 pass / 0 fail**（REQUIRE_REAL=1, x64 250 + x86 55）——与报告精确数逐位吻合（我派单"315±"系 13 样本假设, agent 实测 11 样本自算 305 并披露口径差——D6 宁精勿滥正确取舍）|
| x86 池 11 样本 | ls 亲点 11 个; 抽跑 4 新样本（jmptbl/deepcall/x87gate/bitops）：**machine=0x14C ×4 + stub 1/2/1/2 + WOW64 双跑 byte-exact ×4** |
| **wvmpTest x86 缺陷复现（招牌交付, 我亲手）** | native（machine=0x14C 亲验, rebuild 对齐后 103/103）→ 打壳 **stubs=1 / gate 30 处** → packed **rc=0xC0000005**, 输出停在 `kern.xtea_roundtrip...` 之后——**native 序列的下一 kernel 恰=`kern.mul64hi_closed_forms`**：崩溃 kernel 归因与报告逐位吻合, C2 缺陷真实存在 |
| **D5 机器证明** | 双 CLI 同 seed asm_dump: 双方 sha `ffd47289…`/161,861B **逐字节恒等**（报告称零产品 diff 兑现——21 文件全为样本/脚本/文档面, `git diff --name-only` 亲核）|
| x64 基线 | wvmpTest 14 stubs + jt + en=17 + 双跑 diff 0 103/103 |
| 硬条款 | 三批命名 commit + main 未动 + 零脏 + worktree 自拆 + ff-safe + 时间对账（12:43/12:45/13:34 + 报告 13:36）——**十八连满分** |

## 2. §F.1 反向条款完美兑现（本单验收方法论的胜利）
派单 §F.1 我写过："gate 全绿零命中反而会质疑验得浅"——实测结果**正是设计所愿**：手工样本池（D4 纪律自建）305/305 全绿, 而**真实 /Od 全量语料 wvmpTest 103 kernel 挖出确定性崩溃**（cdb 铁证: ebp=FFFFFFFF + eax/ecx 携带 " WVMP"/" END1" marker magic——VM 退出还原垃圾, 根因=in-region push 破坏 stub callee-saved 保存区, 与 B.4 探针③同链）。agent 未伪全绿、未私修（D5 零产品 diff 维持）、修复素材全套交 X5b——**这就是探测器该有的样子**。

## 3. #33 反向纠锚两处（全合格）
① 446 交接注记"x86 跳表链已随 B.2 参数化"**只对一半**——S64 硬编码在 `try_match_jump_table` 匹配器本体（基址载入+delta add 的 size!=S64 判据）, 参数化仅指步进 tag；实测 x86 S32 链永不匹配 → jmptbl 样本由"3 正形真虚拟化"**转 gate 负例+helper 形态**（行为保真, 缺口登记 X5b/提单素材）——若照抄注记即造出永不匹配的假正例。② MASM `.686p` 无 popcnt/tzcnt/lzcnt 助记符——db 手编码 F3 0F B8/BC/BD 过哨兵（工具链坑, 实录在案）。

## 4. B.4 参数窗裁决（证据链扎实, 批准）
4 dword = **每调用"可见参数桥"非调用上限**（step 2.5 每调用预置 + host_rsp 重基 caller-cleans）；5 参三形实测: mov 形 arg4 确定性丢失（帧完好）/ push-imm 形 C1 gate / push-reg 形 callee-saved 破坏（ebx/esi/edi 值精确落位 [v4-4..v4-0x10] 铁证）→ **维持现窗**（扩窗救不了主形 push, mov 形最小 diff=单常量留 X5b 备选）。**442"guest 栈写恒≥ns"升级为产品正确性边界**——采纳, X5b 立翻译期栈深 gate（C2→C1 化）。

## 5. 遗留风险与 X5b 素材包（报告 §遗留核准）
① **mul64hi 崩溃 = x86 客户态含真实 in-region push 的区域不可安全虚拟化**（当前行为=崩溃/污染非静默错值——C2 定性成立但比静默错可见）→ **X5b 必须立项**（翻译期栈深 gate + 跳表匹配器 S32 + REG-REG 位测试族, 素材=cdb+探针+分布表全套）② gate 分布表: 13/14 位点拦截（跳转目标块未找到 17/push-imm 11/间接 jmp 1）——**92.9% 真实语料 gate 率 = X3d 与客户支持优先级的立项数据**（X0 的 95.74% 覆盖率在 wvmpTest 这类真实混合语料上的镜像验证）。

## 6. 🏁 M2.5-X 多目标平台里程碑收档
STATUS 收口节实读核对（完成口径+x86 生产可用宣告+触发条件清单+支持矩阵行+x87 R-SSE-only 入册）——**main=`df6b751`, 权威基线 56 样本 ×5 = 305/305**; X 波九单: X0✓ X1a✓ X1b✓ X2a✓ X3a✓ X3b✓ X3c✓ X4✓ X5✓。下一战役三选: **X5b（x86 保存区栈深 gate 修复——缺陷已实锤, 建议优先）** / X3d（SSE 32, 分布表数据已备）/ 410（M3 加密, park 中）。
