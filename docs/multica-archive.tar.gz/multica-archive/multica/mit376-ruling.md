# MIT-376 裁定 — SSE 浮点位运算 xorps/orps/andps + 浮点比较 ucomiss/ucomisd 真虚拟化 (Block C 阶段 3 第 5 条)

> Author: 接手人 (项目主) — 2026-08-28 20:10 UTC+8
> Status: **ACCEPT, push to `done`**
> Verdict: code PASS / build rc=0 (323 targets, 0 error) / ctest 16/16 / multiseed REQUIRE_REAL=1 100 runs 75/25 与基线逐项一致 / SSE 职责集 9 样本 45/45 零退化 / 两道 verifier 门 PASS / agent 自报与独立复验**首次全吻合**

## 1. 代码层核查

- `ir/include/wvmp/ir/insn.hpp` L214-236: `Xorps, Orps, Andps, Ucomiss, Ucomisd` 在 `Movupd` 之后、`};` **之内** (pitfall #34 append-only ✅; `};` 计数 main 5 = 分支 5, MIT-375 v2 越括号 bug 未复发 ✅)
- `vm/regvm/isa/.../vm_op.hpp`: VmOp 同 5 值 + kVmOpMax=76 < kTableEntries=128 (static_assert 过) ✅
- lifter `translate_ucomis` **updates_flags=true**, bitwise 组 false — 语义分野正确 ✅
- asmgen diff 新增行无裸多位立即数 (全经 `imm()`, pitfall #78) ✅ + 静态扫描门独立复跑 `RESULT: PASS` ✅
- ucomis handler 形态: zero5 → native ucomis* → setcc5 → flags_tail 真写 ctx+0x98, 与 setcc/jcc 同通路, 比较不改 xmm 故无写回步 — 设计正确, 影子样本负责 flags 断言 ✅

## 2. 行为层核查 (项目主独立 fresh verify, worktree wvmp-mit376-verify @ fb66b98)

```
scripts/build.bat (Ninja)        → rc=0, wvmp_cli.exe 10,204,160 B, 0 error
ctest                            → 100% tests passed, 0 failed out of 16
multiseed REQUIRE_REAL=1         → TOTAL 75 pass / 25 fail (20 样本 × 5 seeds = 100)
  FAIL 集合 == §A 基线 pre-existing drift (call_gate×2/rol/cl_shift/bswap ×5 seeds) 逐项一致 True
  SSE 职责集 9 样本 45/45 PASS (含本单新增 bwcmp + bwcmpss_flags_readback 各 5/5)
  新样本 REQUIRE_REAL 下 5/5 → 真虚拟化, 未被 C1 gate 拦
static_scan_bare_immediates.ps1 → RESULT: PASS
```
新样本 stdout byte-exact (native vs packed × 5 seeds 全一致) 即 §E.3 E2E 主断言 (seed=12345 含于 5 seeds), 且 `已生成 N 个入口 stub` 由 REQUIRE_REAL 强制校验。

## 3. Intel SDM 对齐

- 5 形式编码 `0F 57/56/54/2E /r` + `66 0F 2E /r` 与派发前项目主 capstone 实证一致 (F3 0F 2E 不存在, 无误) ✅
- NaN → unordered → ZF=PF=CF=1 → seta=0 真值表在样本断言 (nan 探针 gt=0) ✅

## 4. 关键 catch (本单新沉淀)

- agent 实测披露新坑 (MASM helper Win64 ABI): `(float,float,ptr,ptr)` 签名下 ptr 参数在 **r8/r9** 而非 rcx/rdx (浮点位次占独立寄存器槽) — 首版按 rcx/rdx 写导致 native 样本自身 segfault, cdb 定位后修正并注释记录。honest disclosure 模式 13 正例。
- 派发时 §A 修正了 issue-64 原文 3 处旧基线数字 (ctest 15→16, multiseed 75→90 runs 基线, 样本数), agent 按修正版执行, 未发生时间线错位假矛盾。

## 5. known compromise

- 仅 REG-REG (mod=11) 形式; xorps/orps/andps 内存形式 (0F xx /r mod≠11) 与 comiss 家族留后续单。
- dump_handler_xmm_check.py 对 ucomiss/ucomisd 刻意不注册 (compare-only 无写回, 写回形常量会误 FAIL) — agent 在报告 §一 已披露, 合理。
- agent 未跑 ctest via scripts/test.bat 的差异核验: 项目主本轮 ctest 直跑 16/16 覆盖。

## 6. 验收回条

§E 8 项: 1✅ 2✅ 3✅(并入4) 4✅ 5✅ 6✅(13 文件均在 §C 8 处+2 配套先例内) 7✅ 8✅ (commit fb66b98 @ mit-376-sse-bwcmp, 未 push 未 merge → 项目主 ff-only 合入)。

## 7. 沉淀

- **agent 自报 = 独立复验全吻合首例** (SSE 线 5 连单): 派活单 §A 数字在派发**前**由项目主 fresh verify 修正为实测值, 消除了 pitfall #70 亚种; 后续派活单沿用"§A 必带本轮实测数字"纪律。
- Win64 MASM helper 浮点+指针混合签名参数寄存器 r8/r9 教训 → 建议入 wvmp-dev pitfalls。
- 影子样本模式 (flags readback + xmm 全槽污染检测) 为第 3 对, 模板固化。

## 8. close-out action

- ff-only merge `mit-376-sse-bwcmp` (fb66b98, main 直接子代) → main
- `multica issue status MIT-376 done`
- 清理验证 worktree wvmp-mit376-verify
- Block C 阶段 3 五连单 (371/373/374/375/376) 全 done

== 完 ==
