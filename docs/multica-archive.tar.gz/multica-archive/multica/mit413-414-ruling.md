# MIT-413 (G2) + MIT-414 (G7p2) 合并裁定 — 双 ACCEPT, 链式合并态一次 ff-merge main=92928e0, 基线 165/165

> 裁定人: 项目主 — 2026-08-29 23:0x | 交付形态: 双单堆叠同分支 `1734829←5b2a874[414]←92928e0[413]`, 22 文件合并态, ff-safe
> 复验 worktree: ../wvmp-413414-verify @92928e0 (合并态一次复验即覆盖双单)

# 裁定 A: MIT-414 (G7p2 x86 安全拒绝面) — ACCEPT

## A.1 独立复验 (合并态实测)
| 项 | 自报 | 实测 |
|---|---|---|
| build/ctest/multiseed | 160/160 零变化 | ✅ rc=0 / 16/16 / 165 全绿含 160 既有 (413 样本外零退化) |
| **行为三态新表** | PE32→rc=2 硬失败 | ✅ **项目主亲验**: hello32+craft32 × 合并态 CLI → **rc=2 + ERROR"32 位目标 (x86) 未支持"+无输出文件** (旧行为: rc=0 静默两字节差, 项目主 412 轮亲验在案) |
| x64 零扰动 | 3 样本 sha256 IDENTICAL | ✅ 我独立换样本复跑 (rol_sample × 旧 main CLI vs 新 CLI 同 seed): packed sha256 `da0da57d…` **IDENTICAL** |
| B.1 修复证明 | struct 直读对照 | ✅ pe_image.cpp 改动直读: PE32 分支 skip8 后 read_u32 与 triage 布局证据一致; PE32+ 分支零扰动 |
| 单测 | fixture 真实布局 | ✅ Pe32OptionalHeaderFieldLayout 逐字段 + RejectsX86InputWithHardError + section_builder 空洞用例改造 (旧"空洞照落"用例被**改为断言拒绝**——诚实面对行为变更, 非悄悄删测试) |
| 并发纪律 | — | ✅ 独立泳道 build-mit414 (Dependencies.cmake 认可机制); 曾主工作区 checkout -b 开发 (411 同款, 分支有 commit 链可接受), 收口切回 main 由项目主执行——**签出尾巴第 6 次**, 见 §3 |

## A.2 判定
P2 四件套全数落地且质量高: gate 放 pe_loader 解析后 (单点, §F#2 接受态), ERROR 语义响亮, B.3 arch 预备零行为变化, B.4 防御校验含 3 新用例, B.5 四文档收口 (GAPS C5 四行审计表 + 16-bit 登记 + CRT E8 误归属观察清单转录)。D1-D4 决策全兑现。**known compromise 接受**: 32 位用户仍无保护 (P1 backlog W6), 拒发生在解析后 (必要且无害)。

# 裁定 B: MIT-413 (G2 跳转表残余) — ACCEPT, 附加分级: 缺陷修复披露为超预期贡献

## B.1 独立复验 (合并态实测)
| 项 | 自报 | 实测 |
|---|---|---|
| build/ctest/multiseed | 165/165 (33 样本) | ✅ rc=0 / 16/16 / **TOTAL: 165 pass / 0 fail**; 新样本 jmp_table8 亲见 5/5 seeds PASS |
| 零回踩 wvmpTest | 14/14+jump-table 原样 | ✅ **stubs=14 + 17 站点 + gated=0 + 双跑 103/103 diff 0 行**; jump-table note 现为 `@ 0xDD84 entries=8 reg-4B-delta` (前缀/地址/entries 原样, 加形态后缀 = B.7 要求的增强, 判合规) |
| D4 单匹配器 | 三参数化禁二套 | ✅ translator.hpp JumpTableReadFn+width / translate_function+image_base 参数扩展, 直读属实 |
| 表长纪律 | 双编码防御 (MSVC K-1/ja + GCC K/jae) | ✅ 报告实汇编表 8 形态字节级; 无防御 gate note `jump-table-gate @ 0x182C: 疑似表形态但未检出防御常数` 原文在案 |
| §F.3 语义裁决 | mem 源 delta 原生即坏→仅绝对 VA 进 | ✅ 实测论证正确 (CPU 不加基址), delta-from-jmp 走 REG 源构造; "基址即跳转点静态不可分取区判据"处理与 409 硬判据一致 |

## B.2 超预期: 暴露并修复 409 两个真实潜在缺陷 (项目主代码级核验)
- **①`jump-table @` 前缀过滤吞 gate note** → backend :137 `rfind("jump-table @",0)==0` 直读证实过滤面; 409-era translator 仅一种 note 字符串 (`jump-table @ 0x%`) vs 413-era 拆出 `jump-table-gate` → **409 存在"命中但 gate 的函数被照常虚拟化 = 缺块字节码静默行为错"的潜伏雷**, 被本单三负例样本踩出并当场修复 (gate note 不过滤→真 gate)。wvmpTest 未爆是幸运 (r06 表全命中)。
- **②表读取固定 8B 步长** → 4B 表越项 (wvmpTest @0xDD84 首跑回退 0xCCCCCCCC 实证), width 参数化修复。
- **判定**: 两缺陷均 409 引入、413 发现+修复+回归全绿, 披露诚实 (报告§四.4 明示"非本单引入但被本单暴露")——这正是验收体系要的 behavior。409 裁定"脚手架质量高"不改, 但教训入 MEMORY: **diag note 前缀是 gate 语义的一部分, 新 note 类型必须与过滤白名单对账** (pitfall 素材, 待入 wvmp-dev)。

## B.3 §F 接受
clang/GCC 真产物未验 (本机无工具链, MASM 等价字节+复跑钩子已留); 无防御永久 gate (D2 不破); K≤32 预算继承。

# 3. 处置与战线

1. 双裁定落盘; ff-merge main = `92928e0`; **413/414 → done + 裁定评论上单**
2. **multiseed 基线刷新: 33 样本 × 5 = 165/165**; wvmpTest 14/14 保持
3. 主工作区签出 mit-414-x86-gate 尾巴: 项目主切回 main (第 6 次踩, 条款文字已边际收益递减——收口 SOP 固化"项目主先查 branch --show-current"已在 MEMORY, 不再升级派单文字)
4. GAPS 现状: **C1 跳转表面收窄至"无防御表(永久 gate)+非 MSVC 真产物未验"; C5 = 安全拒绝面已闭环 (P2 done), P1 全量对齐 backlog; C4c 幻影缺口判伪在案**。G 线正确性剩余: G3 串指令 / G4 lock / G5 x87 / G6 AVX + (x86 P1 视 ROI)
5. W3 接续: G3 (串指令族) 与 G5 x87 侦察可并行派 (改面互斥: translator/lifter 实施 vs 纯侦察)
