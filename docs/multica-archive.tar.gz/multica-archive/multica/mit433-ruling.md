# MIT-433 (P1 rol/ror flags 修复) 裁定 — ACCEPT，235/235，反证闭环双侧亲验；D3 字面预期被 agent 实测推翻（合格 #33）

> 裁定人: 项目主 — 2026-08-31 13:5x | 处置: ff-merge main=`cdc218d`, done
> 复验 worktree: ../wvmp-433-verify @cdc218d

## 1. 独立复验（全部亲测）
| 项 | 实测 |
|---|---|
| build / ctest / **multiseed** | rc=0 / 16/16 / **TOTAL: 235 pass / 0 fail**（47 样本×5，含新 flags_rol 5/5）|
| **反证闭环（我亲手双侧跑）** | ✅ 修复前: main 624e900 CLI protect 同一新样本 → packed `ror_zdiv=1 rol_zdiv=1 rol_sf=0 ror_pf=1` vs native 全 0/1/0——**4 分叉 token 全可观察，shl 对照两侧一致**；修复后: 分支 CLI packed **byte-exact=native**。反证等效性前提亲验（624e900 vs 0ac661a 仅差 1 文档文件；旧 CLI 构建时间戳 12:48 在案）|
| D3 逐 case 对账 | ✅ 共享 `flags_tail` 函数一字未动（diff 仅 +flags_tail_partial 新函数 + build_shift 尾参默认 false）——非 rot 生成路径零风险成立；rot 4 handler 尾部换装（省 4 条/handler）|
| 新样本 | ✅ 5 区真虚拟化（stubs=5 亲验）、区内 Store 观察（427 纪律）、MASM 自含桩（无 sdk 链接）|
| wvmpTest 零回踩 | stubs=14 + jump-table@0xDD84 + ExitNative 17 + 双跑 103/103 diff 0（报告口径，agent 附 note 流 diff 仅节尺寸行）|
| 冻结面 | vm_op/runtime.hpp/backend/ir/translator/lifter 全零触（8 文件 grep 亲验）；kVmOpMax=97；双门 PASS（rot handler dump 形状单独核验）|
| 硬条款 | 命名分支+零脏+切回+ff-safe+100 分钟对账——**八连满分** |

## 2. #33：agent 推翻项目主 D3 字面预期（全链合格，采纳）
我派单写"非 rot 样本 packed sha 逐字节不变"——**本架构下不可达**（解释器镜像整体内嵌每个 packed exe，rot 尾变短 → 镜像尺寸 -48B@seed12345 → 后续偏移全体平移）。agent 未硬凑 sha 假象，而是**以更强的逐 handler 对账（91/95 逐字节相同 + delta∈{0,13,26,39,52} 纯位置效应）+ 机制披露**替代——验收 #5 的"非 rot handler 字节码零扰动"实质达成。我亲测印证: sse_add 同 seed 新旧 CLI packed **同尺寸但 sha 不同**（对齐垫吸收尺寸差、镜像内容确实平移）+ stdout byte-exact——**"sha 不可达、行为恒等"披露与实测完全吻合**。教训入 MEMORY: **涉 runtime 码体尺寸变更的单，零扰动验收口径 = 逐 handler 对账 + 行为恒等，禁用 packed sha 恒等**（428 §F.4"同 seed 同 CLI 才 sha 恒等"的推广形）。

## 3. 两处超预期
① §F.1 修正: partial 尾比全量尾**短**（省 4 条指令）——性能微升非微降；② "230/230 全绿 ≠ rot 通路已验"盲区实证入 GAPS 教训（新样本是首个真执行 VM rot 的 multiseed 样本；rol_sample 旧样本 `_rotl64` 走 CRT callgate 根本不进 VM）——**样本集设计纪律"指令写入面 × 消费形态"矩阵**入文。

## 4. 裁定与排程
ACCEPT，ff-merge main=`cdc218d`，基线 **47 样本 × 5 = 235/235**。B.5 G8a 接入点声明在位（flags_tail_partial 骨架注释）——**选A 下一棒 G8a 立即写单派发**（§A 锚 = P1 合入实态 + 432 §2.5 蓝图 + §6.3 影子样本单基本块硬约束 + mulx 厂商分叉决策留 G8b）。
