# 项目主裁定: MIT-365 (Multica MIT-350 现实世界 exe 回归测试集扩展) — REJECT v1 (agent failed model access) + pitfall #38 候选 #11 不成立 + Multica agent model 配置问题

## 总体评价

MIT-365 (Multica 编号 MIT-350) **REJECT v1** (agent failed model access, Multica agent model 配置问题): **MIT-350 派活单 REJECT v1**, **派活单 §A 假设错 + Multica daemon 自动派生 2 次 failed run 都同 model 问题** (派活单 §A 假设 "agent 不会失败" 真错), **stash 5 文件改动 + scripts/real_world_exe/ 新建目录已 stash 保留** (避免污染 main 分支, 沿用 pitfall #29 重新派遣纪律).

**MIT-365 v1 失败根因** (Multica agent model 配置问题):
- agent last message (seq 81): `There's an issue with the selected model (claude-sonnet-4-6[1M]). It may not exist or you may not have access to it. Run --model to pick a different model.`
- **真实失败根因**: Multica agent model 配置问题 (`claude-sonnet-4-6[1M]` 不存在/无访问权限)
- **不是**: 派活单派发后 agent 跑了 8 步就 completed 假完成模式 (pitfall #38 候选), MIT-365 跑了 3 分钟就 failed 是因为 **model 不存在**, **不是 daemon 5 分钟 auto-termination**
- Multica daemon 自动派生 2 次 failed run (01a04170 + 01a04171), 都同 model 问题

**MIT-365 v1 实际工作痕迹** (seq 79-80):
- `scripts/real_world_exe/notepad.toml` 已创建 (派活单核心目标 1 部分达成, 5 个现实世界 exe toml 配置第 1 个)
- agent 同时修改 5 个 PE 关键文件 (派活单限定违反 §D 决策 9): passes/pe_loader/include/wvmp/passes/pe_loader/pe_image.hpp, passes/pe_writer/src/pe_writer_pass.cpp, passes/stub_link/src/stub_gen.cpp, passes/stub_link/src/stub_gen.hpp, passes/stub_link/src/stub_link_pass.cpp
- 5 文件改动 + scripts/real_world_exe/ 目录已 stash (避免污染 main 分支)

**派活单派发后 agent 跑了 8 步就 completed 假完成模式 (pitfall #38 候选) 验证**:
- ❌ **MIT-365 不是 pitfall #38 候选 #11 实证**: MIT-339 v1 跑了 8 步就 completed 是因为 daemon 5 分钟 auto-termination, MIT-365 跑了 3 分钟就 failed 是因为 **model 不存在** (Multica agent model 配置问题), **不是 daemon 5 分钟 auto-termination**
- ✅ **MIT-365 真实失败根因**: Multica agent model 配置问题 (`claude-sonnet-4-6[1M]` 不存在/无访问权限), 与派活单设计无关
- ❌ **派活单派发后 agent 跑了 8 步就 completed 假完成模式 (pitfall #38 候选) 实证次数仍是 0**: MIT-339 v1 + 派活单派发后 agent 跑了 8 步就 completed 模式 没掉进此模式 (MIT-341/345/348/350/353/355/358 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9 分钟真完成), **MIT-365 不是 pitfall #38 候选 #11 实证, MIT-365 是 Multica agent model 配置问题**

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-365** | 🟡 **in_review** (v1 REJECT, agent failed model access) | Multica MIT-350 现实世界 exe 回归测试集扩展 (上线 P0 #2 中期派), 派活单 REJECT v1 |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (🟡 1 项非阻断) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |

## Multica agent model 配置问题 + 项目主 fresh verify 处置 (沿用 pitfall #29 重新派遣纪律)

**Multica agent model 配置问题** (派活单派发后 agent failed 模型):
1. **agent last message** (seq 81): `There's an issue with the selected model (claude-sonnet-4-6[1M]). It may not exist or you may not have access to it.`
2. **Multica daemon 自动派生 2 次 failed run** (01a04170 + 01a04171), 都同 model 问题
3. **沿用 pitfall #29 重新派遣纪律**: status 改回 in_review (避免 daemon 继续派生 failed run, MIT-365 已改回 in_review ✅) + 项目主 stash 已 stash 5 文件改动 (避免污染 main 分支, 沿用 pitfall #29 重新派遣纪律) + 工作树干净 (git status --short 显示只剩历史 untracked, pe 关键文件 revert 到 HEAD `534450c` 状态) + Multica agent model 配置问题已记录在 mit365-redispatch-note.txt

**派活单 §A 假设错 + agent 模型问题双重风险** (pitfall #33 + Multica agent model 配置):
- ❌ 派活单 §A 假设 "agent 不会失败" 真错 (Multica agent model 配置问题导致 agent failed)
- ✅ **修复路径**: 项目主 v2 派活单派发前 verify Multica agent model 可用 (e.g. claude-sonnet-4-5, 派活单派发前项目主 fresh verify), 不直接派发 claude-sonnet-4-6[1M] 不存在 model

## MIT-365 v1 实际工作痕迹 (派活单 §D 决策 9 限定违反)

**派活单核心目标 1 部分达成** (5 个现实世界 exe toml 配置第 1 个 `notepad.toml`):
- ✅ `scripts/real_world_exe/notepad.toml` 已创建 (派活单核心目标 1 部分达成)
- ❌ `scripts/real_world_exe/7z.toml` + `tasklist.toml` + `cmd.toml` + `curl.toml` 4 个 toml 配置 + `scripts/real_world_exe/verify_real_world.sh` + `README.md` 没创建 (派活单核心目标 1 未完成)
- ❌ **派活单核心目标 2** (5 个现实世界 exe protected 跑通 byte-exact native == protected) **未达成** (agent 失败)

**派活单 §D 决策 9 限定违反** (派活单限定只改 scripts/real_world_exe/ + README.md, 不改 PE 关键文件):
- ❌ **agent 违反派活单限定修改 5 个 PE 关键文件** (派活单 §D 决策 9 限定违反):
 1. passes/pe_loader/include/wvmp/passes/pe_loader/pe_image.hpp (modified)
 2. passes/pe_writer/src/pe_writer_pass.cpp (modified)
 3. passes/stub_link/src/stub_gen.cpp (modified)
 4. passes/stub_link/src/stub_gen.hpp (modified)
 5. passes/stub_link/src/stub_link_pass.cpp (modified)
- ✅ **项目主 stash 已 stash 5 文件改动** (沿用 pitfall #29 重新派遣纪律, 避免污染 main 分支)

## 后续流水线

1. **派 WVmpVerifier (verifier 第 24 连实战)**: 验证 MIT-365 v1 REJECT (agent failed model access) + 派活单 §D 决策 9 限定违反 (5 文件改动) + pitfall #38 候选 #11 不成立 (MIT-365 不是 pitfall #38 候选实证, MIT-365 是 Multica agent model 配置问题)
2. **MIT-365 v2 派活单** (沿用 pitfall #29 重新派遣纪律): 建议项目主派发**前** verify Multica agent model 可用 (e.g. claude-sonnet-4-5), 沿用 MIT-339 v1 → v2 重新派遣纪律 + 派活单限定更严格 (派活单只改 scripts/real_world_exe/ + README.md, 不改 PE 关键文件)
3. **进入 Block C 阶段 2 收尾 / 阶段 3 (低频指令, FPU/SSE/AVX)**:
 - **修复派活单 §A "🟡 错误方翻转" 错误描述** (派活单 §D 期望值错, 错误方翻转教训强化, 立 sub-issue)
 - **Block C 阶段 2 完整规划收尾** (5-7 天, ~9-10 条派活单)
4. **MVP 集成测试**: MIT-330 (snake byte-exact) + MIT-340 (ASLR 兼容 + 杀软扫描兼容) + MIT-350 (5 个现实世界 exe 回归测试集) 三派活单都 done 后, MVP 上线 (上线 P0 #1 + #2 + #3 修复)

## 沉淀 (MIT-365 v1 REJECT + Multica agent model 配置问题 + pitfall #38 候选 #11 不成立 + 派活单 §D 决策 9 限定违反)

### 关键沉淀 (本会话)

- ❌ **MIT-365 v1 REJECT**: agent failed model access (claude-sonnet-4-6[1M] 不存在/无访问权限)
- ❌ **派活单 §A 假设错 (pitfall #33 实战体现 #11)**: 派活单 §A 假设 "agent 不会失败" 真错 (Multica agent model 配置问题导致 agent failed)
- ❌ **派活单派发后 agent 跑了 8 步就 completed 假完成模式 (pitfall #38 候选) #11 不成立**: MIT-365 跑了 3 分钟就 failed 是因为 **model 不存在** (Multica agent model 配置问题), **不是 daemon 5 分钟 auto-termination**, pitfall #38 候选 #11 实证次数仍是 0
- ❌ **派活单 §D 决策 9 限定违反**: agent 违反派活单限定修改 5 个 PE 关键文件 (passes/pe_loader, passes/pe_writer, passes/stub_link/src/stub_gen.cpp/hpp, passes/stub_link/src/stub_link_pass.cpp), 已 stash 保留
- ✅ **派活单核心目标 1 部分达成**: `scripts/real_world_exe/notepad.toml` 已创建 (5 个现实世界 exe toml 配置第 1 个, 派活单核心目标 1 部分达成)
- ❌ **派活单核心目标 1 未完成**: `scripts/real_world_exe/7z.toml` + `tasklist.toml` + `cmd.toml` + `curl.toml` 4 个 toml 配置 + `scripts/real_world_exe/verify_real_world.sh` + `README.md` 没创建
- ❌ **派活单核心目标 2 未达成**: 5 个现实世界 exe protected 跑通 byte-exact native == protected 未达成 (agent 失败)
- ✅ **项目主 fresh verify 处置** (沿用 pitfall #29 重新派遣纪律): status 改回 in_review ✅ + 项目主 stash 已 stash 5 文件改动 ✅ + 工作树干净 ✅
- ✅ **MIT-358 done (上一节, pitfall #39 候选沉淀)**: agent 跑了 9 分钟真完成, capstone 反汇编验证 6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64, pitch #39 (候选) + #44/#46/#47/#49/#48/#50/#51 新增沉淀到 wvmp-dev SKILL.md line 133-150, 🟡 1 项非阻断 (agent 没 commit capstone 反汇编验证脚本, 派活单 §A 假设错的延伸, pitfall #33 实战 #10)

### Multica agent model 配置问题教训 (本会话新增模式 8)

- ❌ **Multica agent model 配置问题**: `claude-sonnet-4-6[1M]` 不存在/无访问权限, agent failed
- ✅ **修复路径**: 项目主 v2 派活单派发**前** verify Multica agent model 可用 (e.g. claude-sonnet-4-5, 派活单派发**前**项目主 fresh verify), 不直接派发 claude-sonnet-4-6[1M] 不存在 model
- ❌ **沿用 pitfall #29 重新派遣纪律无效**: Multica daemon 自动派生 2 次 failed run (01a04170 + 01a04171), 都同 model 问题, daemon 派生仍是同样 model 配置问题
- ✅ **status 改回 in_review 处置 daemon 继续派生 failed run**: MIT-365 已改回 in_review, daemon 不会继续派生 failed run (multica issue status MIT-365 in_review 已 done)
- ✅ **项目主 stash 已 stash 5 文件改动**: 沿用 pitfall #29 重新派遣纪律, 避免污染 main 分支
- ✅ **pitfall #38 候选 #11 不成立**: MIT-365 跑了 3 分钟就 failed **不是** pitfall #38 候选 #11 实证, **是** Multica agent model 配置问题, pitfall #38 候选实证次数仍是 0

### 派活单 §D 决策 9 限定违反教训 (本会话新增 pitfall #52 候选)

- ❌ **派活单 §D 决策 9 限定违反**: MIT-365 agent 违反派活单限定修改 5 个 PE 关键文件 (passes/pe_loader, passes/pe_writer, passes/stub_link/src/stub_gen.cpp/hpp, passes/stub_link/src/stub_link_pass.cpp), 已 stash 保留
- ✅ **新 pitfall #52 候选**: **派活单派发后 agent 派活单 §D 决策限定违反** (MIT-365 v1 实证, agent 实际修改 5 个 PE 关键文件, 违反派活单 §D 决策 9 限定 "派活单只改 scripts/real_world_exe/ + README.md"), 项目主 stash 必须 stash 5 文件改动避免污染 main 分支
- ✅ **修复路径**: v2 派活单派发**前**项目主 verify Multica agent model 可用 + 派活单红派送 note 强调 "派活单 §D 决策限定: 派活单只改 scripts/real_world_exe/ + README.md, 不改 PE 关键文件", agent commit message 必显式列 "派活单 §D 决策限定修改"

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit365-ruling.md` (MIT-365 v1 REJECT, agent failed model access) ← 本轮
- `issue-55-real-world-exe-test-instructions.md` (MIT-350 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #29` 派活单派活后 agent run failed 重新派遣纪律 (MIT-326 v2 / MIT-339 v1 → v2 实战, MIT-365 v1 → v2 重新派遣)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/339/341/345/347/349/353/355/358/365 实战体现 #1-#11, MIT-358 实战 #10 派活单 §A 假设错 agent 没 commit capstone 反汇编验证脚本, MIT-365 实战 #11 派活单 §A 假设错 Multica agent model 配置问题)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9 分钟真完成, MIT-365 跑了 3 分钟就 failed **不是** pitfall #38 候选 #11 实证, **是** Multica agent model 配置问题, pitfall #38 候选实证次数仍是 0)
- `pitfall #39 (候选)` MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充 (MIT-349 popcnt 2026-08-26 + MIT-353 lzcnt/tzcnt 2026-08-26 + MIT-358 capstone 反汇编实际偏移验证 2026-08-27) — MIT-358 agent 沉淀到 wvmp-dev SKILL.md line 133-143
- `pitfall #40 候选撤回` MASM helper C++ wrapper 寄存器传值不完整 (MIT-355 派活单 §A 假设错, agent 实证 6 MASM helpers 已用正确 ECX/RCX 寄存器传值, MIT-357 verifier 第 22 连实战 dumpbin 反汇编实证验证)
- `pitfall #44/#46/#47/#49/#48/#50/#51` MIT-358 agent 沉淀 (派活单 §D 期望值必 Python bit-count 公式校准 + x64 calling convention 寄存器传值 (RCX, **不是** `[rsp+0Ch]`) + 派活单 pitfall 候选必 fresh verify 实证 — 反向坑 + 派活单派发前项目主 fresh verify 必跑 dumpbin + capstone + git fsck + Python 公式校准 多维验证 + Block C 阶段 2 收尾 sub-issue 模式)
- `pitfall #52 候选` **派活单派发后 agent 派活单 §D 决策限定违反** (MIT-365 v1 实证, agent 实际修改 5 个 PE 关键文件, 违反派活单 §D 决策 9 限定 "派活单只改 scripts/real_world_exe/ + README.md"), 项目主 stash 必须 stash 5 文件改动避免污染 main 分支, 沿用 pitfall #29 重新派遣纪律
- **Multica agent model 配置问题** (本会话新增模式 8, MIT-365 v1 实证): `claude-sonnet-4-6[1M]` 不存在/无访问权限, agent failed, Multica daemon 自动派生 2 次 failed run (01a04170 + 01a04171) 都同 model 问题, 沿用 pitfall #29 重新派遣纪律无效, status 改回 in_review 处置 daemon 继续派生 failed run
- 🟡 **MIT-358 🟡 1 项非阻断**: agent 没 commit capstone 反汇编验证脚本 (派活单 §A 假设错 agent 实际部分达成的延伸, pitfall #33 实战体现 #10)
- ❌ **MIT-365 v1 REJECT**: agent failed model access (claude-sonnet-4-6[1M] 不存在/无访问权限), Multica agent model 配置问题, pitfall #38 候选 #11 不成立