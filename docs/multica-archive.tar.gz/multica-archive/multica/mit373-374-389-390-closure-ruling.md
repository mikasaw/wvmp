# MIT-373 / MIT-374 / MIT-389 / MIT-390 批量收口裁定

> Author: 接手人 (handover session) — 2026-08-28 晚 UTC+8
> Status: **ACCEPT ×4, push to `done`**
> Verdict: ctest 16/16 / multiseed(REQUIRE_REAL=1) 90 runs 65 PASS·25 FAIL 与 mit375 基线逐项一致 / SSE 职责集 7 样本 35/35 PASS / 4 单核心目标均已由 main 落地 commit 达成
> 依据: 交接文档 §7.2 P1-4 + historical-in-review-closure-ruling.md 模式 + mit375-ruling.md 模板

## 0. 收口方式（4 单一览）

| 单 | 标题 | 落地 commit (main HEAD 694eda0 祖先核查 ✅) | closure 方式 |
|---|---|---|---|
| MIT-373 | SSE float sub (subss/subps/subpd) | `8ed50b0` | 派活单核心目标已达成，代码+multiseed 实证 |
| MIT-374 | SSE float div (divss/divps/divpd) | `a32018a` | 同上（run completed，报告 in_review） |
| MIT-389 | verifier 验收门加固 (imm() 静态扫描 + xmm readback + handler dump) | `474e210` | 三件套落盘实证：`scripts/verifier/static_scan_bare_immediates.ps1` / `dump_handler_xmm_check.py` / `multiseed_e2e.sh` sse_subss_xmm_readback 影子样本 |
| MIT-390 | SSE/Block backlog 派活单模板更新 | `c959607` (docs) | run 状态 cancelled 但目标由后续 commit (含 mit375 模板 §7 + issue-64) 实际达成；交接文档明确"不需要新 commit，都是 in_review + commit 已在 main" |

## 1. 代码层核查

- `ir/include/wvmp/ir/insn.hpp` L171-210: enum Op append-only 链完整 — `Addss/Addps/Addpd` → `Subss/Subps/Subpd` → `Divss/Divps/Divpd/Movss/Movaps/Movapd/Movups/Movupd`（pitfall #34 合规）✅
- lifter/translator/asmgen 三处 (ir/src/insn.cpp, vm/regvm/translator/src/translator.cpp, vm/regvm/runtime/src/asmgen.cpp) 三族指令处理均在位 ✅

## 2. 行为层核查 (fresh verify, 本接手会话实测)

```
scripts/build.bat                 → rc=0, 0 error, wvmp_cli.exe 10,171,392 B
ctest --output-on-failure         → 100% passed, 0 failed out of 16
multiseed REQUIRE_REAL=1          → TOTAL 65 pass / 25 fail (90 runs)
  FAIL 5 样本 × 5 seeds = call_gate / call_gate_simple / rol / cl_shift / bswap
    ← 与 mit375-ruling.md §2.3 基线**逐样本逐 seed 一致**, pre-existing drift,
      属 GAPS.md C2/C3/C4 + Block A/B 范围, 与本 4 单无关
  SSE 职责集 7 样本 × 5 seeds     → 35/35 PASS
    (sse_add, sse_sub, sse_subss_xmm_readback, sse_div, sse_divss_xmm_readback,
     sse_mov, sse_movss_xmm_readback) ✅
```

## 3. 环境漂移记录（接手会话新发现，非阻塞）

- `scripts/multiseed_e2e.sh` L31 写死 `$repo/build/vs/cli/Debug/wvmp_cli.exe`（旧 VS-generator 布局）；现 build.bat 走 Ninja 输出 `build/cli/wvmp_cli.exe`。本轮以 `mkdir build/vs/cli/Debug + cp` 镜像兼容跑通，**未改仓库脚本**。
- 建议: 并入 MIT-382 (repo hygiene) 派活单，让脚本按 `build/cli/` → `build/vs/cli/Debug/` 顺序探测。
- **注意**: 此漂移导致交接文档 §7.1 第 4 步隐含的 multiseed 路径失效，接手人验证时勿误判为构建损坏。

## 4. known compromise

- MIT-390 run 本身 cancelled，收口依据是"目标由 commit c959607 + 模板文档实际达成"（模式 9: 派活单核心目标已达成 by 后续 commit），非该 run 自报完成。
- MIT-373 首个 run failed（daemon restarted），第二 run 01a045e5-3a1 completed — 本报告未复核 agent run 细节，以 main 代码 + fresh verify 为准。

## 5. 沉淀

- **多单同域批量收口先例 #2**（第一次 = historical-in-review-closure 9 单）：同链路（SSE 族）+ 同验证面（multiseed 90 runs）的 in_review 单，一份裁定覆盖多单，逐单列 closure 方式 + 统一 fresh verify。
- multiseed 基线对比法: 不按总数而按 **(样本 × seed) 逐项** 与既往裁定表比对，pre-existing drift 与 in-scope FAIL 才能区分。

## 6. close-out action

- `multica issue status MIT-373 done` / `MIT-374 done` / `MIT-389 done` / `MIT-390 done`
- `multica issue status MIT-387 cancelled`（MIT-373 重复条目，标题 "MIT-373:" 即误建实证）

== 完 ==
