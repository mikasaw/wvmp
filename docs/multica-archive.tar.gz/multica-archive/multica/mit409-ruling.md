# MIT-409 (MIT-A6) 裁定 — MSVC 跳转表特化达成, wvmpTest 14/14 历史满贯, 基线 150/150

> Author: 接手人 (项目主) — 2026-08-29 20:2x UTC+8
> Status: **ACCEPT (COMPLETE), push to `done`**, ff-merge main
> Verdict: build rc=0 / ctest 16/16 / multiseed REQUIRE_REAL=1 **150/150**
>          / wvmpTest **14/14 满贯** (jump-table @0xDD84 entries=8 实测命中, r06 进 VM, 零 gate 剩余)
>          / 双跑 103/103 byte-exact + ExitNative 17 站点零回踩

## 1. 项目主独立复验 (worktree --detach @ c04ca49)

| 项 | agent 自报 | 实测 |
|---|---|---|
| build / ctest | rc=0 / 16/16 | ✅ / ✅ **16/16** |
| **multiseed** | 150/150 (30 样本) | ✅ **TOTAL: 150 pass / 0 fail** (含新 jmp_table 样本 5/5) |
| **wvmpTest 满贯** | 14/14 | ✅ protect 实测 **stubs=14** + `jump-table @ 0xDD84 entries=8` (与我派单前直读实测的表坐标 0xDD84/8 项逐位吻合) + **still-gated markers = 空** |
| duff 功能 | 2 用例 PASS | ✅ `kern.duff_copy_matches_memcmp` + `flow.duff_device_matches_memcpy` 双 PASS |
| 双跑 byte-exact | 103/103 | ✅ rc=0×2 + **真实 diff 0 行** (test_target sha256 bdbfff91 未漂移, 亲验) |
| 零回踩 | ExitNative 17 站点 | ✅ 17 站点原样 + 145 既有 runs 含于 150 全绿 |
| 冻结契约 | 0 触及 | ✅ diff 文件面 grep: common/framework/backend/runtime.hpp/ir 零命中; **vm_op.hpp diff = 0 行 (D2 零新 VmOp 承诺兑现)** |
| 硬条款 | CLEAN 三连 | ✅ 主工作区 tracked 0 脏 + 在 main + 单分支 2-commit ff-safe——**连续第三单满分** |

## 2. 代码层核查

- **比较链实现 (translator.cpp:834 translate_jump_table)**: `Mov 目标RVA → LeaRva 转VA → Cmp 表值 → Jcc(E) → pending 回填块址` ×K + 末尾 Halt 兜底——纯既有 VmOp 组合, 目标块缺失时防御性二次 gate; 链尾 Halt = "计算值不在表内"的保守落点 (预扫描已证全 ∈ 表, 理论不可达, 双保险正确)
- **§E #33 实测修正两点 (agent 自曝, 合格)**: ① 匹配器放宽 lea/idx 载入顺序 (r06 实际载入在前, 与我派单模板序相反——它没硬套我的 §A 模板, 按实测放宽); ② **lifter build_blocks 死代码保留**——原规则把"只经表可达"的 case body 当死代码整体丢弃, 不改此处跳转表永远匹配不上。这是本单真正的隐藏深度所在, agent 自己挖出来并修好, 附 lifter 单测更新
- **ExitNative "17→17" 差异解释成立**: 我预测 18 错误——基线 17 中 r06 的 `ja 0xDD76` 本是 gate 前幻影站点, 本单转真实而非新增; 0xDD70 `jg` 是区内回跳非越区。**项目主 §A 预测第三次被实测纠正 (#33 家族), 解释链完整, 采纳**

## 3. known compromise (继承, GAPS C1 节已登记)

1. 仅 MSVC 4B-delta + `cmp K-1; ja` 防御形态; 8B 绝对表/clang mem 形态/无防御 → 照旧 gate (残余清单入 GAPS)
2. 比较链 O(K), K≤32 预算
3. 环境事件披露 (agent 工作期间主工作区外部 git reset 19:22)——即我 408→409 间隙的例行操作, 无实际冲突, 但 agent 观察到并披露, 合格

## 4. 处置与基线

1. ff-merge c04ca49 → main; MIT-409 → done
2. **multiseed 基线刷新: 30 样本 × 5 = 150/150** (旧 145 作废)
3. **wvmpTest 覆盖率长征收官: 1/14 → 2/14 (404) → 13/14 (407) → 14/14 (409)**, still-gated = 0
4. 清理: wvmp-mit409-v2 (我) + wvmp-mit409 (agent 留) worktree; 分支保留待归档
5. 下一棒候选: C4c 双访存 / Block F-G 保护强度线 (M3) / C5 x86 / wvmpTest 150 口径联动 (14/14 后 kernels 全 VM, 后续 shell 强度测试可在此基础上加)

## 5. 沉淀

- **"lifter 死代码规则与表可达性冲突"是本单最值钱的一发现**: 跳转表特化不是 translator 单点活, 区域块模型的可达性定义必须同步演进——未来任何"翻译期不可见但运行时可达"形态 (虚表/回调) 都会撞同一堵墙, 本单的死代码保留改动是通用前置
- 派单模板四件套的"寄存器/基址一致 + 防御常数推表长 + 全目标 ∈ 区"三道判据在真实编译器产物上第一次全中, 保守 gate 底线在放宽载入顺序后仍零让步——受限模板匹配路线 validated
- 站点账 "17±" 口径教训: 幻影站点 (gate 前直报) 与真实站点混在一个计数里易误读, D2b 起 diag 建议分 `exit-native (live)` / `exit-native (pre-gate)` 两型标注
