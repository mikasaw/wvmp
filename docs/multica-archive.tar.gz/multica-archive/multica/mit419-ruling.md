# MIT-419 (G4 lock 原子族) 裁定 — ACCEPT, 185/185, 超预期: xadd/bts 走硬件原子保真 + 自曝并钉死载体碰撞缺陷

> 裁定人: 项目主 — 2026-08-30 03:2x | 处置: ff-merge main=`92b21cb`, done
> 复验 worktree: ../wvmp-419-verify @92b21cb

## 1. 独立复验表
| 项 | 自报 | 实测 |
|---|---|---|
| build / ctest / multiseed | 185/185 | ✅ rc=0 / 16/16 / **TOTAL: 185 pass / 0 fail** (37 样本, 180 既有含于内) |
| wvmpTest 零回踩 | 14/14+103/103 | ✅ 亲测 stubs=**14** + jump-table@0xDD84 reg-4B-delta + ExitNative **17** + 双跑 **diff 0 行** + **lock-strip/string-op 误报=0** (wvmpTest 无 lock 面, note 域不串) |
| x64 零扰动 | — | ✅ rol 样本 旧 main CLI vs 419 CLI 同 seed: packed sha256 `cf159d01…` **IDENTICAL** |
| enum | kVmOpMax 86→90 append-only | ✅ vm_op.hpp:518-526 Xadd/Bts/Btr/Btc 括号内尾部; 跳表 128 余量充足 |
| backend 白名单对账 | lock-strip @ 进 | ✅ regvm_backend.cpp:152-155 四前缀齐 (exit-native/jump-table/string-op/lock-strip) |
| 冻结面 | callgate 禁触 | ✅ 13 文件清单直读: runtime.hpp/kFlagsMask/ir::Op/backend.hpp 抽象/callgate 段/kExitSlotDepth 零改 |
| 硬条款 | 命名分支+main 未动+切回 | ✅ `mit-g4-lock-atomic` 单 commit ff-safe + tracked 零脏 + 在 main——**命名分支铁律连 2 单满分** (417 首单+本单) |
| 时长 | ~45 分钟 | ✅ 02:25→03:07 run 窗口 ≈42 分钟, 与报告对账一致 (412/417 纪律吸收) |

## 2. 超预期亮点两项

**① xadd/bts 系 = 硬件原子性保真路线** (D1 授权"换路不算失败"的兑现): 我拍板的 strip-and-execute 是折条, 但 agent 对 **InterlockedAdd 真产物 `lock xadd`** 与 bts 系选了**单 VmOp + handler 内 native lock 指令直执行**——高频 Interlocked 路径上**原子性不妥协** (GAPS D1 边界文本诚实分列: 折条族有撕裂窗口 / 单指令族保真)。比我的先验方案更优, 且 bts 全宽位号装载绕开 keystone 0.9.2 拒 `bts [m],bl` 的 416 同族坑。

**② 载体域碰撞自曝钉死**: src2=imm(5..11) lock 标记**误撞 imul 3-op imm** (exitnative 样本 `imul rax,[rsp+0x40],7` 的 7 恰落标记域)——实测踩出后 op 限定 `is_lock_carrier_op` 修复 + translator:74-86 注释把碰撞案例焊死在代码里。**这是 src2=imm 载体技法 (302 imul 首创→415 string family→419 lock) 第三次踩域** (415 G3 family 0..4 分域、本次 5..11 分域+op 限定)——教训固化: **冻结 ir::Op 下用 imm 值域做侧信道载体, 每次新用必须全域对账现存值+新值×所有读 src2 的 op**, 待入 wvmp-dev pitfall。

## 3. #33 实测推翻先验 (四处, 全合格)
① `InterlockedExchange` 真产物是**裸 xchg 无 F0** (隐式锁) → translate_xchg MEM 无前缀形态补齐 (先验表按 lock xchg 写会漏) ② 带返回值 And/Or/Xor 在 /O1 编成 CAS 循环+prefetchw (白名单外→gate, 语义正确) ③ /O1×/RTC1 硬冲突 → MASM 按 helper 真产物字节兜底 ④ ml64 拒 `lock mov` → db 直发。§A.3 我先验表被改写的部分全部有实测字节支撑, 采纳。

## 4. 登记 (非阻断)
- **lock inc/dec 残余** (`_InterlockedIncrement` 真产物, agent 实测 CRT 高频)——**唯一实质缺口**, 折条复用 Inc/Dec 本体通路 = 半天级小单, 立为 G4b 候选 (可并 G6r 波)
- 无锁 bts reg 形式未入面 (声明); bts 未定义位跨 CPU 不承诺 (与原生行为面一致); MFENCE 全序不建模
- 负例通道 = capstone 拒解码→skipped_ranges→gate (与"白名单拒"不同 note 文本, 语义达成, 登记)

## 5. 基线与战线
**multiseed 权威基线: 37 样本 × 5 = 185/185**; wvmpTest 14/14 满贯保持。G 线余量: G4b lock inc/dec (小) → G6r AVX 侦察 (待拍板) → G7 P1 x86 (backlog, 跳表扩容前置) → W7 重启 410 (M3 强度线)。
