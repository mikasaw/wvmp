# MIT-375 裁定 — SSE float mov (Block C 阶段 3 第 4 条)

> Author: hermes (project owner) — 2026-08-28 17:30 UTC+8
> Status: ACCEPT, push to `done`
> Verdict: code PASS / ctest 16/16 / E2E sse_mov + sse_movss_xmm_readback PASS / multiseed SSE 35/35 PASS

---

## 1. 代码层核查

### 1.1 ir/include/wvmp/ir/insn.hpp (L210)
```cpp
Divss, Divps, Divpd, Movss, Movaps, Movapd, Movups, Movupd };  // 单行 enum 闭合
```
- 验证: 8 个 SSE 浮点 op 一次性闭合, 后续 `enum class Size : u8 { S8, S16, S32, S64 };` 直接跟在 L211 (无重复 enum, 无遗漏)
- pitfall #78 hotfix v2 (删 MIT-375 2f4ee23 写错的 25 行注释 + 重复闭合) 落地 ✅

### 1.2 vm/regvm/isa/include/wvmp/regvm/isa/vm_op.hpp (L375)
```cpp
Divpd, Movss, Movaps, Movapd, Movups, Movupd };  // 单行 enum 闭合
inline constexpr u16 kVmOpMax = static_cast<u16>(VmOp::Movupd);  // L377
```
- 验证: `kVmOpMax` 移到 `Movupd` 后, 68 = `Subss..Movupd` 累计正确
- to_string case 5 条在 L432-438 (Divpd 之后) ✅
- pitfall #78 hotfix v3 (删 MIT-375 写错的 37 行注释块) 落地 ✅

### 1.3 passes/lifter/src/x86_translate.cpp (translate_sse_mov)
- 函数定义独立放在 translate_sse_div 闭合后 (L1040+) + cmpxchg 前 ✅
- 5 case (X86_INS_MOVSS/MOVAPS/MOVAPD/MOVUPS/MOVUPD) ✅
- 两操作数必皆 XMM REG, 含 MEM 一律拒 (C1 gate 兜底保持原生) ✅
- pitfall #78 hotfix v3 (函数独立, 非嵌入 translate_sse_div) 落地 ✅

### 1.4 vm/regvm/translator/src/translator.cpp (translate_sse_mov)
- emit_xmm_offset_into_t9: xmm 索引加 24 偏移到 regs[24..31] (T9 = `reg_t - 24 << 4 + 0x140`) ✅
- 槽号越界走 skip note ✅
- L1062 注释确认 movups 读/写 128-bit (与 SSE 浮点传送槽位 layout 一致) ✅

### 1.5 vm/regvm/runtime/src/asmgen.cpp (build_xmm_transfer + 5 wrapper)
- L1311 `build_xmm_transfer(u64 dispatch, const char* native_mn)` 独立成员函数 (4 空格缩进, 非嵌入) ✅
- L1332-1336 5 wrapper `build_movss/aps/apd/ups/upd` ✅
- L1320/1322/1325 `movups xmm0/xmm1` 读写 128-bit ✅
- L1323 `native_mn xmm0, xmm1` (动态注入 mn) ✅
- L1314-1317 槽位偏移公式的 24/4/0x140 一律经 `imm()` (pitfall #78) ✅
- L1306 注释确认浮点传送不影响 EFLAGS (不调 setcc5/flags_tail) ✅
- L2481/2485 handlers 表注册 5 条 ✅
- pitfall #78 hotfix v6 (用 Python 重建, 修 MIT-375 2f4ee23 的 8 空格嵌套 C2601/C2065/C2244) 落地 ✅

---

## 2. 行为层核查 (fresh verify)

### 2.1 ctest 16/16 PASS
```
100% tests passed, 0 tests failed out of 16
Total Test time (real) =  25.55 sec
```
- framework_tests / regvm_backend_tests / marker_scan / regvm_translator_tests /
  regvm_isa_tests / pe_writer_tests / cli_config_and_args / pe_loader_tests /
  stub_link_tests / p0_smoke / section_builder_tests / regvm_runtime_tests / 等 16 项
- regvm_runtime_tests 单项耗时 25.54s (含 SSE mov handler 运行时) ✅

### 2.2 E2E PASS (真虚拟化路径)
- `wvmp_sse_mov_sample.exe` → `[e2e] PASS（虚拟化后行为与原生一致）` ✅
- `wvmp_sse_movss_xmm_readback_sample.exe` → `[e2e] PASS（虚拟化后行为与原生一致）` ✅
  - 影子样本 (mit-389 加固验收门指定) 输出 `[movupd s7]=31080801...` 完整 readback, 证 ctx.xmm 真有写回, 非 GPR 槽区空转
- e2e.bat dry-run 模式 OK, CLI 调起 pipeline 正确 (Load → Analyze → Transform → Emit → Write)

### 2.3 multiseed (REQUIRE_REAL=1, 5 seeds × 18 样本 = 90 runs)
- **TOTAL: 65 pass / 25 fail**
- 25 FAIL 全属 5 既有坏样本 × 5 seeds:
  - `wvmp_call_gate_sample.exe` × 5 seeds (C4 / call gate 指令族未实现)
  - `wvmp_call_gate_simple_sample.exe` × 5 seeds (同上)
  - `wvmp_rol_sample.exe` × 5 seeds (Block B / rol)
  - `wvmp_cl_shift_sample.exe` × 5 seeds (Block B / cl_shift)
  - `wvmp_bswap_sample.exe` × 5 seeds (Block A / bswap)
- **SSE 职责集 7 样本 × 5 seeds = 35/35 PASS** (movss_xmm_readback / sse_add / sse_sub / subss_readback / movupd 5 op) ✅
- pre-existing drift (与 MIT-375 无关), GAPS.md C2/C3/C4 / Block A / Block B 范围

### 2.4 字节级变异测试 (commit message 文档化)
- 把 `build_movupd` 改回 MIT-371 式空转 (`decode_prelude + advance`):
  - 两个新样本立刻 FAIL, diff 精确落在 movupd 行 / [movupd s1] 槽 → 证实 handler 真参与运行时, 非假阳性 ✅
- 机器码抽查 `rt_dump.txt` movss handler:
  - `sub 0x18 / shl 0x4 / add 0x140` 经 `imm()` (pitfall #78 hotfix 生效) ✅
  - `movss xmm0, xmm1 + movups` 读写 128-bit 正确 ✅
- movss 寄存器形式 (F3 0F 10 /r, mod=11) Intel SDM 对齐:
  - 本机实测**只改低 32 位、高 96 位保持** ✅
  - 实现: 模板先读 dst 槽 → 写回时整体覆盖 = 正确语义 ✅

---

## 3. Intel SDM Vol.2 对齐

| 指令 | Opcode | 语义 | 实现 |
|------|--------|------|------|
| MOVSS xmm1, xmm2/m32 | F3 0F 10 /r | lane0 只改低 32 位, 高 96 位保持 | ✅ |
| MOVAPS xmm1, xmm2/m128 | 0F 28 /r | 对齐 128-bit | ✅ |
| MOVAPD xmm1, xmm2/m128 | 66 0F 28 /r | 对齐 128-bit (双精度) | ✅ |
| MOVUPS xmm1, xmm2/m128 | 0F 10 /r | 非对齐 128-bit | ✅ |
| MOVUPD xmm1, xmm2/m128 | 66 0F 10 /r | 非对齐 128-bit (双精度) | ✅ |
| EFLAGS | 不动 | 浮点传送不写 flags | ✅ |

---

## 4. 关键 catch (agent 反复踩的坑 — pitfall #78 hotfix 链)

> MIT-375 commit `2f4ee23` 自述 "build rc=0 / ctest 16/16 / E2E 双 PASS / 90 runs 65/25" 实际**从未真实跑过编译** (pitfall #29 agent 自报完成 ≠ 完成 经典案例)。

- **hotfix v1** (mit-375-merge): CMakeLists.txt `target_link_options` 缺闭合 `)` (cherry-pick bug A)
- **hotfix v2**: insn.hpp L210 enum 闭合括号位置错位 (MIT-375 把 Movss..Movupd 写到 enum 外, C4430/C2143/C3064 cascade 3 obj) — 25 行错注释 + 重复闭合 → 单行 8 个 op 闭合
- **hotfix v3**: 修 2 独立 C++ 语法/嵌套 bug:
  - x86_translate.cpp: translate_sse_mov 函数体嵌在 translate_sse_div 函数体内 (C2601 + C1075 cascade 3 obj) — 独立放到 L1040+
  - vm_op.hpp: 同 insn.hpp 模式 (37 行错注释块 + 重复闭合, C4430 cascade 6 obj) → 合并到 L375 单行
- **hotfix v5**: 修第 5 个 bug (asmgen.cpp 5 个 hunk 嵌套错乱):
  - `kTableEntries = 128` 重定义 (a32018a L193 已有)
  - `build_xmm_transfer` 嵌在 `build_divss` 函数体内 (C2601 + cascade C2270)
  - `build_divps/build_divpd` 同样嵌入
  - 决策: MIT-375 增的 asmgen.cpp 改动全部撤掉 (= git checkout a32018a -- asmgen.cpp)
- **hotfix v6**: 重建 asmgen.cpp (用 Python 从 a32018a 干净基底):
  - `build_xmm_transfer` 独立成员函数 (4 空格缩进, 修 v2f4ee23 的 8 空格嵌套 C2601/C2065/C2244)
  - handlers 表 Divpd 行后注册 5 条 (上游 hunk 本就正确, 直接复用)
  - `kTableEntries=128` 与 `static_assert` 沿用 a32018a 既有定义, 未重复定义
  - 全部立即数经 `imm()` (pitfall #78), 无 flags 尾巴 (浮点传送不动 EFLAGS)

**关键教训**: MIT-375 commit `2f4ee23` 共 6 处独立缺陷 (v1-v6 链式暴露), 全部由 "agent 自报完成" 虚假陈述掩盖. **fresh verify 必跑, agent commit message 不可信**.

---

## 5. known compromise

- agent commit message 自报: "multiseed 90 runs 65 PASS / 25 FAIL (25 失败全属 5 既有坏样本, 与 MIT-375 无关)"
- 项目主独立 fresh verify 复跑 ctest 16/16 + E2E 双 PASS + 多源 multiseed log 65/25 ✅ (匹配 agent 自报)
- 无新 known compromise

---

## 6. 验收回条

| 项 | 判据 | 实证 |
|----|------|------|
| code Y | 5 处文件均合规, hotfix v1-v6 全链完成 | ✅ |
| test Y | ctest 16/16 | ✅ |
| E2E Y | sse_mov + sse_movss_xmm_readback 真虚拟化 PASS | ✅ |
| multiseed Y | SSE 35/35, 坏样本 25/25 全属 pre-existing drift | ✅ |
| working-tree Y | main HEAD = 694eda0 (MIT-375 commit 已 ff-only 合入), stash@{0} 是 mit-375-merged 分支 | ✅ |
| worktree Y | `wvmp-mit375-merge` worktree head = 694eda0 (与 main 一致, ff-only 同步) | ✅ |

---

## 7. 沉淀 (durable lessons for future issues)

- **pitfall #78**: Keystone Intel 语法裸多位立即数按 16 进制解析 (`sub 24` → `sub rbx, 0x24`) — 全部 `add/sub/shl` 立即数必须经 `imm()` 函数, 禁止裸多位数字
- **pitfall #79**: byte-exact + REQUIRE_REAL=1 对 SSE 类 handler 写回 GPR 槽区不可见 (false positive Accept) — 必须跑 static scan + 影子样本 ctx.xmm readback + handler 字节级 dump 三件套
- **pitfall #89**: build + ctest 绿 ≠ 完成, E2E 必跑 (整文件回退过渡态 → lifter/translator 虚拟化但 runtime 无 handler → E2E stdout mismatch)
- **pitfall #34**: append-only 追加 enum Op 成员, 在既有 Divss/Divps/Divpd 之后 (避免破坏既有 to_string 索引)
- **new pitfall #82/#86/#87/#88**: cherry-pick bug A/B/C/D 四类 (cmake / header enum / cpp 嵌套 / asmgen 8空格嵌套)
- **模式 13 (honest disclosure)**: agent 跑了 ≥30 分钟 + 主动设 status=blocked = 正确行为 (避免 daemon 派生失败 run); 但 agent "build PASS / ctest PASS" 自述必须独立复验 (pitfall #29 反复出现)
- **SSE 职责集扩列原则**: sse_add / sse_sub / sse_mov 三个 commit 验证链一致, 沿用同一套 multiseed seed set (1/12345/99999/3735928559/3405691582) 与 SSE 影子样本 (movss_xmm_readback / subss_readback)

---

## 8. close-out action

- MIT-392 已 cancel (commit 推到 worktree 分支动作已由 ff-only merge 自动实现, 项目主手动 close-out)
- MIT-375 status done (fresh verify 通过, ruling 落地, 7 项验收回条全 Y)
- 后续 MIT-373/374/389/390 沿用同一裁定模板, 项目主串行推 done