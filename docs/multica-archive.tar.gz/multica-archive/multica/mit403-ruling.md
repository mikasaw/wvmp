# MIT-403 (MIT-B2) 裁定 — callgate 栈回退常量派生化修复 + multiseed 基线 100/100

> Author: 接手人 (项目主) — 2026-08-29 10:30 UTC+8
> Status: **ACCEPT, push to `done`**
> Verdict: build rc=0 / ctest 16/16 / **multiseed REQUIRE_REAL=1 = 100 pass / 0 fail (历史首次全绿)** / B.2 同族 4 处一并派生化 / 两道 verifier 门 PASS / agent 自报与独立复验全吻合 (连续第二单)

## 1. 代码层核查 (main @ 43b3827)

- `runtime.hpp`: `kCtxSize = ((sizeof(VmContext)+15) & ~15) + 8` 上移为单一事实来源 + 双 static_assert (≥sizeof, ≡8 mod 16) ✅ — 直击根因性质: 消灭第二份拷贝
- `asmgen.cpp`: `kCallgateSpRollback = 2·kCalleeSavedPushBytes + kCtxSize + kCallRetBytes + kCtxPushBytes − kWinShadowBytes = kCtxSize + 0x68` + mod-16 static_assert (公式错位编译期即炸) ✅; 发射点经 `imm()` 合规 ✅
- **派生正确性独立核算**: 0x1C8+0x68 = **0x230** ✅ 且回代旧 0x140 → 0x1A8 与 bug 前时代常量吻合 (双向自洽)
- step 7 旧行 `o += "    sub rsp, 0x1A8\n"` 硬编码字符串 → `imm(kCallgateSpRollback)` ✅
- B.2 同族: stub `lea rax,[rsp+0x208]` → `hex(kStubPushBytes+kCtxSize)`、SSE 11× `imm(0x140)` → `imm(kCtxXmmBase)`、stub_gen 常量去重 — 14 处判定表逐处有依据, 抽查 #7 (0x28 shadow) / #11 (ctest 字节断言) 判定合理 ✅
- 冻结契约: 6 文件全在允许面 ✅

## 2. 行为层核查 (项目主独立 fresh verify, 分支态 worktree)

```
scripts/build.bat (Ninja, 全量)   → rc=0, 0 error
ctest                             → 100% tests passed, 16/16
multiseed REQUIRE_REAL=1          → [multiseed] TOTAL: 100 pass / 0 fail   ← 核心断言
  · 5 坏样本 × 5 seeds 全转 PASS (call_gate/call_gate_simple/rol/cl_shift/bswap)
  · 修复前 25 FAIL 清零; 其余 75 项零退化 (SSE 9 样本 45/45 含于内)
static_scan_bare_immediates.ps1   → RESULT: PASS
dump_handler_xmm_check.py (main 重生成 dump) → RESULT: PASS, 12 SSE handler 写回实证
  (WARNING: mov/ucomis 未注册 = MIT-376 D2.1 刻意设计, 非回归)
B.3 双探测实证: 删除 build/vs/ 镜像后 multiseed 直跑成功 → 镜像 hack 正式退役 ✅
```

agent 报告 12 项与上列逐项吻合, 无虚报 (含 bswap rc=139→0 的 byte-exact 细节)。

## 3. Intel SDM / ABI 对齐

回退量 mod-16 不变式与 Win64 影子空间 (0x28) / call ret (0x8) 摆位推导复核通过; 修复只动一个 rsp 常量, 指令语义面零触碰。

## 4. 关键 catch

- **注释早就写了正确答案而代码没人动** (asmgen.cpp:231-236 MIT-249 时代警告"callgate step 7 按 0x1C8 算, 实际需 0x1A0"→ 本单派生式与两条时代数值互证) — 文档-代码漂移的教科书案例; 派生化 (而非改魔数) 是唯一根治, D1.1 拍板正确。
- **崩溃在正确答案之后**: bswap 崩时 rax 已=0x78563412 — "不崩"不等于"算对", §E.4 强制 byte-exact 断言拦住了这类半修复。

## 5. known compromise

- 5 坏样本转 PASS 的路径是 callgate **真工作** (16/16 stubs cl_shift 全 VM 执行) — 无遗留降级。
- /MDd intrinsic 未内联 (bswap/rol → CRT call) 属工具链形态, D2.2 已留样本头哨兵注释; 换编译器版本可能静默流失 callgate 覆盖, 已披露。
- rol/cl_shift/bswap 修复收益: 既是 callgate 回归样本, 也同时使 C2 位运算族 multiseed 首获真 PASS 记录 (历史上它们从未全绿过)。

## 6. 验收回条

§E 1-12 全 ✅。commit `43b3827` @ `mit-b2-callgate-sp-fix` (main 直接子代, ff-only 安全) → **已 ff-merge main**。

## 7. 沉淀

- **新基线冻结: multiseed REQUIRE_REAL=1 = 20 样本 100/100**。自本单起所有派活单验收断言退化为"TOTAL: 100 pass / 0 fail"一行, 逐样本对 drift 的时代结束。
- 布局常量三件套纪律: 任何 sizeof/帧尺寸常量必须**单一来源 + 编译期派生 + mod 不变式 assert**, 禁止跨文件拷贝 — 建议入 wvmp-dev skill (pitfall #67 家族强化: 字段偏移有 offsetof assert 守护, 但"尺寸的消费方"此前无人守护)。
- B 线全程 = 分诊(项目主) → 定位(MIT-393 verifier) → 修复+刷新(MIT-403 cppdev) 三段式, 零返工, 模板可复制。
- 遗留小项: agent 完成时停在分支未切回 main (工作区签出 mit-b2 分支), 已由项目主代切 — 红派送 note 补一句"完工切回 main"。

## 8. close-out action

- `multica issue status MIT-403 done` ✅
- GAPS.md C3 行状态刷新 (callgate 静默破坏已修) + C2 复验记录 ✅ (随本裁定文档)
- wvmp-dev skill / MEMORY 基线刷新 ✅ (见 §7, 执行于 skill patch)
- 下一棒: C4 rip-relative 派单评估 (GAPS 建议序 3, 解锁"访问全局的真实函数")

== 完 ==
