# MIT-443 (X3a asmgen x86 核心, XL) 裁定 — ACCEPT；x86 VM 码体首次在真实 32 位进程内执行；x64 恒等 161,756B 逐字节铁证；十四连满分

> 裁定人: 项目主 — 2026-09-01 15:5x | 处置: ff-merge main=`4050a4c`, done
> 复验: agent 已自拆 worktree（硬条款第 8 条彻底执行）→ 项目主另建 `wvmp-x3a`@4050a4c 双 arch 独立重建亲跑

## 1. 独立复验（全部亲测，双 arch 零采信自报）
| 项 | 实测 (@4050a4c) |
|---|---|
| **x86 交叉构建链** | 我亲手重建 `build_x86_tests.bat` rc=0 → 产物 `file` 验真 **PE32 console** |
| **x86 电池真跑（B.5 验收核心）** | 我亲手在 WOW64 下跑 32 位电池 exe：**11/11 PASS rc=0**（902ms，BootHalt 空转闭环/AddSubFlags 五标志/CmpJcc 边界/LoopSum 回边/IncDecCF SDM 探针/FiveSeedStability 全在）|
| **x86 dump 门** | 我亲手带 `WVMP_RUNTIME_DUMP` 重跑电池 → 41,428B x86 转储 → `verify_x86_dump.py --asm` **PASS**（arch 标记+entry=+0x0 布局+19 handler 登记全覆盖+反汇编审）|
| **D6 x64 恒等铁证（XL 单最大风险项）** | 我亲手双 CLI 同 seed(12345) 转储对账：main@5ce27c7 vs 分支@4050a4c = **161,756 字节逐字节恒等**（sha `f67c2d40…` 双方一致，与报告数字吻合）——池 14→6 重构对 x64 分毫未扰 |
| asmgen 删除行审计 | `^-` 行仅：KsSession/AsmGen 签名参数化、4 处 static_cast（C4244）、generate_runtime 改名 wrapper 转发、handler 表 if/else 包裹——**x64 逻辑零删除** |
| multiseed / wvmpTest | 亲跑 **250/250**（REQUIRE_REAL=1）；分支 CLI 打壳 14 stubs + jt@0xDD84 + en=17 + 双跑 **diff 0 103/103**；ctest **16/16** |
| 冻结契约 | runtime.hpp/vm_op(97)/backend/cli/lifter/translator/stub_gen/markers/SDK diff = **0 行**；kCtxSize 0x1C8 冻结不破（pc/flags 走既有 ctx 槽 +0x8/+0x98 内存常驻释放 2 寄存器——巧解）|
| 硬条款 | 命名分支+main 未动+零脏+已切回 main（本次连 worktree 都自拆）+ff-safe+108 分钟对账（13:36→15:24）——**十四连满分** |

## 2. 预算 3-4 天 → 实际 108 分钟的完成度裁决
XL 定级来自 X0 §6 粗算（保守）；**完成度按 §B 逐项核**：B.1 五处分叉收敛 ✓ / B.2 池=实测 6 池+临时 4（X0"6"粗算被真数出来，esp 排除/ecx 保 cl/r8-r15 无 REX 排除；spill=固定栈帧 0x24 常量槽零动态 push/pop）✓ / B.3 D2 call-pop idiom+D3 8B 表项掩码零改动 ✓ / B.4 保存区裁决=维持 442 规则+三点理由（重排牵 stub_gen=X4 越单）✓ / B.5 电池 19 handler（派单要求 6-8，超额）✓ / B.6/B.7 ✓——**无缩水项，D5"不许缩电池"兑现**。判定：预算估计偏保守，交付质量与深度双高，非赶工。

## 3. #33 判定（双发现全合格）
① 电池首跑自炸出 size_chain_x86 缺陷（链尾顺延跌进 S64 防御 no-op 出口→S16 整路空转，6 例当场 FAIL）——**"电池优先于花活"的 D5 设计当场兑现价值**；修复=三路显式 cmp/je 分派+回归钉死。② rs() 复用度真验：X0 §7"已就位"只对一半——bpl/sil/dil 是 REX 专属名 32 位不可编码，x86 数据临时强制 {eax,edx,ebx} 抽取。另 6 处测试期望漏算 PF/S8 保高位=期望算错非 VM 错，SDM 逐位重算修正——方向判断正确。

## 4. X3b/X3c 地基确认
- X3b 批迁面清晰：其余 ~78 op 沿既有机制折叠 Halt（恢复友好），GAPS X3a 节含池映射表+交接注记（哪些 handler 真可跑/哪些纸面）
- X3c 挂账就位：CallGate reg-target（442 半程资产+本单 entry `[ebp+0x128]=esp` host_rsp 记账预留）、ExitNative 4B、x87 D1 一页备忘（§A.3 映射表归属 X3c 不变）
- **X4 stub_gen cdecl 的 ABI 锚已被电池 entry 实证**：push esi/call next/pop esi/sub base,6 + 4 callee-saved + cdecl ctx 指针 [esp+0x14]——stub 侧对齐此形即可

## 5. 遗留（非阻断）
X3a 电池 = runtime 直调通道（generate_runtime_x86 直接产码执行），非全管道（D1 未解锁维持，X5 拍板）——交接注记已写明；--code 二进制审面留 X4（脚本头注已披露）。
