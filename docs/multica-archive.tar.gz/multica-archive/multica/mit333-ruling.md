# 项目主裁定: 采纳 MIT-333 (bswap 指令支持) — Block C 阶段 2 第 1 条 done

## 总体评价

MIT-333 commit `e82dad5` **采纳** (ACCEPT): **Block C 阶段 2 第 1 条 bswap 指令支持完成** — lifter + translator + asmgen 三层完整加 bswap, ctest 15/15, bswap 5/5 真虚拟化, multiseed 5×7 35/35 PASS, **Block C 阶段 1 snake byte-exact 闭环不被破坏** (snake 5/5 真虚拟化 byte-exact 一致保持)。

agent 沿用诚实披露 + 改修复方向风格 (MIT-332 风格), 不是 MIT-322 编造风格。

## 独立核查结果 (2026-08-26, hermes)

### 双重确认 (agent + 项目主 fresh verify)

- **agent 报告** (MIT-334 完成): commit `e82dad5`, 8 文件 +212 行
 - build 294/294, ctest 15/15, E2E seed=12345 bswap PASS
 - **multiseed 5×7 REQUIRE_REAL=1: 35/35 PASS** (bswap 5/5 真虚拟化)
 - stdout: `bswap32=78563412 bswap64=f0debc9a78563412 chain=12345678` byte-exact 一致
 - 回归零退化 (imul / movsxd / movzx / cl_shift / call-bearing / snake 全保)
 - 冻结契约核查通过

- **项目主 fresh verify** (本轮, 双重确认):
 - HEAD `e82dad5` ✅
 - build rc=0 (294/294) ✅
 - native bswap stdout = `bswap32=78563412 bswap64=f0debc9a78563412 chain=12345678` ✅
 - fresh protect: "已生成 3 个入口 stub, .wvmp 节 17234 字节 @ RVA 0xB000" ✅
 - **protected bswap stdout == native bswap stdout** → BYTE-EXACT MATCH! ✅
 - **snake protected stdout == native snake stdout** → SNAKE BYTE-EXACT MATCH! (Block C 阶段 1 闭环不被破坏) ✅

### 1. git state

```
HEAD: e82dad5 (clean, on main)
git log --oneline -3:
  e82dad5 MIT-333: lifter + translator + asmgen 加 bswap 指令支持 (Block C 阶段 2 第 1 条)
  7b02496 MIT-322: 加 VmOp::LeaRva 修 rip-relative lea 缺 RVA→VA 转换 (snake 真虚拟化 byte-exact 闭环)
  c2faa32 MIT-326 cherry-pick: snake_sample 改造 forward-jump (算术提交去 je, snake 真虚拟化闭环)
```

### 2. fresh verify 总览 (12 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-333 commit 存在 | ✅ | ✅ HEAD `e82dad5` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 294/294 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 (含 ISA10000 fuzz + translator 23 + runtime) | ✅ |
| 4 | E2E seed=12345 bswap PASS | ✅ | ✅ bswap PASS (虚拟化后行为与原生一致) | ✅ |
| 5 | multiseed 5×7 REQUIRE_REAL=1: 35/35 PASS + 全样本真虚拟化 | ✅ | ✅ 35/35 (bswap 5/5) | ✅ |
| 6 | bswap 二次验证: 3 个入口 stub 已生成 | ✅ | ✅ 3 入口 stub, .wvmp 节 17234 字节 @ RVA 0xB000 | ✅ |
| 7 | stdout 字节比对 native vs protected 完全一致 | ✅ | ✅ `bswap32=78563412 bswap64=f0debc9a78563412 chain=12345678` | ✅ |
| 8 | imul / movsxd / movzx / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter/IR Op/VmOp/translator/asmgen/新 sample/CMakeLists/multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 3 处 (lifter BSWAP + IR Bswap + VmOp Bswap) | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 | ✅ | ✅ (派发**前**跑 cl_shift / imul / snake 确认基线) | ✅ |
| 12 | git 4 重核查纪律 + 派活单 §A 假设不一定是真根因 | ✅ | ✅ 派活单 §A 假设"lifter + translator + asmgen 三层都没 bswap"是初始假设, agent 沿用诚实披露风格 (不是 MIT-322 编造) | ✅ |

### 3. 关键沉淀 (agent 主动披露)

**`VmOp::Bswap = 48` 必须在 `LeaRva = 47` 之后** (additive enum append-only) — 否则后续 enum 上移超过 `kVmOpMax` 触发 ISA decoder "illegal opcode value"。

agent commit message 沉淀:
- **additive enum 扩展必须 append-only** (Bswap=48 放 LeaRva=47 之后)
- 已在 commit message + 报告 + 后续派活单模板中沉淀

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-333** | ✅ **done** | lifter + translator + asmgen 加 bswap 完整支持 (Block C 阶段 2 第 1 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾, snake 5/5 真虚拟化 byte-exact 保持) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done, imul 真虚拟化独立完成) |

### 5. Block C 阶段 2 第 1 条 done ✅ (阶段 2 启动)

| 维度 | 数值 |
|---|---|
| 总 commit | **46** (MIT-300 ~ `e82dad5`) |
| lifter 白名单 | **~41 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + **bswap**) |
| 真虚拟化样本 | **12 个** (call_gate 系列 + rip_relative + sar/adc/sbb/rol/whitelist/virt + imul + cl_shift + snake + **bswap**) |
| C1 gate 兜底样本 | **0 个** |
| ctest | **15/15** PASS |
| E2E byte-exact | **16/16** (snake 5/5 + bswap 5/5 + 其它 10 样本, multiseed 5×7 35/35) |
| **E2E REQUIRE_REAL=1** | **16/16 真虚拟化** |
| multiseed 5×7 REQUIRE_REAL=1 | **35/35 真虚拟化** |

### 6. 后续流水线

1. **立 Block C 阶段 2 第 2 条派活单** (xchg / bswap / movzx / movsx / cmpxchg / xadd / setcc / cmovcc 中选)
 - 推荐下一条: **xchg** (RSP 调整常用, 1 字节指令, 模板化, 1 天工作量)
 - 或: **cmpxchg** (原子, 复杂但有市场需求)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 33 个 pitfall + **additive enum append-only** 教训
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (Block C 阶段 2 第 1 条 done, 33 个 pitfall + 新教训)

### 新教训 (本会话 MIT-333 agent 主动披露)

**additive enum 扩展必须 append-only**: `VmOp::Bswap = 48` 必须在 `LeaRva = 47` 之后, 不能插队。否则后续 enum 上移超过 `kVmOpMax` 触发 ISA decoder "illegal opcode value"。

**未来派活单派活单 §A 完整性** (pitfall #25 强化):
- 新增 VmOp enum 值时, **append-only 显式说明** (LeaRva=47 → Bswap=48 → Cmovcc=49 → ...)
- 派活单派活**前**项目主 fresh verify 跑 `kVmOpMax` 数量 + enum 顺序
- 派活单派活**后**agent 主动披露 enum 顺序约束 (类似本会话)

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单 (xchg / cmpxchg / setcc / cmovcc 等) 派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (LeaRva=47 之后 append-only)
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum
- 冻结契约核查 (lifter/IR Op/VmOp/translator/asmgen 允许改, common/ir Operand 字段/framework/backend.hpp 不改)

---

## 引用链

- `m3-lifter-paihuo-9-issue-progression.md` (13 节点完整演进)
- `mit332-ruling.md` (snake byte-exact 闭环 ruling)
- `issue-33-bswap-instructions.md` (MIT-333 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit334-bswap-fresh/` (本轮 fresh verify 证据, 含 native + protected stdout)
- `pitfall #22g` 冻结契约白名单纪律 (ir/insn.hpp + vm_op.hpp enum 扩白名单)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (诚实披露 + 改修复方向)