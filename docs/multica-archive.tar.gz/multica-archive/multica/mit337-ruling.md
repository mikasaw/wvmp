# 项目主裁定: 采纳 MIT-336 (setcc 指令支持) — Block C 阶段 2 第 3 条 done

## 总体评价

MIT-336 commit `c79f665` **采纳** (ACCEPT): **Block C 阶段 2 第 3 条 setcc 指令支持完成** — lifter + translator + asmgen 三层完整加 setcc 16 variants (沿用 MIT-333 bswap + MIT-335 xchg 模板), 11 文件 (8 修改 + 3 新增), ctest 15/15, **setcc 5/5 真虚拟化 + native/protected BYTE-EXACT MATCH**, multiseed 5×9 45/45, **Block C 阶段 1+2 闭环保持** (snake 仍 byte-exact 一致)。

agent 主动披露新 pitfall: **MASM helper rax 跨 SDK marker_end 调用必存栈守恒** (SDK 内部 `mov rax, imm64` clobber rax, 必须存到 memory 备查)。

## 独立核查结果 (2026-08-26, hermes)

### 双重确认 (agent + 项目主 fresh verify)

- **agent 报告** (MIT-337 完成): commit `c79f665`, 11 文件, build 299/299, ctest 15/15, multiseed 5×9 REQUIRE_REAL=1: 45/45, setcc 5/5 真虚拟化
- **项目主 fresh verify** (本轮, 双重确认):
 - HEAD `c79f665` ✅
 - native setcc stdout = `setcc ne12=1 e12=0 b12=1 a12=0 l12=1 g12=0 ne55=0 e55=1 b55=0 a55=0 aneg=1 lneg=1` ✅ (16 variants 全部逻辑正确)
 - fresh protect: "已生成 6 个入口 stub, .wvmp 节 19122 字节 @ RVA 0xB000" ✅
 - **protected setcc stdout == native setcc stdout** → **SETCC BYTE-EXACT MATCH!** ✅
 - **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

### 1. git state

```
HEAD: c79f665 (clean, on main)
git log --oneline -3:
  c79f665 MIT-336: lifter + translator + asmgen 加 setcc 指令支持 (Block C 阶段 2 第 3 条)
  44052e9 MIT-334: lifter + translator + asmgen 加 xchg 指令支持 (Block C 阶段 2 第 2 条)
  e82dad5 MIT-333: lifter + translator + asmgen 加 bswap 指令支持 (Block C 阶段 2 第 1 条)
```

### 2. fresh verify 总览 (12 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-336 commit 存在 | ✅ | ✅ HEAD `c79f665` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 299/299 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E seed=12345 setcc byte-exact | ✅ | ✅ setcc byte-exact | ✅ |
| 5 | multiseed 5×9 REQUIRE_REAL=1: 45/45 PASS | ✅ | ✅ 45/45 (setcc 5/5 + bswap 5/5 + xchg 5/5 + snake 5/5) | ✅ |
| 6 | setcc 二次验证: 6 个入口 stub | ✅ | ✅ 6 入口 stub, .wvmp 节 19122 字节 @ RVA 0xB000 | ✅ |
| 7 | **stdout 字节比对: SETCC BYTE-EXACT MATCH** | ✅ | ✅ 16 variants 全部逻辑正确 | ✅✅✅ |
| 8 | bswap / xchg / imul / movsxd / movzx / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter/IR Op/VmOp/translator/asmgen/新 sample/MASM helper/CMakeLists/multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 9 处 | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 | ✅ | ✅ (派发**前**跑 bswap / xchg / snake 确认基线) | ✅ |
| 12 | git 4 重核查纪律 + additive enum append-only + MASM helper (pitfall #31 + #34 + #35) | ✅ | ✅ Setcc=50 append-only Xchg=49 之后, MASM helper 强制 codegen | ✅ |

### 3. 关键设计决策 (agent 实施 + 项目主确认)

| 维度 | 内容 |
|---|---|
| **派活单 §A 假设对** | 派活单 §A 假设 "lifter + translator + asmgen 三层都没 setcc" 真对, agent 沿用派活单 §A 字面执行 |
| **additive enum append-only** | VmOp::Setcc=50 (在 Xchg=49 之后, pitfall #34), ir::Op::Setcc=50 (同样位置) |
| **cond 复用** | setcc 条件码复用 ir::Cond (与 Jcc 共享 16 条件枚举, 4-bit cond_or_size 字段), 不加新 SetccCondition enum (派活单 §C 决策4 精简路径) |
| **lifter 16 variants case** | 加 X86_INS_SETE/SETNE/.../SETNO 16 variants case + map_setcc_cond (cc → 0-15) |
| **MASM helper rax 跨 SDK marker_end 调用必存栈守恒** | SDK 内部 `mov rax, imm64` clobber rax, 必须存到 memory 备查 (新 pitfall, agent 主动披露) |

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-336** | ✅ **done** | setcc 指令支持 (Block C 阶段 2 第 3 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

### 5. Block C 阶段 2 第 3 条 done ✅ (阶段 2 推进, 3 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **48** (MIT-300 ~ `c79f665`) |
| lifter 白名单 | **~43 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + **setcc 16 variants**) |
| 真虚拟化样本 | **14 个** (call_gate 系列 + rip_relative + sar/adc/sbb/rol/whitelist/virt + imul + cl_shift + snake + bswap + xchg + **setcc**) |
| ctest | **15/15** PASS |
| E2E byte-exact | **18/18** (含 setcc) |
| **E2E REQUIRE_REAL=1** | **18/18 真虚拟化** |
| multiseed 5×9 REQUIRE_REAL=1 | **45/45 真虚拟化** |

### 6. 后续流水线

1. **立 Block C 阶段 2 第 4 条派活单** (cmpxchg / setcc / cmovcc / movzx 8→16/16→64 / movsx 等)
 - 推荐下一条: **cmovcc** (条件 mov, 模板化, 1-2 天) 或 **movzx 8→16/16→64** (cl_shift 已覆盖部分, 补全)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 35 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒**
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (Block C 阶段 2 第 3 条 done, 35 → 36 个 pitfall)

### 新教训 (本会话 MIT-337 agent 主动披露, pitfall #36 候选)

**MASM helper rax 跨 SDK marker_end 调用必存栈守恒**: SDK 内部 `mov rax, imm64` clobber rax, 必须存到 memory 备查 (不能依赖 rax 跨 SDK marker_end 调用保存值)。

未来 M3 阶段 2 中频指令派活单 (setcc / cmpxchg / cmovcc / 等) 测试 fixture MASM (.asm) helper 设计:
- (a) 必存栈守恒: SDK 内部 rax/rbx 跨调用易 clobber, helper 内部必 push/pop 或 mem
- (b) setcc helper emit 16 variants 真字节 (`0F 90+cc+rm` REG 形式)
- (c) Jcc 共享同一 cond_or_size 字段 (pitfall #22g 冻结契约白名单纪律, additive 兼容)

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Setcc=50 之后 append-only)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 调用必存栈守恒** (pitfall #36 候选)
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum
- 冻结契约核查

---

## 引用链

- `m3-lifter-paihuo-10-issue-progression.md` (15 节点完整演进)
- `mit333-ruling.md` (bswap ruling)
- `mit335-ruling.md` (xchg ruling)
- `mit336-ruling.md` (xchg verifier ruling, 接受)
- `issue-36-setcc-instructions.md` (MIT-336 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit337-setcc-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335 实证)
- `pitfall #34` additive enum append-only (MIT-333 实证, MIT-335/337 实战体现)
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen (MIT-335 实证, MIT-337 实战体现)
- **pitfall #36 候选** (本会话新增): MASM helper rax 跨 SDK marker_end 调用必存栈守恒 (MIT-337 agent 主动披露)