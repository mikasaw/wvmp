# MIT-438 (X1b ret imm16 清栈) 裁定 — ACCEPT；x64 静默炸弹修复反证亲手复现；十二连满分

> 裁定人: 项目主 — 2026-09-01 11:3x | 处置: ff-merge main=`110a6aa`, done
> 复验: 亲用 agent 保留 worktree wvmp-x1b@110a6aa 产物（复用零重建，437 同款配合）
> 备注: 盯盘 monitor 于 02:53 后停更（本机进程中断），run 实际 02:53 已 completed——回收由本次验收触发，非交付问题

## 1. 独立复验（全部亲测非采信自报）
| 项 | 实测 (@110a6aa) |
|---|---|
| ctest / **multiseed** | **16/16 亲跑** / **TOTAL: 245 pass / 0 fail**（49 样本×5，240 既有零回踩 + retimm 5/5）|
| **x64 全链反证（D4 硬项，我亲手双侧）** | 修复前 main 2dad6ff CLI: 3 stub **零 gate note**（静默面实证）→ packed **rc=3221225477 (0xC0000005) + 空 stdout**；修复后分支 CLI: packed `stdret8 bal=0 ret=36 …` **byte-exact=native rc=0**——X0 🔴1 定性完全兑现："非 gate 非静默通过，是栈失衡行为错误" |
| CLI arch 四象限 | **亲手跑全过**: Q1 x64声明+x64=rc0 / Q2 x86声明+x64=rc2"arch=x86 与目标 machine=0x8664 不符" / Q3 x64声明+x86=rc2 / **Q4 auto+x86=rc2 硬拒原样（D1 不回退）** |
| D2(i) 选型 | translator `case Op::Ret` aux 载 imm（低 16 掩码，SDM C2 iw 无符号不加宽——注释钉死）plain ret→aux=0≡D3 边界；**kVmOpMax=97 不动、零跳表扩容** |
| build_ret 终态链 | 直读: `kRetFrameDiscard=0x210` 派生式+**static_assert 钉**、`kRetGuestRspFromNs=0x1D8` 派生、"出口不走 HALT 通道"（物理 rsp 无法表达清栈→handler 内复刻 stub 终态链，ExitNative 先例）——尺寸常量单一来源纪律合规；#33 对账诚实（**本 op 此前无 handler，跳表指 Halt**——X0 §3.1"pop-ret-addr handler 在 asmgen"实为"不存在"，agent 复核纠正）|
| SEH/FS 实测表（🔴2）| capstone x86 32 位模段前缀落 prefix[1]/mem.segment=FS/mem.base=INVALID 逐字段单测钉 + 判据链直读（prefix[1]≠0 入口闸→C1，无静默 flat-drop 旁路）——GAPS gate 文本+两情形区分+矩阵行落位 |
| 冻结面/互斥 | runtime.hpp/backend/callgate/载体域零触；**X1a 面（marker_scan/src+sdk）零 diff**（tests/CMakeLists 仅追加共存）；kCtxSize 不动 |
| 硬条款 | 命名分支+main 未动+零脏+ff-safe+73 分钟对账——**十二连满分** |

## 2. 诚实披露清单核查（六条遗留全合格）
①x86 面纸级（pop 宽度分叉归 X4）②MASM `ret 0`→C3 优化形（translator imm=0 档钉等价）③清栈量 mod-16 约束取 10h/C3/90h + imm=8 走 runtime 电池——**良构 stdcall 清栈恒 ≡0 mod 16 的洞见值得记**④未配平 push 写穿=ExitNative 同款登记面 ⑤retf 语料未现文档一句 ⑥**dump 门 WARNING 审阅面 +1（`ret` 被列 unregistered=HALT 链复刻的 movups 写回，非 SSE 计算面）——主动披露不私改 checker**，处置正确（登记：X4 收口时随 handler 注册表统一审阅）。

## 3. 裁定与排程
ACCEPT，ff-merge main=`110a6aa`，**权威基线 49 样本 × 5 = 245/245 刷新**。多目标平台: X0 ✓ X1a ✓ X1b ✓ → **X2a translator arch 分叉（M，含 leave 0.37% 顺路 + x87 三路线 D1 拍板点）** 可开工。派单 §A 素材: X1b 已把 Ret aux 通道/build_ret 骨架留好（X2a 消费面），X0 triage §1.4 fork 面（call [mem]/plain movsd/S16 p66）+ leave 折条是本单主体。
