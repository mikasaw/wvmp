# 项目主裁定: 采纳 MIT-341 (cmpxchg 指令支持) — Block C 阶段 2 第 5 条 done

## 总体评价

MIT-341 commit `799fc11` **采纳** (ACCEPT): **Block C 阶段 2 第 5 条 cmpxchg 指令支持完成** — lifter + translator + asmgen 三层完整加 cmpxchg (沿用 MIT-333 bswap + MIT-335 xchg + MIT-337 setcc + MIT-339 cmovcc 模板), build rc=0, **cmpxchg 5/5 真虚拟化 + native/protected BYTE-EXACT MATCH**, multiseed 5×11 55/55, **Block C 阶段 1+2 闭环保持** (snake 仍 byte-exact 一致)。

## 双重确认 (agent + 项目主 fresh verify)

- **agent 报告** (MIT-342 完成, 跑了 40 分钟真完成): commit `799fc11`, build 301/301, ctest 15/15, multiseed 5×11 55/55, cmpxchg 5/5 真虚拟化
- **项目主 fresh verify** (本轮, 双重确认):
 - HEAD `799fc11` ✅
 - native cmpxchg stdout = `cmpxchg s64_eq_same=5 s64_eq_diff=42 s64_ne_eq=5 s64_ne_ne=100 s32_eq_same=5 s32_ne_ne=100` ✅ (64-bit eq/same + 64-bit eq/diff + 64-bit ne/eq + 64-bit ne/ne + 32-bit eq/same + 32-bit ne/ne 全部逻辑正确)
 - fresh protect: "已生成 4 个入口 stub, .wvmp 节 21042 字节 @ RVA 0xB000" ✅
 - **protected cmpxchg stdout == native cmpxchg stdout** → **CMPXCHG BYTE-EXACT MATCH!** ✅
 - **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

### 1. git state

```
HEAD: 799fc11 (clean, on main)
git log --oneline -4:
  799fc11 MIT-341: lifter + translator + asmgen 加 cmpxchg 指令支持 (Block C 阶段 2 第 5 条)
  fea06dd MIT-339: lifter + translator + asmgen 加 cmovcc 指令支持 (Block C 阶段 2 第 4 条)
  c79f665 MIT-336: lifter + translator + asmgen 加 setcc 指令支持 (Block C 阶段 2 第 3 条)
  44052e9 MIT-334: lifter + translator + asmgen 加 xchg 指令支持 (Block C 阶段 2 第 2 条)
```

### 2. fresh verify 总览 (12 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-341 commit 存在 | ✅ | ✅ HEAD `799fc11` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 301/301 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E seed=12345 cmpxchg byte-exact | ✅ | ✅ cmpxchg byte-exact | ✅ |
| 5 | multiseed 5×11 REQUIRE_REAL=1: 55/55 PASS | ✅ | ✅ 55/55 (cmpxchg 5/5 + cmovcc 5/5 + setcc 5/5 + bswap 5/5 + xchg 5/5 + snake 5/5) | ✅ |
| 6 | cmpxchg 二次验证: 4 个入口 stub | ✅ | ✅ 4 入口 stub, .wvmp 节 21042 字节 @ RVA 0xB000 | ✅ |
| 7 | **stdout 字节比对: CMPXCHG BYTE-EXACT MATCH** | ✅ | ✅ 6 variants 全部逻辑正确 | ✅✅✅ |
| 8 | cmovcc / setcc / bswap / xchg / imul / movsxd / movzx / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter/IR Op/VmOp/translator/asmgen/新 sample/MASM helper/CMakeLists/multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 9 处 | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 | ✅ | ✅ (派发**前**跑 cmovcc / setcc / bswap / xchg / snake 确认基线) | ✅ |
| 12 | git 4 重核查纪律 + additive enum append-only + MASM helper (pitfall #31 + #34 + #35 + #36 + #37) | ✅ | ✅ Cmpxchg=52 append-only Cmovcc=51 之后, MASM helper 强制 codegen | ✅ |

### 3. 关键设计决策 (agent 实施 + 项目主确认)

| 维度 | 内容 |
|---|---|
| **派活单 §A 假设对** | 派活单 §A 假设 "lifter + translator + asmgen 三层都没 cmpxchg" 真对, agent 沿用派活单 §A 字面执行 |
| **additive enum append-only** | VmOp::Cmpxchg=52 (在 Cmovcc=51 之后, pitfall #34), ir::Op::Cmpxchg=52 (同样位置) |
| **acc 隐式 rax/al 标注** | IR 字段 acc 标注, translator emit VmOp::Cmpxchg (3 操作数, 隐式 acc + 显式 dst + 显用 src) |
| **MASM helper rax 跨 SDK marker_end 栈守恒** | 沿用 MIT-337 pitfall #36 路径 |
| **asmgen `cond_eval` clobber T1 寄存器** | 沿用 MIT-339 pitfall #37 路径, 必 save src to T6 first |
| **lock prefix 不支持** | 派活单限定, 涉及 atomic 语义, 需独立 issue 调试 VM runtime |
| **acc 必保存/恢复** | cmpxchg 隐式 RAX, 必 save/restore (pitfall #36) |
| **ZF flag writes/reads 必恢复** | dispatch 后必恢复 ZF |

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-341** | ✅ **done** | cmpxchg 指令支持 (Block C 阶段 2 第 5 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

### 5. Block C 阶段 2 第 5 条 done ✅ (阶段 2 推进, 5 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **50** (MIT-300 ~ `799fc11`) |
| lifter 白名单 | **~45 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + **cmpxchg**) |
| 真虚拟化样本 | **16 个** (call_gate 系列 + rip_relative + sar/adc/sbb/rol/whitelist/virt + imul + cl_shift + snake + bswap + xchg + setcc + cmovcc + **cmpxchg**) |
| ctest | **15/15** PASS |
| E2E byte-exact | **20/20** (含 cmpxchg) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |

### 6. 后续流水线

1. **立 Block C 阶段 2 第 6 条派活单** (movzx 8→16/16→64 / movsx / popcnt / lzcnt / tzcnt)
 - 推荐下一条: **movzx 8→16/16→64** (cl_shift 已覆盖部分, 补全) 或 **popcnt** (位计数, 模板化)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 37 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber T1 → T6 save**
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (Block C 阶段 2 第 5 条 done, 沿用 37 个 pitfall)

### 关键沉淀 (本会话)

- ✅ cmpxchg 5/5 真虚拟化 + native/protected BYTE-EXACT MATCH (64-bit + 32-bit, REG-REG, 4 个入口 stub)
- ✅ snake 仍 byte-exact 闭环 (Block C 阶段 1+2 闭环保持)
- ✅ multiseed 5×11 55/55 (cmpxchg 5/5 + cmovcc 5/5 + setcc 5/5 + bswap 5/5 + xchg 5/5 + snake 5/5)
- ✅ **MIT-341 没掉进派活单派发后 agent 跑了 8 步就 completed 模式** (沿用 MIT-339 v1 → v2 重新派遣纪律 + pitfall #29 派活单派活后 agent run failed 重新派遣纪律 + 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"), agent 跑了 40 分钟真完成
- ✅ 派活单 §A 假设对 (沿用 MIT-339 风格, agent 沿用派活单 §A 字面执行, 不需改修复方向)
- ✅ acc 隐式 rax/al 标注 (cmpxchg 特有, 类似 setcc/cmovcc 的 cond 字段)
- ✅ lock prefix 不支持 (派活单限定, 涉及 atomic 语义, 需独立 issue 调试)

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Cmpxchg=52 之后 append-only)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **acc 隐式 rax/al 字段** (cmpxchg 特有, 标注 IR acc 字段, 派活单限定 lock prefix 不支持)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证): 沿用 pitfall #29 重新派遣纪律
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only)
- 冻结契约核查

---

## 引用链

- `m3-lifter-paihuo-11-issue-progression.md` (16 节点完整演进)
- `mit339-ruling.md` (cmovcc ruling, 采纳 + 3 catch + pitfall #37 候选)
- `mit341-ruling.md` (cmovcc verifier ruling, 接受)
- `issue-40-cmpxchg-instructions.md` (MIT-341 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit342-cmpxchg-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- **pitfall #38 候选** (本会话新增): 派活单派发后 agent 跑了 8 步就 completed, daemon 5 分钟 auto-termination 模式 (MIT-339 v1 实证)