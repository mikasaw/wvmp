# 项目主裁定: 采纳 MIT-309 (lifter imul MEM 形式支持 + multiseed 改进)

## 总体评价

MIT-309 commit `63789cc` (git commit message 标 "MIT-306", Multica 派单标 MIT-309) **采纳** (ACCEPT)。**派活单核心目标 (imul 真虚拟化) 达成**: `wvmp_imul_sample` 5/5 seed 真虚拟化, 3 个入口 stub per seed。**snake 部分闭环**: imul 部分已修 (从多条 → 0 条 imul 警告), C1 gate 仅来自 movsxd。**双重确认** (verifier 报告 + 项目主 fresh verify) 全部一致。

## 独立核查结果 (2026-08-25, hermes)

### 双重确认 (verifier + 项目主 fresh verify)

- **verifier 报告**: `.multica/mit309-verifier-report.md` (13,539 字节, 完整 11 节)
- **项目主 fresh verify** (bash 避开 rtk):
  - build rc=0, 292/292, ctest 15/15 PASS
  - imul sample 5/5 真虚拟化 (`已生成 3 个入口 stub`)
  - snake 二次验证: imul 警告消失, C1 gate 仅来自 movsxd

### 1. git state

```
HEAD: 63789cc3f2b9489bd83d1f642cf5d2970378b766 (clean, main)
MIT-309 commit: 63789cc (git message 标 MIT-306, Multica 标 MIT-309)
改动: 5 文件 +233/-42 (lifter +52, lifter tests +107, scripts +22, multiseed_real 新+12, translator +82)
```

### 2. fresh verify 总览 (与 verifier 一致)

| 项 | 结果 |
|---|---|
| HEAD | 63789cc (clean, main) |
| build | rc=0, **292/292** (0 警 0 错) |
| ctest | **15/15 PASS** (24.69s, 含 7 新 imul MEM 单测) |
| E2E | **14/14 byte-exact** (verifier 跑, agent 报 13) |
| **imul 真虚拟化** | ✅ **5/5 seed, 3 stub per seed** |
| multiseed 5×6 byte-exact | **30/30 PASS** |
| **multiseed REQUIRE_REAL=1** | ✅ **20/30 真虚拟化, 10/30 C1 gate** (call_gate / call_gate_simple / rol / imul PASS; snake / cl_shift FAIL) |
| **snake 二次验证** | ✅ imul 0 条警告, C1 gate 仅 movsxd (2 条) |
| 冻结契约核查 | ✅ 5 文件, 未追加 src3/src4 |

### 3. imul sample 真虚拟化硬证据 (bash 跑)

```
$ bash verify_imul.sh
PASS seed=1 (real virtualization, 3 stub)
PASS seed=12345 (real virtualization, 3 stub)
PASS seed=99999 (real virtualization, 3 stub)
PASS seed=3735928559 (real virtualization, 3 stub)
PASS seed=3405691582 (real virtualization, 3 stub)
---
Real: 5/5, C1 gate: 0/5
```

**与 verifier 报告完全一致**。

### 4. snake 二次验证硬证据 (bash 跑)

```
[wvmp] [warning] marker_scan: end@0x6c4 没有配对的 begin（区域被丢弃）
[wvmp] [warning] marker_scan: end@0x81d 没有配对的 begin（区域被丢弃）
[wvmp] [note] lifter: (marker@0x501) @rva 0x4450: 未支持指令 'movsxd' ，已跳过
[wvmp] [note] lifter: (marker@0x501) @rva 0x4477: 未支持指令 'movsxd' ，已跳过
[wvmp] [note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化（保持原生）:
   函数 (marker@0x501): lifter 跳过 2 条指令 (rva/size 列表), IR 缺字节, 触发 C1 gate
[wvmp] [warning] virtualize: 没有任何函数被虚拟化
[wvmp] [warning] stub_link: 无已虚拟化函数，跳过 stub 生成
```

**关键观察**:
- ✅ **无 "未支持指令 'imul'" 警告** → imul 全部被 lifter 接住
- ✅ C1 gate 现来自 **movsxd** (2 条) 而不是 imul → imul 部分闭环
- ✅ 与 verifier 报告 §8 预测完全一致

### 5. 派活单预先标记 4 个隐藏问题 (MIT-305 verifier 抓) 全部修复

| # | MIT-305 隐藏问题 | MIT-309 状态 |
|---|---|---|
| 1 | imul sample 0% 真虚拟化 | ✅ 5/5 真虚拟化 (3 个入口 stub per seed) |
| 2 | 冻结契约头越权 (src2 撤回?) | ✅ src2 保留, 未追加 src3/src4, 未越权 |
| 3 | 测试盲区 (6 个新单测全 register-only) | ✅ 7 个新单测全部 MEM 形式 + 1 回归 |
| 4 | multiseed 30/30 误导 | ✅ REQUIRE_REAL=1 加入, 20/30 vs 10/30 C1 gate 暴露 |

### 6. 派活单验收逐条核对 (9 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-309 commit 存在 | ✅ | ✅ HEAD `63789cc` 标 MIT-306 | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15, 24.69s | ✅ |
| 4 | E2E byte-exact | ✅ 13/13 | ✅ 14/14 (verifier 全跑) | ✅ |
| 5 | **imul sample 真虚拟化** | ✅ | ✅ 5/5 seed, 3 stub per seed | ✅ |
| 6 | multiseed 5×6 byte-exact | ✅ 30/30 | ✅ 30/30 | ✅ |
| 7 | **multiseed REQUIRE_REAL=1** | imul + 4 call-bearing PASS | ✅ call_gate / call_gate_simple / rol / imul PASS, snake / cl_shift FAIL | ✅ |
| 8 | **snake 二次验证** | imul 部分闭环 | ✅ imul 0 条, C1 gate 仅 movsxd | ✅ |
| 9 | 冻结契约核查 | 仅改 lifter + translator + scripts + tests | ✅ 5 个文件, 未追加 src3/src4 | ✅ |

### 7. 关键技术成果

**lifter `translate_imul` 三形式全接 (REG-REG / REG-MEM / REG-MEM-IMM)**:
- REG-MEM 2-op: `48 0F AF 44 24 28` (imul rax, [rsp+0x28])
- REG-MEM 2-op diff disp: `48 0F AF 44 24 48` (imul rax, [rsp+0x48])
- REG-MEM-IMM 短 (imm8): `48 6B 44 24 30 07` (imul rax, [rsp+0x30], 7)
- REG-MEM-IMM 短 (imm100): `48 6B 44 24 30 64` (imul rax, [rsp+0x30], 100)
- REG-MEM-IMM 短 diff base: `48 6B 44 24 28 64`
- REG-MEM-IMM 长 (imm32): `48 69 44 24 28 E8 03 00 00` (imul rax, [rsp+0x28], 1000)

**translator 折 MEM → Load + Imul 两条技巧**:
- 3-op imm MEM: emit Load (tmp:=[mem]) + Mov(dst, tmp) + Mov(scratch, imm) + Imul(dst, scratch) = 4 条 VM 字节码
- 2-op MEM: emit Load (tmp:=[mem]) + Imul(dst, tmp) = 2 条 VM 字节码
- scratch 预算 6 内, 安全

**multiseed 改进 (REQUIRE_REAL=1)**:
- 默认 REQUIRE_REAL=0, 30/30 byte-exact (兼容现有 CI)
- 显式 REQUIRE_REAL=1 时, grep `已生成` + `stub` 区分真虚拟化 vs C1 gate

### 8. 状态结论

**MIT-309 status**: **done** ✅

**阶段 1 进度**:
- ✅ MIT-301 cl_shift: lifter 实现完整 (但 sample 仍 C1 gate 因 movzx 跳出)
- ✅ MIT-305 imul: REJECT (派活单设计缺陷, 未控制 MSVC /Od 真实 codegen)
- ✅ MIT-309 imul MEM 修复: **真虚拟化达成** (派活单预先反汇编验证是关键)
- 🕒 MIT-307 movsxd: 待派 (snake 部分闭环, 还有 25 条 movsxd)

### 9. 后续行动

1. **立刻派 MIT-307 (movsxd)** — snake 25 条 movsxd 是真虚拟化最后一公里
2. **派活单派活前反汇编验证** (沿用 MIT-309 模式): capstone disassemble `wvmp_snake_sample.exe`, 列 25 条 movsxd 字节编码给 agent
3. **mit30x-ruling 写完 snake 闭环后**, 改 MIT-300 → done (snake 真虚拟化)
4. **cl_shift (MIT-301) 仍 C1 gate 因 movzx**, 留后续派 (MIT-308+, 中频指令)

## 沉淀 (Block C 阶段 1 重要经验)

### 派活单设计三连失败 → 第四次成功

| 派活单 | 失败 / 成功 | 关键差异 |
|---|---|---|
| **MIT-300 snake** | ❌ 失败 | imul + movsxd 跳出 |
| **MIT-301 cl_shift** | ❌ 失败 | movzx 跳出 (类型扩展) |
| **MIT-305 imul** | ❌ REJECT | lifter 仅接 REG-REG, MSVC 实际产 REG-MEM |
| **MIT-309 imul MEM** | ✅ 成功 | **派活单派活前反汇编验证** 列字节编码给 agent |

**MIT-309 派活单的关键改进**:
- §A 反汇编验证: capstone disassemble `wvmp_imul_sample.exe`, 列 11 条 imul 的真实字节编码 (RVA + 字节 + 形式)
- §B 项目主决策: 接受 `Operand src2` 字段 (扩冻结契约白名单), 不撤回
- §B 决策 2: MEM 形式折成 REG 形式 (translator 层处理, asmgen 不改 MEM 路径)

### verifier 实战价值 (MIT-308 vs MIT-311)

**MIT-308 verifier (imul REG-REG)** 抓到 4 个隐藏问题:
1. 核心目标未达成
2. 冻结契约越权
3. 测试盲区
4. multiseed 误导性

**MIT-311 verifier (imul MEM)** 9/9 项通过 + 1 个改进建议:
- multiseed REQUIRE_REAL=0 默认合理 (兼容现有 CI)
- 显式 REQUIRE_REAL=1 触发区分需求

### 派活单派活前反汇编是强制纪律

每个补指令派活单,项目主前必须:
1. capstone disassemble 目标 E2E 样本
2. 列所有相关指令的 RVA + 字节 + 形式
3. 列在派活单 §A (派活前反汇编验证)
4. agent 拿真实字节编码实现

### multiseed 改进 (REQUIRE_REAL=1) 实战价值

**改进前**: 30/30 byte-exact, 但不知道是真虚拟化还是 C1 gate
**改进后**: 
- REQUIRE_REAL=0 默认 (兼容 CI): 30/30
- REQUIRE_REAL=1 (显式区分): 20/30 真虚拟化, 10/30 C1 gate

**MIT-309 验证**: 跑 REQUIRE_REAL=1 暴露 C1 gate 样本 (snake/cl_shift), 防止假 PASS。

### 冻结契约白名单扩展 (additive 兼容)

- MIT-305 `Operand src2` 字段: 已 additive 兼容, 撤回成本高
- 派活单显式允许: 后续 3-op 指令 (ROL r/m, imm 等) 允许 `Operand src3` / `Operand src4`
- 每次追加须在派活单明示
- 当前 MIT-309 未追加 src3/src4 (冻结契约未越权)

### 派活单编号混乱问题 (verifier 抓到)

verifier §建议 2 提到: 派活单 issue 标 MIT-309, git commit 标 MIT-306, 不一致。**下次派活单建议编号对齐** — 派活单文件路径 + issue 编号 + git commit message 三者一致。

## MIT-309 沉淀 (阶段 1 第一个真虚拟化成功)

**这是阶段 1 第一个派活单真虚拟化达成**:
- ✅ imul sample 5/5 seed 真虚拟化
- ✅ snake 部分闭环 (imul 修)
- ✅ multiseed 改进 (REQUIRE_REAL=1)
- ✅ 派活单派活前反汇编验证纪律

**阶段 1 剩余工作**:
- MIT-307 movsxd (snake 25 条 movsxd, 真虚拟化最后一公里)
- cl_shift movzx 修复 (留阶段 2 中频指令)