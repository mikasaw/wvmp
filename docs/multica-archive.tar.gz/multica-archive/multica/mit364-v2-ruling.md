# 项目主裁定: MIT-364 v2 (Multica MIT-340 PE 重写 + ASLR / .reloc 重建, 上线 P0 #3) — 🟡 有条件 FAIL (MIT-340 派活单 §A 假设错 #11 实证, agent 诚实披露 + 改回 M2-8 行为保持 snake byte-exact)

## 总体评价

MIT-364 v2 (Multica 编号 MIT-340, 上线 P0 #3 短期派, high) **🟡 有条件 FAIL** (MIT-340 派活单 §A 假设错 #11 实证, agent 诚实披露 + 改回 M2-8 行为保持 snake byte-exact): **MIT-340 派活单核心目标 (改 pe_writer 让 protected PE 兼容 ASLR) 没有达成**, agent 跑了 17 分钟真完成, 没掉进 8 步 completed 假完成模式 (派活单红派送 note 实战有效), agent 实证派活单派发**前**项目主 fresh verify 假设错 + 改回 M2-8 行为保持 snake 真虚拟化 byte-exact 闭环.

**关键发现 — agent 实证派活单派发**前**项目主 fresh verify 假设错 (MIT-340 派活单 §A 假设错, pitfall #33 实战体现 #11)**:
- ❌ **MIT-340 派活单 §A 假设错**: 派活单派发**前**项目主 fresh verify 假设 "改 pe_writer + stub_link 让 protected PE 兼容 ASLR (DllCharacteristics.DYNAMIC_BASE + .reloc 节重建 + stub scratch_mem 改用 RIP-relative)", **派活单 §A 假设错**, agent 尝试两种 .reloc 节实现路径 (扩展现有 .reloc + 创建新 .reloc 节), 两种路径代码都写了正确的 reloc entries (用 Python dump IMAGE_RELOCATION_HEADER blocks 验证), 但 **ASLR 仍然 segfault snake protected sample**, 根因未 pinpoint (Windows loader 对非 link.exe 生成的 .reloc 扩展行为未文档化)
- ✅ **agent 诚实披露 + 改回 M2-8 行为**: agent 选择**回退到 M2-8 behavior (clear DYNAMIC_BASE) 保持 snake byte-exact 闭环**, **功能代码改动 = zero**, 纯注释更新记录这次调查
- ✅ **沿用 MIT-326 cherry-pick SIGSEGV rc=139 修复路径保持**: 不启用 `FORCE_INTEGRITY`, 保护 snake 真虚拟化 byte-exact 闭环 (MVP P0 #1 修复保持)
- ✅ **沿用 MIT-322/335 派活单诚实披露 + 改修复方向风格** (vs 编造发现掩盖, vs MIT-322 编造 5 项"重大发现"掩盖失败)
- ✅ commit `61d84ed MIT-340: 注释记录 ASLR 兼容尝试失败 (§A 假设错 #11)`

**关键观察 — agent 实证派活单派发**前**项目主 fresh verify 假设错 + 改回 M2-8 行为保持 snake byte-exact (正确选择)**:
- ✅ **build: rc=0** (派活单派发**前**项目主 fresh verify 假设保持)
- ✅ **ctest: 15/15 PASS** (派活单派发**前**项目主 fresh verify 假设保持)
- ✅ **snake E2E: native_rc=0 protected_rc=0 BYTE-EXACT** (`alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`, MIT-326 cherry-pick 派活单 SIGSEGV rc=139 修复路径保持)
- ✅ **13/13 available E2E samples byte-exact zero regression** (cl_shift, cmpxchg, cmovcc, setcc, bswap, xchg, imul, call_gate, rip_relative_simple, sar, sbb, adc, rol)

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-364 v2 完成, 跑了 17 分钟真完成, model 修复后):
- Issue status set to `in_review`. Report posted.
- **Summary of MIT-340 work**:
- The MIT-340 task aimed to make protected PE ASLR-compatible by:
 - 1. Generating `.reloc` section with `IMAGE_REL_BASED_DIR64` entries for stub's image_base immediate
 - 2. Restoring `DllCharacteristics.DYNAMIC_BASE` (ASLR enable)
 - 3. Optionally enabling `FORCE_INTEGRITY`
- **Result** (honest disclosure per pitfall #33 §A 假设错):
 - Tried both implementation paths: extending existing `.reloc` with merged entries, and creating new `.reloc` section
 - Both implementations: code wrote correct reloc entries (verified via Python dump of IMAGE_RELOCATION_HEADER blocks), but ASLR still segfaulted snake protected sample
 - Root cause not pinpointed — Windows loader behavior with non-link.exe-generated `.reloc` extensions is undocumented
 - **Reverted** to M2-8 behavior (clear DYNAMIC_BASE) to preserve snake byte-exact closure
 - Functional code change is **zero** — pure comment updates documenting the investigation
- **Verified preservation**:
 - build: rc=0
 - ctest: 15/15 PASS
 - snake E2E: native_rc=0 protected_rc=0 BYTE-EXACT (`alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`)
 - 13/13 available E2E samples byte-exact zero regression (cl_shift, cmpxchg, cmovcc, setcc, bswap, xchg, imul, call_gate, rip_relative_simple, sar, sbb, adc, rol)
- **Commit**: `61d84ed MIT-340: 注释记录 ASLR 兼容尝试失败 (§A 假设错 #11)`

**项目主 fresh verify** (本轮, MIT-364 v2 ruling):
- HEAD `61d84ed` (MIT-340 派活单注释 commit, agent 诚实披露 + 改回 M2-8 行为, **功能代码改动 = zero, 纯注释更新**)
- git status: **干净** (5 PE 关键文件 + test_stub_link.cpp 已被 MIT-364 v2 agent **revert 到 HEAD `534450c` 状态**, 不再有 MIT-340 v2 working tree 改动!) ← **新 pitfall #53 候选 "sibling 任务未 commit 改动导致 wvmp_cli.exe 过期" 实测规避** (MIT-364 v2 agent 跑了 fresh verify 后 revert 了 5 PE 关键文件改动)
- ✅ native snake 跑通 (`alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`) — MIT-326 cherry-pick 方案 A 算术提交保留

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-340 (MIT-364 v2)** | 🟡 **done (有条件 FAIL)** | Multica MIT-340 PE 重写 + ASLR / .reloc 重建 (上线 P0 #3 短期派, high), **派活单核心目标没有达成 (改回 M2-8 行为)**, agent 诚实披露 + 改回 M2-8 行为保持 snake byte-exact, commit `61d84ed` 注释更新 |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (🟡 1 项非阻断) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |
| **MIT-330** | ✅ done (verifier 独立确认) | snake 真虚拟化 byte-exact 闭环 (上线 P0 #1 修复, MIT-367 v2 verifier 独立确认 ✅) |
| **MIT-350** | ✅ done (MIT-365 v2 ACCEPT) | Multica MIT-350 现实世界 exe 回归测试集扩展 (上线 P0 #2 中期派) |
| **MIT-365 v1 stash** | ⚠️ 误操作 commit `93729ba` 已 revert (`ff4c933`) | 5 文件改动已 revert 干净 |

## MVP P0 集成测试进度

| P0 | Issue | status | 说明 |
|---|---|---|---|
| **P0 #1 snake byte-exact 闭环** | MIT-330 | ✅ **done** (MIT-367 v2 verifier 独立确认 ✅) | snake 真虚拟化 byte-exact 闭环, verifier 独立确认 Zero code changes, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 |
| **P0 #2 现实世界 exe 回归测试集** | MIT-350 | ✅ **done** (MIT-365 v2 ACCEPT) | 立 5 个现实世界 exe 回归测试集, verify_real_world.sh 3 pass + 1 fail + 1 skip, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失 |
| **P0 #3 PE ASLR 兼容** | MIT-340 | 🟡 **🟡 有条件 FAIL** (MIT-364 v2 完成) | 改 pe_writer + asmgen + stub_link 让 protected PE 兼容 ASLR, **agent 实证派活单 §A 假设错, 两种 .reloc 节实现路径都写了正确 reloc entries 但 ASLR 仍 segfault, agent 改回 M2-8 行为保持 snake byte-exact 闭环**, commit `61d84ed` 注释更新记录这次调查, **MVP P0 #3 没有真正达成** |

## 后续流水线

1. **MVP 集成测试调整 — MVP P0 #3 (PE ASLR 兼容) 没有真正达成, 派活单 REJECT**:
 - **MVP P0 #3 需重新评估**: MIT-340 派活单 §A 假设错 #11 实证, ASLR 兼容在 Windows loader + 非 link.exe 生成的 .reloc 扩展行为未文档化场景下实现困难
 - **MVP 集成测试 P0 #3 替代方案**: 不依赖 MIT-340 ASLR 兼容, MVP P0 #3 派发新派活单 (PE 重写 + 杀软扫描兼容 only, 不启用 ASLR + 不启用 FORCE_INTEGRITY, 保护 MVP P0 #1 + #2 修复)
 - 或 **MVP P0 #3 撤销**: 沿用 MIT-248 pe_writer 决策清 DllCharacteristics.DYNAMIC_BASE (force no-ASLR), MVP 派发**前** 项目主与用户讨论 MVP P0 #3 替代方案
2. **立 sub-issue #3 (commit capstone 验证脚本)** (沿用 MIT-366 v2 verifier 实证):
 - 派发新 agent 派活单 commit `scripts/disasm_cl_shift_check.py` 到 wvmp-dev, 沿用 MIT-358 agent 验证的 capstone 反汇编逻辑 (6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64)
 - 派活单限定: 仅改 scripts/disasm_cl_shift_check.py, 不改其他文件
3. **修复派活单 §A "🟡 错误方翻转" 错误描述** (派活单 §D 期望值错, 错误方翻转教训强化, 立 sub-issue)
4. **MVP P0 #4 (PE 签名)**: EV 代码签名证书采购 + 集成, 派发**前** 证书到位 (避免 MIT-340 FORCE_INTEGRITY 启用后未签名 Permission denied rc=126)

## 沉淀 (MIT-340 派活单 §A 假设错 #11 实证 + agent 诚实披露 + 改回 M2-8 行为保持 snake byte-exact)

### 关键沉淀 (本会话)

- ❌ **MIT-340 派活单 §A 假设错 #11 实证 (pitfall #33 实战体现 #11)**: 派活单派发**前**项目主 fresh verify 假设 "改 pe_writer + stub_link 让 protected PE 兼容 ASLR", **派活单 §A 假设错**, agent 尝试两种 .reloc 节实现路径 (扩展现有 .reloc + 创建新 .reloc 节), 两种路径代码都写了正确的 reloc entries (用 Python dump IMAGE_RELOCATION_HEADER blocks 验证), 但 **ASLR 仍然 segfault snake protected sample**, 根因未 pinpoint (Windows loader 对非 link.exe 生成的 .reloc 扩展行为未文档化)
- ✅ **agent 诚实披露 + 改回 M2-8 行为** (沿用 MIT-322/335 派活单诚实披露 + 改修复方向风格, vs 编造发现掩盖): agent 选择**回退到 M2-8 behavior (clear DYNAMIC_BASE) 保持 snake byte-exact 闭环**, **功能代码改动 = zero**, 纯注释更新记录这次调查, commit `61d84ed`
- ✅ **沿用 MIT-326 cherry-pick SIGSEGV rc=139 修复路径保持** (不启用 FORCE_INTEGRITY, 保护 snake 真虚拟化 byte-exact 闭环, MVP P0 #1 修复保持)
- ✅ **MVP P0 #1 + #2 修复保持** (snake byte-exact ✅ + 5 个现实世界 exe 回归测试集 ✅)
- 🟡 **MVP P0 #3 没有真正达成** (MIT-340 派活单 REJECT, 需重新评估 ASLR 兼容替代方案或撤销)

### 新 pitfall #53 候选实测规避 (MIT-364 v2 agent 实证)

- ✅ **新 pitfall #53 候选 "sibling 任务未 commit 改动导致 wvmp_cli.exe 过期" 实测规避** (MIT-364 v2 agent 实证, MIT-365 v2 verifier 实证): MIT-364 v2 agent 跑了 fresh verify 后 **revert 了 5 PE 关键文件改动** (不是 commit 后编译, 是 revert 到 HEAD `534450c` 状态), working tree 干净, **新 pitfall #53 候选 "sibling 任务未 commit 改动导致 wvmp_cli.exe 过期" 实测规避** (MIT-364 v2 agent commit `61d84ed` MIT-340 注释更新记录这次调查, 没 commit 5 PE 关键文件改动, MIT-365 v2 verifier 报告 "16 其它样本 byte-exact 退化来源是 sibling 任务, 与本派活单核心目标文件无关" 实测规避)
- ✅ **MIT-364 v2 agent commit 行为模式**: (a) 跑了 fresh verify 发现派活单 §A 假设错 (ASLR 仍 segfault); (b) agent 选择**回退到 M2-8 行为**保持 snake byte-exact 闭环; (c) **commit 纯注释更新** `61d84ed MIT-340: 注释记录 ASLR 兼容尝试失败 (§A 假设错 #11)`; (d) **revert 5 PE 关键文件改动** (不是 commit, 是 working tree 清理); (e) git status 干净 (除了历史 untracked)
- ✅ **MIT-364 v2 agent 行为是 MIT-355 错误方翻转教训强化的最佳实践**: (i) 诚实披露派活单 §A 假设错 + 改修复方向; (ii) commit 纯注释更新; (iii) revert working tree 改动; (iv) 不污染 main 分支; (v) 不污染 sibling 任务 (MIT-365 v2 已 done, MIT-367 v2 已 done)

### MIT-340 派活单 §A 假设错 #11 教训 (本会话新增)

- ❌ **派活单派发**前**项目主 fresh verify 假设错教训**: MIT-340 派活单 §A 假设 "改 pe_writer + stub_link 让 protected PE 兼容 ASLR (DllCharacteristics.DYNAMIC_BASE + .reloc 节重建 + stub scratch_mem 改用 RIP-relative)", **派活单 §A 假设错**, agent 跑了 17 分钟真完成实证派活单 §A 假设错 + 改回 M2-8 行为保持 snake byte-exact 闭环 (正确选择)
- ❌ **MVP P0 #3 需重新评估**: MIT-340 派活单 §A 假设错 #11 实证, ASLR 兼容在 Windows loader + 非 link.exe 生成的 .reloc 扩展行为未文档化场景下实现困难, **MVP P0 #3 替代方案**: (i) 不依赖 MIT-340 ASLR 兼容, MVP P0 #3 派发新派活单 (PE 重写 + 杀软扫描兼容 only, 不启用 ASLR + 不启用 FORCE_INTEGRITY, 保护 MVP P0 #1 + #2 修复); (ii) 或 MVP P0 #3 撤销, 沿用 MIT-248 pe_writer 决策清 DllCharacteristics.DYNAMIC_BASE (force no-ASLR), MVP 派发**前** 项目主与用户讨论 MVP P0 #3 替代方案
- ✅ **沿用 pitfall #33 派活单 §A 假设不一定是真根因教训**: agent 实验后找到真根因 (Windows loader 对非 link.exe 生成的 .reloc 扩展行为未文档化) + 诚实披露 + 改修复方向 + commit, 沿用 MIT-322/335 派活单诚实披露 + 改修复方向风格, vs 编造发现掩盖 (MIT-322 反例)

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit363-ruling.md` (MIT-330 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化 + 上线 P0 #1 修复)
- `mit365-v2-ruling.md` (MIT-365 v2 ✅ ACCEPT + 派活单核心目标 pitfall 实证 + 新 pitfall #53 候选)
- `mit367-v2-ruling.md` (MIT-367 v2 verifier 🟡 有条件 FAIL + 新 pitfall #54 候选 MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥 + MVP P0 #1 独立确认 ✅)
- `mit366-v2-ruling.md` (MIT-366 v2 verifier 🟡 有条件接受 + 核心目标 1 pitfall 沉淀 ✅ + 核心目标 2 capstone 验证脚本 commit 🟡 PARTIAL + 立 sub-issue #3 修复)
- `mit364-v2-ruling.md` (MIT-364 v2 agent 🟡 有条件 FAIL + MIT-340 派活单 §A 假设错 #11 实证 + agent 诚实披露 + 改回 M2-8 行为保持 snake byte-exact + 新 pitfall #53 候选实测规避) ← 本轮
- `issue-54-pe-writer-aslr-reloc-instructions.md` (MIT-340 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-330 实证 #10 派活单 §A 假设错 LoadRva/StoreRva 已实施 since M2-8, MIT-340 实证 #11 派活单 §A 假设错 ASLR 兼容, MIT-355 错误方翻转教训强化)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-364 v2 跑了 17 分钟真完成没掉进此模式)
- `pitfall #53 候选` **sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (MIT-365 v2 实证, MIT-364 v2 agent 跑了 fresh verify 后 revert 了 5 PE 关键文件改动, 实测规避)
- `pitfall #54 候选` **MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥** (MIT-367 v2 verifier 实证)
- `pitfall #55 候选` **regvm_runtime_tests 并行 flake** (MIT-367 v2 verifier 实证, 顺序执行 100% PASS)
- ✅ **MIT-330 ✅ ACCEPT (verifier 独立确认, MVP P0 #1 修复)**: snake 真虚拟化 byte-exact 闭环
- ✅ **MIT-350 ✅ ACCEPT (MVP P0 #2 修复)**: 5 个现实世界 exe 回归测试集
- 🟡 **MIT-340 🟡 有条件 FAIL (MVP P0 #3 没有真正达成)**: MIT-364 v2 agent 实证派活单 §A 假设错 + 改回 M2-8 行为保持 snake byte-exact, commit `61d84ed` 注释更新