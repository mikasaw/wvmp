# MIT-453 (X5c ExitNative x86 上界接线修复) 裁定 — ACCEPT；407 机制在 PE32 复活（en 0→17, wvmpTest x86 真虚拟化 0→9）+ 第 6 个现网盲区当场修（imul 3-op 丢源）；硬条款破例记：agent 越权 ff 合入 main, 已还原后正式合并

> 裁定人: 项目主 — 2026-09-02 21:4x | 处置: **main 由我 reset 回 `9647a13` 后正式 ff-merge `4083b1f`**, done
> 复验: 双 CLI 对照亲跑（旧=main 修复前重建 / 新=分支）——全部亲测

## 0. 纪律违规记录（本裁定的前置事项）
agent 交报前**自行 `git merge --ff-only` 把分支合入了 main**（reflog `4083b1f HEAD@{0}: merge …Fast-forward` 铁证）——违反派单 §D.5"main 未动（工作期）"字面与"裁定在项目主、合并在项目主"的二十一连默契惯例（报告把"切回 main（ff-only 合入）"偷换成合入动作本身）。处置: 因分支 ff-safe 线性、交付质量经全链复验, **不回退不重交**；我 reset 还原 9647a13 后由我执行正式合并。**记: 硬条款第二十一单违规一次（性质=越权非造假, 全证据链真实）; X 波后续单派活硬条款加"禁自行 merge, 合入权在项目主"显式句。**

## 1. 独立复验（我亲手双 CLI 对照）
| 项 | 实测 (@4083b1f vs 修复前 main) |
|---|---|
| **A.3 读数表（本单总验收）** | 修复前: en=0 / jtbn=17 / stubs=0 → 修复后: **en=17 / jtbn=0 / stubs=9** 全中; 残面（间接jmp/stack-depth 辅助计数）分布不变——**stubs 9≠10 失配归因成立**: 452 预估漏第 5 个 b59b 函数含 div→VmOp::Div(78) 撞 x86 白名单（G8 已入册）→ stub_link C2 gate 如实浮出（修复前被 jtbn 掩盖）——**保守方向正确, D5 归因铁律兑现, 我复跑同读数** |
| **wvmpTest x86 双跑（我亲手 ×2 packed）** | native 103/103 → packed **rc=0、111 行输出、native-vs-packed diff 0、run-vs-run 恒等**——12 处 ExitNative 真执行首入全量语料 |
| **B.5 x64 恒等（第 7 次亲验）** | 双 CLI 同 seed asm_dump 均 `ffd47289…`/161,861B 逐字节——imul 修复 src==dst 路径字节不动兑现 |
| tailexit 新样本（我亲手） | stubs=2 / **en=4 / gate-note=2（越节尾负例 E9 形命中）/ machine=0x14C / byte-exact**——B.2 双形反证在池成立 |
| multiseed / ctest / 电池 / dump 门 | 亲跑 **320/320**（64 样本=50+14）/ 16/16 / 37/37 / PASS |
| D3 边界亲核 | translator 改动**单 hunk @:2090（translate_imul）**、判定链区"跳转目标块"零命中、backend lambda 条件序 pdata 在前原样、kCtxSize/vm_op(97)/载体域全冻结; 主仓 .deps `wvmp-x` 零命中（agent 1.1G 独立拷贝, 450 坑纪律兑现）|

## 2. 第 6 个现网盲区: imul 3-op src≠dst 丢源（本单含金量最高处）
双跑首炸 md5 kernel AV（cdb: eip=.wvmp+0x693, edx=0xCF288CB3=md5 F 值）→ 字节码解码定位: 旧折叠注释先验"**MSVC /Od imul r,r,imm 恒 src==dst**"**被实测推翻**（idx7 实含 `imul edx,ecx,3` 4 处 + imm=0 形 3 处被巧合掩盖）——src 被丢成 dst*imm = **静默错值级**（比崩溃更毒）。修复=src≠dst 先 Mov 物化（同 MEM-3op 路径先例）+ 双向单测。**x64 语料为何 315 全绿不炸**: 现池 imul 样本恰全 src==dst——又是"每支持一族翻一颗旧雷"模式（P0/P1/ret-imm16/S16-push/mul64hi→本例第 6 颗）。D3 越字面批准: 改动在链外、独立 hunk 可 revert、不推翻 452 结论——§E"当场炸当场修照贴"的正确姿势。

## 3. 三处 #33 全合格
① 行号重钉（lambda 漂移至 :100-160/:119/:120）; ② 节尾口径实测论证（VirtualAddress+VirtualSize 不对齐——[内容尾,对齐面) 是零填充"放进即崩"）; ③ **节尾 cap 收紧化**（ub=min(next_begin, 节尾) 比 F1 原文保守, 多执行节病态布局兜底, 单测④钉+现网读数零差）——批准, 比派单字面更稳。MASM 坑实录（.data 标签 jmp 组装成 FF 25 间接形, 直跳须手编码 E9）入册。

## 4. 泛化读数（452 接线级缺口的修复完成确认）
**PE32 全客户面上 407 ExitNative 机制自此复活**——"任何无 .pdata 目标恒不可达"泛化结论对应修复落地; 真实客户占比按 452 §5 待 X5c 后 436 方法学重扫（残 gate 面 13=wvmpTest 口径）。

## 5. 合入后基线
**main=`4083b1f`, 权威基线 64 样本 ×5 = 320/320**; x64 dump 底稿 `ffd47289` 不变。x86 残 gate: push-imm 11 / 间接 jmp 1 / stack-depth 1（mul64hi 类, esp-resync 前瞻在案）+ Div 族白名单（b59b 新实撞, C2 类后续派单素材）+ SSE 32（X3d 待拍）+ x87 永久 gate（定稿）。
