# MIT-423 (G4b) + MIT-424 (G6r) 合并裁定 — 双 ACCEPT；423 ff-merge 基线 190/190；424 路线裁决 R2 采纳

> 裁定人: 项目主 — 2026-08-30 16:5x | 423: ff-merge main=`123bf09` done | 424: done (零代码) + 路线拍板

# 裁定 A: MIT-423 (G4b lock inc/dec) — ACCEPT（硬条款三连满分）

## A.1 独立复验 (@123bf09 worktree 亲测)
| 项 | 自报 | 实测 |
|---|---|---|
| build/ctest/**multiseed** | 190/190 | ✅ rc=0 / 16/16 / **TOTAL: 190 pass / 0 fail** (38 样本) |
| 新样本 | 8 stub+11 note | ✅ 亲跑: **stub=8 + lock-strip note 11 + gate 2**; 语义值全对 (inc64=1e12/dec64 负值回绕/inc_rip rip 通道); 双跑 byte-exact |
| wvmpTest 零回踩 | 14/14 | ✅ stubs=14 + jump-table + ExitNative 17 + **diff 0 行** + lock/string 误报 0 |
| 对账清单 (一票否决项) | §3 四项 | ✅ 直读核实: enum 双镜像 12/13 同步 (lifter:1441/translator:73)、carrier +Inc/Dec (:89)、**Operand 默认 kind=None 比"Imm 0"更强的安全论证** (src2.kind==Imm 恒假)、imul 不误拦回归用例 ×2 (7 + 12/13 双锁) 在位 |
| 419 面零触碰/D4 | 5..11 不重排 | ✅ diff 文件面: runtime.hpp/vm_op.hpp/asmgen/backend/ir 零触及; append-only 12/13 |
| 硬条款 | 全 | ✅ 命名分支+main 未动+tracked 零脏+切回 main+单 commit ff-safe+53 分钟对账一致——**三连满分** |

## A.2 #33 两处推翻我的先验（合格，采纳）
① **§A.3 真产物先验证伪**: `lock inc/dec` (`f0 ff 06`) 根本非 MSVC 产物——/O2 与 /Od 双档 /FAcs 实测 `_InterlockedIncrement` 全编成 **`lock xadd +1` 内联**（返回值语义决定），已走 419 硬件原子通路。裸形态=手写/第三方面。② D1 我暗示的"丢增量更隐蔽"被逐条反驳: 折条撕裂窗口结构同 lock add 类、inc/dec 唯一构造点不写 src2、CF 保留语义 build_incdec 现成——**native 换路收益=零产物覆盖**。裁决: 折条方案成立，且这是"先验被数据修正后方案反而更简单"的正例。
D2 not/neg 续 gate + **可调用负例**（区别于 #UD 负例）设计聪明。

## A.3 登记（非阻断）
S8 锁字节 inc gate（无产物支撑，白名单+1 行即开）/ §7.4 db 手编 ModRM 误编 TEST /1 插曲（cdb 自定位修正——手编 F7 组纪律素材）。

# 裁定 B: MIT-424 (G6r AVX 侦察) — ACCEPT，路线裁决 = **R2 采纳**（项目主拍板 2026-08-30）

## B.1 复验
- triage 207 行全读，五路互证（45 探针矩阵 + System32 4354→86 全扫 49 阳性 + E2E 六区域三态 + 成本量化 + 代码核验）
- **派单方（我）6 处被修正**，抽查采信：④ **VEX 不经 legacy prefix 数组**（C4/C5/EVEX prefix 全零，直达 switch default→gate）——我 §A.1 猜错，机制级纠正影响后续所有前缀类派单；⑤ 719→723（我方计数方法差，认）、跳表余量 37；② "标量升 VEX" 强化为 **/arch:AVX 下 100% SSE 升 VEX**（38 条全 VEX legacy=0）——**档A 从"优化项"升格为"必要项"，这是本侦察最重要的数字**
- B.2 三态：**VEX+EVEX 全谱零逃逸**（上报义务未触发）=现状"半 R3"，与 x87 同构验证
- 50 分钟对账 ✅；主仓零扰动 ✅（并发披露含 423 的 6 文件改动识别）；留样内嵌报告（416 教训吸收）✅

## B.2 路线拍板（对齐 G 线总排程）
1. **档A（VEX.128 折叠，零新 VmOp，M 级）→ 立单 `MIT-G6a`，排在 G1b 之后**——采纳其"G1b 先行/同波"建议的理由: VEX 整数/mul V-对直接复用 G1b 的 SSE2 整数与 mul 族产物，串行反而省 G6a 半张单
2. **档B（ymm）不永久 gate 措辞**——采纳: ymm 挂 `G6r-B0 跳表 128→256 扩容` hinge，随 G7 P1 统裁（x87 L0/G7 共享前置，三债并还）
3. R1/R3 处置同意（R1 不排波 / R3 文本备档）
4. **新发现处置**: 🟡#1 marker_scan 幻影 begin → **立观察项不单开**（现有误归属只产生空区域，412 §8#4 同族，G7 P1 立项时随归属规则收紧一并处理）；🟡#2 **BMI1/2 (rorx/mulx/andn/shlx) 是独立缺口**——此前 G 线清单从未列过它！真实高频（ClipUp rorx 288），档A 显式排除 = 新缺口 G8-BMI 登记进需求书，AVX 收官后拍板；🟢#3 FMA 双舍入红线/#4 EVEX 入 gate 声明 → 随 G6a/B0 文档带走；#5 callgate 无 ymm 需求 ✅
5. GAPS:194 kVmOpMax stale 修正 → G1b 派单顺带（408 尾巴同款）

## B.3 基线与排程更新
- **multiseed 权威基线: 38 样本 × 5 = 190/190**（423 合入后）
- 指令虚拟化阶段收官路径（更新版）: **G1b（SSE mul+andnps+SSE2 整数）→ G6a（VEX.128 档A）→ [G8-BMI 拍板] → [G7 x86 P1 统裁: ymm/x87 L0/跳表扩容 三合一] → 阶段收官 → 410 (M3)**
- 423 ff-merge main=`123bf09`; 423/424 → done + 裁定评论上单
