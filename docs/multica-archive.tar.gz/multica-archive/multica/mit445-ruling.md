# MIT-445 (X3c 协议面收口) 裁定 — ACCEPT；442 挂账闭环（call [mem] x64 全链翻案亲验）+ #33 纠正我 D6 前提的机械性错误 + 跨 run 接续干净落地；十六连满分

> 裁定人: 项目主 — 2026-09-01 22:2x | 处置: ff-merge main=`e20b383`, done
> 复验: agent worktree git 注册已自拆（空壳目录被其 shell cwd 占用留物理残壳——如实披露，合规）；项目主另建 `wvmp-x3c`@e20b383 双 arch 独立重建亲跑

## 1. 独立复验（全部亲测）
| 项 | 实测 (@e20b383) |
|---|---|
| 双 arch 构建 | x64 rc=0 + x86 交叉链 rc=0 |
| ctest / **x86 电池（我亲手 WOW64）** | 16/16 / **35/35 PASS rc=0**（7755ms；CallGate 3 + ExitNative 2 + Ret 2 新增全真执行）|
| x86 dump 门 | 亲手重跑电池出 dump → **PASS 60 登记项全覆盖**（57→60 同步兑现）|
| multiseed / wvmpTest | 亲跑 **250/250** / stubs=14 + jt + en=17 + 双跑 **diff 0 103/103** |
| **B.1 翻案亲验（本单灵魂）** | 我亲手 forkface: **stubs 3→5、双 reg-target gate note 全消、bal=0/callmem=997/callreg=998 byte-exact**（残留 std/mov=442 负例区设计行为，非回退）——442 "D4 停手"挂账就此闭环，x64 call [mem]/call reg 从无到有 |
| **D6 双口径铁证（亲测重构）** | 旧 CLI(9c00962)×forkface = `f67c2d40`/161,756B（444 底稿逐位吻合）→ 新 CLI = `ffd47289`/161,861B；**第二样本(adc)新 CLI dump == forkface 新 CLI dump 逐字节**——"asm_dump 是 seed 纯函数"论断亲验成立；delta 96 行归因抽验：布局头 table 偏移（0x69C8→0x69D8）+ dispatch 1 行 + callgate a_kind 分派新块——**唯一 handler 码体 delta** 与报告一致 |
| 冻结契约 | runtime.hpp/vm_op(97)/kCtxSize/backend/lifter/cli/sdk/pe_* 全家 **0 行 diff**；translator 改动 `grep ^@@` = 2 hunk（:924 Call 分发行 + :1665 translate_call 体）——**B.4"限 translate_call"严格兑现，S64 tag 零触碰（红线遵守）**，B.4/D4 禁改面全绿 |
| 跨 run 接续归因（本次特别核查项） | attempt-1（110 分钟, 零 commit, 500 炸单）的 WIP 由 attempt-3 收拾成**四批干净 commit**（21:11/21:12/21:47/21:51, worktree 20:15→21:56 对账吻合）+ 批次纪律恢复 + 交报零"attempt"字样混淆——接续质量满分 |
| 硬条款 | 命名分支+main 未动+零脏+切回 main+worktree 注册自拆+ff-safe——**十六连满分** |

## 2. #33 判定：纠正派单前提的机械性错误（最高成色一档）
我 §B.7/D6 设计"48 样本恒等 + forkface 例外"**前提不成立**——asm_dump 与样本无关（seed 纯函数），callgate delta 以同形出现在全部样本。agent 未照抄执行一个"无法通过的验收标准"，而是**实测钉死底稿事实（snake/forkface @12345 同 sha）后给等价口径**（逐 handler 对账 + 行为恒等双铁），我本轮亲验等价口径全兑现。教训入册：**恒等类验收条款动笔前必须想清楚"对什么恒等"——dump 层的样本维度恒等是伪命题，行为层（multiseed 输出串）才是样本维度**。

## 3. 实战缺陷 ×2 实录（cdb 铁证入档，444 模式延续）
① callgate 目标分派置于参数快照后 → 本 seed t_[4]=rax 被覆写 → 槽索引=残渣 AV（修正=分派块前移+防御 reg_a∈reserved）；② Ret x86 出口 push 置于 `sub ebx,4` 后 → push 了死槽地址非 v4'（cdb: eip=0/esp=guest_top−4 铁证；修正=push 前移）。x86 面无①类坑（pc/flags 内存常驻）——架构差异当场学到。

## 4. B.5/B.6 交付确认
- x87 D1 一页备忘三路线表齐（建议维持 A=R-SSE-only：S 级零扩容与 x64 承诺一致；B=XL 拆 2-3 单仅"老客户 x87 命中率高到值得"时立项）——**项目主拍板输入已交, 见本裁定 §6**
- shld/shrd=折条可行挂观察（lifter 无 lift 形需先开冻结面, 触发=客户语料命中）；cwd=不立项（capstone 双 id 归 cwde 系, 语料 0）

## 5. X4 交接注记确认
GAPS X3c 节含 S64 tag 点位×5（translator rsp 步进/rip-RVA 改形精确坐标）+ stub ABI 锚×4（含 B.1 新帧形对齐）——444 挂账已转化为 X4 的可执行输入。

## 6. 项目主拍板（本裁定时代）
**x87 路线 = 定稿 A（R-SSE-only）**：与 x64 承诺一致、零扩容、gate 整函数 byte-identical 兜底；B 路线立项触发条件=客户语料 x87 区域命中率实证（备忘中语料判定归 X5 样本池波）。STATUS/GAPS 的 x87 表述在 X5 收口单统一翻正（本单文档 commit 已含 X4 交接, 不追加改动）。
