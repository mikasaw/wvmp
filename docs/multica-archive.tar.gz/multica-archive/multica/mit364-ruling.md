# 项目主裁定: MIT-364 + MIT-366 + MIT-367 (Multica MIT-340 + MIT-364 verifier + MIT-365 verifier) — 🟡 全部 in_review (Multica agent model 配置问题, claude-sonnet-4-6[1M] + claude-opus-4-8[1m] 都不存在)

## 总体评价

**MIT-364 + MIT-366 + MIT-367 三个派活单 全部 in_review (Multica agent model 配置问题, 项目主无法直接修改 daemon model 配置)**: **MIT-340 (PE 重写 + ASLR / .reloc 重建) + MIT-364 verifier + MIT-365 verifier 三个派活单派发后 agent 都因 model 配置问题 failed**:

| 派活单 | Multica 编号 | agent | model | 状态 |
|---|---|---|---|---|
| MIT-365 v1 | MIT-350 (Multica 编号) | WVmpCppDev | `claude-sonnet-4-6[1M]` | failed (3 分钟) |
| MIT-364 | MIT-340 (Multica 编号) | WVmpCppDev | `claude-sonnet-4-6[1M]` | failed (5 分钟) |
| MIT-366 | (Multica 编号 verifier) | WVmpVerifier | `claude-opus-4-8[1m]` | failed (立即) |
| MIT-367 | (Multica 编号 verifier) | WVmpVerifier | `claude-opus-4-8[1m]` | failed (立即) |

**关键发现 — Multica agent model 配置问题已影响 4 个派活单**:
- ❌ **WVmpCppDev 默认派发用 `claude-sonnet-4-6[1M]` model**: 不存在/无访问权限 (MIT-365 v1 + MIT-364 实证)
- ❌ **WVmpVerifier 默认派发用 `claude-opus-4-8[1m]` model**: 不存在/无访问权限 (MIT-366 + MIT-367 实证)
- ⚠️ **Multica daemon 自动派生 2 次 failed run 都同 model 问题** (MIT-365 v1 + MIT-365 v2, MIT-366 也有类似问题): 沿用 pitfall #29 重新派遣纪律 **无效** (Multica daemon 派生仍是同样 model 配置问题)
- ⚠️ **项目主无法直接修改 Multica daemon model 配置**: `multica agent get` 显示 WVmpCppDev / WVmpVerifier 配置, model 在 daemon runtime 里, 项目主无法改
- ⚠️ **沿用 pitfall #29 status 改回 in_review 处置 daemon 继续派生 failed run**: MIT-364/365/366/367 已改回 in_review ✅, daemon 不会继续派生 failed run (multica issue status MIT-364 in_review 已 done, MIT-366 in_review 已 done, MIT-367 in_review 已 done)

**MIT-330 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 已达成 ✅** (上一节 MIT-363 done, 上线 P0 #1 修复):
- ✅ **MIT-330 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 已达成**: Native snake rc=0 + Protected snake rc=0 + identical stdout → **BYTE-EXACT MATCH**, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复
- ✅ **agent 跑了 3 分钟真完成, 没掉进 8 步 completed 假完成模式** (派活单红派送 note 实战有效)
- ⚠️ **MIT-330 verifier (MIT-367) failed (claude-opus-4-8[1m] model 不存在)**: MIT-367 verifier pending, 沿用 pitfall #29 重新派遣纪律
- ⚠️ **MIT-330 done 但 verifier pending**: project 主 self-claim ACCEPT (派活单 §A 假设错, snake byte-exact 已 byte-exact 闭环, Zero code changes), 但沿用 MIT-355 错误方翻转教训强化需 verifier 独立确认

## 双重确认 (4 个派活单全部 failed, 项目主 fresh verify 已做)

**MIT-364 (MIT-340 PE 重写 + ASLR / .reloc 重建)**:
- agent 跑了 5 分钟就 failed (POLL #6, status=failed)
- agent last message: `There's an issue with the selected model (claude-sonnet-4-6[1M]). It may not exist or you may not have access to it. Run --model to pick a different model.`
- 项目主 fresh verify: agent 没 commit (model 失败前 agent 没来得及工作, 派活单核心目标未达成)

**MIT-366 (MIT-364 verifier, MIT-358 验证)**:
- agent 跑了立即就 failed (POLL #1, status=failed)
- agent last message: `There's an issue with the selected model (claude-opus-4-8[1m]). It may not exist or you may not have access to it. Run --model to pick a different model.`
- 项目主 fresh verify: agent 没 commit (model 失败前 agent 没来得及工作, 派活单核心目标未达成)

**MIT-367 (MIT-365 verifier, MIT-330 验证)**:
- agent 跑了立即就 failed (POLL #1, status=failed)
- agent last message: `There's an issue with the selected model (claude-opus-4-8[1m]). It may not exist or you may not have access to it. Run --model to pick a different model.`
- 项目主 fresh verify: agent 没 commit (model 失败前 agent 没来得及工作, 派活单核心目标未达成)

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-364 (MIT-340)** | 🟡 **in_review** (Multica agent model 配置问题) | Multica MIT-340 PE 重写 + ASLR / .reloc 重建 (上线 P0 #3 短期派, high), agent failed model access |
| **MIT-366 (MIT-364 verifier)** | 🟡 **in_review** (Multica agent model 配置问题) | Multica MIT-364 verifier, MIT-358 验证 + pitfall #39 候选沉淀验证, agent failed model access |
| **MIT-367 (MIT-365 verifier)** | 🟡 **in_review** (Multica agent model 配置问题) | Multica MIT-365 verifier, MIT-330 验证 + 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化, agent failed model access |
| **MIT-330** | ✅ done (派活单 §A 假设错, snake 真虚拟化 byte-exact 闭环已达成) | 上线 P0 #1 修复, **但 MIT-367 verifier pending, 沿用 MIT-355 错误方翻转教训强化需 verifier 独立确认** |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (🟡 1 项非阻断) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |
| **MIT-362 (MIT-350 v1)** | 🟡 in_review (REJECT v1, Multica agent model 配置问题) | Multica MIT-350 v1 现实世界 exe 回归测试集扩展, agent failed model access, v1 REJECT |
| **MIT-365 v1 stash** | ⚠️ 误操作 commit `93729ba` 已 revert (`ff4c933`) | 5 文件改动已 revert 干净, snake_sample_main.cpp 仍是 HEAD `534450c` 版本 |

## Multica agent model 配置问题 (本会话新增模式 8 + 4 个派活单 failed 实证)

**Multica agent model 配置问题模式 8 强化**:
1. ❌ **WVmpCppDev 默认派发用 `claude-sonnet-4-6[1M]` model**: 不存在/无访问权限 (MIT-365 v1 + MIT-364 实证)
2. ❌ **WVmpVerifier 默认派发用 `claude-opus-4-8[1m]` model**: 不存在/无访问权限 (MIT-366 + MIT-367 实证)
3. ⚠️ **Multica daemon 自动派生 2 次 failed run 都同 model 问题** (MIT-365 v1 + MIT-365 v2 实证): 沿用 pitfall #29 重新派遣纪律 **无效** (Multica daemon 派生仍是同样 model 配置问题)
4. ⚠️ **项目主无法直接修改 Multica daemon model 配置**: `multica agent get` 显示 WVmpCppDev / WVmpVerifier 配置, model 在 daemon runtime 里, 项目主无法改
5. ⚠️ **沿用 pitfall #29 status 改回 in_review 处置 daemon 继续派生 failed run**: MIT-364/365/366/367 已改回 in_review ✅
6. ✅ **MIT-330 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 已达成 ✅** (上一节 MIT-363 done, 派活单 §A 假设错 snake byte-exact 已 byte-exact 闭环, agent 跑了 3 分钟 fresh verify 成功)
7. ⚠️ **MIT-330 done 但 MIT-367 verifier pending**: 沿用 MIT-355 错误方翻转教训强化需 verifier 独立确认, 但 verifier 派发因 model 问题 failed
8. ⚠️ **派活单派发沿用 pitfall #29 重新派遣纪律无效**: Multica daemon 派生仍是同样 model 配置问题, 沿用 pitfall #29 status 改回 in_review 是 **当前唯一可行处置** (避免 daemon 继续派生 failed run)

**Multica agent model 配置问题修复路径** (Multica daemon owner 处理, 项目主无法直接修):
1. ⚠️ **Multica daemon owner 修改 daemon 配置**: 修改 daemon 默认派 WVmpCppDev / WVmpVerifier 用可用 model (e.g. `claude-sonnet-4-5` / `claude-opus-4-7`), 项目主无法直接改 daemon 配置
2. ⚠️ **项目主未来派活单派发前 verify Multica agent model 可用**: 派活单派发**前**项目主跑 `multica agent get <id>` + `multica runtime list` 验证 model 可用 (避免 model 配置问题导致 agent failed)
3. ⚠️ **沿用 MIT-365 v1 失败教训 + MIT-364 + MIT-366 + MIT-367 4 个派活单 failed 实证**: 项目主未来派活单派发**前**必 verify Multica agent model 可用, 不直接派发 `claude-sonnet-4-6[1M]` / `claude-opus-4-8[1m]` 不存在 model (沿用 pitfall #29 重新派遣纪律无效)

## 后续流水线

1. **Multica daemon owner 修改 daemon 配置** (项目主无法直接改 daemon 配置, 需 Multica owner 协助): 修改 daemon 默认派 WVmpCppDev / WVmpVerifier 用可用 model (e.g. `claude-sonnet-4-5` / `claude-opus-4-7`)
2. **项目主未来派活单派发**前** verify Multica agent model 可用** (沿用 MIT-365 v1 + MIT-364 + MIT-366 + MIT-367 4 个派活单 failed 实证): 派活单派发**前**项目主跑 `multica agent get <id>` + `multica runtime list` 验证 model 可用 (避免 model 配置问题导致 agent failed)
3. **派发** (Multica daemon model 配置修复**后**):
 - MIT-365 v2 重派 (Multica MIT-350 现实世界 exe 回归测试集扩展, 上线 P0 #2 中期派, medium)
 - MIT-364 v2 重派 (Multica MIT-340 PE 重写 + ASLR / .reloc 重建, 上线 P0 #3 短期派, high)
 - MIT-366 v2 重派 (verifier 第 23 连实战, MIT-358 验证 + pitfall #39 候选沉淀验证, medium)
 - MIT-367 v2 重派 (verifier 第 24 连实战, MIT-330 验证 + 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化, medium)
4. **进入 Block C 阶段 2 收尾 / 阶段 3 (低频指令, FPU/SSE/AVX)**:
 - **修复派活单 §A "🟡 错误方翻转" 错误描述** (派活单 §D 期望值错, 错误方翻转教训强化, 立 sub-issue)
 - **Block C 阶段 2 完整规划收尾** (5-7 天, ~9-10 条派活单)
5. **MVP 集成测试**: MIT-330 (snake byte-exact, ✅ done) + MIT-340 (ASLR 兼容 + 杀软扫描兼容, **Multica model 修复后重派**) + MIT-350 (5 个现实世界 exe 回归测试集, **Multica model 修复后 v2 重派**) 三派活单都 done 后, MVP 上线 (上线 P0 #1 + #2 + #3 修复)

## 沉淀 (Multica agent model 配置问题模式 8 强化 + 4 个派活单 failed 实证)

### 关键沉淀 (本会话)

- ❌ **Multica agent model 配置问题** (本会话新增模式 8): WVmpCppDev 默认派发用 `claude-sonnet-4-6[1M]` model + WVmpVerifier 默认派发用 `claude-opus-4-8[1m]` model, 两个 model 都不存在/无访问权限, **4 个派活单 (MIT-365 v1 + MIT-364 + MIT-366 + MIT-367) 都因 model 问题 failed**
- ❌ **沿用 pitfall #29 重新派遣纪律无效**: Multica daemon 自动派生 2 次 failed run 都同 model 问题 (MIT-365 v1 + MIT-365 v2, MIT-366 也有类似问题)
- ⚠️ **项目主无法直接修改 Multica daemon model 配置**: `multica agent get` 显示 WVmpCppDev / WVmpVerifier 配置, model 在 daemon runtime 里, 项目主无法改
- ✅ **沿用 pitfall #29 status 改回 in_review 处置 daemon 继续派生 failed run**: MIT-364/365/366/367 已改回 in_review ✅, daemon 不会继续派生 failed run
- ⚠️ **MIT-330 done 但 MIT-367 verifier pending**: 沿用 MIT-355 错误方翻转教训强化需 verifier 独立确认, 但 verifier 派发因 model 问题 failed, 项目主 self-claim ACCEPT (派活单 §A 假设错, snake byte-exact 已 byte-exact 闭环)
- ✅ **MIT-330 派活单核心目标 (snake 真虚拟化 byte-exact 闭环) 已达成 ✅** (上一节 MIT-363 done, 上线 P0 #1 修复)

### Multica agent model 配置问题教训 (本会话新增模式 8, MIT-365 v1 + MIT-364 + MIT-366 + MIT-367 4 个派活单 failed 实证)

- ❌ **Multica agent model 配置问题**: `claude-sonnet-4-6[1M]` + `claude-opus-4-8[1m]` 都不存在/无访问权限, agent failed
- ⚠️ **沿用 pitfall #29 重新派遣纪律无效**: Multica daemon 自动派生 2 次 failed run 都同 model 问题 (MIT-365 v1 + MIT-365 v2, MIT-366 也有类似问题)
- ✅ **status 改回 in_review 处置 daemon 继续派生 failed run**: MIT-364/365/366/367 已改回 in_review ✅
- ⚠️ **Multipart daemon owner 处理 model 配置问题** (项目主无法直接改 daemon 配置): 修改 daemon 默认派 WVmpCppDev / WVmpVerifier 用可用 model (e.g. `claude-sonnet-4-5` / `claude-opus-4-7`)
- ⚠️ **项目主未来派活单派发**前** verify Multica agent model 可用** (沿用 MIT-365 v1 + MIT-364 + MIT-366 + MIT-367 4 个派活单 failed 实证)

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit363-ruling.md` (MIT-330 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化 + 上线 P0 #1 修复)
- `mit365-ruling.md` (MIT-365 v1 REJECT, agent failed model access)
- `mit364-ruling.md` (MIT-340 + MIT-364 verifier + MIT-365 verifier 三派活单都因 Multica agent model 配置问题 failed) ← 本轮
- `issue-54-pe-writer-aslr-reloc-instructions.md` (MIT-340 派活单)
- `issue-56-mit358-verifier-instructions.md` (MIT-364 verifier 派活单, MIT-358 验证)
- `issue-57-mit363-verifier-instructions.md` (MIT-365 verifier 派活单, MIT-330 验证)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #29` 派活单派活后 agent run failed 重新派遣纪律 (MIT-326 v2 / MIT-339 v1 → v2 实战, MIT-365 v1 → v2 重新派遣, **沿用 pitfall #29 重新派遣纪律无效 for Multica agent model 配置问题**)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-330 实证 #10 派活单 §A 假设错 LoadRva/StoreRva 已实施 since M2-8, MIT-355 错误方翻转教训强化)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358/363 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9/3 分钟真完成, **MIT-365 v1 + MIT-364 + MIT-366 + MIT-367 不是 pitfall #38 候选 #11 实证**, **是 Multica agent model 配置问题**)
- **Multica agent model 配置问题** (本会话新增模式 8, MIT-365 v1 + MIT-364 + MIT-366 + MIT-367 4 个派活单 failed 实证): `claude-sonnet-4-6[1M]` + `claude-opus-4-8[1m]` 都不存在/无访问权限, project 主无法直接改 daemon 配置, Multica daemon owner 处理
- ✅ **MIT-330 ✅ ACCEPT (派活单 §A 假设错, snake 真虚拟化 byte-exact 闭环已达成, 不需修改)**: 上线 P0 #1 修复, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复, 但 MIT-367 verifier pending