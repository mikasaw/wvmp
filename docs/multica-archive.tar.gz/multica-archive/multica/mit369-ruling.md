# 项目主裁定: MIT-369 (Block C 阶段 2 收尾 sub-issue #3 commit capstone 反汇编验证脚本) — ✅ ACCEPT (scripts/disasm_cl_shift_check.py 已 commit + capstone 反汇编验证 PASS)

## 总体评价

MIT-369 (Multica 编号 MIT-368, Block C 阶段 2 收尾 sub-issue #3) **✅ ACCEPT** (scripts/disasm_cl_shift_check.py 已 commit + capstone 反汇编验证 PASS): **MIT-358 派活单核心目标 2 (capstone 验证脚本 commit) PARTIAL 修复完成**, agent 跑了 16 分钟真完成, 没掉进 8 步 completed 假完成模式 (派活单红派送 note 实战有效).

**关键发现 — MIT-358 派活单核心目标 2 PARTIAL 修复完成**:
- ✅ **scripts/disasm_cl_shift_check.py 已 commit** (404 lines, pure ASCII, 0 non-ASCII bytes)
- ✅ **commit `db95936` (MIT-368) on main** (Chinese structured 3-section commit message: 目的/改动/验证)
- ✅ **capstone 反汇编验证 PASS**: 6 helpers found, NOP padding 64/75/70/75/74/75 bytes, min spacing 80B > 64B
- ✅ **build: rc=0** (302/302, 派活单核心目标只是 commit 一个脚本, 不需改其他文件)
- ✅ **ctest: 15/15 PASS**
- ✅ **E2E seed=12345: 20/20 byte-exact**
- ✅ **MVP P0 #1 + #2 + #3 修复保持** (snake byte-exact + 5 个现实世界 exe 回归测试集 + PE 重写 + 杀软扫描兼容, MVP P0 #1 + #2 + #3 修复保持)

**scripts/disasm_cl_shift_check.py 核心功能**:
- ✅ capstone-based verifier, locate 6 MASM helpers via characteristic instruction signatures
- ✅ walk back to count NOP padding (>=64B)
- ✅ verify min spacing between consecutive helpers (must be > kStubWindow=64)

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-369 完成, 跑了 16 分钟真完成, model 修复后):
- **Done. The capstone verification script is committed and verified:**
- **Deliverables:**
 - `scripts/disasm_cl_shift_check.py` (404 lines, pure ASCII, 0 non-ASCII bytes) — capstone-based verifier that locates 6 MASM helpers via characteristic instruction signatures, walks back to count NOP padding (>=64B), and verifies min spacing between consecutive helpers (must be > kStubWindow=64)
 - Commit `db95936` (MIT-368) on main
 - Report posted as comment on Multica issue MIT-369
- **Verification:**
 - capstone 反汇编 PASS: 6 helpers found, NOP padding 64/75/70/75/74/75 bytes, min spacing 80B > 64B
 - build: rc=0 (302/302)
 - ctest: 15/15 PASS
 - E2E seed=12345: 20/20 byte-exact
 - Issue status: in_review

**项目主 fresh verify** (本轮, MIT-369 ruling):
- HEAD `db95936` (MIT-368 commit, scripts/disasm_cl_shift_check.py 已 push)
- git log --oneline -3: db95936 (MIT-368) + b2372a9 (MIT-370) + 61d84ed (MIT-340 注释)
- git status: working tree 干净 (除历史 untracked)
- ✅ **scripts/disasm_cl_shift_check.py 跑通**: capstone 反汇编验证 PASS, 6 helpers found, NOP padding 64/75/70/75/74/75 bytes, min spacing 80B > 64B
- ✅ **build: rc=0** (302/302)
- ✅ **ctest: 15/15 PASS**
- ✅ **E2E seed=12345: 20/20 byte-exact** (snake byte-exact + cl_shift + 14 其它 E2E 样本 byte-exact 保持)
- ✅ **MVP P0 #1 + #2 + #3 修复保持** (snake 真虚拟化 byte-exact 闭环 + 5 个现实世界 exe 回归测试集 + PE 重写 + 杀软扫描兼容)

## scripts/disasm_cl_shift_check.py 跑通输出 (本轮 fresh verify)

```
=== WVmp capstone disassembly check (MIT-368) ===
exe              : C:\Users\www\AiCode\WVmp\wvmp\build\passes\marker_scan\tests\wvmp_cl_shift_sample.exe
size             : 33280 bytes
kStubWindow      : 64
required padding : 64
Per-helper:
  [popcnt32_fn] RVA=0x232c nop_pad=64B (need >=64B) [OK]
  [popcnt64_fn] RVA=0x238f nop_pad=75B (need >=64B) [OK]
  [lzcnt32_fn] RVA=0x23e0 nop_pad=70B (need >=64B) [OK]
  [lzcnt64_fn] RVA=0x2430 nop_pad=75B (need >=64B) [OK]
  [tzcnt32_fn] RVA=0x2480 nop_pad=74B (need >=64B) [OK]
  [tzcnt64_fn] RVA=0x24d0 nop_pad=75B (need >=64B) [OK]
Spacing:
  popcnt32_fn    -> popcnt64_fn    delta=99B (0x63)
  popcnt64_fn    -> lzcnt32_fn     delta=81B (0x51)
  lzcnt32_fn     -> lzcnt64_fn     delta=80B (0x50)
  lzcnt64_fn     -> tzcnt32_fn     delta=80B (0x50)
  tzcnt32_fn     -> tzcnt64_fn     delta=80B (0x50)
  min spacing   = 80B (must be > 64B) [OK]
all helpers found : True
all padding ok    : True
min spacing ok    : True
OVERALL           : PASS
```

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-368 (MIT-369)** | ✅ **done (Block C 阶段 2 收尾 sub-issue #3 ACCEPT)** | scripts/disasm_cl_shift_check.py 已 commit + capstone 反汇编验证 PASS, MIT-358 派活单核心目标 2 PARTIAL 修复完成 |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (MIT-358 派活单核心目标 2 PARTIAL 修复完成) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |
| **MIT-330** | ✅ done (verifier 独立确认) | snake 真虚拟化 byte-exact 闭环 (上线 P0 #1 修复, MIT-367 v2 verifier 独立确认 ✅) |
| **MIT-350** | ✅ done (MIT-365 v2 ACCEPT) | Multica MIT-350 现实世界 exe 回归测试集扩展 (上线 P0 #2 中期派) |
| **MIT-340** | 🟡 **有条件 FAIL** | MIT-340 派活单 §A 假设错 #11 实证 (沿用 M2-8 行为, agent 改回保持 snake byte-exact 闭环) |
| **MIT-370** | ✅ **done** (MVP P0 #3 替代方案 A ACCEPT) | PE 重写 + 杀软扫描兼容, **不**启用 ASLR + **不**启用 FORCE_INTEGRITY |

## MVP P0 集成测试进度 (上线 P0 #1 + #2 + #3 + #4 修复)

| P0 | Issue | status | 说明 |
|---|---|---|---|
| **P0 #1 snake byte-exact 闭环** | MIT-330 | ✅ **done** (MIT-367 v2 verifier 独立确认) | snake 真虚拟化 byte-exact 闭环 |
| **P0 #2 现实世界 exe 回归测试集** | MIT-350 | ✅ **done** (MIT-365 v2 ACCEPT) | 5 个现实世界 exe 回归测试集 |
| **P0 #3 杀软扫描兼容** | MIT-370 (替代方案 A) | ✅ **done** (MVP P0 #3 替代方案 A ACCEPT) | PE 重写 + 杀软扫描兼容 |
| **P0 #4 PE 签名 EV 证书** | — | ⚠️ 待派 (MVP派发**前** EV 证书到位) | — |

## 后续流水线

1. **MVP P0 #1 + #2 + #3 都 done ✅, MVP派发**前**只剩 P0 #4**:
 - 派 MVP P0 #4 (PE 签名 EV 代码签名证书采购 + 集成) [~1-2 周, 取决于 EV 证书采购]
2. **MVP 集成测试**: MVP派发**前**项目主 fresh verify 必跑 dumpbin + capstone + git fsck + Python 公式校准 多维验证 (pitfall #50 强化)
3. **MVP派发**前**杀软扫描验证**: MVP派发**前**项目主必跑 Windows Defender / 360 / 火绒 / 卡巴斯基 杀软扫描验证 protected PE 不标"异常 PE"
4. **MVP 上线 (~1-2 周后, 取决于 EV 证书采购)**

## 沉淀 (MIT-369 sub-issue #3 ACCEPT + MIT-358 派活单核心目标 2 PARTIAL 修复完成 + MVP P0 #1 + #2 + #3 都 done)

### 关键沉淀 (本会话)

- ✅ **MIT-369 sub-issue #3 ACCEPT**: scripts/disasm_cl_shift_check.py 已 commit + capstone 反汇编验证 PASS
- ✅ **MIT-358 派活单核心目标 2 PARTIAL 修复完成** (沿用 MIT-355 错误方翻转教训强化): scripts/disasm_cl_shift_check.py 404 lines, pure ASCII, 0 non-ASCII bytes, capstone-based verifier, 6 MASM helpers found + NOP padding 64/75/70/75/74/75 bytes + min spacing 80B > 64B
- ✅ **MVP P0 #1 + #2 + #3 都 done** (MVP P0 #1 修复 + MVP P0 #2 修复 + MVP P0 #3 替代方案 A 修复)
- ✅ **MVP派发**前**只剩 MVP P0 #4 (PE 签名 EV 证书)**: MVP派发**前** EV 证书到位 (避免 MIT-340 FORCE_INTEGRITY 启用后未签名 Permission denied rc=126)

### MIT-355 错误方翻转教训强化 (本会话强化模式 7, MIT-366 v2 verifier + MIT-369 sub-issue #3 ACCEPT 实证)

- ✅ **派活单描述错 agent 实际正确, verifier 必独立确认** (派活单核心目标 byte-exact 真虚拟化达成), **不盲反 agent, 也不盲采派活单描述**
- ✅ **MIT-366 v2 verifier 实证**: 派活单派发**前**项目主 fresh verify 假设 "派活单核心目标 2 = agent commit capstone 验证脚本", **派活单 §A 假设错** (派活单派发后项目主 fresh verify 实证 "派活单核心目标 2 PARTIAL, agent 实际部分达成, agent 跑了验证但漏了 commit step")
- ✅ **MIT-369 sub-issue #3 ACCEPT 实证**: MIT-358 派活单核心目标 2 PARTIAL 修复完成 (派活单派发**前**项目主 fresh verify 假设 "scripts/disasm_cl_shift_check.py 不存在", 派活单派发后项目主 fresh verify 实证 "scripts/disasm_cl_shift_check.py 跑通, capstone 反汇编验证 PASS, 6 helpers found + NOP padding 64/75/70/75/74/75 bytes + min spacing 80B > 64B", **派活单核心目标达成**)

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit363-ruling.md` (MIT-330 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化 + 上线 P0 #1 修复)
- `mit365-v2-ruling.md` (MIT-365 v2 ✅ ACCEPT + 派活单核心目标 pitfall 实证 + 新 pitfall #53 候选)
- `mit367-v2-ruling.md` (MIT-367 v2 verifier 🟡 有条件 FAIL + 新 pitfall #54 候选 MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥 + MVP P0 #1 独立确认 ✅)
- `mit366-v2-ruling.md` (MIT-366 v2 verifier 🟡 有条件接受 + 核心目标 1 pitfall 沉淀 ✅ + 核心目标 2 capstone 验证脚本 commit 🟡 PARTIAL + 立 sub-issue #3 修复)
- `mit364-v2-ruling.md` (MIT-364 v2 agent 🟡 有条件 FAIL + MIT-340 派活单 §A 假设错 #11 实证 + agent 诚实披露 + 改回 M2-8 行为保持 snake byte-exact + 新 pitfall #53 候选实测规避)
- `mit370-ruling.md` (MIT-370 MVP P0 #3 替代方案 A ✅ ACCEPT + MVP P0 #1 + #2 修复保持)
- `mit369-ruling.md` (MIT-369 sub-issue #3 ✅ ACCEPT + scripts/disasm_cl_shift_check.py 已 commit + capstone 反汇编验证 PASS + MIT-358 派活单核心目标 2 PARTIAL 修复完成 + MVP P0 #1 + #2 + #3 都 done) ← 本轮
- `issue-57-disasm-cl-shift-check-instructions.md` (MIT-368 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-330 实证 #10 + MIT-340 实证 #11, MIT-355 错误方翻转教训强化)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358/363/365 v2/367 v2/370/369 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9/3/4/3/5/17/9/16 分钟真完成)
- `pitfall #39 候选` MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充 (MIT-349 popcnt + MIT-353 lzcnt/tzcnt + MIT-358 capstone 反汇编验证, MIT-369 sub-issue #3 实证 NOP padding 64/75/70/75/74/75 bytes + min spacing 80B > 64B)
- `pitfall #53 候选` **sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (MIT-365 v2 实证, MIT-364 v2 agent 实测规避)
- `pitfall #54 候选` **MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥** (MIT-367 v2 verifier 实证, MIT-370 派活单 §D 决策 1 沿用)
- `pitfall #55 候选` **regvm_runtime_tests 并行 flake** (MIT-367 v2 verifier 实证, 顺序执行 100% PASS)
- ✅ **MIT-330 ✅ ACCEPT (MVP P0 #1 修复)**: snake 真虚拟化 byte-exact 闭环
- ✅ **MIT-350 ✅ ACCEPT (MVP P0 #2 修复)**: 5 个现实世界 exe 回归测试集
- ✅ **MIT-370 ✅ ACCEPT (MVP P0 #3 替代方案 A 修复)**: PE 重写 + 杀软扫描兼容
- ✅ **MIT-369 ✅ ACCEPT (Block C 阶段 2 收尾 sub-issue #3 ACCEPT)**: scripts/disasm_cl_shift_check.py 已 commit + capstone 反汇编验证 PASS
- 🟡 **MVP P0 #4 (PE 签名 EV 证书) 待派**: MVP派发**前** EV 证书到位