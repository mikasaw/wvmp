# MIT-417 (P0 callgate FP) + MIT-418 (G5r-R3 x87 文档化) 合并裁定台账

> 2026-08-30 项目主; ff-merge main=51c2870; 双裁定工单评论同文上单。

# [项目主验收裁定 · 417/418 双单合并复验] MIT-417 ACCEPT — P0 静默坏壳修复闭环（g5r_p0 固定样本项目主亲手双向反证）

> 裁定人: 项目主 — 2026-08-30 01:4x | 处置: 链式合并 (417 基底 + 418 cherry-pick, 项目主编排解 3 处冲突) → **ff-merge main = `51c2870`**, 本单 done
> run 终态 failed 定性: `claude exited with error: exit status 1` = 平台侧会话崩溃 (双单 01:02-01:03 同时挂, 交付报告与 commit 均完整在分支)——**非交付问题, 验收照常**, run 历史保留 failed 记录

## 本单 (417 P0 callgate FP) 独立复验
| 项 | 自报 | 实测 |
|---|---|---|
| build / ctest | rc=0 / 16/16 | ✅ (worktree @58fb96d 与合并态两次亲测) |
| **P0 反证 (406 铁律)** | pre 错 post 对 | ✅ **项目主用固定样本 %TEMP%\g5r_p0 亲手双向复跑**: PRE-FIX (main fa08d50 CLI) packed `fp_sum=3.00 last=2.00 rc=1` 静默错乱 → POST-FIX (417 CLI) 同输入 packed **`fp_sum=15.00 last=7.00 rc=0` == native** — 全项目首例静默坏壳正式闭环 |
| 新样本真虚拟化 | stub≥1 | ✅ protect 亲验 stub=1 真虚拟化非 gate |
| 修复实现 | step5.5 4×movups 入 + step10.5 xmm0→ctx 回 | ✅ 代码直读: 时机正确 (call 前/pop ctx 后), `imm(kCtxXmmBase+16*N)` 全派生零字面量, 全 movups (movaps 红线遵守), keystone legacy 0F 10/11 编码实测入报告; B.2 指令边界无活值论证注释在位 |
| 单测 | CallGateFpArgReturnWiring 20 seeds | ✅ 序列+时机断言 (ctest 16/16 含) |
| D1 零 aux | 无条件搬运 | ✅ 兑现 (translator 未动), 简化方案成立 |
| 冻结面 | 栈布局常量零触碰 | ✅ kCallgateCalleeWindow/kPushCtxDepth 等未改 |
| **新铁律首单** | 命名分支交付 | ✅ `mit-p0-callgate-fp` + main 未动 + tracked 零脏——**415 违规后首个满分执行, 铁律生效** |

## 合并态复验 (51c2870, 双单合体)
- multiseed REQUIRE_REAL=1 = **TOTAL: 180 pass / 0 fail (36 样本)** — 两单各自单边报 35/175 的口径冲突由项目主合并解裁定: **合并后权威基线 = 36 样本 180/180** (multiseed 头注释已钉)
- build 0 错 0 警 / ctest 16/16
- wvmpTest 零回踩: stubs=**14** + jump-table@0xDD84 reg-4B-delta + ExitNative 17 + 双跑 **103/103 diff 0 行**
- **新基线含 g5r 盲区消灭证明**: fp_callgate_sample 入池 = 回归体系第一份全 FP 参数 callgate 样本

## 遗留 (登记非阻断)
1. 时间报告: 417 交付报告初版 "~55 分钟" 有误, **其自己随后追评修正为 ≈25 分钟 (<30 红线)**——修正主动且诚实, 判合格登记 (412 时间对账纪律生效证据)
2. 417/418 均无影子样本 (flags 面零涉 + 四可观察输出设计兜底, 接受)
3. __vectorcall 多槽返回 / 类型错配披露面 → GAPS C3 残余登记 (417 B.5 完成)

完整裁定台账: `.multica/mit417-418-ruling.md` (含 418 部分)。


---

# [项目主验收裁定 · 417/418 双单合并复验] MIT-418 ACCEPT — x87 永久 gate 文档化收口, R3 路线闭环

> 裁定人: 项目主 — 2026-08-30 01:4x | 处置: 链式合并 (417 基底 + 本单 cherry-pick=51c2870, 项目主解 3 处冲突) → **ff-merge main = `51c2870`**, 本单 done
> run 终态 failed 定性: 平台侧会话崩溃 (与 417 同时刻, 交付报告+commit 完整在分支 `mit-g5r-r3`)——非交付问题, 验收照常

## 本单 (418 R3) 独立复验 (合并态 CLI @51c2870 亲测)
| 项 | 自报 | 实测 |
|---|---|---|
| **B.2 四件套 gate 断言** | 全过 | ✅ **项目主亲手复跑 x87 样本**: ① 未支持 `f*` note **11 条** (fld×5/faddp/fstp×3/fcomip/fsin) ② stub=**1** (=仅 helper 真区, x87 区零 stub 计数钉死) ③ `触发 C1 gate` 日志在位 ④ native/packed **rc 0==0 + stdout 逐字节一致** |
| 机器码级双证 (报告结构证据) | x87 区 54B identical + helper 区 E9 覆写 | ✅ 与 stub 计数口径自洽 (0+1=1) |
| D2 红线 | 零产品代码触碰 | ✅ diff 7 文件 = 文档×4 + 样本×2 + CMake/multiseed, 代码面零越界 |
| A.2 REQUIRE_REAL 兼容选型 | helper 真区结构依赖 + B.5 禁删登记 | ✅ multiseed 头注释登记在位, 36/180 合并口径采纳 |
| 越界发现 (D2 停下上报义务) | 无 | ✅ 未触发——x87 全族确认 gate 不逃逸 (探针还揪出 ml64 对部分编码 A2008/A2070 拒汇编, fcomip 改 db 直发, 处理干净) |
| 新铁律 | 命名分支 + worktree 隔离 + 412 例外注记 (417 并发期零扰动) | ✅ `mit-g5r-r3` 全合规 |

## 合并冲突裁决记录 (项目主编排, 413/414 先例第 2 次)
both-changed ×3: GAPS.md (自动合, 双方内容完好——C3 callgate FP 节 + x87 独立小节双在) / multiseed_e2e.sh (样本数组双保留, **头注释总数裁决 35→36=180 runs**) / CMakeLists (尾行交错冲突手工解, 去重复 enable_language)。合并态全链复验: build 0 / ctest 16/16 / **multiseed 180/180** / wvmpTest 14/14 + 103/103 diff 0。

## 路线闭环确认 (416 裁决 → 417+418 执行)
- R3 文档化 ✅ (本单) | P0 callgate FP ✅ (417, 主裁定见其工单) | R2 挂 G7 P1 捆绑评估 (登记) | R1 全量 x87 蓝图留档 `.multica/mit-G5r-triage.md` 不排波 ✅
- **multiseed 权威基线刷新: 36 样本 × 5 seeds = 180/180**

完整裁定台账: `.multica/mit417-418-ruling.md`。

