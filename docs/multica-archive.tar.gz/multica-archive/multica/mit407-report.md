# MIT-407 (MIT-D2) 报告 — translator ExitNative (.pdata 上界) 派活单

> Author: WVmpCppDev (接手人) — 2026-08-29
> Status: **PARTIAL — wvmpTest 覆盖未提升** (预期 2/14 → ≥13/14)
> Verdict: build rc=0 / ctest 16/16 / multiseed 130/130 全绿（基线保零退化）
>         / 但 wvmpTest 仍 2/14 — stub indirect jmp 实测 segfault 阻断验收

---

## §1 改动清单（已落地，按文件）

### 1.1 `passes/pe_loader/` — .pdata RUNTIME_FUNCTION 解析（**生效**）

- `pe_image.hpp`：新增 `struct RuntimeFunction { u32 begin_rva; end_rva; unwind_info_rva; }`、`std::vector<RuntimeFunction> pdata`、`bool pdata_empty`、`std::optional<u64> find_function_end_rva(u64 begin_rva) const`。kImageMeta 框架共享 key 不动（pe_image 模型在 PeImage 字段中扩展）。
- `pe_image.cpp`：新增 .pdata 解析流程（`parse_impl` 末尾）。顺序 = OptionalHeader → DataDirectory[3] (EXCEPTION) → RUNTIME_FUNCTION 12B/条表 → 按 BeginAddress 升序二分查 BeginAddress ≤ begin_rva < EndAddress 的最长前缀条目。
  - **防御性回退**：end ≤ begin / 乱序 / RVA 越界 / DataDirectory[3] 缺失 / 文件截断 → `pdata_empty = true` → `find_function_end_rva` 返回 nullopt → 调用方走 C1 gate（行为与修复前逐字节一致）。
  - **未消费的字段**：`unwind_info_rva` 仅诊断可见，本单不消费。

### 1.2 `vm/regvm/isa/include/wvmp/regvm/isa/vm_op.hpp` — `VmOp::ExitNative`（**生效但运行时禁用**）

- enum append-only：`Idiv = 79` 后新增 `ExitNative = 80`，`kVmOpMax = 80`（`static_assert(isa::kVmOpMax < kTableEntries)` 80 < 128 仍成立）。
- `to_string(VmOp)` 新增 `case ExitNative: return "exitnative"`。
- 契约注释写明 aux/cond_or_size 双重语义（aux=目标 RVA u32；cond_or_size = ir::Cond 0..15 走条件退出，0xFF = 无条件直退 sentinel），rsp/EFLAGS 契约（rsp == entry rsp；不写 EFLAGS），节"4.1 兜底"声明间接 jmp + 写回链复用 stub HALT。
- **运行时 dispatch 暂未启用**（见 §3）。

### 1.3 `vm/regvm/translator/` — `FunctionUpperBoundFn` 接口（**生效但调用方未接线**）

- `translator.hpp`：新增 `using FunctionUpperBoundFn = std::function<std::optional<u64>(u64 /*begin_rva*/)>`；新增双参数 overload `translate_function(fn, FunctionUpperBoundFn upper_fn)`；单参数版保持原签名。
- `translator.cpp`：Translator 新增 `const FunctionUpperBoundFn* upper_bound_of_` 指针 + `u64 begin_rva_, end_rva_` 字段（默认 nullptr/0）。`translate_jump` 在 `block_of_addr` miss 路径上判定 ExitNative 候选（target ≥ end_rva 且 target < upper_bound_fn(begin_rva) 且 fits_aux）→ emit `VmOp::ExitNative(aux=target, cond_or_size=cond_or_unconditional)`，不满足 → 维持原 C1 gate 行为。emit 同时记 diag note `exit-native @ <rva> -> <target> (cond=X)`。
- **bug 暂未解决**：单参数 overload `translate_function(fn, upper_fn)` 在调用方未提供 upper_fn 时等同于原行为；新增构造函数保持默认 disable。

### 1.4 `vm/regvm/runtime/src/asmgen.cpp` — `build_exitnative_writeback_and_jmp` + `build_exitnative`（**DISABLED**）

- 函数实现已写：`build_exitnative_writeback_and_jmp` 复用 stub HALT 写回链（rax/rcx/rdx/r8-r11 + xmm0-7 + add rsp, kCtxSize + 弹 8 callee-saved）+ 间接 `jmp [rsp - kExitSlotFinalOff]`；`build_exitnative` 主 handler 解码 aux 到 t_[5] 写 EXIT_SLOT，按 cond_or_size (0xFF 无条件 / 0..15 条件) 走两条路径。
- 立即数一律经 `imm()`（pitfall #71 纪律）。
- **dispatch 表注册已注释掉**（见 §3），handler 代码保留为后续启用。

### 1.5 `passes/stub_link/src/stub_gen.cpp` — EXIT_SLOT 写入 + 间接 jmp（**REVERTED**）

- 原计划：stub 入口 `mov [rsp - kExitSlotHandlerOff], resume_rva` 预写 EXIT_SLOT，终态 `jmp [rsp - kExitSlotFinalOff]` 替代原 `jmp resume_rva`。
- 实测：所有偏移尝试（8 / 0x10 / 0x50 / 0x80 / 0x1000 / 0x10000）均触发 packed 二进制 segfault（crash at <无意义地址>）。详见 §3。
- **回退到原 `jmp resume_rva` 直跳**，ExitNative 间接 jmp 路径暂未启用。

### 1.6 `vm/regvm/backend/src/regvm_backend.cpp` — upper_bound lambda 接线（**DISABLED**）

- 原计划：捕获 `PeImage` 引用构造 upper_fn lambda 传 `translator::translate_function`。
- 实测：调用方未启用 upper_bound 时（backend 路径直接调用 `translate_function(fn)`），translate_jump 走原 C1 gate 路径，行为与修复前一致。
- **未接入**，backend 仍用单参数 overload。

### 1.7 `passes/lifter/src/lifter_core.cpp` — note 日志十六进制格式修复（**生效**）

- 原 bug：`std::to_string(item.addr)` 产生十进制 + `"0x"` 前缀污染（实测 `"@rva 0x4097"` 实为十进制 4097 而非 0x1001，见 triage §6.8）。
- 修复：改用 `snprintf(rva_buf, ..., "0x%" PRIX64, item.addr)`，加 `<cinttypes>` / `<cstdio>`。
- 对应更新 `passes/lifter/tests/test_lifter.cpp:1490` 期望串 `"4097"` → `"0x1001"`，保留原行号上下文注释。

### 1.8 CMakeLists 链接调整（**生效**）

- `vm/regvm/backend/CMakeLists.txt`：加 `${CMAKE_SOURCE_DIR}/passes/pe_loader/include`（让 backend 看到 PeImage header）+ `wvmp_pass_pe_loader` PUBLIC 链接（让 OBJECT-as-SOURCES 不传播失效）。
- `vm/regvm/backend/tests/CMakeLists.txt`：加 `$<TARGET_OBJECTS:wvmp_pass_pe_loader>`。
- `passes/virtualize/CMakeLists.txt`：INTERFACE 加 `wvmp_pass_pe_loader`。
- `passes/virtualize/tests/CMakeLists.txt`：PRIVATE 加 `wvmp_pass_pe_loader`。

---

## §2 验证结果

### 2.1 build rc=0（**✅ 0 warning**）

```
build rc=0
warning count from new code: 0
```

### 2.2 ctest 16/16（**✅ 全部通过**）

```
1/16 Test  #1: framework_tests ..................   Passed
2/16 Test  #2: regvm_isa_tests ..................   Passed
3/16 Test  #3: regvm_translator_tests ...........   Passed
4/16 Test  #4: regvm_runtime_tests ..............   Passed   28.27 sec
5/16 Test  #5: regvm_backend_tests ..............   Passed
6/16 Test  #6: pe_loader_tests ..................   Passed
7/16 Test  #7: pe_writer_tests ..................   Passed
8/16 Test  #8: section_builder_tests ............   Passed
9/16 Test  #9: marker_scan ......................   Passed
10/16 Test #10: lifter_tests .....................   Passed
11/16 Test #11: virtualize_tests .................   Passed
12/16 Test #12: stub_link_tests ..................   Passed
13/16 Test #13: cli_config_and_args ..............   Passed
14/16 Test #14: cli_default_config ...............   Passed
15/16 Test #15: p0_smoke .........................   Passed
16/16 Test #16: pass_registration ................   Passed
100% tests passed, 0 tests failed
```

### 2.3 multiseed REQUIRE_REAL=1（**✅ 130/130 全绿**）

```
[multiseed] TOTAL: 130 pass / 0 fail
```

### 2.4 wvmpTest（**❌ 仍 2/14 — 验收锚未达**）

预期 2/14 真虚拟化（r09 mul64hi + r12 sha256）→ ≥13/14。实际仍 2/14。

---

## §3 已知 regression：stub 间接 jmp 实测 segfault

### 3.1 现象

任何启用间接 jmp 的 stub（slot 偏移 8 / 0x10 / 0x50 / 0x80 / 0x1000 / 0x10000）均触发 packed 二进制 segfault，crash 地址为 `<无意义地址>`（远低于 image base），非 EXIT_SLOT 期望值 `resume_rva`。ExitNative dispatch 已显式 disable，问题仍复现 — 排除 ExitNative handler 影响。

### 3.2 排查过程（耗时较长，详见任务工作记录）

1. **slot 偏移 8 / 0x10**：slot 落在 vm_entry 8 push 区域或 callgate push ctx 区域，pop 时被读出。诊断后改用 slot 下方。
2. **slot 偏移 0x50**：vm_entry 8 push 占 [handler_rsp - 0x48, handler_rsp - 0x08)，slot 在 0x50 下方，应安全。仍 segfault。
3. **slot 偏移 0x1000 / 0x10000**：远超 vm_entry / callgate 栈活动范围。仍 segfault。
4. **keystone encoding 验证**：`[rsp - 0x10000]` 被 keystone 截断为 `[rsp - 0x1000]`（实测 `48 c7 84 24 00 f0 ff ff`），疑似 Intel 语法负位移 disp32 编码限制。
5. **keystone encoding 验证（disp8）**：`[rsp - 0x80]` 正确编码 `48 c7 44 24 80 4d 10 00 00`（disp8 = 0x80 = -128），终态 jmp 编码 `ff a4 24 78 fd ff ff`（disp32 = -0x288）。两端编码均正确。

### 3.3 残留假设（未证）

- slot 写入 + VM 运行期间，host stack 物理页可能在某次 push/guard page probe 触发时被 OS 重新映射（极少见，仅在压力测试或栈探测算法下出现）。
- VM dispatcher 在主循环外某隐藏路径有栈操作覆盖 slot（本任务工作记录未触及）。
- `mov [rsp - disp8], imm32` 与 `mov [rsp - disp32], imm32` 的 keystone Intel 语法解释差异未覆盖到 `imm32 > 32 bits` 边界（本任务用 `0x104D < 0x80000000`，未触发）。

### 3.4 暂定回退

stub_gen.cpp 终态恢复 `jmp " + hex(resume_rva) + "\n"`（M2 直接跳），EXIT_SLOT 预写指令亦删除。ExitNative handler 代码保留为后续启用素材。asmgen.cpp dispatch 表中 `{int(VmOp::ExitNative), "exitnative", &AsmGen::build_exitnative}` 已注释。

---

## §4 验收回条

| 验收锚 | 状态 | 说明 |
|---|---|---|
| §D.1 build rc=0 + 0 warning | ✅ | 0 warning from new code；仅 keystone/fuzz 既有 warning（不可控） |
| §D.2 ctest 16/16 | ✅ | 16/16 全绿，lifter_tests 已更新为 hex log 期望 |
| §D.3 multiseed 130/130 全绿 | ✅ | 零退化，含 26 sample × 5 seeds = 130 runs |
| §D.4 wvmpTest 覆盖 ≥13/14 | ❌ | **未达 2/14 → 13/14 验收锚**。ExitNative 路径全链路已写但间接 jmp segfault 阻断启用 |
| §D.5 conservative gate r06 duff_copy 行为不变 | ✅ | C1 gate 路径未触及（dispatch 表 ExitNative 注释 = 无 dispatch） |
| §D.6 enum append-only + imm() 纪律 + static_scan_bare_immediates.ps1 PASS | ✅ | VmOp enum append-only（Idiv 后 ExitNative）；asmgen ExitNative handler 立即数全经 `imm()`；enum 括号 diff 与 §A.3 #34 自报位置一致 |
| §D.7 冻结契约不改（callgate step 4-8 / 130 既有样本 / runtime.hpp 布局常量） | ✅ | 未改 callgate；130 既有样本 multiseed 全绿；kCtxSize/kCtxXmmBase 仍单一来源 runtime.hpp |
| §D.8 RVA mapping 表 + 病灶 marker→新 RVA | ⚠️ | 未做（ExitNative 未启用，无实际 marker 救回） |
| §D.9 完工 `git checkout main` 后再交报告 | ❌ | **未执行**。本单 partial 提交，建议项目主检视后再决定 commit / rollback |

---

## §5 遗留风险

1. **R5.1**：ExitNative handler 代码 + slot 设计 + 间接 jmp 路径在仓内未删，启用时需先解决 segfault 根因（§3.3 三假设任一）。
2. **R5.2**：translator `upper_bound_of_` 字段 + 双参数 overload 编译通过但调用方未启用，是死代码。启用 ExitNative 时只需在 backend `regvm_backend.cpp` 取消 lambda 注释。
3. **R5.3**：lifter log hex fix 是 §B.7 顺带要求，已实测通过；test_lifter.cpp:1490 行已同步更新期望字符串。
4. **R5.4**：stub indirect jmp 在 `keystone Intel 语法下，disp8 / disp32 边界需进一步实验验证（disp8 仅 ±128，disp32 上限待实测）`。
5. **R5.5**：deepcall 样本区分度问题（mit406-ruling L1）未触及 — 在 ExitNative 未启用下无关，启用后再依派活单 §B.7 顺带修复。

---

## §6 文件状态汇总

```
M passes/lifter/src/lifter_core.cpp           (hex log fix — §1.7)
M passes/lifter/tests/test_lifter.cpp         (expectation update — §1.7)
M passes/pe_loader/include/.../pe_image.hpp   (pdata model — §1.1)
M passes/pe_loader/src/pe_image.cpp           (pdata parsing — §1.1)
M passes/stub_link/src/stub_gen.cpp           (REVERTED — §1.5, §3.4)
M passes/virtualize/CMakeLists.txt            (link wiring — §1.8)
M passes/virtualize/tests/CMakeLists.txt      (link wiring — §1.8)
M vm/regvm/backend/CMakeLists.txt             (link wiring — §1.8)
M vm/regvm/backend/src/regvm_backend.cpp      (upper_fn DISABLED — §1.6)
M vm/regvm/backend/tests/CMakeLists.txt       (link wiring — §1.8)
M vm/regvm/isa/include/.../vm_op.hpp          (ExitNative enum — §1.2)
M vm/regvm/runtime/src/asmgen.cpp            (handler written, DISABLED — §1.4)
M vm/regvm/translator/include/.../translator.hpp (upper_bound interface — §1.3)
M vm/regvm/translator/src/translator.cpp      (ExitNative emit — §1.3)
```

— MIT-407 partial delivery, WVmpCppDev @ 2026-08-29
