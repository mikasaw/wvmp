# MIT-444 (X3b asmgen x86 整数面全支持) 裁定 — ACCEPT；x86 真可跑面 19→57；#33 反向纠项目主两处粗数；十五连满分

> 裁定人: 项目主 — 2026-09-01 18:2x | 处置: ff-merge main=`9c00962`, done
> 复验: agent worktree 已自拆（十五连延续），项目主另建 `wvmp-x3b`@9c00962 双 arch 独立重建亲跑

## 1. 独立复验（全部亲测）
| 项 | 实测 (@9c00962) |
|---|---|
| 双 arch 构建 | x64 build rc=0 + x86 交叉链 rc=0（`file` 验真 PE32）|
| **x86 电池（我亲手 WOW64 复跑）** | **28/28 PASS rc=0**（6842ms——X3a 11 例全保留 + 17 例新增逐族：AdcSbbCarry/ImulMulEdges/CdqSignExt/ShiftImmMask/RolRorFlags/ExtendOps/BswapXchg/SetccCond/CmovccCond/BitCountOps/CmpxchgAcc/XaddBitOps/PushPopStack/RvaFamily/JmpJccFarTarget——补集清单↔TEST 名对照表点数一 op 不漏）|
| x86 dump 门 | 我亲手带 WVMP_RUNTIME_DUMP 重跑电池 → **PASS（57 登记项全覆盖）**；三件套同步亲点: x86 handler 表 grep=**57** = BATTERY_HANDLERS=**57** |
| ctest | 亲跑 **16/16** |
| **D6 x64 恒等铁证** | 我亲手双 CLI（main@4050a4c vs 分支）同 seed(12345) asm_dump：**161,756B 逐字节恒等**，sha256 前缀 `f67c2d408a5e587a3445a7be4873b577` 与报告逐位吻合；且 agent **每批次 commit 逐批复验**（7 commit 全绿节奏=批次纪律兑现）|
| multiseed / wvmpTest | 亲跑 **250/250**（REQUIRE_REAL=1，无新样本——B.3 零代码故池不变）；stubs=14 + jt@0xDD84 + en=17 + 双跑 **diff 0 103/103** |
| 冻结契约 | translator/lifter/runtime.hpp/vm_op(97)/backend/cli/sdk diff=**0 行**（D3 唯二解禁中 translator 实际零动用——见 §3）|
| 移位掩码直读 | `0x1F` 双处落点（:3607-3608 kX86FRegA/B 表）亲见 |
| 硬条款 | 命名分支+main 未动+零脏+切回 main+worktree 自拆+ff-safe+104 分钟对账——**十五连满分** |

## 2. #33 判定：反向纠锚两处，成色十足
① 我 §A.2 写"x86 表 29 登记行"——**实数 19**（agent `grep -c` 点名，我本轮复点 57=19+38 恰吻合其批迁账）；② 交接注记"SSE 族 34"——**实数 32**（逐枚举去重）。"45 粗数"按 D1 补集为准=**38 真迁 + 2 Div/Idiv(D2) + 2 Movsxd 族(x86 不可达) + 3 协议面 + 32 SSE = 77 账目闭合**——B.4"60+"目标差 3（57 实交），不凑数违 D2 保折叠——**宁少而准全文物兑现**。

## 3. 三项裁决 + B.3 证据链全合格
- **4B 槽裁决**（本单最精）: guest esp 步进 4B × ctx 槽 8B（442"S64=VM 槽宽"）不冲突——槽内 32 位零扩展不变量 ⇒ dword 低半字算术等价、下溢回绕 0xFFFFFFFC 恰=native esp 语义（qword 回绕才是错形）
- **X4 新挂账（高价值发现）**: translator 的 rsp 步进/rip-RVA 带 size_field(S64)（VM 槽宽 tag 非 native 宽度请求）→ **x86 运行时 3 路尺寸链折防御 no-op——X4/X5 全管道解锁前必须改形，否则 rsp 步进静默空转**。已入 GAPS；X3a 备好的 Push/Pop 4B handler 供切换。**这条是"电池全绿≠全管道通"的教科书预演——若拖到 X4 撞见，排查成本翻数倍**
- 移位掩码 = 0x1F 全宽（派单"S32 与 x64 相同"措辞被纠: x64 S32 档实际 0x3F——x86 实测 count=0x20 值+flags 双不变钉死）；RVA=base+RVA 非 identity（base=0x400000≠0 反证锚）
- **B.3 零代码收口（合规）**: pop 位宽=442 已同 commit 双侧 gate（`git log -S` 取证，纠我派单"只 gate push"锚）；S16 串形=维持 gate 三点证据链（唯一来源闸在 lifter=冻结面/translator 单改=不可达死代码/X3c 两文件最小 diff 配方已写入 GAPS 且运行时零改动——S16 Load/Store/Cmp handler 本单已全绿）

## 4. 批迁实录
电池当场炸当场修 3 处 x86 emit 缺陷（xadd 写回误用 kind 槽/cmpxchg S8 载体越字节可编码集 seed 相关/setcc tail 复用 cond 载体）+ 9 处期望侧心算错反证修正——x64 恒等全程未受扰。D2 除零保持折叠（例外有意）；Cmpxchg/Xadd/Bts 族按 419 单 VmOp native 直执行模板平移成功。

## 5. X3c 输入更新（按剩余纸面真数重排）
仍纸面 39 = **SSE 32**（GAPS 已纠数）+ Div/Idiv 2（D2 例外）+ Movsxd 族 2（不可达注死）+ **协议面 3（CallGate reg-target/ExitNative 4B/Ret x86 形）** + 本单新账 translator S64 tag 改形（归 X4 前置）。X3c 建议范围: 协议面 3 + x87 D1 一页备忘 + shld/shrd/cwd 评估（442 挂账）；SSE 32 独立评估是否拆 X3d（槽位偏移公式按 x86 帧重核=纯机械但有量）。
