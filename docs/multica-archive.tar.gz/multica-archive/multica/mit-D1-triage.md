# MIT-D1 triage 报告 — 区域外跳转 8 病灶侦察 + ExitNative(B') 可行性确认书

- verifier: WVmpVerifier (裁定型 / 纯侦察, 零产品代码改动, 未采纳开发侧任何结论)
- 静态分析基线: `wvmpTest/build/x64/test_target.exe` 941,056 B, sha256 `bdbfff91…edba862c` (08-28 17:46 构建, 与 §A handover_protect.log 同一二进制)
- CLI 基线: main `43b3827` (MIT-B2), 用 `git worktree add --detach C:\Users\www\AiCode\WVmp\wvmp-mitD1-verify 43b3827` 自建 (Ninja Debug 336/336 rc=0; 主仓 build/cli 的 CLI 是 **mit-c-intdiv 分支 404-WIP 产物**, mtime 10:13 > HEAD 10:05, 已按 §C 隔离不用)
- 采集时间: 2026-08-29 10:40–12:00 (+0800), 全部数字来自实测输出/脚本粘贴, 分析脚本留档于本机 workdir (d1_scan/d1_master/d1_b1/d1_matrix.py + %TEMP%\d1_verify\d1_b3_*)
- 结论置信度: 高 (obj 符号字节匹配 + .pdata + capstone 5.0.7 反汇编 + 干净 main CLI 复跑 + B.3 双样本实测, 五路互证)

## §0 结论(裁定)

**B' 全行 (GO)** — 8 病灶 8/8 救回 (判据 ≥6), 17 条越区跳转 0 反例 (跳出后 0 回跳), 且上界算法实测最优解是 **③ .pdata 函数真边界 (17/17)**, 而非派单倾向的 ② int3 扫描 (13/17, 紧排布函数间无 ≥8 字节 int3 垫时失效) — D2.1 的"打平才选 ②"前提不成立, 详见 §3。

**D2 按可救集派单**: 可救集 = 8 个已报告病灶全部 + MIT-404 合入后新暴露的 4 个隐性病灶中的 3 个 (r07/r08/r11, 隐藏跳转全为 END-call 目标); 维持 gate 集 = r06 wv_duff_copy (Duff 设备 `jmp rax` 间接跳转, B' 静态不可解, 属 404 后残留, 与越区跳转无关)。**404+B' 后预测覆盖 13/14** (r09 mul64hi + r12 sha256_compress 真虚拟化, 11 个 ExitNative 救回, 1 个保守 gate) — 达到 ≥12/14 验收锚。404-WIP CLI 实测 (§2.3) 已实证该预测: 2 stubs + 12 个跳转 gate note, RVA 与静态预测逐一相符。

## §1 B.1 marker→函数 映射实证 (8/8 全部推翻派单猜测)

**方法 (可复现)**: ① 用 kernels.obj COFF 符号表 (dumpbin /symbols) 取 15 个 `wv_*` extern 函数的独立 section; ② 对每个函数取首段 24 字节无重定位窗口做 key, 在 test_target.exe .text 做重定位掩码字节匹配 → 14/15 唯一命中 (wv_sha256_h0 为纯数据 thunk 无匹配, 未打标无影响); ③ .pdata RUNTIME_FUNCTION 边界与 obj rawsz 逐一互证 (14/14 start/end 全等); ④ 语义抽检: r01 区内 `call 0xD540` 指向自身入口 = 递归 (ackermann ✓); r04 的越区 jmp 目标 0xDA4B 落在 `add rsp,0x38; ret` 且旁路 `mov eax,-1` (bsearch 未命中路径 ✓)。

| # | 日志 marker (文件偏移) | 区域 [begin,end) RVA | 实测函数 (RVA) | 派单猜测 | 判定 |
|---|---|---|---|---|---|
| 1 | 0xc951 | [0xD551, 0xD57C) | **wv_ackermann** (0xD540) | wv_mul64hi? | ❌ 推翻 |
| 2 | 0xc9c7 | [0xD5C7, 0xD694) | **wv_b64_decode** (0xD5B0) | wv_duff_copy? | ❌ 推翻 |
| 3 | 0xcac7 | [0xD6C7, 0xD988) | **wv_b64_encode** (0xD6B0) | wv_bsearch_i32? | ❌ 推翻 |
| 4 | 0xcdc7 | [0xD9C7, 0xDA41) | **wv_bsearch_i32** (0xD9B0) | wv_insertion_sort? | ❌ 推翻 |
| 5 | 0xce67 | [0xDA67, 0xDB62) | **wv_crc32_update** (0xDA50) | wv_ackermann? | ❌ 推翻 |
| 6 | 0xd758 | [0xE358, 0xE44F) | **wv_rc4_crypt** (0xE340) | wv_rc4_ksa? | ❌ 推翻 |
| 7 | 0xe023 | [0xEC23, 0xED07) | **wv_xtea_decipher** (0xEC10) | wv_b64_encode? | ❌ 推翻 |
| 8 | 0xe153 | [0xED53, 0xEE37) | **wv_xtea_encipher** (0xED40) | wv_b64_decode? | ❌ 推翻 |

根因: 链接器排布 ≠ 源文件声明顺序 (实测布局: ackermann, b64_decode, b64_encode, bsearch, crc32, duff_copy, insertion_sort, md5_compress, mul64hi, rc4_crypt, rc4_ksa, sha256_compress, xtea_decipher, xtea_encipher)。附: 真虚拟化的 1/14 = **wv_mul64hi** (r09, marker@0xd673); div/cdqe 病灶归属实测为 duff(count/8 idiv×2)/insertion(cdqe×1)/md5(cdqe×1+cdq×3)/rc4_ksa(i%keylen idiv×1)/sha256(cdqe×8)。

**日志地址语义澄清 (三套地址空间, 实测钉死)**:
1. `marker@0x…` 名字 = **文件偏移** (marker_scan_pass.cpp:171 `hex_off(r.begin_off)`, 设计如此; RVA = 名字 + 0xC00);
2. virtualize 跳转 note `(rva=0x…)` = **真实 RVA** 的跳转指令地址 (13/13 与静态反汇编逐一相等);
3. lifter note `@rva 0x56214` = **十进制误挂 0x 前缀** (lifter_core.cpp:159 `std::to_string(item.addr)`): 56214(十进制) = 0xDB96 = duff 第 1 条 idiv 的真实 RVA。17/17 条 lifter note 按十进制解读后与静态清单逐一相等。→ 🟡 建议修为 hex 输出 (一行), 否则人读日志必被误导 (派单 §A 的"目标 RVA"列即受害于此, 见 §2.1)。

## §2 B.2 四问矩阵 (17 条越区跳转全量, 0 抽查)

### §2.1 关键更正: 派单 §A 的"越区目标 RVA"列实为"跳转指令地址"

实测 (capstone 直读编码目标): 17 条越区跳转 (13 条在 8 个已报告病灶 = 日志 note 逐一对应; 4 条藏在 404 病灶的 lifter-gate 后面, 见 §2.3) 的**真实编码目标**只有两类:
- **13 条 → 本区域自己的 END-call** (`target == end_rva`, 即 `call marker_end` 的 E8 地址 — 恰是现有 stub 的 resume 点!);
- **4 条 → 本函数 epilogue** (0xD59F ackermann ×2, 0xD69D b64_decode, 0xDA4B bsearch `add rsp;ret` — 0xD59F/0xD69D/0xDA4B 均越过 END-call 5 字节之后)。

无一条跳向其他函数、无一回跳本区。§A 表中"0xD55F/0xD566/0xD57A 三连跳共享尾部"实为 ackermann 区内 **3 个跳转点**(2 个目标), 不存在跨 marker 共享尾。

### §2.2 四问全表 (列: 跳转@RVA mn → 目标 | Q1 落界 | Q2 回跳 | Q3 栈 | Q4 共享)

| 区/函数 | 跳转@ | 目标 | 目标形态 | ① next-BEGIN | ② int3+retn | ③ .pdata | 回跳 | 目标处栈形态 |
|---|---|---|---|---|---|---|---|---|
| r01 ackermann | 0xD55F jmp | 0xD59F | epilogue | Y(0xD5C7) | Y(0xD5A4) | Y(0xD5A4) | 无 | add rsp,0x28; ret |
| r01 ackermann | 0xD566 jne | 0xD57C | END-call | Y | Y | Y | 无 | call marker_end; 2×递归 call; epilogue |
| r01 ackermann | 0xD57A jmp | 0xD59F | epilogue | Y | Y | Y | 无 | 同上 epilogue |
| r02 b64_decode | 0xD5FB jae | 0xD694 | END-call | Y(0xD6C7) | Y(0xD6A2) | Y | 无 | call marker_end; mov eax; add rsp,0x48; ret |
| r02 b64_decode | 0xD638 jmp | 0xD69D | epilogue | Y | Y | Y | 无 | add rsp,0x48; ret |
| r03 b64_encode | 0xD8A3 jmp | 0xD988 | END-call | Y(0xD9C7) | Y(0xD9A4) | Y | 无 | call; movsxd; 写 NUL; ret |
| r03 b64_encode | 0xD8B3 jne | 0xD988 | END-call | Y | Y | Y | 无 | 同 |
| r04 bsearch | 0xD9E1 jg | 0xDA41 | END-call | Y(0xDA67) | **N**(无 int3 垫) | Y(0xDA50) | 无 | call; mov eax,-1; add rsp; ret |
| r04 bsearch | 0xDA14 jmp | 0xDA4B | epilogue | Y | **N** | Y | 无 | add rsp,0x38; ret (旁路 mov eax,-1) |
| r05 crc32 | 0xDB1B je | 0xDB62 | END-call | Y(0xDB88) | **N** | Y(0xDB70) | 无 | call; mov eax; add rsp; ret |
| r06 duffⒶ | 0xDBB4 ja | 0xDD76 | END-call | Y(0xDDC2) | Y(0xDDA4) | Y(0xDDA4) | 无 | call; nop; add rsp; ret |
| r07 insertionⒶ | 0xDDDF jge | 0xDE5A | END-call | Y(0xDE98) | Y(0xDE65) | Y(0xDE65) | 无 | call; nop; add rsp; ret |
| r08 md5Ⓐ | 0xDFBB jge | 0xE18B | END-call | Y(0xE273) | Y(0xE258) | Y(0xE258) | 无 | call; 读状态; 多 instr |
| r10 rc4_crypt | 0xE392 jae | 0xE44F | END-call | Y(0xE498) | Y(0xE477) | Y(0xE477) | 无 | call; 写 i,j; ret |
| r11 rc4_ksaⒶ | 0xE4EF jge | 0xE57A | END-call | Y(0xE5D8) | Y(0xE5A2) | Y(0xE5A2) | 无 | call; 写 i=j=0; ret |
| r13 xtea_dec | 0xEC76 jge | 0xED07 | END-call | Y(0xED53) | **N**(垫 5B<8) | Y(0xED3B) | 无 | call; 写 v[0],v[1] |
| r14 xtea_enc | 0xEDA6 jge | 0xEE37 | END-call | **N**(末区无下家) | Y(0xEFD3) | Y(0xEE6B) | 无 | call; 写 v[0],v[1] |

Ⓐ = 被 div/cdqe lifter-gate 掩盖的隐性病灶 (D3 已证, 静态+404-WIP 双重确认)。13 条已报告 note 中: ① 7/8 病灶覆盖 (r14 末区无下家), ② 5/8 (r04/r05/r13 失败), ③ 8/8。17 条全量: ① 16/17, ② 13/17, ③ **17/17**。

### §2.3 隐性病灶 (D3): lifter-gate 掩蔽机制 + 404 后将暴露的 4 条

机制实证: regvm_backend.cpp:85-88 — lifter 有 skipped_ranges 时 `if (!skipped) translate_function(fn)` **短路**, translator 根本不跑 → r06/r07/r08/r11 的越区跳转 note 在 08-28 日志里结构性不可见。静态预测它们 404 修复后将全部以 END-call 目标形态暴露; 404-WIP CLI 实测 (本机 build/cli, mit-c-intdiv 分支产物, 仅作旁证并披露): 恰好 12 个 marker 出跳转 gate note, 含 0xDBB4/0xDDDF/0xDFBB/0xE4EF — 与静态预测**逐一相等**, 且 r12 sha256 (纯 cdqe×8) 成功虚拟化 (2 stubs)。待 404 正式合入后按 §D3.1 复扫确认。

### §2.4 Q3 详答: ExitNative 写回链 = 可复用, 差一处需适配 (终态 jmp)

- **区域栈事实**: 14 个区域 push 计数全 0, sub/add rsp 全 0 (全在区域外的 prologue) → 每个退出点上 VM 跟踪 rsp (regs[4]@ctx+0x30) 恒等于 entry rsp。
- **现状链**: HALT 后 stub_gen.cpp 写回 rax,rcx,rdx,r8-r11 + xmm0-7 → `add rsp,kCtxSize; pop r15..rbx; jmp resume_rva`, 物理 rsp 恢复到 **entry rsp** (= native_sp, 与 callgate ctx+0x120 基准同一假设)。对 callgate (asmgen.cpp:1012-1080 注释链) 的对照: callgate 是"短期出去再回来" (step 4 切 native_sp-0x28, step 7-8 回滚), ExitNative 是"终端出去不回来" — 因此 ExitNative 复用的不是 callgate step 4-11, 而是 **stub 的 HALT 写回链本身**。
- **可复用判定**: 13 条 END-call 目标的 ExitNative(end_rva) 与现有 resume 语义**逐字节等价** (stub 终态 `jmp resume_rva` 的 resume_rva 本来就是 end_rva); 4 条 epilogue 目标同样落在 entry rsp 上, 链直接可用。
- **需适配的一处**: stub 终态 `jmp rel32 end_rva` 是**编译期固定目标**, ExitNative 的目标是**逐操作数动态** (aux RVA) → D2 需把终态 jmp 改为 ctx 槽间接 (`jmp [rsp+SLOT]`; stub 入口预写 end_rva, ExitNative handler 覆写 aux)。stub 在 .wvmp 节内无窗口限制, 改动面可控。
- **条件语义**: 17 条中 12 条 jcc (je/jne/jg/jge/jae/ja) + 5 条 jmp → ExitNative 需要条件退出形态 (复用 VmOp::Jcc 的 cond 机制或 Jcc+ExitNative 对), 纯 jmp 5 条可无条件。
- **EFLAGS 契约**: 写回链不恢复 rflags。实测 15 个去重目标的落点代码 (§2.2 末列) 在任何 flags 读取前就覆写 flags (mov/call/add 全为写) — 本二进制零风险; D2 须把"目标不得消费 flags"写进 handler 契约。
- **潜在约束 (如实披露)**: 若未来区域含未配平 push, 现有 HALT/resume 链 (及 ExitNative) 会以 entry rsp ≠ VM rsp 恢复 — 这是**当前就存在的潜在缺陷** (今日 14 区域不触发), 非 B' 引入; 建议 D2 顺带在契约中写明或显式回写 regs[4]。

### §2.5 Q4 详答: 无跨 marker 共享尾

15 个去重目标, 每个只属于 1 个函数; 唯一共享是函数内 (ackermann 2 跳转点 → 同一 0xD59F)。D2 无需去重机制: ExitNative 的目标是操作数 (aux RVA) 而非发射代码, 多站点同目标天然无冲突。

## §3 上界三候选覆盖对比 + 选型 (D2.1 答复)

| 候选 | 定义 (实测实现) | 17 条覆盖 | 8 病灶覆盖 | 失败模式 |
|---|---|---|---|---|
| ① 下个 BEGIN 的 marker 函数地址 | next region begin (marker 序) | 16/17 | 7/8 | 末区 (r14) 无下家, 需补 section-end 兜底 |
| ② int3-padding + retn 簇扫描 | 从 END 向后扫首个 ≥8B 连续 0xCC (扫到前须见 ret) | 13/17 | 5/8 | MSVC /Od 紧排布: r04/r05 函数间 0 字节垫, r13 仅 5 字节垫 → 无 int3 run 可找 |
| ③ 函数真边界 (.pdata) | RUNTIME_FUNCTION EndRva | **17/17** | **8/8** | 叶函数无 .pdata 条目 — 但打标函数必调 marker_begin ⇒ 必非叶 ⇒ 必有条目 (B.3 样本 d1_far_helper 实证叶函数确实无条目, 与本判定不冲突) |

**选型结论: ③ .pdata**, 依据: (a) 唯一 17/17 全覆盖; (b) 边界精确到真函数尾 (①② 给的都是"下家之前"的松上界); (c) 数据已在目标 PE 里 (test_target.exe .pdata 0x549C 字节, 1805 条), pe_loader 解析 ~50 行, 无符号表/PDB 依赖; (d) 对 /O2 尾调用/尾合并等跨函数跳转天然保守 (目标超 .pdata end → gate)。派单 D2.1 "打平才选 ②" 的前提不成立 — ② 与 ③ 差 4/17。维护成本: .pdata 解析需处理条目缺失/乱序的防御 (排序 + 二分), 以及函数 chunk (x64 可分片) 时取主片 end 的语义 — 建议写入 D2 派单。

## §4 B.3 反例压力测试 (临时样本, %TEMP%\d1_verify, 不进仓库)

样本: d1_b3_sample.cpp (cl /O2, 标记宏复用 wvmpTest/src/targets/wvmp_protect.h; 4 个打标函数 + 1 个叶辅助), 用干净 main CLI (worktree 自建) protect。

### ① 跳出后回跳 (B' 必须识别并 gate)

d1_back: `goto L_out` 越区 (jmp@0x107A → 0x10A2), L_out 内 `jmp 0x1089` **回跳进区域** (0x1089 = L_in ∈ [0x1065,0x1094)) — 回跳 walker 实测 `back_into_region=YES`。
- protect 实测: `函数 (marker@0x465) … 跳转目标块未找到（区域外/未 lift） (rva=0x107A)` → 整函数 gate ✓ (当前 C1 保守底线成立; note 只报 0x107A 一条系 lifter 块终结后 0x107C 不可达不 lift, 与主样本 17 条静态 vs 13 条 note 的收敛规则一致)
- 运行实测: native rc=0 / packed rc=0, stdout **byte-exact PASS** (cmp 无差) ✓

### ② 目标超界 (下一函数中, 必须 gate)

d1_tail (/O2 尾调用): 编译器真实发出 `add rsp,0x28; jmp d1_far_helper` (0x1157) — 自然形态的跨函数跳转, 但链接器把 callee 排在了下一打标函数**之前**, 目标向后。为得到"向前超界"形态, 对临时样本做 **4 字节 rel32 补丁** (jmp@0x1157: 0x1100 → 0x1174 = main 体内, 超出 d1_tail .pdata end 0x1169, 超出全部三候选上界; 披露: /Od 编译器不会发出向前跨函数跳转, 自然形态受链接器布局所限, 故用补丁构造, 样本语义变为确定性垃圾路径)。
- protect 实测: `(marker@0x54c) … (rva=0x114F)` + `(rva=0x1157)` 双 note → 整函数 gate ✓ (B' 判据下 0x1174 超全部上界 → 必须维持 gate, 现管道行为正确)
- 运行实测: patched native 与 packed **同因同位崩溃** (均 rc=139, 均 0 字节 stdout, byte-exact PASS) — 证明 gate 后函数 = 原字节原样执行, 行为逐位保持 ✓

### 对照组

d1_mid / d1_ctrl (单出口干净函数) 均成功虚拟化 (2 stubs) — 管道对干净函数的虚拟化能力不受影响。

## §5 裁决出口 (B.4)

**✅ B' 全行** — 判据逐条: 8 病灶救回 8/8 (≥6 ✓); 17 条越区跳转 0 反例 (✓); B.3① 证明回跳形态真实可构造且静态 walker 可检出 (B' 必须带上"目标块 ≤3 层可达集内不得回跳本区"的静态检查, 已给实现要点); B.3② 证明超界形态下现管道 gate 底线不破。

**可救集/维持集精确划分** (404 合入后口径): 可救 = r01 ackermann, r02 b64_decode, r03 b64_encode, r04 bsearch, r05 crc32, r07 insertion, r08 md5, r10 rc4_crypt, r11 rc4_ksa, r13 xtea_dec, r14 xtea_enc (11 个); 真虚拟化 = r09 mul64hi + r12 sha256 (404 后); 维持 gate = r06 duff_copy (间接 jmp, B' 范围外)。预测覆盖 **13/14**。

**给 C (双向分段) 的入场理由**: 不需要 — B' 覆盖 13/14 后剩余仅间接跳转类 (不可静态定目标, C 亦无解), C 的双向 re-enter 场景 (区域内↔区域外往返) 在实测语料中 0 出现。

## §6 D2 派单 §A 假设素材 (可直接抄进 MIT-D2 描述文件)

1. **上界算法 = .pdata 函数真边界**: pe_loader 新增 RUNTIME_FUNCTION 解析 (12B/条, 排序+二分); 越区判定: `target ∈ [end_rva, pdata_end(begin_rva))` 且目标可达集 (静态 jcc/jmp 边 ≤3 层) 与 [begin_rva, end_rva) 无交。.pdata 无条目时回退 ① next-marker-begin + section-end (末区/ stripped)。
2. **VmOp::ExitNative** (append-only): aux = 目标 RVA (u32), cond_or_size = ir::Cond (无条件形态用固定值); 12/17 站点为 jcc, handler 需条件退出 (复用 Jcc cond 求值); 纯 jmp 可无条件直退。
3. **写回链复用 stub HALT 链** (stub_gen.cpp): rax,rcx,rdx,r8-r11 + xmm0-7 写回 + add rsp/pop 序列不变; **唯一结构改动 = 终态 `jmp rel32 end_rva` → `jmp [rsp+EXIT_SLOT]`**, stub 入口预写 end_rva, handler 命中时覆写为 aux。
4. **rsp 基准**: 沿用 entry rsp (= ctx+0x120 native_sp, 与 callgate 同基准); 本语料全部退出点 VM rsp == entry rsp (14 区域 0 push/0 rsp 调整实测)。契约须写明"区域退出点若有未配平 push 需回写 regs[4]"(现 HALT 链同样存在的潜在约束)。
5. **EFLAGS**: 落点不消费 flags (15 去重目标实测); 契约写明, 不做 pushfq 回写 (范围决策留给项目主)。
6. **验收锚**: wvmpTest 1/14 → **≥13/14** (404 已合入口径; 若 404 未合入先验, 按 8/14 病灶口径 ≥8/14); 新 E2E 双形态样本 = B.3 的 d1_back (回跳 gate) + d1_tail (超界 gate) + 一个 END-call 形态正样本 (ExitNative 生效路径); multiseed 全绿 + wvmpTest 双跑 byte-exact + 保守 gate marker (r06) 行为与修复前逐字节一致。
7. **diag**: `exit-native @ <rva> -> <target> (<cond>)`, note 级, 每站点一条。
8. **顺带修复建议 (非阻断)**: lifter_core.cpp:159 note 的十进制+0x 前缀混淆 (§1); marker_scan 名字的文件偏移空间 vs note 的 RVA 空间建议统一 (至少在 STATUS/文档写明)。

## §7 known compromise / 披露

1. 主仓 build/cli/wvmp_cli.exe 为 404-WIP 构建 (mit-c-intdiv 分支, 8 个未提交修改文件, mtime 晚于 HEAD) — 本报告一切门禁级结论均用 **worktree 干净 main 43b3827 自建 CLI** 复跑; 404-WIP 运行仅作 §2.3 旁证并明确标注。主仓工作树的未提交改动系 404 开发所有, 本单零触碰 (HEAD 不变, tracked 文件 0 改动)。
2. B.3② 用 4 字节补丁构造 (原因见 §4②); 补丁后程序为确定性垃圾路径, 同因崩溃亦逐位保持 — 若需"非崩溃形态"的正/反样本, 属 D2 样本工程范围。
3. 派单 §A 表的两处事实修正: (a) "越区目标 RVA"列 = 跳转指令地址而非目标 (§2.1); (b) "8×11 目标"实为 8 病灶 × 13 note (去重后 15 目标); 本单按 13 note 全量作答。
4. RVA 有效性范围: 全部 RVA 仅对 sha256 bdbfff91… 的 08-28 test_target.exe 有效 (§F); B' 上界算法的鲁棒性由"算法不依赖具体 RVA"保证 (.pdata/区域边界均运行时读)。
5. 未覆盖范围: C (双向分段) 的运行时 re-enter 协议未做原型验证 (结论 §5 基于 0 反例的静态证据); .pdata 函数 chunk (分片) 在本语料 0 出现, D2 需防御性处理。

== MIT-D1 triage 完 (验证员: WVmpVerifier, 2026-08-29) ==
