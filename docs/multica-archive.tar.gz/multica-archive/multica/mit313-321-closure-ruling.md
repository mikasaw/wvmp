# MIT-313 / MIT-321 批量收口裁定 — 历史 verifier todo 单

> Author: 接手人 (项目主) — 2026-08-29 UTC+8
> Status: **ACCEPT ×2, push to `done`**
> 依据: 交接文档 §7.2 P2-9 ("沿用 MIT-380 verifier 模式裁定") + historical-in-review-closure 模式 9 (派活单核心目标已由后续 commit 达成, self-claim 收口)

## 1. 双单核查

### MIT-313 (MIT-312 verifier: fresh verify movsxd + snake 区域配对)

| 项 | 状态 |
|---|---|
| verifier run `01a037db-fe6` | **completed** (报告已发: "MIT-307/312 自身目标达成, 4 种字节形式全接住, 0 条 movsxd 警告") |
| 项目主裁定文档 | ✅ 已存在 `.multica/mit312-ruling.md` ("采纳 ACCEPT + 立 snake 改造 sub-issue") |
| 裁定遗留 sub-issue | movsxd 在 main (git log 可溯); snake 改造线 = MIT-320/322/324 链, 其中 MIT-324 `d493d93` 系 main 祖先 ✅; "区域配对 3 早返回"问题已被 MIT-322/324 forward-jump 线 + 本会话 MIT-B2 后的 100/100 基线覆盖 |
| 结论 | **核心目标已达成, verifier 已交付, 裁定文档已落盘** — 单状态 todo 系收口时漏推 (与历史 9 单批量收口同因) |

### MIT-321 (MIT-320 verifier: fresh verify snake div + forward-jump blocker)

| 项 | 状态 |
|---|---|
| verifier run `01a0386f-e03` | **completed** ("有条件接受 ✅, div 修复核心目标完全达成, 91ee827") |
| 项目主裁定文档 | ✅ 已存在 `.multica/mit320-ruling.md` ("部分采纳 CONDITIONAL ACCEPT + 立 forward-jump sub-issue") |
| 裁定遗留 sub-issue | `91ee827` 实测 **main 祖先 ✅** (merge-base --is-ancestor); forward-jump sub-issue = MIT-322→324 链已 done (mit322/mit324-ruling.md 在案) |
| 结论 | 同上 — 目标与遗留全部闭环, 单状态 todo 系漏推 |

## 2. fresh verify 实测记录 (2026-08-29)

```
multica issue runs: 两单 verifier run 均 completed (非无报告空转)
git merge-base --is-ancestor 91ee827 main  → YES
git log main | grep -c "forward-jump"     → 命中 (MIT-324 链)
multiseed REQUIRE_REAL=1 (MIT-403 后)      → 100/100 — snake 样本 5/5 含于内
```

## 3. 沉淀

- **pitfall 补记**: verifier 单收口三件套 = ruling 落盘 + 遗留 sub-issue 闭环 + **status 推 done** — 历史流程做了前两件漏第三件, 导致 08-25 的两单挂 todo 三天。wvmp-issue-conductor 收口步骤应显式列"三件套缺一不可"。
- 本裁定后 WVmp multica 板面 **open 单清零** (50 done / 2 cancelled / 0 todo-in_review-in_progress-backlog?) — 待 multica list 复核。

## 4. close-out action

- `multica issue status MIT-313 done` + `MIT-321 done`
- 板面清零后, backlog 重建 (下一批候选见另文)

== 完 ==
