# MIT-379 裁定 — wvmpTest kernels.cpp WVMP 虚拟化标记 + 加壳 byte-exact diff

> Author: WVmpCppDev (verifier 角色, 依 2026-08-28 裁定型派活单 §B) — 2026-08-28 17:50 UTC+8
> Status: **ACCEPT** (6/6 PASS), 待项目主按 §H push `done`
> Verdict: 代码层 3 处核查 PASS / 行为层完整复跑 103/103 byte-exact PASS / cross-verify 两 diff 空 PASS / conflict 根因 = 时间线错位 (MIT-380 修复落地于 agent 报告之后), 非任何一方的不诚实

---

## 0. 时间线还原 (conflict 的唯一真根因)

| 时刻 (UTC+8) | 事件 | sha256 区域结局 |
|---|---|---|
| 08-27 ~19:58 | agent 用 `build\vs\cli\Debug\wvmp_cli.exe` (pre-MIT-380) protect → packed.exe 970240B | **崩** rc=0xC0000005, `--filter=kern.sha256` 100% 复现 |
| 08-27 20:12 | agent 报告 + status=blocked ("lifter 有 8 条 cdqe notes 但无 veto 行, 疑似 gate 漏判") | 报告在当时**完全真实** |
| 08-27 21:38 | **MIT-380 `882df68` commit** — commit message 第一段点名 "MIT-379 诚实披露的 wvmpTest packed kern.sha256 segfault", 根因锁定 `regvm_backend.cpp` 的 `meta_list->front()` 退化: 14 函数虚拟化循环永远读 metadata[0] (空), sha256 的 skipped_ranges 在 metadata[N] → gate 永不触发 | 修复 |
| 08-27 21:59–22:07 | 项目主 fresh verify: 重建 + 重保护 → base_packed.log passed=103 + diff 空 | **通过** |
| 08-28 | 派活单 §A 拿 "agent 08-27 19:58 的报告" 对 "08-27 22:02 之后的盘面" 比较 → 判为 "双重矛盾" | — |

**结论**: 两个观测都为真, 相差一个上游修复提交 (100 分钟)。§A 表格中 "agent 自报 blocker ⚠️ 与 §A baseline 实证矛盾" 一行应改注为 "✅ 报告时点为真, 已被 MIT-380 修复超越"。

## 1. 代码层核查 (B.1) — 全部 PASS

### 1.1 kernels.cpp (commit 6f23f8e, 工作树=HEAD 干净)
- `#include "wvmp_protect.h"` L18 ✅
- `#pragma optimize("", off)` L108 ✅ (extern "C" 块前, 上方文件助手不受影响)
- **14 对标记逐函数核对**: BEGIN@118/132/150/162/173/185/214/247/269/283/300/314/333/364, END 各自函数收尾前配对 ✅; `wv_sha256_h0()` 无标记 ✅
- **§A "第 15 处 BEGIN 在 wv_sha256_compress 函数体内或 wrap-up 注释?" 两种猜测均不成立**: 第 15 处命中在 L7/L9 文件头部伪代码示例注释 (原仓库自带, 非本 commit 引入)。派活单 §A 该行应更正。
- 行数实测 **384** (git show 6f23f8e:...), §A 记 359 有误。

### 1.2 wvmp_protect.h
- noinline + volatile imm64 桩 (L38-58), static 不出符号 ✅
- magic 三方字节级比对 Python 实证: `kBeginMagic/kEndMagic` (0x31474542504D5657/0x31444E45504D5657) 的 LE 字节 == scan_core.hpp `kBeginPattern/kEndPattern` == sdk/markers.hpp — SYNC_BEG: True / SYNC_END: True ✅

### 1.3 kernels.toml
- input/output 绝对路径 = build/x64/test_target.exe → packed.exe ✅
- 六段管道 pe_loader/marker_scan/lifter/virtualize/stub_link/pe_writer ✅ seed=12345 ✅

## 2. 行为层核查 (B.2, D1.1) — 全部 PASS

fresh verify (本轮独立执行, 08-28 17:46):
```
build.bat → rc=0, [ok] build\x64\test_target.exe (941056B)
wvmp\build\cli\wvmp_cli.exe protect --config kernels.toml → rc=0
  stub_link: 已生成 1 个入口 stub, .wvmp 节 23730 字节 @ RVA 0x115000
  关键差异: (marker@0xd9d8) 出现 veto 行
    "含不可翻译指令, 跳过虚拟化 (保持原生): lifter 跳过 8 条指令 ... 触发 C1 gate"
    ← 08-27 agent 运行时恰恰缺失此行 (front() 退化, MIT-380 修复对象)
  13/14 区域保持原生 (cdqe/cdq/div/间接 jmp/区域外跳转), 1 区域 (0xD673) 真虚拟化
test_target.exe --compact --log → rc=0  SUMMARY passed=103 failed=0 skipped=0 total=103
packed.exe     --compact --log → rc=0  SUMMARY passed=103 failed=0 skipped=0 total=103
diff verifier_unpacked vs verifier_packed → 空 (byte-exact) ✅
packed --filter=kern.sha256 → [PASS] rc=0 (08-27 同命令 100% segfault) ✅
packed --filter=kern.xtea / kern.md5 → PASS ✅
```
注: §E 原命令用裸 stdout 重定向, 与 base 日志的 `--compact --log` 工序不一致将导致 B.3 必然非空; 本裁定按 base 日志同工序执行 (run_compare.cmd 语义), 且刻意不跑 run_compare.cmd 本身以免覆写项目主基线 out\base_*.log。

## 3. cross-verify (B.3) — 全部 PASS
```
diff base_unpacked.log verifier_unpacked.log → 空 ✅
diff base_packed.log   verifier_packed.log   → 空 ✅
```
verifier CLI (08-28 16:30 构建, HEAD 694eda0, 比 22:07 基线的 CLI 新 5 个 commit 含 MIT-373/374/375 SSE 支持) 输出与项目主基线逐字节一致 — 运行期行为对上游演进稳定。packed.exe 体积 963072 (08-27 基线) → 965120 (本轮) 属 VM runtime 镜像随 SSE 指令表增长的预期差异, 非配置漂移。§A "大小差 +22016 bytes (markers 字节)" 解释不确: 增量主体是 .wvmp 节 + 跳板, 14 处 marker 调用点仅 ~140B。

## 4. conflict 解释 (B.4, D2.1)

1. **"expected 128bit hex string, but got garbage"**: 该引语在 agent commit message (grep "128bit|garbage|hex string" = 0 命中)、报告评论、附件日志中**均不存在**, 亦不在 mit375-ruling.md — 系派活单误引。agent 当时的真实表述是 rc=-1073741819 (0xC0000005) 访问违例 + `--filter=kern.sha256` 100% segfault, 有附件 base_packed.log (md5 行后截断) 为证。
2. **"segfault" vs "passed=103"**: 两侧皆为真, 见 §0 时间线 — 观测分属 MIT-380 修复 (`882df68`, 08-27 21:38) 前后。
3. **"SHA 128bit 期望值错位"是否发生过**: 未发生过, 且从未被 agent 主张。本次 "错误方翻转" (pattern 7) 的实际形态是: **派活单 §A 将误引语安在 agent 头上, 而 agent 原始报告的根因诊断 (cdqe 记录存在但 gate 未 veto) 恰与 MIT-380 commit message 的根因结论逐字吻合** — agent 自报可信度高于 §A 引语。
4. agent 报告的一处自我修正 (不影响结论): 08-27 报告称 "xtea 对 = 真 VM 执行 PASS" — 实际当时 xtea 两区域亦被 gate 回退保持原生, 真虚拟化区域为 0xD673 (干净) + 0xD9D8 (残缺致崩)。当时 2 stub 中仅 0xD673 在 VM 内真执行并通过。

## 5. 最终 verdict (§E.6)

6 项全 PASS → **ACCEPT, MIT-379 push done**。
commit `6f23f8e` 真实达成验收流 "标记 → 编译 → protect → packed 与 unpacked 输出逐字节比对"; 验收达成依赖的上游修复 MIT-380 已合入主仓并随 CLI 演进保持有效 (本轮 verifier 用的是比项目主基线更新 5 个 commit 的 CLI, 结果仍 byte-exact)。

## 6. 遗留与建议

- 当前 14 内核中仅 1 区域真虚拟化, 13 区域靠 C1 gate 保持原生 — "加标 ≠ 被保护" 的覆盖率问题不在本单范围, 属 C2/C3/C4 handler/白名单扩展线 (MIT-244~249 精神) 的后续。
- 派活单 §A 表格若沉淀模板, 建议增列 "观测时刻" 字段, 防止再次把修复前自报 vs 修复后盘面判成 "矛盾" (pitfall #33 新亚种: 时间线错位假矛盾)。
