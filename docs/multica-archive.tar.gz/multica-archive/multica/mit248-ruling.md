# 项目主裁定: 采纳 MIT-248 (C4 rip-relative) 当前实现

## 独立核查结果 (2026-08-24, hermes)

### 1. 代码层核查 — 读关键改动文件

- `vm/regvm/isa/include/wvmp/regvm/isa/vm_op.hpp`: 新增 `VmOp::LoadRva` (32) / `VmOp::StoreRva` (33)
- `vm/regvm/runtime/src/asmgen.cpp:602-604` 新增 `build_loadrva`; 同样位置新增 `build_storerva`
- `vm/regvm/runtime/src/asmgen.cpp:1047-1048` handler 表注册 `{LoadRva, "loadrva", ...}` / `{StoreRva, "storeriva", ...}`
- `vm/regvm/translator/src/translator.cpp` `translate_load` / `translate_store`: 检测 m.base == Rip 时选 LoadRva/StoreRva, emit RVA 作为立即数
- `passes/pe_loader/include/wvmp/passes/pe_loader/pe_image.hpp` / `pe_image.cpp`: PeImage 加 image_base 字段 (PE32+ 8B / PE32 4B), parse_impl 读 OptionalHeader.ImageBase
- `passes/stub_link/src/stub_gen.cpp` / `stub_gen.hpp`: `generate_entry_stub` 多收 image_base 参数, stub 把 image_base 写入 VmContext+0x110 (scratch_mem 槽). PE32+ ImageBase > 0x7FFFFFFF 走 rax 中转避免 mov [mem], imm32 符号扩展.
- `passes/stub_link/src/stub_link_pass.cpp`: 从 PeImage 读 image_base 传入 generate_entry_stub
- `passes/pe_writer/src/pe_writer_pass.cpp`: 保护后清除 DllCharacteristics.DYNAMIC_BASE (ASLR); 仅在确实虚拟化时清除, byte-identical 单测不受影响

### 2. 行为层核查 — fresh 跑 build + 真二进制

- `scripts\build.bat`: rc=0, 0 警 0 错 (完整构建, 含新 rip-relative sample)
- `scripts\test.bat` (ctest): `100% tests passed, 0 tests failed out of 15`, 17.52 sec
  - regvm_translator_tests 0.65s (含 RipRelativeEncodesAbsoluteRVA / RipRelativeNegativeDisp PASS)
  - regvm_runtime_tests 3.01s (SemanticBattery 含 (e2) 段 LoadRva/StoreRva 真执行电池)
  - stub_link_tests 2.14s (新增 image_base 参数调用)
- `scripts\e2e.bat build\passes\marker_scan\tests\wvmp_rip_relative_sample.exe`: rc=0, **[e2e] PASS（虚拟化后行为与原生一致）** — 真虚拟化路径
- `scripts\e2e.bat build\passes\marker_scan\tests\wvmp_rip_relative_simple_sample.exe`: rc=0, **[e2e] PASS（虚拟化后行为与原生一致）** — 真虚拟化路径
- 回归样本 (无破坏):
  - `wvmp_rol_sample.exe`: rc=0 PASS（虚拟化后行为与原生一致）
  - `wvmp_whitelist_sample.exe`: rc=0 PASS（虚拟化后行为与原生一致）

证据路径: `C:\Users\www\AppData\Local\Temp\hermes-verify-mit248-73ccca6-fresh\verify_mit248.txt`

### 3. 重要事实: 原 run `01a03209` 在 daemon 重启时 failed, 新 run `01a03229` 自动接力

时间线 (multica timeline):
- 04:30 原 run 启动 (WVmpCppDev)
- 05:05 原 run failed (daemon restarted while task was in flight)
- 05:05 新 run `01a03229` 自动接力
- 05:17 agent 提交 commit `2d0b8ee`, status → in_review
- 05:21 agent 提交 fixup commit `73ccca6`, squad_leader_evaluated → action, status → completed

**原 run 真正卡点**: agent 在 05:05 时刻跑完保护后的 rip_relative_simple_sample.exe 出现 segfault (exit 139), 紧接着 daemon 在 05:05 重启, run 被标 failed. segfault 根因是 image_base 没正确传到 VM context 的 scratch_mem 槽 (或 stub 跳板的 image_base 计算有边界错). agent 接力后修复 (具体见 commit `2d0b8ee` 第 2/3/4 条改动), fresh verify 后两 E2E 样本 PASS, 无 segfault.

### 4. 已知妥协 (commit message 显式标注, 不算回归)

**ASLR 兼容性**: 当前实现下, pe_writer 在确实虚拟化时**清除 DllCharacteristics.DYNAMIC_BASE** (PE ImageBase 直接写入 VM context, ASLR 重定位后实际基址 ≠ ImageBase → 全局读写越界). 完整 ASLR 兼容需 stub 运行时通过 GetModuleHandle / __ImageBase 取真实基址, 已排期 M2-9+.

**含义**: 在启用 ASLR 的 Windows 上, 保护后的 PE **不会**被重定位, 等价于"禁用 ASLR". 短期可接受 (本地调试 + 自定义用户场景常关 ASLR), 长期需修. 提交说明里 M2-9+ 排期明确.

### 5. Intel SDM 对齐 (核心语义)

x64 [rip+disp] 实际访存地址 = next_ip + disp32, 其中 next_ip = 当前指令下一条指令的 RVA.

- 翻译期: translator.cpp `translate_load/store` 在 base == Rip 时算 `next_ip + disp` = 绝对 RVA, emit LoadRva/StoreRva + RVA 立即数. next_ip 从块布局推断: 同块下一条 / 下一块首 / fn.end_rva (与 Capstone 解出的 insn_len 一致).
- 运行时: asmgen `build_loadrva/storerva` 用 `VmContext.scratch_mem` (= image_base) + 立即数 (= RVA) 还原 VA, 然后做访存.
- `Load/Store` (非 rip) 改为直接对绝对 VA 访存, 不再加 scratch_mem (避免 host 寄存器值再次叠加 image_base 错位).

证据: `Translate.RipRelativeEncodesAbsoluteRVA` / `Translate.RipRelativeNegativeDisp` PASS.

## MIT-248 状态

采纳当前实现, 验收通过:
- 代码 Y (commit 2d0b8ee + fixup 73ccca6)
- 测试 15/15 Y (含 RipRelative 翻译测试 + LoadRva/StoreRva 语义电池)
- E2E Y (rip_relative_sample + rip_relative_simple_sample 真虚拟化)
- 回归 Y (rol / whitelist 无破坏)
- Working tree 干净 Y

请 (agent) 把 status 改 done. **C4 rip-relative done,  MIT-249 (C3 call gate) 可由项目主单独派活单, 严格串行纪律不变.**

## 沉淀

- **daemon 重启不会丢工作**: Multica 自动接力, agent 从中断处继续 (segfault 修复验证了这点). 原 run `01a03209` 标 failed, 新 run `01a03229` 接力完成.
- **E2E 真虚拟化 ≠ ** PASS 行最关键的判读: "虚拟化后行为与原生一致" 表示真跑通 VM 路径, "无入口 stub" 表示 C1 gate 跳过 (对修复前是阻塞, 修复后不应再有).
- **ASLR 妥协**: 当前实现禁了 ASLR (commit message 第 6 条显式标注), 短期可接受, 长期 stub 跳板需运行时取真实基址. M2-9+ 排期.
- **agent 不读 issue 评论**: 如果想给 agent hint, 应在 commit 前或派活前; 跑起来后基本不会回头看评论. 后续遇到复杂 issue 考虑在派活前多花点笔墨把关键技术点写在 issue 描述里.