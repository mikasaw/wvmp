# MIT-426 (G6a VEX.128 档A) 裁定 — ACCEPT，210/210，零新 VmOp 机器证明成立，命名分支铁律五连满分

> 裁定人: 项目主 — 2026-08-30 20:4x | 处置: ff-merge main=`b8dbde4`, done
> 复验 worktree: ../wvmp-426-verify @b8dbde4

## 1. 独立复验（全部亲测非采信自报）
| 项 | 自报 | 实测 (@b8dbde4) |
|---|---|---|
| build / ctest / **multiseed** | 210/210 | ✅ rc=0 / 16/16 / **TOTAL: 210 pass / 0 fail**（42 样本×5）|
| 新主样本 | 12 正例+8 负例 | ✅ 亲跑: **stub=12**、gate notes 恰 8 条逐名核对（rorx / vaddps[=ymm 位宽闸,同 mnemonic 陷阱钉死] / vfmadd213sd / vmovsd[假Mov] / vmulsd[标量d==s2] / vpaddd / vsubsd / vzeroupper）——**与派单 §A.4/§B.4/D2/§F.4 全边界精确一致**；语义值手对（addss=40700000=1.5+2.5 ✓ / andn=F0F0 基线 ✓ / movaps=DEADBEEF… 系拷贝 ✓）；双跑 byte-exact |
| wvmpTest 零回踩 | 14/14 | ✅ stubs=14 + jump-table@0xDD84 + ExitNative 17 + **diff 0** 103/103 |
| D1 零新 VmOp | kVmOpMax=95 不动 | ✅ 冻结面 grep: runtime.hpp/vm_op.hpp/asmgen/backend/ir **零触及**（14 文件全在 lifter 私有+translator 1 行+测试/样本/脚本/文档）|
| §B.4 位宽闸 | op.size>16 拒 | ✅ 直读 :1546-1551: 全操作数 size>16 → unsupported + 寄存器非 16B 双保险——**同 mnemonic ymm 陷阱正确封堵**（样本亲证 vaddps gate note）|
| 载体扩展 | TranslateResult.extra append-only | ✅ lifter 私有 struct 尾部追加，聚合初始化兼容声明；pre_insns 透传链 lifter_core 两点 |
| translator 1 行 | next_ip_of insert_or_assign | ✅ 语义核查: 前置 Mov 与主 insn 共享地址时后者覆盖——unique-addr 行为不变（既有全部样本回归在 210 内绿=机器证明）|
| 硬条款 | 全 | ✅ 命名分支+main 未动+tracked 零脏+切回 main+单 commit ff-safe+**75 分钟对账**（monitor 18:48 起→平台 completed 20:25 吻合）——**五连满分** |

## 2. #33 实测推翻/发现清单（全合格，采纳）
1. **triage "26 V-对" 修正为 38**——425 落了 mul/pand/andnps 后白名单口径位移（triage 时代 26 没错，是本单时点新基线 38）——派单 §A.2 早写"两边数字都不许信、重跑映射表"，命中
2. **vvvv 取反/pp 手算错 4 处被 capstone probe 纠正**——实汇编对照表纪律价值实证
3. **标量 d==s2 语义陷阱（超派单 §F.4 预期的家族扩展）**: `vmulsd xmm1,xmm0,xmm1`——VEX 标量"dst 高位←s1 高位"与 swap 后"高位=dst 原值"不相容，pre-Mov 又摧毁 s2（==dst）值 → **正确折叠需 xmm→GP 暂存原语（既有 VmOp 无此路径）→ gate 有架构必然性**，非仅频率论（0.75%<1% 双理由齐）。负例样本已钉
4. **D2 非交换 d==s2 频率实测**: ucrtbase 2.19% / smartscreen 0% / 合并 0.75%——计数命令入报告，裁决=gate 合规
5. 影子样本首版 segfault 假 PASS（双空输出 byte-exact）→ agent 自曝+修复——**登记 harness 盲区: multiseed 对 segfault rc 未显式 FAIL**（未来单独立项修，见 §4）

## 3. /arch:AVX 真产物验证（D3 价值锚成立）
cl v145 `/arch:AVX` 直产 vmovsd/vmulsd/vaddsd/vdivsd → protect 2 stub 零 gate，语义手算对（mul_chain=225 / mixed=10.8），byte-exact。探针源内嵌报告（424 留样纪律延续）。**"100% 标量浮点走 VEX" 的最大流量面自此覆盖。**

## 4. 登记（非阻断，转后续）
- **multiseed harness 盲区**: segfault+空 stdout = 假 PASS → G 线收官后小单修（对 rc≥0xC0000000 显式 FAIL）
- packed d==s2 swap NaN 载荷顺序理论可差（数值逐位等价，411 同级披露）/ xmm8..15 整函数 gate（与 legacy 同口径，档B 前置）——GAPS G6a 节均已在册

## 5. 排程更新
**VEX.128 SIMD 档清零**。指令虚拟化阶段剩余: **G1c**（movd/movq+paddq，movd 是 x87 L0/通用桥前置）+ **G8-BMI** 拍板 + **档B ymm/x87 L0/跳表扩容统裁** → 阶段收官 → 410(M3)。基线刷新: **42 样本 × 5 = 210/210**。
