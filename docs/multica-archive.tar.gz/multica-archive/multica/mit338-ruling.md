# 项目主裁定: 采纳 MIT-338 verifier 报告 + 接受 MIT-336 (setcc 指令支持) + 🟢 1 项建议

## 总体评价

MIT-338 verifier 报告 (verifier 第 15 连实战) **接受** MIT-336 (commit `c79f665` setcc 指令支持): **9 项全部通过** (含 capstone 反汇编独立验证 6 setcc variants 真字节 + MASM helper rax 栈守恒 pitfall #36 验证 + additive enum append-only pitfall #34 验证), **🟢 1 项非阻断建议** (派活单 frozen-contract regex overly strict on `ir/include/` for additive enum changes, 实际冻结契约严格满足)。

verifier 独立 fresh verify 双重确认:
- ✅ Build 300/300 clean
- ✅ Tests 15/15 PASS in 27.92s
- ✅ E2E setcc byte-exact match (6 entry stubs, .wvmp 19122B @ RVA 0xB000)
- ✅ Capstone disassembly 实证 real `0F 9X C0` bytes at RVA 0x12CC-0x13E4
- ✅ Multiseed 5×9 REQUIRE_REAL=1: 45/45 PASS
- ✅ MASM helper rax 栈守恒 (pitfall #36): all 6 functions correctly save/restore rax
- ✅ Additive enum append-only (pitfall #34): Setcc=50 correctly appended after Xchg=49

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 实证** (9 项 + 3 项重点):
- capstone 反汇编独立确认 setcc codegen 真实存在 (RVA 0x12CC-0x13E4 6 setcc variants, `0F 9X C0` 字节)
- **MASM helper rax 栈守恒 pitfall #36 实证**: all 6 functions correctly save/restore rax across SDK marker_end calls
- **aditive enum append-only pitfall #34 实证**: Setcc=50 correctly appended after Xchg=49, kVmOpMax updated
- **three-layer integration 实证**: lifter + translator + asmgen 三层完整 add, MEM form 单独 emit (Load + Setcc + Store, rip-relative aware)
- **asmgen `build_setcc` uses alias_write** to preserve dst high 56 bits (新发现, setcc 是 8-bit 结果, 64-bit dst 高 56 位不能丢)

**项目主 fresh verify** (本会话上一轮, MIT-337 ruling):
- HEAD `c79f665` ✅
- native setcc stdout = `setcc ne12=1 e12=0 b12=1 a12=0 l12=1 g12=0 ne55=0 e55=1 b55=0 a55=0 aneg=1 lneg=1` ✅
- fresh protect: 6 个入口 stub 生成, .wvmp 节 19122 字节 @ RVA 0xB000 ✅
- **protected setcc stdout == native setcc stdout** → **SETCC BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

## 🟢 1 项建议处理 (verifier 报, 不阻塞 MIT-336 done)

### 建议: 派活单 frozen-contract regex overly strict on `ir/include/` for additive enum changes

**verifier 实证**: 实际冻结契约**严格满足** (`Operand` 字段未改), additive enum 扩白名单已允许 (pitfall #22g)。派活单 frozen-contract regex 误判 `ir/include/` 完整文件树为"冻结"。

**项目主处理**: ✅ 沉淀到 pitfall #22g (冻结契约白名单纪律), 派活单 frozen-contract regex 需**精确化**: 仅冻结 `Operand` 字段 + `Op` enum 顺序 (not add), 不冻结 `ir/include/` 整个目录 (additive enum 允许)。后续派活单 frozen-contract regex 模板改用"字段级冻结 + 枚举 append-only" 模式 (派活单 §D 显式说明 append-only 位置)。

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-336** | ✅ **done** | setcc 指令支持 (Block C 阶段 2 第 3 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 第 3 条 done ✅ (verifier 第 15 连实战接受, 阶段 2 推进, 3 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **48** (MIT-300 ~ `c79f665`) |
| lifter 白名单 | **~43 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + **setcc 16 variants**) |
| 真虚拟化样本 | **14 个** |
| ctest | **15/15** PASS |
| E2E byte-exact | **18/18** (含 setcc) |
| **E2E REQUIRE_REAL=1** | **18/18 真虚拟化** |
| multiseed 5×9 REQUIRE_REAL=1 | **45/45 真虚拟化** |
| **verifier 实战** | **15 连** (含 MIT-338 verifier 第 15 连实战接受 MIT-336) |
| wvmp-dev SKILL.md pitfall | **36 个** (含本会话沉淀 pitfall #36 MASM helper rax 栈守恒) |

## 🟢 后续待办 (1 项非阻断, 立 sub-issue 跟踪)

1. **sub-issue A**: 派活单 frozen-contract regex 精确化, 仅冻结 `Operand` 字段 + `Op` enum 顺序, 不冻结 `ir/include/` 整个目录 (additive enum 允许), 派活单 §D 显式说明 append-only 位置 (沿用 pitfall #22g + #34)

## 后续流水线 (Block C 阶段 2 收尾)

```
Block C 阶段 2 第 4 条候选:
 - cmovcc (条件 mov, 模板化, 1-2 天)
 - movzx 8→16/16→64 (cl_shift 已覆盖部分, 补全)
 - movsx (与 movzx 对偶)
 - cmpxchg (原子, 复杂但有市场需求)
  ↓
阶段 2 完整规划 (5-7 天, ~7 条派活单)
```

## 沉淀 (verifier 第 15 连实战, 与 36 个 pitfall 联动)

### 关键沉淀 (本会话)

- ✅ verifier 第 15 连实战接受 MIT-336 (9 项 + 3 项重点核查全部 PASS)
- ✅ pitfall #36 (MASM helper rax 跨 SDK marker_end 调用必存栈守恒) 加入 wvmp-dev SKILL.md
- ✅ pitfall #33 (派活单 §A 假设不一定是真根因) MIT-335/336 实战体现
- ✅ pitfall #34 (additive enum append-only) MIT-333/335/336 实战体现
- ✅ pitfall #35 (MSVC x64 不支持 inline asm, MASM helper 强制 codegen) MIT-335/336 实战体现
- ✅ **新发现**: asmgen `build_setcc` uses alias_write to preserve dst high 56 bits (setcc 是 8-bit 结果, 64-bit dst 高 56 位不能丢)

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Setcc=50 之后 append-only)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 调用必存栈守恒** (pitfall #36)
- **asmgen `build_setcc`-style alias_write**: 8-bit 结果 dst 必须 alias_write 保护高 56 位
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only)
- 冻结契约核查 (派活单 §D 显式说明 append-only 位置, frozen-contract regex 精确化)

---

## 引用链

- `m3-lifter-paihuo-10-issue-progression.md` (15 节点完整演进)
- `mit333-ruling.md` (bswap ruling)
- `mit335-ruling.md` (xchg ruling)
- `mit336-ruling.md` (xchg verifier ruling, 接受)
- `mit337-ruling.md` (setcc ruling, 采纳 + pitfall #36 候选)
- `issue-37-mit336-verifier-instructions.md` (MIT-338 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit337-setcc-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 调用必存栈守恒 (本会话新增)