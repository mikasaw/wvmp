# MIT-436 (X0 x86 侦察) 裁定 — ACCEPT，多目标平台里程碑开工行图定版；两枚 🔴 前置地雷 + x87 三路线数字齐备待 D1 裁决

> 裁定人: 项目主 — 2026-09-01 01:0x | 处置: ff-merge main=`f7a865c`, done
> 复验: ff-safe 亲验 / triage 421 行落盘 / worktree 已拆（worktree list 亲验）/ **414 硬拒回归亲跑**: tracert.exe(PE32) → rc=2 "32 位目标未支持…不产出保护壳"、无落盘——现网安全线原样

## 1. 独立抽查（数字回溯亲验）
- 覆盖率总数字 §1 表: direct=95.74% (SysWOW64 100 文件 22.53M) / 98.72% (第三方 17 文件 15.59M)、**x87=missing 的 61.3%**、形级 fork 2-4% → 诚实下界 92-94%——三态矩阵/ret 计数（msvbvm60 7829/1755=82%）直读在案，**"全部数字自测未采纳开发侧结论"兑现**
- x87 分层: core_os 0.12 / modern_ucrt 1.00 / old_runtime 7.55（d3dx9 8-15%）+ ucrtbase x86 2.49%——**推翻"x87 只在老代码"直觉**（我 §A.2 预判方向对但低估了现代组件）；探针矩阵补关键事实: **/arch:SSE 下 double 仍走 x87**（SSE-only 子集成立的前提=客户开 /arch:SSE2）
- asmgen XL 量化: **真正的硬骨头=物理池 14→6→临时 10→2 的 spill 重构**（callee-saved 4 个全被 ctx/base/t0/t5 占用）；RIP-relative 全运行时仅 1 处（:417 取码基址，call/pop 即解）——**我 A.2"ctx 基址怎么给"冲击预判被降级一个量级**（命中但远小于预想）；A/B/C 档 handler 分拆 45/25/5 可拆单
- xmm[0..7] 恰完整（x86 无 REX→xmm8-15 编码不可达）——A.2 反转确认 ✅

## 2. 🔴 两枚前置地雷（写死进 X1 范围，漏做=C2 级行为错误）
1. **ret imm16（stdcall 被调方清栈）**: x86 ABI 主形（msvbvm60 82% of ret！），lifter 已 lift 但 **translator/runtime 清栈语义从未实现**（x64 无此形）——虚拟化后栈失衡。非 gate 非静默，**必须 X1 实现+样本钉**
2. **SEH/FS gate 显式点名**: seg_fs 0.32%（Delphi 0.68/vmwarecui 1.7%）——FS:[0] 进标记区域即 gate 文档化；callgate callee 自装 SEH 无碍（原生栈）
🟡 顺带: plain movsd 串形（dxcompiler 10k 结构体拷贝）=G3 开口或 gate 披露; **leave 0.37%=非 FP 缺口第一名、零新 VmOp 折条→X2a 顺路收**

## 3. D1 x87 三路线（数字备齐，悬置合法——不阻塞 X1/X2a）
| 路线 | 覆盖 | 成本 | 一致性 |
|---|---|---|---|
| **R-SSE-only**（侦察侧倾向） | ~97-98%（x87 维持 gate） | 零扩容、零 x87 战役 | 与 x64"永久 gate"承诺一致 |
| R-x87-L0 | +2.61% | ~80 op → **触发跳表扩容 178>128**（唯一必然触发者）+ MMX 域 | x64/x86 两套 x87 立场需文档缝合 |
| R-浮点整函数 gate | 最省 | 0 | 保护面大幅打折（浮点客户函数全裸奔）|
**项目主裁决 = 待 X1 合入后与 X2a 同批拍**（报告 §B.6: 悬置可保留到 X2a，届时若第三方存量痛点无实证则默认 R-SSE-only 定稿）。

## 4. 排波定版（X1 可立即开工）
X1a marker_scan arch 驱动+SDK x86 锚点（412 §6 形态, S）∥ X1b CLI arch 字段+**ret imm16 runtime/translator 语义+样本**+SEH gate 文档+硬拒翻声明（S+M 合成, **含 🔴1/🔴2**）→ X2a translator arch 分叉（M, +leave 顺路）→ X2b stub_gen cdecl（M）→ X4 asmgen XL 拆 2-3 张 → X5 x86 样本池（与 X2 并行起）。410(M3) 按用户指令继续 park，X 波为主推。
- 合入 main=`f7a865c`（仅 +1 .md，无 CLI 重建必要）; 基线 240/240 引用不变
