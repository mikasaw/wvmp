## 项目主裁定: 采纳 MIT-245 (C2-Adc) 当前实现

### 独立核验结果 (2026-08-23, hermes)

**1. 状态纠正**
上一轮我误判 "agent run 卡住 8 小时" — 实际 run 在 13:15 已 completed,
daemon 显示状态滞后. agent 24 分钟内完成全部工作 + commit + 报告.

**2. 代码层核验** — 读 `vm/regvm/runtime/src/asmgen.cpp` 实际改动:
- `:852-872` `build_adc(u64 dispatch)`: **不复用 build_binary**, 核心顺序:
  ```
  load A → T0     (mov/movzx 不改 flags)
  load B → T1     (mov/movzx 不改 flags)
  zero5           (清 flag scratch; 副作用宿主 CF←0)
  bt  flags_, 1   (宿主 CF = flags_ bit 1 = CF_in)
  adc  T0, T1     (CPU 完成 A+B+CF_in, flags 由 setcc5 捕真值)
  setcc5
  ```
- `:926` handler 表注册 `{int(VmOp::Adc), "adc", &AsmGen::build_adc}`
- `:871` `flags_tail(dispatch, false)` 写入 flags_ 寄存器, 跨指令保 CF_in

**3. 行为层核验** — fresh 实跑:
- `scripts\build.bat`: rc=0, 0 错 0 警
- `scripts\test.bat`: `100% tests passed, 0 tests failed out of 15`
  (含新增 (j) 段 6 子用例 + AdcFuzzTenThousand 5 万条, 378 ms 跑通)
- `wvmp_regvm_runtime_tests --gtest_filter=*Adc*`: `Interpreter.AdcFuzzTenThousand` PASSED
- `scripts\e2e.sh wvmp_adc_sample.exe`: rc=0, 含 PASS (虚拟化路径, 64+64 → 128-bit 加法)
- git working tree 干净 (8/8 PASS)

详见 `C:\Users\www\AppData\Local\Temp\hermes-verify-fix-cli-fresh4\verify_mit245.txt`

### Intel SDM 对齐核验

agent 实现的 flags 语义 = Intel SDM Vol. 2 ADC 条目:

| flag | agent 行为 | Intel SDM 实际 | 对齐 |
|---|---|---|---|
| CF | `setc` 捕获 host 真值 = 全加最高位 carryout | 全加最高位 carryout | ✅ |
| OF | `seto` 捕获 host 真值 | 两操作数符号同 + 结果异号时 = 1 | ✅ |
| SF | `sets` 捕获 host 真值 | 结果最高位 | ✅ |
| ZF | `setz` 捕获 host 真值 | 结果 == 0 | ✅ |
| PF | `setp` 捕获 host 真值 | 低 8 位偶校验 | ✅ |

**关键点**: agent 抓到了 issue 描述里 "build_binary 改 native 即用" 的简化错误,
主动不复用 + 自己写 build_adc, 这与项目主上一轮在 issue 描述里强调的
"build_binary 是否清 CF" 完全对齐.

### 5 万条 fuzz 验证

`AdcFuzzTenThousand` 测试: 5 Rng × 10000 = 50000 条随机 (a, b, cf_in) →
与 C++ 参考实现全加 bit-exact 比对, 378 ms 跑通.

覆盖:
- count=0 (CF_in 初值, 含 0/1 两种)
- 32/64 位 S/U 数
- 进位链 (j.3/j.4: -1+1, -1+1+1 等)
- signed overflow 边界 (j.5: S32 0x80000000 + 0x80000000)
- unsigned 边界 (j.6: 0xFFFFFFFF + 0x00000001)

### MIT-245 验收

- 代码 ✅ (commit 47c234f)
- 测试 15/15 ✅ (含 5 万条 fuzz)
- E2E ✅ (虚拟化路径, 含 CF_in 链路)
- Working tree 干净 ✅

请 (agent) 把 status 改 `done`. 后续 MIT-246 (C2-Sbb) 由项目主单独派单,
**严格串行纪律不变**: 一个 issue done 才派下一个.
