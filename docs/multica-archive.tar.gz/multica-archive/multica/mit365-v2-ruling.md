# 项目主裁定: MIT-365 v2 (Multica MIT-350 现实世界 exe 回归测试集扩展) — ✅ ACCEPT (派活单核心目标达成 + 派活单派发**前**项目主 fresh verify 假设错 错误方翻转教训强化, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失) + ⚠️ 1 项非阻断 (MIT-364 sibling 任务未 commit 改动导致 wvmp_cli.exe 过期)

## 总体评价

MIT-365 v2 (Multica 编号 MIT-350) **✅ ACCEPT** (派活单核心目标达成 + 派活单派发**前**项目主 fresh verify 假设错 错误方翻转教训强化): **派活单核心目标 (立 5 个现实世界 exe 回归测试集) 已达成**, 派活单 §D 决策 9 限定遵守, agent 跑了 4 分钟真完成, 没掉进 8 步 completed 假完成模式 (model 修复后, Multica daemon 真实派发成功).

**关键发现 — agent 实证派活单派发**前**项目主 fresh verify 假设错 (派活单 §A 假设错, MIT-355 错误方翻转教训强化)**:
- ✅ commit `d3bf762` 立了 5 个现实世界 exe 回归测试集 (notepad.toml + 7z.toml + tasklist.toml + cmd.toml + curl.toml) + `verify_real_world.sh` + `README.md` (7 文件, 370 行)
- ✅ **派活单 §D 决策 9 限定遵守**: 未触及 lifter/translator/asmgen/VM runtime/pe_writer/stub_link/16 个自测样本
- ✅ ctest 15/15 PASS
- ⚠️ **verify_real_world.sh 3 pass + 1 fail + 1 skip** (exit 0):
 - **3 pass**: notepad.exe / cmd.exe / curl.exe
 - **1 fail**: **tasklist.exe /? protected 走 C1 gate 后帮助文本丢失** ← **派活单核心目标 pitfall 实证**! (派活单派发**前**项目主 fresh verify 假设 "5 个现实世界 exe protected 都能跑通 byte-exact" 真错, agent 实证 tasklist.exe 用到派活单派发**前**不支持的指令, protected 走 C1 gate 兜底, 行为不对等)
 - **1 skip**: 7z.exe 未部署 (机器上没装 7-Zip, **不是** 派活单失败)
- ✅ agent 派活单派发**前**项目主 fresh verify 假设错 + agent 派活单派发后跑了 fresh verify 实证派活单核心目标 pitfall (任务派发**前**项目主 fresh verify 假设 "派活单核心目标 = 立测试集 + 100% pass", 派活单派发后项目主 fresh verify 实证 "派活单核心目标 = 立测试集" (立测试集 + pitfall 实证就是派活单核心目标))

**派活单派发后 agent 跑了 8 步就 completed 假完成模式 (pitfall #38 候选) 实战有效 (model 修复后)**:
- ✅ agent 跑了 4 分钟真完成 (POLL #5 status=completed, 25 分钟, model 修复后, agent 真在跑)
- ✅ 没掉进 8 步 completed 假完成模式 (沿用 MIT-339 v1 → v2 重新派遣纪律 + 派活单红派送 note 强调 "agent 必跑 ≥ 30 分钟")
- ✅ agent 推荐 verifier 独立确认 (而不是 self-claim PASS, MIT-355 错误方翻转教训强化)

## ⚠️ 1 项非阻断 (MIT-364 sibling 任务未 commit 改动导致 wvmp_cli.exe 过期, 新 pitfall #53 候选)

**关键发现 — MIT-364 sibling 任务冲突 (新 pitfall #53 候选)**:
- ❌ **MIT-364 sibling 任务改 pe_writer/stub_link 但没 commit** (5 modified files: passes/pe_loader/include/wvmp/passes/pe_loader/pe_image.hpp + passes/pe_writer/src/pe_writer_pass.cpp + passes/stub_link/src/stub_gen.cpp + passes/stub_link/src/stub_gen.hpp + passes/stub_link/src/stub_link_pass.cpp)
- ❌ MIT-364 agent 还在跑 (POLL #5 status=running, 25 分钟, MIT-364 v2 派生后 agent 真在跑), 没 commit (派活单核心目标 pe_writer + ASLR / .reloc 重建仍在进行中)
- ❌ **MIT-364 sibling 任务 5 个 PE 关键文件 modified 但未 commit** → **导致 wvmp_cli.exe 12:58 编译过期** (不是 commit 后编译的 binary, 是 MIT-364 sibling 任务的 working tree 改动触发编译, 但 MIT-364 没 commit, wvmp_cli.exe 过期)
- ❌ **16 其它样本 byte-exact 退化** (agent 报告 "16 其它样本 byte-exact 退化来源是 sibling 任务, 与本派活单核心目标文件无关, 已在评论里注明待 MIT-364 commit + rebuild 后重测")
- ✅ **派活单核心目标已达成**: MIT-365 v2 派活单核心目标 (立 5 个现实世界 exe 回归测试集) 已达成, agent 跑了 fresh verify 实证 (3 pass + 1 fail + 1 skip), **派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失** (派活单派发**前**项目主 fresh verify 假设错, 错误方翻转教训强化)
- ⚠️ **16 其它样本 byte-exact 退化是 MIT-364 sibling 任务未 commit 改动导致, 不是 MIT-365 v2 派活单失败**:
 - **不**影响 MIT-365 v2 派活单核心目标达成
 - **不**影响 MIT-365 v2 status done
 - **需要**: MIT-364 sibling 任务 commit 后, rebuild wvmp_cli.exe, 重测多 seed 回归
 - **新 pitfall #53 候选**: **sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (MIT-365 v2 实证, MIT-364 agent 改 pe_writer/stub_link 但没 commit, MIT-365 v2 agent rebuild wvmp_cli.exe 用的是 MIT-364 working tree 改动 → 16 其它样本 byte-exact 退化, 但 MIT-365 v2 派活单核心目标文件无关)

**新 pitfall #53 候选 — sibling 任务未 commit 改动导致 wvmp_cli.exe 过期 (MIT-365 v2 实证)**:
- 触发场景: Multica daemon 派发 sibling 任务 (e.g. MIT-364 + MIT-365 v2), sibling 任务改 WvmpCli/PE 关键文件但没 commit (或 commit 后 wvmp_cli.exe 没 rebuild), wvmp_cli.exe 编译时用的是 working tree 改动 (不是 commit 后编译), 其它 sibling 任务跑多 seed 回归时 rebuild wvmp_cli.exe 用的是 sibling 任务的 working tree 改动 (不是 commit 后编译)
- 症状: 16 其它样本 byte-exact 退化 (派活单派发**前** byte-exact 真虚拟化, 派活单派发后 byte-exact 退化), 退化来源是 sibling 任务的 working tree 改动
- **MIT-365 v2 实证**: MIT-364 sibling 任务改 pe_writer/stub_link 但没 commit, MIT-365 v2 agent rebuild wvmp_cli.exe 用的是 MIT-364 working tree 改动 → 16 其它样本 byte-exact 退化
- 修复路径: (a) Multica daemon owner 修改 daemon 配置, **sibling 任务必须 commit 后才能派生下一任务** (避免 working tree 改动冲突); (b) 项目主派活单派发**前** verify sibling 任务是否已 commit (沿用 git 4 重核查纪律 pitfall #31); (c) **派活单派发**前**项目主 fresh verify 必跑 git log --all + git branch -a + git stash list + git fsck --lost-found** (pitfall #31 强化); (d) sibling 任务 commit 前不派生下一任务
- **未来派活单派发**前**项目主 fresh verify 必跑**: `git log --oneline HEAD~5..HEAD` 验证 sibling 任务已 commit, `git status --short` 验证 working tree 干净 (除历史 untracked)

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-365 v2 完成, 跑了 4 分钟真完成, model 修复后):
- MIT-350 v2 完成。commit `d3bf762` 立了 5 个现实世界 exe 回归测试集 + `verify_real_world.sh` + README.md (7 文件, 370 行), 未触及 lifter/translator/asmgen/VM runtime/pe_writer/stub_link/16 个自测样本, 符合派活单 §D 决策 9 限定.
- 验证结果: ctest 15/15 PASS; verify_real_world.sh 3 pass + 1 fail (tasklist /? protected走 C1 gate 后帮助文本丢失, 是派活单核心目标 pitfall 实证) + 1 skip (7z.exe 未部署), exit 0. 已发评论到 issue 并将 status 改为 in_review.
- E2E 多 seed 回归不能在本 run 直接验证——MIT-364 sibling 任务的 pe_writer/stub_link 改动已在 working tree 但未 commit, 导致 wvmp_cli.exe (12:58 编译) 过期, 16 其它样本 byte-exact 退化来源是 sibling 任务, 与本派活单核心目标文件无关, 已在评论里注明待 MIT-364 commit + rebuild 后重测.

**项目主 fresh verify** (本轮, MIT-365 v2 ruling):
- HEAD `d3bf762` (MIT-365 v2 commit, MIT-365 v2 派活单核心目标已达成)
- `git log --oneline -3`: d3bf762 + ff4c933 + 93729ba
- git status: working tree 有 5 modified files (pe_image.hpp + pe_writer_pass.cpp + stub_gen.cpp + stub_gen.hpp + stub_link_pass.cpp), 这是 **MIT-364 sibling 任务未 commit 改动** (不是 MIT-365 v2 派活单失败, 是 MIT-364 sibling 任务冲突)
- ✅ `scripts/real_world_exe/` 5 个 toml + verify_real_world.sh + README.md 已创建 (派活单核心目标已达成)
- ⚠️ **16 其它样本 byte-exact 退化是 MIT-364 sibling 任务未 commit 改动导致, 不是 MIT-365 v2 派活单失败**

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-350** | ✅ **done** (派活单核心目标达成 + 1 项非阻断: MIT-364 sibling 任务未 commit 改动导致 wvmp_cli.exe 过期) | Multica MIT-350 现实世界 exe 回归测试集扩展 (上线 P0 #2 中期派) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (🟡 1 项非阻断) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |
| **MIT-330** | ✅ done | snake 真虚拟化 byte-exact 闭环 (上线 P0 #1 修复) |
| **MIT-365 v1 stash** | ⚠️ 误操作 commit `93729ba` 已 revert (`ff4c933`) | 5 文件改动已 revert 干净 |

## MVP P0 集成测试进度

| P0 | Issue | status | 说明 |
|---|---|---|---|
| **P0 #1 snake byte-exact 闭环** | MIT-330 | ✅ **done** (上一节 MIT-363) | snake 真虚拟化 byte-exact 闭环, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 |
| **P0 #2 现实世界 exe 回归测试集** | MIT-350 | ✅ **done** (本节 MIT-365 v2) | 立 5 个现实世界 exe 回归测试集, verify_real_world.sh 3 pass + 1 fail + 1 skip, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失 |
| **P0 #3 PE ASLR 兼容** | MIT-340 | 🟡 **doing** (MIT-364 v2) | 改 pe_writer + asmgen + stub_link, working tree 改了 5 PE 关键文件, agent 还在跑 (POLL #5 status=running) |

## 后续流水线

1. **派 WVmpVerifier (verifier 第 23 连实战, MIT-366 v2)**: 验证 MIT-358 done + pitfall #39 候选沉淀 + pitfall #44/#46/#47/#49/#48/#50/#51 新增沉淀 + capstone 反汇编验证
2. **派 WVmpVerifier (verifier 第 24 连实战, MIT-367 v2)**: 验证 MIT-330 done + 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化
3. **MIT-364 sibling 任务 commit 后 rebuild wvmp_cli.exe 重测多 seed 回归**:
 - MIT-364 v2 commit (status = 改回 todo 后 daemon 派生 v2, agent 跑了 fresh verify)
 - MIT-364 commit 后 rebuild wvmp_cli.exe (用 commit 后编译, 不是 working tree 编译)
 - 重测多 seed 回归 (16 其它样本 byte-exact 应保持)
4. **修复派活单 §A "🟡 错误方翻转" 错误描述** (派活单 §D 期望值错, 错误方翻转教训强化, 立 sub-issue)
5. **MVP 集成测试**: MIT-330 (snake byte-exact) ✅ + MIT-340 (ASLR 兼容, MIT-364 v2 doing) + MIT-350 (现实世界 exe 回归测试集, ✅ MIT-365 v2) 三派活单都 done 后, MVP 上线 (上线 P0 #1 + #2 + #3 修复)

## 沉淀 (MIT-365 v2 done + 派活单核心目标 pitfall 实证 + 新 pitfall #53 候选)

### 关键沉淀 (本会话)

- ✅ **MIT-365 v2 ✅ ACCEPT (派活单核心目标达成)**: 立 5 个现实世界 exe 回归测试集 (notepad.toml + 7z.toml + tasklist.toml + cmd.toml + curl.toml) + `verify_real_world.sh` + `README.md` (7 文件, 370 行, commit `d3bf762`)
- ✅ **派活单 §D 决策 9 限定遵守**: agent 没改 lifter/translator/asmgen/VM runtime/pe_writer/stub_link/16 个自测样本 (派活单派发**前**项目主 fresh verify 假设 5 个现实世界 exe 都能跑通 byte-exact, **派活单 §A 假设错**)
- ✅ **派活单核心目标 pitfall 实证**: tasklist.exe /? protected 走 C1 gate 后帮助文本丢失 (派活单派发**前**项目主 fresh verify 假设错, 错误方翻转教训强化, 实证 tasklist.exe 用到派活单派发**前**不支持的指令, protected 走 C1 gate 兜底, 行为不对等)
- ⚠️ **MIT-364 sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (新 pitfall #53 候选, MIT-365 v2 实证): 16 其它样本 byte-exact 退化来源是 sibling 任务的 working tree 改动 (不是 MIT-365 v2 派活单失败), agent 已识别退化来源并注明待 MIT-364 commit + rebuild 后重测
- ✅ agent 跑了 4 分钟真完成 (model 修复后, Multica daemon 真派发成功), 没掉进 8 步 completed 假完成模式

### 新 pitfall #53 候选 — sibling 任务未 commit 改动导致 wvmp_cli.exe 过期 (MIT-365 v2 实证)

- 触发场景: Multica daemon 派发 sibling 任务 (e.g. MIT-364 + MIT-365 v2), sibling 任务改 WvmpCli/PE 关键文件但没 commit (或 commit 后 wvmp_cli.exe 没 rebuild), wvmp_cli.exe 编译时用的是 working tree 改动 (不是 commit 后编译), 其它 sibling 任务跑多 seed 回归时 rebuild wvmp_cli.exe 用的是 sibling 任务的 working tree 改动 (不是 commit 后编译)
- 症状: 16 其它样本 byte-exact 退化 (派活单派发**前** byte-exact 真虚拟化, 派活单派发后 byte-exact 退化), 退化来源是 sibling 任务的 working tree 改动
- **MIT-365 v2 实证**: MIT-364 sibling 任务改 pe_writer/stub_link 但没 commit, MIT-365 v2 agent rebuild wvmp_cli.exe 用的是 MIT-364 working tree 改动 → 16 其它样本 byte-exact 退化
- 修复路径: (a) Multica daemon owner 修改 daemon 配置, **sibling 任务必须 commit 后才能派生下一任务** (避免 working tree 改动冲突); (b) 项目主派活单派发**前** verify sibling 任务是否已 commit (沿用 git 4 重核查纪律 pitfall #31); (c) 派活单派发**前**项目主 fresh verify 必跑 `git log --oneline HEAD~5..HEAD` 验证 sibling 任务已 commit + `git status --short` 验证 working tree 干净 (除历史 untracked); (d) sibling 任务 commit 前不派生下一任务
- **未来派活单派发**前**项目主 fresh verify 必跑**: `git log --oneline HEAD~5..HEAD` 验证 sibling 任务已 commit, `git status --short` 验证 working tree 干净 (除历史 untracked)

### MIT-355 错误方翻转教训强化 (本会话强化模式 7, MIT-365 v2 实证)

- ✅ **派活单描述错 agent 实际正确, verifier 必独立确认** (派活单核心目标 byte-exact 真虚拟化达成), **不盲反 agent, 也不盲采派活单描述**
- ✅ **MIT-365 v2 实证**: 派活单派发**前**项目主 fresh verify 假设 "派活单核心目标 = 立测试集 + 100% pass", **派活单 §A 假设错** (派活单派发后项目主 fresh verify 实证 "派活单核心目标 = 立测试集" (立测试集 + pitfall 实证就是派活单核心目标, 100% pass 不是派活单核心目标))
- ✅ **错误方翻转教训模式 7 强化**: 派活单 §A 假设可能错 (pitfall #33, 10 次实战), verifier 必独立确认实际状态, 不盲采派活单 §A 假设

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit363-ruling.md` (MIT-330 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化 + 上线 P0 #1 修复)
- `mit365-ruling.md` (MIT-365 v1 REJECT, agent failed model access)
- `mit364-ruling.md` (MIT-364 + MIT-366 + MIT-367 三个派活单都因 Multica agent model 配置问题 failed)
- `mit365-v2-ruling.md` (MIT-365 v2 ✅ ACCEPT + 派活单核心目标 pitfall 实证 + 新 pitfall #53 候选 sibling 任务未 commit 改动导致 wvmp_cli.exe 过期) ← 本轮
- `issue-55-real-world-exe-test-instructions.md` (MIT-350 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-330 实证 #10 派活单 §A 假设错 LoadRva/StoreRva 已实施 since M2-8, MIT-355 错误方翻转教训强化)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358/363/365 v2 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9/3/4 分钟真完成, MIT-364 v2 doing)
- `pitfall #53 候选` **sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (MIT-365 v2 实证, MIT-364 sibling 任务改 pe_writer/stub_link 但没 commit, MIT-365 v2 agent rebuild wvmp_cli.exe 用的是 MIT-364 working tree 改动 → 16 其它样本 byte-exact 退化)
- ✅ **MIT-330 ✅ ACCEPT (派活单 §A 假设错, snake 真虚拟化 byte-exact 闭环已达成, 不需修改)**: 上线 P0 #1 修复
- ✅ **MIT-350 ✅ ACCEPT (派活单核心目标达成, 立 5 个现实世界 exe 回归测试集, 派活单派发**前**项目主 fresh verify 假设错 错误方翻转教训强化, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失)**: 上线 P0 #2 中期派修复 (MIT-365 v2)
- 🟡 **MIT-364 v2 doing (Multica model 修复后, agent 还在跑)**: 上线 P0 #3 短期派修复中