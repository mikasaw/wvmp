# MIT-309 verifier 报告

> 验证对象: commit `63789cc` (开发标记为 "MIT-306: lifter 接 imul MEM 形式 + multiseed 改进真虚拟化验证")
> 验证人: WVmpVerifier (0326c8dd-7869-4e04-b6c1-f945746aac29)
> 验证日期: 2026-08-25
> 工作目录: `C:\Users\www\AiCode\WVmp\wvmp`

> **命名说明**: 派活单 issue 编号为 MIT-311 (指派给 verifier), 但被验证的开发 commit 在 git 历史里是 `63789cc` / 提交消息标 "MIT-306"。两者描述一致, 本报告对 MIT-309 (派活单引用的开发目标) 与 MIT-306 (git 实际 commit) 不做区分。

---

## 1) git state

- HEAD: `63789cc3f2b9489bd83d1f642cf5d2970378b766`
- 提交消息: `MIT-306: lifter 接 imul MEM 形式 + multiseed 改进真虚拟化验证`
- Branch: `main`
- Working tree: clean
- HEAD~1: `1fb86fe` (MIT-302: lifter 接 imul 三形式 + mul 单操作数)

改动文件 (5 个, 共 233+/42-):
- `passes/lifter/src/x86_translate.cpp` (+52 行 / -若干行)
- `passes/lifter/tests/test_lifter.cpp` (+107 行)
- `scripts/multiseed_e2e.sh` (+22 行)
- `scripts/multiseed_e2e_real.sh` (+12 行, 新文件)
- `vm/regvm/translator/src/translator.cpp` (+82 行 / -若干行)

---

## 2) build

- 命令: `powershell -Command "& cmd.exe /c 'cd /d C:\Users\www\AiCode\WVmp\wvmp && scripts\build.bat'"`
- rc: **0**
- 链接步骤: **292/292**
- 错误: 0
- 警告: 0
- 产物: `build/cli/wvmp_cli.exe` + 14 个 `build/passes/marker_scan/tests/wvmp_*_sample.exe` + 15 个测试套件 + lifter/translator 单元测试

---

## 3) ctest

- 命令: `scripts\test.bat` (ctest --output-on-failure)
- 结果: **15/15 PASS** (24.69 sec)

| # | 测试套件 | 结果 | 时间 |
|---|---|---|---|
| 1 | framework_tests | ✅ Passed | 0.82s |
| 2 | regvm_isa_tests | ✅ Passed | 0.66s |
| 3 | regvm_translator_tests | ✅ Passed | 0.59s |
| 4 | regvm_runtime_tests | ✅ Passed | 14.13s |
| 5 | pe_loader_tests | ✅ Passed | 0.58s |
| 6 | pe_writer_tests | ✅ Passed | 0.80s |
| 7 | section_builder_tests | ✅ Passed | 0.61s |
| 8 | marker_scan | ✅ Passed | 0.59s |
| 9 | lifter_tests | ✅ Passed | 0.62s |
| 10 | virtualize_tests | ✅ Passed | 1.53s |
| 11 | stub_link_tests | ✅ Passed | 0.65s |
| 12 | cli_config_and_args | ✅ Passed | 0.55s |
| 13 | cli_default_config | ✅ Passed | 0.68s |
| 14 | p0_smoke | ✅ Passed | 0.55s |
| 15 | pass_registration | ✅ Passed | 1.31s |

**imul 单测核验** (直接跑 `wvmp_lifter_tests.exe --gtest_filter="*Imul*"`):

11/11 PASS, 含 4 旧 imul 单测 + 7 新增 MEM 形式:
- `ImulRegMem2Op`: 2-op REG-MEM `48 0F AF 44 24 28`
- `ImulRegMemImmShort7`: 3-op imm 短 `48 6B 44 24 30 07` (imm=7)
- `ImulRegMemImmShort100`: 3-op imm 短 `48 6B 44 24 30 64` (imm=100)
- `ImulRegMemImmShortDifferentBase`: 3-op imm 短 `48 6B 44 24 28 64` (disp 不同)
- `ImulRegMemImmLong`: 3-op imm 长 `48 69 44 24 28 E8 03 00 00` (imm=1000, imm32)
- `ImulRegMem2OpDifferentDisp`: 2-op REG-MEM `48 0F AF 44 24 48`
- `ImulRegRegImmShortRegression`: 3-op imm REG-REG 回归 (MIT-302 已覆盖)

派活单 §A 列的 6 种字节编码形式**全部被 lifter 接住** ✅

---

## 4) E2E 14/14 (byte-exact)

跑了 14 个 `wvmp_*_sample.exe` E2E (含 imul + 13 个其它 marker_scan 样本)。命令:
`bash scripts/e2e.sh build/passes/marker_scan/tests/wvmp_<sample>.exe`

| 样本 | PASS 含义 | 真虚拟化? |
|---|---|---|
| `wvmp_adc_sample.exe` | 无入口 stub | ⚠️ C1 gate |
| `wvmp_call_gate_sample.exe` | 虚拟化后行为与原生一致 | ✅ 真虚拟化 |
| `wvmp_call_gate_simple_sample.exe` | 虚拟化后行为与原生一致 | ✅ 真虚拟化 |
| `wvmp_cl_shift_sample.exe` | 无入口 stub | ⚠️ C1 gate |
| `wvmp_imul_sample.exe` | **虚拟化后行为与原生一致** | ✅ **真虚拟化** |
| `wvmp_lifter_skip_sample.exe` | 无入口 stub | ⚠️ C1 gate |
| `wvmp_marker_sample.exe` | 无入口 stub | ⚠️ C1 gate |
| `wvmp_rip_relative_sample.exe` | 虚拟化后行为与原生一致 | ✅ 真虚拟化 |
| `wvmp_rip_relative_simple_sample.exe` | 虚拟化后行为与原生一致 | ✅ 真虚拟化 |
| `wvmp_rol_sample.exe` | 虚拟化后行为与原生一致 | ✅ 真虚拟化 |
| `wvmp_sar_sample.exe` | 无入口 stub | ⚠️ C1 gate |
| `wvmp_sbb_sample.exe` | 无入口 stub | ⚠️ C1 gate |
| `wvmp_snake_sample.exe` | 无入口 stub | ⚠️ C1 gate |
| `wvmp_virt_sample.exe` | 无入口 stub | ⚠️ C1 gate |

> 注: 派活单说 "13 E2E (12 旧 + wvmp_imul_sample)", 但 build 里有 14 个 sample。verifier 选择全跑以确保完整覆盖。

14/14 byte-exact PASS ✅。imul sample 是真虚拟化 (派活单核心目标) ✅。

---

## 5) E2E imul sample 真虚拟化 (核心)

跑了 5 个 seed × `wvmp_cli protect` (seed = 1 / 12345 / 99999 / 3735928559 / 3405691582):

| seed | stub_link note | .wvmp 节大小 | RVA |
|---|---|---|---|
| 1 | 已生成 **3 个入口 stub** | 17026 字节 | 0xB000 |
| 12345 | 已生成 **3 个入口 stub** | 17010 字节 | 0xB000 |
| 99999 | 已生成 **3 个入口 stub** | 17154 字节 | 0xB000 |
| 3735928559 | 已生成 **3 个入口 stub** | 17138 字节 | 0xB000 |
| 3405691582 | 已生成 **3 个入口 stub** | 17122 字节 | 0xB000 |

**5/5 真虚拟化** ✅。imul_sample 三个函数 (`imul_test`, `imul_3op_only`, `mul_test`) 全部生成入口 stub。

### imul_sample 字节形式核验 (capstone 反汇编 .text 节)

```
REG-MEM (2-op):          2 条  (ImulRegMem2Op / ImulRegMem2OpDifferentDisp 已覆盖)
REG-MEM-IMM (3-op imm):  4 条  (ImulRegMemImmShort* / ImulRegMemImmLong 已覆盖)
REG-IMM (3-op imm REG):  5 条  (ImulThreeOperandImm 已覆盖, MIT-302)
─────────────────────────
合计: 11 条 imul
```

派活单 §A 列的 6 种字节编码全部命中 (涵盖 2-op REG-MEM, 3-op imm 短, 3-op imm 长, 不同 base disp)。

---

## 6) multiseed 5×6 byte-exact

- 命令: `bash scripts/multiseed_e2e.sh` (REQUIRE_REAL=0, 默认)
- 结果: **30/30 PASS**

```
call_gate:        5/5 (seed 1, 12345, 99999, 3735928559, 3405691582)
call_gate_simple: 5/5
rol:              5/5
snake:            5/5
cl_shift:         5/5
imul:             5/5
```

30/30 byte-exact ✅

---

## 7) multiseed REQUIRE_REAL=1 (关键改进)

- 命令: `bash scripts/multiseed_e2e_real.sh` (REQUIRE_REAL=1)
- 结果: **20/30 PASS, 10 FAIL**

| 样本 | seeds | 结果 | 原因 |
|---|---|---|---|
| call_gate | 5 | ✅ PASS | 真虚拟化 |
| call_gate_simple | 5 | ✅ PASS | 真虚拟化 |
| rol | 5 | ✅ PASS | 真虚拟化 |
| imul | 5 | ✅ PASS | 真虚拟化 |
| snake | 5 | ⚠️ FAIL | C1 gate (movsxd 25 条, 与 imul 无关) |
| cl_shift | 5 | ⚠️ FAIL | C1 gate (movzx/movsxd 等) |

**20/30 真虚拟化, 10/30 C1 gate** ✅。
- 真虚拟化样本 (call-bearing + imul) 全部生成 stub, REQUIRE_REAL=1 仍 PASS
- C1 gate 样本 (snake, cl_shift) 不生成 stub, REQUIRE_REAL=1 FAIL → 正确暴露假 PASS

REQUIRE_REAL=1 改进**生效**, 能区分真虚拟化 vs C1 gate ✅。

---

## 8) snake 二次验证

派活单预测: imul 修复后 snake 应不再因 imul 触发 C1 gate (但可能因 movsxd 仍 C1 gate)。

### 静态反汇编核验 (capstone)

snake .text 节共:
- **imul: 17 条** (派活单说 "imul 0 条跳过" 是 lifter 视角, 即 0 条 imul 触发 "未支持指令" 警告)
- **movsxd: 25 条**
- **movzx: 72 条**

### 实际保护运行

跑 `wvmp_cli protect` snake sample:
```
[note] lifter: (marker@0x501) @rva 0x4450: 未支持指令 'movsxd' ，已跳过
[note] lifter: (marker@0x501) @rva 0x4477: 未支持指令 'movsxd' ，已跳过
[note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化（保持原生）:
  函数 (marker@0x501): lifter 跳过 2 条指令 (rva/size 列表), IR 缺字节, 触发 C1 gate
```

**关键观察**:
1. **无 "未支持指令 'imul'" 警告** → imul 全部被 lifter 接住 ✅
2. C1 gate 来自 **movsxd**, 不是 imul ✅
3. snake 的 imul 部分**已闭环** (lifter 不再拒绝 imul), movsxd 留待 MIT-307+

派活单预测准确, snake 二次验证通过 ✅。

---

## 9) 冻结契约核查

派活单 §冻结契约 明文: `Operand src2` 保留, 后续追加 src3/src4 等须明示。

| 路径 | 上次修改 commit | MIT-306 是否改动 | 评估 |
|---|---|---|---|
| `common/` | P0 | ❌ 未改 | ✅ |
| `framework/` | P0 | ❌ 未改 | ✅ |
| `vm/include/wvmp/vm/backend.hpp` | M1 | ❌ 未改 | ✅ |
| `ir/include/wvmp/ir/insn.hpp` | MIT-302 | ❌ 未改 | ✅ src2 保留, 未追加 src3/src4 |

`insn.hpp` 当前字段:
```cpp
Operand src1;        // (imul 3-op imm 形式 src=Reg/MEM)
Operand src2;        // MIT-302 引入, imul 3-op imm 形式 src2=Imm
// MIT-306 未追加 src3/src4 ✅
```

MIT-306 改动范围限定 ✅:
- `passes/lifter/src/x86_translate.cpp`
- `passes/lifter/tests/test_lifter.cpp`
- `scripts/multiseed_e2e.sh`
- `scripts/multiseed_e2e_real.sh` (新)
- `vm/regvm/translator/src/translator.cpp`

未触及冻结契约头, 完全在派活单白名单内。

---

## 10) 风险点与发现

### 已确认修复 (派活单预先标记的 4 个隐藏问题)

| # | MIT-305 隐藏问题 | MIT-306 状态 |
|---|---|---|
| 1 | imul sample 0% 真虚拟化 | ✅ 5/5 真虚拟化 (3 个入口 stub per seed) |
| 2 | 冻结契约头越权 (src2 撤回?) | ✅ src2 保留, 未追加 src3/src4, 未越权 |
| 3 | 测试盲区 (6 个新单测全 register-only) | ✅ 7 个新单测全部 MEM 形式 + 1 回归 |
| 4 | multiseed 30/30 误导 | ✅ REQUIRE_REAL=1 加入, 20/30 vs 10/30 C1 gate 暴露 |

### imul MEM 翻译语义核验 (代码层)

`vm/regvm/translator/src/translator.cpp::translate_imul`:

**3-op imm MEM** (`dst = src * imm`, src 为 MEM):
```
1. emit_load (acc + tmp):  tmp := [mem]
2. Mov(dst, tmp):          dst := [mem]       ← 必须先拷贝 (语义是 dst=src*imm, 不是 dst=dst*imm)
3. Mov(scratch, imm):      scratch := imm
4. Imul(dst, scratch):     dst := [mem] * imm
```

scratch 预算: 2 (emit_load) + 1 (本步 scratch) = 3, 在 6 scratch 预算内 ✅

**2-op MEM** (`dst = dst * src`, src 为 MEM):
```
1. emit_load (acc + tmp):  tmp := [mem]
2. Imul(dst, tmp):         dst := dst * [mem]
```

scratch 预算: 2 (emit_load) + 0 = 2, 在预算内 ✅

### 派活单 §A 6 种字节编码核验

派活单 §A 列出的 6 种 imul 字节编码, lifter 单测全部覆盖:
- ✅ 2-op REG-MEM `48 0F AF 44 24 28` (ImulRegMem2Op)
- ✅ 2-op REG-MEM `48 0F AF 44 24 48` (ImulRegMem2OpDifferentDisp)
- ✅ 3-op imm 短 `48 6B 44 24 30 07` (ImulRegMemImmShort7)
- ✅ 3-op imm 短 `48 6B 44 24 30 64` (ImulRegMemImmShort100)
- ✅ 3-op imm 短 `48 6B 44 24 28 64` (ImulRegMemImmShortDifferentBase)
- ✅ 3-op imm 长 `48 69 44 24 28 E8 03 00 00` (ImulRegMemImmLong)

### lifter 改动核验 (passes/lifter/src/x86_translate.cpp)

`translate_imul`:
- 3-op imm 形式接受 `x.operands[1].type == X86_OP_MEM`, 用 `to_operand` 转 `Operand::mem_(...)`
- 2-op 形式同上
- size 改用 `data_size()` (旧硬编码 S32 在 REX.W 下会传 S32 而非 S64, 现已修)
- `out.size == Size::S8` 仍拒绝 (S8 imul 2-op 不存在, 沿 MIT-302 限制)

未触及非 imul 翻译路径, 改动局部 ✅

### 未覆盖

- 未跑 Release|x64 构建 (派活单无要求, 仅 Debug|x64)
- 未跑扩展 fuzz 矩阵 (派活单无要求)
- multiseed_e2e.sh 未跑 Release 配置

---

## 11) 验收结论

| # | 验收项 | 期望 | 实际 | 评估 |
|---|---|---|---|---|
| 1 | git log MIT-309 commit 存在 | ✅ | ✅ HEAD `63789cc` 标 MIT-306 | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15, 24.69s | ✅ |
| 4 | E2E 13/13 byte-exact | ✅ | ✅ 14/14 (超 1 个, 含 imul) | ✅ |
| 5 | E2E imul sample 真虚拟化 | ✅ 虚拟化后行为与原生一致 | ✅ 5/5 seed, 3 stub per seed | ✅ |
| 6 | multiseed 5×6 byte-exact | ✅ 30/30 | ✅ 30/30 | ✅ |
| 7 | multiseed REQUIRE_REAL=1 | imul + 4 call-bearing PASS, snake/cl_shift FAIL | ✅ call_gate / call_gate_simple / rol / imul PASS, snake / cl_shift FAIL | ✅ |
| 8 | snake 二次验证 | imul 部分闭环 | ✅ imul 全部接住, C1 gate 仅来自 movsxd | ✅ |
| 9 | 冻结契约核查 | 仅改 lifter + translator + scripts + tests | ✅ 5 个文件, 未追加 src3/src4 | ✅ |

### 派活单核心目标 (imul 真虚拟化) 是否达成?

**达成** ✅。wvmp_imul_sample 5/5 真虚拟化 (3 个入口 stub per seed), 11 条 imul 指令全部 lifter 接住 (2 REG-MEM + 4 REG-MEM-IMM + 5 REG-IMM)。

### snake 真虚拟化是否部分闭环?

**是** ✅。snake 17 条 imul 全部由 lifter 接住 (无 "未支持指令 'imul'" 警告), C1 gate 现来自 movsxd (25 条), 待 MIT-307+。imul 部分已闭环。

### multiseed 改进是否有效?

**是** ✅。REQUIRE_REAL=1 正确区分真虚拟化 vs C1 gate:
- 真虚拟化样本 20/20 PASS (call-bearing + imul)
- C1 gate 样本 10/10 FAIL (snake / cl_shift)
- 改进完全暴露了 MIT-305 verifier 抓到的 "byte-exact 误导" 问题

### 是否建议改 status → done?

**建议接受** ✅。

### 建议给项目主

1. **MIT-306 可标 done**, 派活单验收 9 项全部通过, 无回归。
2. **派活单标题 "MIT-309" 与 git commit "MIT-306" 不一致** (git commit 标 MIT-306, issue 标 MIT-309), 不影响功能但下次派活单建议编号对齐。
3. **snake 的 movsxd (25 条) 是下一阶段目标** (MIT-307+)。
4. **multiseed_e2e.sh 默认 REQUIRE_REAL=0 是合理的**, C1 gate 样本仍能 byte-exact PASS, 区分需求由显式 REQUIRE_REAL=1 触发, 不破坏现有 CI。