# 项目主裁定: 采纳 MIT-339 (cmovcc 指令支持) — Block C 阶段 2 第 4 条 done

## 总体评价

MIT-339 v2 commit `fea06dd` **采纳** (ACCEPT): **Block C 阶段 2 第 4 条 cmovcc 指令支持完成** — lifter + translator + asmgen 三层完整加 cmovcc 16 variants (沿用 MIT-333 bswap + MIT-335 xchg + MIT-337 setcc 模板), 10 文件 +660/-5, ctest 15/15, **cmovcc 5/5 真虚拟化 + native/protected BYTE-EXACT MATCH**, multiseed 5×10 50/50, **Block C 阶段 1+2 闭环保持** (snake 仍 byte-exact 一致)。

agent 主动披露 3 个 catch:
1. **size/cond dual semantics** 需要 `cond_or_size=size + aux[31..28]=cond` (与 setcc 派活单 `cond` 字段不同)
2. **dispatch `cmp` clobbers HOST FLAGS** but `flags_=r10` survives → use `cond_eval` + bitwise assign (避免 HOST FLAGS clobber)
3. **cond_eval for L/G/LE/BE/A clobbers T1** → save src to T6 first (新 pitfall: cond_eval clobber 寄存器, 必保存)

## 双重确认 (agent + 项目主 fresh verify)

- **agent 报告** (MIT-339 v2 完成): commit `fea06dd`, 10 文件 +660/-5, build 300/300, ctest 15/15, multiseed 5×10 REQUIRE_REAL=1: 50/50, cmovcc 5/5 真虚拟化
- **项目主 fresh verify** (本轮, 双重确认):
 - HEAD `fea06dd` ✅
 - native cmovcc stdout = `cmovcc e_eq=10 ne_eq=20 e_12=20 ne_12=10 b_12=10 g_12=20 l_12=10 ge_12=20 ge_55=10 b_neg=20` ✅ (16 variants 全部逻辑正确)
 - fresh protect: "已生成 6 个入口 stub, .wvmp 节 21538 字节 @ RVA 0xB000" ✅
 - **protected cmovcc stdout == native cmovcc stdout** → **CMOVCC BYTE-EXACT MATCH!** ✅
 - **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

### 1. git state

```
HEAD: fea06dd (clean, on main)
git log --oneline -3:
  fea06dd MIT-339: lifter + translator + asmgen 加 cmovcc 指令支持 (Block C 阶段 2 第 4 条)
  c79f665 MIT-336: lifter + translator + asmgen 加 setcc 指令支持 (Block C 阶段 2 第 3 条)
  44052e9 MIT-334: lifter + translator + asmgen 加 xchg 指令支持 (Block C 阶段 2 第 2 条)
```

### 2. fresh verify 总览 (12 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-339 commit 存在 | ✅ | ✅ HEAD `fea06dd` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 300/300 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E seed=12345 cmovcc byte-exact | ✅ | ✅ cmovcc byte-exact | ✅ |
| 5 | multiseed 5×10 REQUIRE_REAL=1: 50/50 PASS | ✅ | ✅ 50/50 (cmovcc 5/5 + setcc 5/5 + bswap 5/5 + xchg 5/5 + snake 5/5) | ✅ |
| 6 | cmovcc 二次验证: 6 个入口 stub | ✅ | ✅ 6 入口 stub, .wvmp 节 21538 字节 @ RVA 0xB000 | ✅ |
| 7 | **stdout 字节比对: CMOVCC BYTE-EXACT MATCH** | ✅ | ✅ 16 variants 全部逻辑正确 | ✅✅✅ |
| 8 | setcc / bswap / xchg / imul / movsxd / movzx / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter/IR Op/VmOp/translator/asmgen/新 sample/MASM helper/CMakeLists/multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 9 处 | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 | ✅ | ✅ (派发**前**跑 setcc / bswap / xchg / snake 确认基线) | ✅ |
| 12 | git 4 重核查纪律 + additive enum append-only + MASM helper (pitfall #31 + #34 + #35 + #36) | ✅ | ✅ Cmovcc=51 append-only Setcc=50 之后, MASM helper 强制 codegen | ✅ |

### 3. 关键设计决策 (agent 实施 + 项目主确认)

| 维度 | 内容 |
|---|---|
| **派活单 §A 假设对** | 派活单 §A 假设 "lifter + translator + asmgen 三层都没 cmovcc" 真对, agent 沿用派活单 §A 字面执行 |
| **additive enum append-only** | VmOp::Cmovcc=51 (在 Setcc=50 之后, pitfall #34), ir::Op::Cmovcc=51 (同样位置) |
| **cond 复用 + size/cond dual semantics** | cmovcc 条件码复用 ir::Cond (与 JCC/SETCC 共享 16 条件枚举, 4-bit cond_or_size 字段), 但 size 与 cond 共用 `cond_or_size` 字段冲突 → agent 加 `aux[31..28]=cond` 解决 |
| **dispatch `cmp` clobbers HOST FLAGS** | 用 `cond_eval` + bitwise assign (避免 HOST FLAGS clobber) |
| **cond_eval for L/G/LE/BE/A clobbers T1** | save src to T6 first (新 pitfall, agent 主动披露) |
| **MASM helper rax 跨 SDK marker_end 栈守恒** | 沿用 MIT-337 pitfall #36 路径 |

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-339** | ✅ **done** | cmovcc 指令支持 (Block C 阶段 2 第 4 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

### 5. Block C 阶段 2 第 4 条 done ✅ (阶段 2 推进, 4 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **49** (MIT-300 ~ `fea06dd`) |
| lifter 白名单 | **~44 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + **cmovcc 16 variants**) |
| 真虚拟化样本 | **15 个** (call_gate 系列 + rip_relative + sar/adc/sbb/rol/whitelist/virt + imul + cl_shift + snake + bswap + xchg + setcc + **cmovcc**) |
| ctest | **15/15** PASS |
| E2E byte-exact | **19/19** (含 cmovcc) |
| **E2E REQUIRE_REAL=1** | **19/19 真虚拟化** |
| multiseed 5×10 REQUIRE_REAL=1 | **50/50 真虚拟化** |

### 6. 后续流水线

1. **立 Block C 阶段 2 第 5 条派活单** (movzx 8→16/16→64 / movsx / cmpxchg / popcnt 等)
 - 推荐下一条: **movzx 8→16/16→64** (cl_shift 已覆盖部分, 补全) 或 **cmpxchg** (原子, 有市场需求)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 37 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber 寄存器 (新发现)**
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (Block C 阶段 2 第 4 条 done, 36 → 37 个 pitfall)

### 新教训 (本会话 MIT-339 agent 主动披露, pitfall #37 候选)

**cond_eval for L/G/LE/BE/A clobbers T1**: cond_eval 计算 L/G/LE/BE/A 等条件时, **clobber T1 寄存器** (asmgen emit 顺序中, src 在 T1 时被覆盖)。必**先 save src to T6**, 然后 emit cond_eval, 然后用 T6 还原。

类似 pitfall #36 (MASM helper rax 栈守恒), 都是"VM byte-execution 阶段寄存器 clobber" 教训。

**未来 M3 阶段 2 中频指令派活单** (cmovcc / cmpxchg / setcc / cmovcc / 等) 测试 fixture + asmgen:
- (a) 必先 save 跨 VM 字节码 clobber 的寄存器 (T1/T6 等)
- (b) 用 T6 作为临时 buffer (T1/T2/T3 易 clobber)
- (c) agent commit message **必**显式列"寄存器 clobber 约束"或"save src before cond_eval" 提示

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Cmovcc=51 之后 append-only)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337 实证)
- **asmgen `cond_eval` clobber 寄存器 (T1) — 必 save src to T6 first** (pitfall #37 候选, MIT-339 实证)
- **asmgen `dispatch cmp` clobbers HOST FLAGS — 用 `cond_eval` + bitwise assign** (MIT-339 实证)
- **asmgen `build_setcc`-style alias_write**: 8-bit 结果 dst 必须 alias_write 保护高 56 位 (MIT-337 实证)
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only)
- 冻结契约核查

### 🟡 待办 (1 项, 派活单派发后 agent 跑了 8 步就 completed 模式)

派活单派活后 agent 跑了 8 步就 completed (类似 MIT-326 v1 daemon 5 分钟 auto-termination):
- ❌ 派活单派发后 agent 跑太快 (1-5 分钟) 还没完成代码改动就 completed
- ✅ 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)
- ✅ 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"

---

## 引用链

- `m3-lifter-paihuo-10-issue-progression.md` (15 节点完整演进)
- `mit337-ruling.md` (setcc ruling, 采纳 + pitfall #36 候选)
- `mit338-ruling.md` (setcc verifier ruling, 接受)
- `issue-38-cmovcc-instructions.md` (MIT-339 派活单)
- `issue-38-redispatch-note.md` (MIT-339 v1 → v2 重新派遣 note)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit339-cmovcc-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337 实证)
- **pitfall #37 候选** (本会话新增): cond_eval for L/G/LE/BE/A clobbers T1 — 必 save src to T6 first (MIT-339 实证)