# 项目主裁定: 采纳 MIT-344 verifier 报告 + 接受 MIT-341 (cmpxchg 指令支持) — Block C 阶段 2 第 5 条 done

## 总体评价

MIT-344 verifier 报告 (verifier 第 17 连实战) **接受** MIT-341 (commit `799fc11` cmpxchg 指令支持): **12 项全部通过 + 3 项重点核查全通过**, 8 分钟跑通, **pitfall #36 + #37 双保险到位**, **pitfall #38 候选验证 MIT-341 没掉进 8 步 completed 假完成模式 (agent 跑了 40 分钟真完成)**。

verifier 独立 fresh verify 双重确认:
- ✅ Build 302/302, ctest 15/15 (29.51s)
- ✅ 派活单 §3 fresh verify: 5/5 byte-exact (cmovcc/setcc/bswap/xchg/snake)
- ✅ Capstone 字节搜索: 4 条真 cmpxchg REG-REG 字节 (RVA 0x5ee/0x62f/0x662/0x69d), **无 LOCK prefix** (派活单限定生效)
- ✅ E2E cmpxchg: BYTE-EXACT MATCH (native == protected)
- ✅ multiseed 5×11 REQUIRE_REAL=1: 55/55
- ✅ 回归零退化: 11 样本 5 seeds 全 PASS (Block C 阶段 1+2 闭环保持)
- ✅ IR/VmOp enum append-only: Bswap=48 → Xchg=49 → Setcc=50 → Cmovcc=51 → Cmpxchg=52 (pitfall #34)
- ✅ pitfall #36 (rax 跨 SDK call 栈守恒) + pitfall #37 (T1 规避 setcc5 clobber) 双保险到位
- ✅ **pitfall #38 候选验证**: MIT-341 没掉进 8 步 completed 假完成模式, agent 跑了 40 分钟真完成

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 实证** (8 分钟):
- capstone 字节搜索独立确认 4 条真 cmpxchg REG-REG 字节 (RVA 0x5ee/0x62f/0x662/0x69d)
- **无 LOCK prefix** (派活单限定生效)
- pitfall #36 + #37 双保险到位 (vs MIT-339 1 个 pitfall 报告)
- pitfall #38 候选验证 MIT-341 没掉进 8 步 completed 假完成模式

**项目主 fresh verify** (本轮上一节, MIT-342 ruling):
- HEAD `799fc11` ✅
- native cmpxchg stdout = `cmpxchg s64_eq_same=5 s64_eq_diff=42 s64_ne_eq=5 s64_ne_ne=100 s32_eq_same=5 s32_ne_ne=100` ✅
- fresh protect: 4 个入口 stub 生成, .wvmp 节 21042 字节 @ RVA 0xB000 ✅
- **protected cmpxchg stdout == native cmpxchg stdout** → **CMPXCHG BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-341** | ✅ **done** | cmpxchg 指令支持 (Block C 阶段 2 第 5 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 第 5 条 done ✅ (verifier 第 17 连实战接受, 阶段 2 推进, 5 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **50** (MIT-300 ~ `799fc11`) |
| lifter 白名单 | **~45 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + **cmpxchg**) |
| 真虚拟化样本 | **16 个** (call_gate 系列 + rip_relative + sar/adc/sbb/rol/whitelist/virt + imul + cl_shift + snake + bswap + xchg + setcc + cmovcc + **cmpxchg**) |
| ctest | **15/15** PASS (29.51s) |
| E2E byte-exact | **20/20** (含 cmpxchg) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |
| **verifier 实战** | **17 连** (含 MIT-344 verifier 第 17 连实战接受 MIT-341) |
| wvmp-dev SKILL.md pitfall | **37 个** |

## 后续流水线

1. **立 Block C 阶段 2 第 6 条派活单** (movzx 8→16/16→64 / movsx / popcnt / lzcnt / tzcnt)
 - 推荐下一条: **movzx 8→16/16→64** (cl_shift 已覆盖部分, 补全) 或 **popcnt** (位计数, 模板化)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 37 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber T1 → T6 save** + **acc 隐式 rax/al 字段** (cmpxchg 特有)
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (verifier 第 17 连实战, 与 37 个 pitfall 联动)

### 关键沉淀 (本会话)

- ✅ verifier 第 17 连实战接受 MIT-341 (8 分钟跑通, 12/12 + 3/3 全通过)
- ✅ **pitfall #36 + #37 双保险到位** (rax 栈守恒 + T1 规避 setcc5 clobber)
- ✅ **pitfall #38 候选验证**: MIT-341 没掉进 8 步 completed 假完成模式, agent 跑了 40 分钟真完成 (vs MIT-339 v1 84 秒就 completed)
- ✅ **无 LOCK prefix** (派活单限定生效, 不支持 lock cmpxchg atomic 语义)
- ✅ **acc 隐式 rax/al 标注** (cmpxchg 特有, IR 字段 acc 标注, translator emit VmOp::Cmpxchg 3 操作数)
- ✅ 派活单 §A 假设对 (沿用 MIT-339 风格, agent 沿用派活单 §A 字面执行, 不需改修复方向)

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Cmpxchg=52 之后 append-only)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337/341 实证)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **acc 隐式 rax/al 字段** (cmpxchg 特有, IR 字段 acc 标注, lock prefix 不支持)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341 没掉进此模式): 沿用 pitfall #29 重新派遣纪律
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only)
- 冻结契约核查

### pitfall #38 正式沉淀到 wvmp-dev (MIT-341 没掉进此模式, 沿用 pitfall #29 重新派遣纪律实际生效)

**未来 M3 阶段 2 中频指令派活单** (cmpxchg / cmovcc / 等) 派活单派发后:
- 项目主 fresh verify 必跑 (5 件事全做, pitfall #22f 强化)
- 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed" (沿用 MIT-339 v1 → v2 重新派遣纪律)
- 沿用 pitfall #29 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)

---

## 引用链

- `m3-lifter-paihuo-11-issue-progression.md` (16 节点完整演进)
- `mit341-ruling.md` (cmovcc verifier ruling, 接受)
- `mit342-ruling.md` (cmpxchg ruling, 采纳)
- `mit344-ruling.md` (cmpxchg verifier ruling, 接受) ← 本文
- `issue-40-cmpxchg-instructions.md` (MIT-341 派活单)
- `issue-41-mit341-verifier-instructions.md` (MIT-344 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit342-cmpxchg-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed, daemon 5 分钟 auto-termination 模式 (MIT-339 v1 实证, MIT-341 没掉进此模式)