## 项目主裁定: 采纳 A (保留当前 MIT-244 实现)

### 独立核验结果 (2026-08-23, hermes)

**1. 代码层核验** — 读 `vm/regvm/runtime/src/asmgen.cpp` 的实际改动:
- `:834`: `std::string build_sar(u64 d) const { return build_shift("sar", d); }`
  (包装, 复用 Shl/Shr codegen, native 参数化)
- `:886`: handler 表注册 `{int(VmOp::Sar), "sar", &AsmGen::build_sar}`
- `:417-425`: `setcc5()` 用 `setc/seto/setz/sets/setp` **直接捕获 host CPU 真值**
  (不强行覆写, 与 Intel SDM byte-exact)
- `:563`: `zero5()` 在指令**前**清 flags, 让 `setcc5` 拿到 CPU 实际产出
- `:541`: `build_shift` 注释明确 "Shl/Shr", 但 native 参数化设计天然支持 Sar

**2. 行为层核验** — fresh 实跑 build + ctest + e2e.sh:
- `scripts\build.bat`: rc=0, 0 错 0 警
- `scripts\test.bat`: `100% tests passed, 0 tests failed out of 15`
  (含新增 (i) 段 + SarFuzzTenThousand 5 万条, 296 ms 跑通)
- `wvmp_regvm_runtime_tests --gtest_filter=*Sar*`: 1 test PASSED
- `scripts\e2e.sh wvmp_sar_sample.exe`: rc=0, 含 PASS 行 (虚拟化路径, 非 gate)

总计 8/8 PASS — 见 `C:\Users\www\AppData\Local\Temp\hermes-verify-fix-cli-fresh4\verify_mit244.txt`

### Intel SDM 对齐核验

agent 实现的 flags 语义 = Intel SDM Vol. 2 SAR 条目:

| flag | agent 行为 | Intel SDM 实际 | 对齐 |
|---|---|---|---|
| CF | `setc` 捕获 host 真值 = 末位移出位 | 末位移出位 (与 SHR 同语义) | ✅ |
| OF | `seto` 捕获 host 真值 | count=1: 0; count>1: undefined | ✅ |
| SF | `sets` 捕获 host 真值 = 结果最高位 | 结果最高位 | ✅ |
| ZF | `setz` 捕获 host 真值 | 结果 == 0 | ✅ |
| PF | `setp` 捕获 host 真值 = 低 8 位偶校验 | 低 8 位偶校验 | ✅ |
| count=0 | 走 adv_lbl 不动 flags | flags 不动 | ✅ |
| count≥64 | `and cl, 0x3F` 掩码 | count mod 64 | ✅ |

证据 (agent 提供, 我复跑验证):
```
mov al, 0x01
sar al, 1   → al=0x00, CF=1  ← LSB=1 被移出, CF 进位
```
CF **不是**永远 0, 是末位移出位.

### 纠正之前的关键技术点 (诚实标注)

**项目主之前给你的关键技术点** (CF=永远 0, OF=永远 0) **是错的**, agent 正确抓到
issue 描述的同款错误并按 Intel SDM 实现. 这是项目主侧的失误, 已在 issue 链
记录, 不影响本 issue 验收.

### 为什么选 A 不选 B

- **B (永远 CF=0 / OF=0) 的风险**:
  - 与 host 行为不匹配 (用 setc/seto 读到的东西会和约定给的 0 不一致)
  - 用户 exe 里 `jc/jnc` 紧随 `sar` 会假阳通过
  - **与 WVmp 仿真目标 (保护前后逐字节一致) 直接冲突**
- **A 的优势**:
  - 与 host 真执行 byte-exact, fuzz 已证
  - 与 x86 仿真目标一致
  - 后续 MIT-245/246/247 的 Adc/Sbb 涉及 CF/OF 真值传递 (carry/borrow 链),
    B 会破坏这条链路, A 不会

### MIT-244 状态

采纳 A, 验收通过:
- 代码 ✅
- 测试 15/15 ✅
- E2E ✅ (虚拟化路径)
- Commit `fd6cd00` ✅
- Working tree 干净 ✅

请 (agent) 把 status 改 `done`. 后续 MIT-245 (C2-Adc) 由项目主单独派单,
**严格串行纪律不变**: 一个 issue done 才派下一个.
