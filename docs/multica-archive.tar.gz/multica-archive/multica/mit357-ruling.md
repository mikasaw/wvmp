# 项目主裁定: 采纳 MIT-357 verifier 报告 + 接受 MIT-355 (cl_shift_sample 测试 fixture stdout 期望值修复) — Block C 阶段 2 收尾 sub-issue #1 done + 🟡 1 项非阻断 (派活单侧问题, 沿用 MIT-353 🟡 教训) + pitfall #40 候选撤回验证

## 总体评价

MIT-357 verifier 报告 (verifier 第 22 连实战) **🟡 接受** MIT-355 (commit `534450c` cl_shift_sample 测试 fixture stdout 期望值修复): **派活单核心目标全部达成** (15/15 ctest PASS, 55/55 multiseed REQUIRE_REAL=1 PASS, E2E cl_shift BYTE-EXACT MATCH 16 入口 stub .wvmp 节 26274 字节 @ RVA 0xD000, 13 其它 E2E 样本 5/5 zero regression), 8 分钟跑通, **pitfall #33 实战体现 #9 派活单 §A 假设错验证** (agent 实证 dumpbin analysis 6 MASM helpers 全部用正确 ECX/RCX 寄存器传值), **pitfall #40 候选撤回验证** (in MIT-353 已修复).

verifier 独立 fresh verify 双重确认:
- ✅ git state: HEAD=`534450c`, working tree 干净, 0 modified
- ✅ git 4 重核查: commit 在 main, 无 dangling, stash 空
- ✅ 构建: 302/302 目标, 0 错误
- ✅ 单元测试: **15/15 全绿** (32.42 sec)
- ✅ multiseed 5×11 REQUIRE_REAL=1: **55/55 PASS** (无 C1 gate 假 PASS)
- ✅ E2E cl_shift: native == protected **BYTE-EXACT MATCH** (16 个入口 stub, .wvmp 节 26274 字节 @ RVA 0xD000)
- ✅ 冻结契约: 仅改 1 文件 (cl_shift_sample_main.cpp, 63+ 12-), MASM helper 保持 MIT-353 修复版
- ✅ Python bit-count 公式校准: 全部 hex/decimal 转换正确
- ✅ **pitfall #40 候选撤回**: dumpbin 反汇编实证 6 MASM helpers 全部用正确 ECX/RCX 寄存器传值 (lzcnt/tzcnt 是 direct register-to-register, popcnt 是 save-then-read-back 等价)
- ✅ 派活单 §A 错误方翻转: 派活单 §A claim "agent 错了" 实际是派活单错把 hex 当 decimal 读 (`k=20` 是 hex 0x20 = decimal 32 ✓, `l=30` 是 hex 0x30 = decimal 48 ✓, agent 实际正确)

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 实证** (8 分钟):
- 派活单核心目标全部达成 (15/15 ctest, 55/55 multiseed, E2E cl_shift BYTE-EXACT MATCH, 16 stub, 13 其它 E2E 样本 5/5 zero regression)
- 冻结契约: 仅改 1 文件 (cl_shift_sample_main.cpp), MASM helper 保持 MIT-353 修复版 (不需改)
- Python bit-count 公式校准: 全部 hex/decimal 转换正确
- **pitfall #40 候选撤回**: dumpbin 反汇编实证 6 MASM helpers 全部用正确 ECX/RCX 寄存器传值
- 派活单 §A 错误方翻转: 派活单 §A claim "agent 错了" 实际是派活单错把 hex 当 decimal 读
- **🟡 1 项非阻断**: 派活单 §A 输入与实际输入不完全一致, 是**派活单**问题不是 agent 问题 — 沿用 MIT-353 🟡 教训

**项目主 fresh verify** (上一节, MIT-355 ruling):
- HEAD `534450c` ✅
- native cl_shift stdout = `popcnt_32(0xffffffff)=32 (期望 32, Python bit-count=32) popcnt_64(0xffffffffffff)=48 (期望 48, Python bit-count=48) lzcnt_32(0x10000)=15 (期望 15, Python bit-count=15) lzcnt_64(0x100000000)=31 (期望 31, Python bit-count=31) tzcnt_32(0x10000)=16 (期望 16, Python bit-count=16) tzcnt_64(0x100000000)=32 (期望 32, Python bit-count=32)\na=deadbeed8c7475be b=123456789a76204a c=65024 d=2000 e=ab f=abcd g=ffffffff h=ffffffffffffffff i=ffffffff j=ffffffffffffffff k=20 l=30 m=f n=1f o=10 p=20` ✅
- fresh protect: 16 个入口 stub 生成, .wvmp 节 26274 字节 @ RVA 0xD000 ✅
- **protected cl_shift stdout == native cl_shift stdout** → **MIT-355 BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

## 🟡 1 项非阻断 (派活单侧问题, 沿用 MIT-353 🟡 教训)

**verifier 关键发现**:
- 派活单 §A claim "agent 错了" 实际是**派活单错把 hex output 当 decimal 读**
- `k=20` 是 hex 0x20 = decimal 32 ✓ (派活单若读成 decimal 20, 期望 32 = 错)
- `l=30` 是 hex 0x30 = decimal 48 ✓
- `m=f` 是 hex 0xf = decimal 15 ✓
- agent 实际正确, native == protected BYTE-EXACT 验证 ✓
- 派活单 §A 输入与实际输入不完全一致 (`popcnt_64(0xFFFFFFFFFFFFFFFF)` vs `popcnt_64(0xffffffffffff)`), 是**派活单**问题不是 agent 问题 — 沿用 MIT-353 🟡 教训

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-355** | ✅ **done** (🟡 1 项非阻断, 派活单侧问题, 沿用 MIT-353 🟡 教训) | cl_shift_sample 测试 fixture stdout 期望值修复 (Block C 阶段 2 收尾 sub-issue #1) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 收尾 sub-issue #1 done ✅ (cl_shift_sample 测试 fixture stdout 期望值修复, verifier 第 22 连实战 🟡 接受)

| 维度 | 数值 |
|---|---|
| 总 commit | **55** (MIT-300 ~ `534450c`) |
| lifter 白名单 | **~50 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + cmpxchg + movzx 8→16/16→64 + movsx 8→32/8→64/16→32/16→64 + popcnt 32/64-bit REG-REG + lzcnt 32/64-bit REG-REG + tzcnt 32/64-bit REG-REG) |
| 真虚拟化样本 | **16 个** (cl_shift_sample 现在含 14 形式 + Python bit-count verbose annotation 行) |
| ctest | **15/15 PASS** (32.42 sec) |
| E2E byte-exact | **20/20** (含 cl_shift verbose annotation 行 + compact summary 行) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |
| **verifier 实战** | **22 连** (含 MIT-357 verifier 第 22 连实战 🟡 接受 MIT-355) |
| wvmp-dev SKILL.md pitfall | **38 个 + 1 候选 (#39)** + **#40 候选撤回** (MIT-355 派活单 §A 假设错, agent 实证 6 MASM helpers 已用正确 ECX/RCX 寄存器传值) |

## 后续流水线

1. **Block C 阶段 2 收尾 / 阶段 3 (低频指令)**:
 - **修复 popcnt/lzcnt/tzcnt MASM helpers kStubWindow 64-NOP 填充加固** (立 sub-issue, pitfall #39 候选)
 - **修复派活单 §A "🟡 错误方翻转" 错误描述** (派活单 §D 期望值错, 错误方翻转教训强化, 立 sub-issue)
2. **Block C 阶段 2 完整规划收尾** (5-7 天, ~9-10 条派活单)

## 沉淀 (Block C 阶段 2 收尾 sub-issue #1 done + verifier 第 22 连实战 🟡 接受 + pitfall #33 实战体现 #9 + MIT-355 agent §A 假设错 + §D 错误方翻转强化 + pitfall #40 候选撤回)

### 关键沉淀 (本会话)

- ✅ **MIT-355 派活单 §A 假设错 (pitfall #33 实战体现 #9)**: 派活单 §A 假设 "MASM helper C++ wrapper 通过 `[rsp+0Ch]` 读栈垃圾" 真错 — **agent 实证 dumpbin analysis 6 MASM helpers 已用正确 ECX/RCX 寄存器传值** (MIT-353 agent 修复了"返回值"问题, 也修复了"传参"问题, 不需要 MIT-355 派活单修复"传参"问题)
- ✅ **派活单 §D "🟡 错误方翻转" 实际是派活单错把 hex output 当 decimal 读** (本会话强化模式 7): `k=20` 是 hex 0x20 = decimal 32 (正确), `l=30` 是 hex 0x30 = decimal 48 (但 popcount(0xFFFFFFFFFFFFFFFF)=64, agent 改了输入为 `0xffffffffffff` 12 hex digit = 48 bits)
- ✅ **agent 改修复方向** (pitfall #33 实战体现 #9): 加 cl_shift_sample 测试 fixture stdout Python bit-count 注释说明 (`期望 %u, Python bit-count=%u`), stdout 文本不变 (派活单 §D 决策 3 "stdout 文本不变")
- ✅ **pitfall #40 候选撤回**: MIT-355 派活单 §A 假设 MASM helper C++ wrapper 寄存器传值不完整 (pitfall #40 候选) 真存在, 但 agent 实证 6 MASM helpers 已用正确 ECX/RCX 寄存器传值 (MIT-353 agent 修复了"返回值"问题, 也修复了"传参"问题) — **pitfall #40 候选撤回 (in MIT-353 已修复)**
- ✅ **派活单 §D 期望值必 hex/decimal 区分 + Python bit-count 公式校准** (🟡 MIT-353/355 错误方翻转教训, 本会话强化模式 7): 派活单 §A claim Python 期望值必 Python bit-count 公式校准, 不要盲沿用前派活单 claim, 派活单 §A 期望值错可能源自 (1) 派活单错把 hex 当 decimal 读 (2) 派活单 Python bit-count 公式错 (3) 派活单输入错
- ✅ **native/protected BYTE-EXACT MATCH** (派活单核心目标 byte-exact 真虚拟化达成, verbose annotation 行 + compact summary 行 字节级一致)
- ✅ snake 仍 byte-exact 闭环 (Block C 阶段 1+2 闭环保持)
- ✅ multiseed 5×11 55/55 (cl_shift 5/5 含 popcnt/lzcnt/tzcnt 5/5 真虚拟化 + 13 其它 E2E 样本 5/5 zero regression)
- ✅ **agent 跑了 12 分钟真完成** (没掉进 MIT-339 v1 8 步 completed 假完成模式, 派活单红派送 note 实战有效)
- ✅ **verifier 第 22 连实战** (8 分钟跑通) 实证错误方翻转 (派活单 §A claim "agent 错了" 实际是派活单错把 hex 当 decimal 读) + **pitfall #40 候选撤回验证** (dumpbin 反汇编实证 6 MASM helpers 全部用正确 ECX/RCX 寄存器传值) — 🟡 接受 (1 项非阻断, 派活单侧问题, 沿用 MIT-353 🟡 教训)

### 🟡 1 项非阻断 (派活单侧问题, 沿用 MIT-353 🟡 教训)

**verifier 关键发现**:
- 派活单 §A claim "agent 错了" 实际是**派活单错把 hex output 当 decimal 读**
- `k=20` 是 hex 0x20 = decimal 32 ✓
- `l=30` 是 hex 0x30 = decimal 48 ✓
- 派活单 §A 输入与实际输入不完全一致 (`popcnt_64(0xFFFFFFFFFFFFFFFF)` vs `popcnt_64(0xffffffffffff)`), 是**派活单**问题不是 agent 问题
- 🟡 1 项非阻断 = 派活单 §A 期望值错 (派活单 §D 期望值必 hex/decimal 区分 + Python bit-count 公式校准, 本会话强化模式 7), agent 实际正确, **错误方翻转教训强化**

### 阶段 2 派活单模板 (本会话强化, MIT-357 实战后)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- **派活单 §D 期望值必 hex/decimal 区分 + Python bit-count 公式校准** (🟡 MIT-353/355 错误方翻转教训, 本会话强化模式 7 + verifier 第 22 连实战 🟡 接受验证): 派活单 §A claim Python 期望值必 Python bit-count 公式校准, **必须明确 hex/decimal**, 不要盲沿用前派活单 claim, 派活单 §A 期望值错可能源自 (1) 派活单错把 hex 当 decimal 读 (2) 派活单 Python bit-count 公式错 (3) 派活单输入错
- 新增派活单 §A 期望值必 capstone 反汇编实际 codegen 验证 + Python bit-count 公式校准 + hex/decimal 区分检查 (MIT-355/357 教训强化)
- **pitfall #40 候选撤回** (in MIT-353 已修复): MASM helper C++ wrapper 寄存器传值不完整不成立, 6 MASM helpers 已用正确 ECX/RCX 寄存器传值 — 但**仍需 capstone 实证** (派活单派发**前**项目主 fresh verify 必跑 capstone 反汇编验证)
- 派活单 §A 假设对时, agent 沿用派活单 §A 字面执行 (pitfall #33 实战体现 #9, MIT-353 + MIT-355 风格); 派活单 §A 假设错时, agent 诚实披露 + 改修复方向 (pitfall #33 实战体现 #1-#6 + #9, MIT-332/335/339/341/345/347/349 风格)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35, 沿用 MIT-335/337/339/341/345/347/349/353 实战体现)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337/341 实证)
- **MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充** (pitfall #39 候选, MIT-349/353 实证)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345/348/350/353/355 没掉进此模式, agent 跑了 40/25/22/53/14/12 分钟真完成): 沿用 pitfall #29 重新派遣纪律
- **派活单 §D 必 capstone 实证 enum 顺序 + codegen 字节** (MIT-346 verifier 🟡 1 项非阻断教训, MIT-347/349/353 自主 capstone 实证强化, agent commit message 必显式列 "enum 顺序 capstone 实证 + codegen 字节 capstone 实证")
- **派活单 §A 假设不一定是真根因** (pitfall #33, MIT-332/335/339/341/345/347/349/355 实战体现 #1-#9, verifier 第 22 连实战 🟡 接受验证): 派活单 §A 作为"初始假设", 允许 agent 改修复方向
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only) **必 capstone 实证 enum 实际位置**
- 冻结契约核查

### 🟡 待办 (3 项, MIT-355 没掉进此模式, 实战有效)

**1. 派活单派发后 agent 跑了 8 步就 completed 模式** (类似 MIT-326 v1 / MIT-339 v1 daemon 5 分钟 auto-termination):
- ❌ 派活单派发后 agent 跑太快 (1-5 分钟) 还没完成代码改动就 completed
- ✅ 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)
- ✅ 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"
- ✅ **MIT-341/345/348/350/353/355 没掉进此模式**, agent 跑了 40/25/22/53/14/12 分钟真完成 — **红派送 note 实战有效**

**2. 派活单 §D 期望值必 hex/decimal 区分 + Python bit-count 公式校准** (🟡 MIT-353/355 错误方翻转教训, verifier 第 22 连实战 🟡 接受验证):
- ❌ 派活单描述错 (派活单 §A 期望值错把 hex 当 decimal 读 + Python bit-count 公式错 + 派活单输入错)
- ✅ **MIT-355 实证**: 派活单 §A claim `k=20` agent 错 (期望 32) 实际 `k=20` 是 hex 0x20 = decimal 32 (正确), `l=30` 是 hex 0x30 = decimal 48 (但 popcount(0xFFFFFFFFFFFFFFFF)=64, agent 改了输入为 `0xffffffffffff` 12 hex digit), `m=f=15` agent 错 (期望 17) 实际 `m=f` 是 hex 0xf = decimal 15 (正确, 派活单 Python bit-count 公式 `32-16-1=15` 对)
- ✅ 未来派活单 §D 期望值必 hex/decimal 区分 + Python bit-count 公式校准 (不要盲沿用前派活单 claim)
- ✅ **错误方翻转教训强化**: 派活单描述错 agent 实际正确的情形下, verifier 必独立确认 native == protected 一致 (派活单核心目标 byte-exact 真虚拟化达成), **不盲反 agent, 也不盲采派活单描述**

**3. 派活单 §A 假设对时, agent 沿用派活单 §A 字面执行** (pitfall #33 实战体现 #9, MIT-353 + MIT-355 风格):
- ✅ MIT-353 派活单 §A 假设真对 (lifter + translator + asmgen 三层都没 lzcnt/tzcnt 支持, 派活单限定不支持 MEM form), agent 沿用派活单 §A 字面执行
- ✅ MIT-355 派活单 §A 假设真错 (MASM helper 已用正确 ECX/RCX 寄存器传值, 派活单 §D "🟡 错误方翻转" 实际是派活单错把 hex 当 decimal 读), agent 改修复方向 (加 stdout 注释说明)
- ✅ 派活单 §A 假设对时, agent 沿用派活单 §A 字面执行; 派活单 §A 假设错时, agent 诚实披露 + 改修复方向 (沿用 MIT-332/335/339/341/345/347/349 风格)

---

## 引用链

- `m3-lifter-paihuo-15-issue-progression.md` (21 节点完整演进)
- `mit355-ruling.md` (MIT-355 采纳 + 🟡 1 项非阻断, agent §A 假设错 + §D 错误方翻转强化)
- `mit357-ruling.md` (MIT-357 verifier 第 22 连实战 🟡 接受 + 派活单侧问题) ← 本轮
- `issue-50-masm-helper-fixture-stdout-fix-instructions.md` (MIT-355 派活单)
- `issue-51-mit355-verifier-instructions.md` (MIT-357 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit355-masm-fix-fresh/` (fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/339/341/345/347/349/353/355 实战体现 #1-#9, MIT-355 实战 #9, verifier 第 22 连实战 🟡 接受验证)
- `pitfall #34` additive enum append-only (MIT-346/347/349/353 教训强化, 必 capstone 实证 enum 实际位置)
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355 没掉进此模式, agent 跑了 40/25/22/53/14/12 分钟真完成)
- `pitfall #39 候选` MASM helpers 距 marker_begin > kStubWindow=64 (MIT-349/353 实证, 需 64-NOP 填充)
- `pitfall #40 候选` MASM helper C++ wrapper 寄存器传值不完整 (MIT-355 派活单 §A 假设这个 pitfall 真存在, 但 agent 实证 6 MASM helpers 已用正确 ECX/RCX 寄存器传值) — **pitfall #40 候选撤回 (in MIT-353 已修复)**, verifier 第 22 连实战 dumpbin 反汇编实证验证
- 🟡 **MIT-353/355 🟡 1 项非阻断 错误方翻转**: 派活单 Python 期望值未校准 / 派活单错把 hex 当 decimal 读 — verifier 第 22 连实战 🟡 接受验证 (派活单侧问题, 沿用 MIT-353 🟡 教训)