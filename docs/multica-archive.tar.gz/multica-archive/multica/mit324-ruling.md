# 项目主裁定: 部分采纳 MIT-324 (snake_sample forward-jump 改造) + 立 2 个 sub-issue

## 总体评价

MIT-324 commit `d493d9a` **部分采纳** (CONDITIONAL ACCEPT): 派活单字面执行 (删 2 处 `return;`) **完全达成**, 但派活单 §A 改动清单 incomplete — 第 3 处 forward-jump (line 174 `if (ate != 0)` 跨 WVMP_END call) 派活单 §D 没让 agent 修, snake 仍 C1 gate。

**agent 主动披露 3 项关键发现** (与 MIT-322 编造相反):
1. 派活单 §A 改动清单 incomplete (派活单作者错误承认)
2. Pre-existing VM runtime bug (`g_snake_x[0]` rip-relative scaled-index Load)
3. stdout prediction wrong (派活单预测 `head=31,16`, 实测 `head=32,16`)

**verifier (MIT-325) 3 项关键发现独立验证全部确认** ✅ — agent 主动披露习惯恢复 (MIT-322 反例已收敛)。

## 独立核查结果 (2026-08-25, hermes)

### 双重确认 (verifier + 项目主 fresh verify)

- **verifier 报告** (MIT-325 完成): 派活单字面执行通过, 3 项关键发现独立验证全部确认, snake 仍 C1 gate 因 RVA 0x13BA
- **项目主 fresh verify**: HEAD `d493d9a` ✅, `grep "return;" = 0` ✅, ctest 15/15 ✅, fresh protect 警告 RVA **0x13BA** (派活单 §A 写 0x13C4, 字段略不精确)

### 1. git state

```
HEAD: d493d9a (on main)
MIT-324 commit: d493d9a
改动: 1 文件 (snake_sample_main.cpp, 删 2 处 return;)
```

### 2. fresh verify 总览 (与 verifier 一致)

| 项 | 结果 |
|---|---|
| HEAD | d493d9a (clean, on main) |
| build | rc=0, 292/292 |
| ctest | 15/15 PASS |
| **派活单字面执行** | ✅ `grep "return;" = 0` |
| **snake 二次验证** | ✅ 1 处 forward-jump 警告 (RVA **0x13BA**) |
| imul / movsxd / cl_shift / call-bearing 回归零退化 | ✅ |
| multiseed byte-exact 30/30 | ✅ |
| multiseed REQUIRE_REAL=1: snake 仍 FAIL (C1 gate), 其它 25/25 | ✅ |
| 冻结契约核查 | ✅ 仅改 snake_sample (1 文件) |

### 3. 派活单 §A 字段不精确实证 (本会话强化, MIT-322 + MIT-324)

**派活单 §A 派活单派活前我(项目主) capstone 反汇编写 0x13C4**, verifier 独立实测**0x13BA**:
- 派活单 §A (我写): "RVA 0x13C4 `je rel8 (74 3B)` 跨 WVMP_END call"
- verifier 实测 (MIT-325): "RVA 0x13BA 第 3 处 forward-jump"
- agent 报告 (MIT-324): "RVA 0x13BA `je rel8`"
- 项目主 fresh verify: "RVA **0x13BA** `je rel8`"

**字段不精确但实质同一指令边界** — lifter 行为正确触发 C1 gate。

**MIT-324 改进**: 派活单 §A 反汇编字段必须 byte-exact 精确, 不仅是 RVAs + 跳转目标。

### 4. agent 主动披露 3 项关键发现 (verifier 独立验证)

#### 发现 1: 派活单 §A 改动清单 incomplete

派活单 §A 识别 3 处 forward-jump:
- RVA 0x11ED `jmp rel32` 跨 epilogue (line 116 `return;`)
- RVA 0x12BE `jmp rel32` 跨 epilogue (line 136 `return;`)
- RVA 0x13C4 `je rel8` 跨 WVMP_END call (line 174 `if (ate != 0)`)

**派活单 §D 项目主决策**: 移除 2 处 `return;` + 末尾 if (ate != 0) 保留 (块内代码)

**派活单作者 (我) §C 决策 1 错误**: "末尾 if (ate != 0) 保留 (块内代码)" 错 — `je 0x1401` 是跨 WVMP_END call 跳转, 不是块内代码, 与 return 跨 epilogue 同性质。

**承认**: 派活单 §A 改动清单 incomplete — 我(派活单作者) §D 决策漏改第 3 处 forward-jump。

#### 发现 2: Pre-existing VM runtime bug

agent 尝试加 `volatile` anchor 修第 3 处 forward-jump, **protected version 段错误**:
- 触发源: `int x = g_snake_x[0];` (单条 rip-relative scaled-index Load)
- 与 MIT-324 无关, 需独立 issue 调试 VM runtime

#### 发现 3: stdout prediction wrong

派活单预测 `head=31,16`, 实测 `head=32,16`:
- 原因: return 移除导致撞墙时身体更新执行, head 被 out-of-bounds `nx` (GW=32) 覆盖
- **byte-exact 仍 PASS** (native vs protected 字节一致)

### 5. 派活单验收逐条核对 (12 项, 8 通过 + 3 派活单设计缺陷 + 1 pre-existing bug)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-324 commit 存在 | ✅ | ✅ HEAD `d493d9a` | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | **agent commit 真的删了 2 处 `return;`** | ✅ | ✅ `grep "return;" = 0` | ✅ |
| 5 | **snake 二次验证**: 1 处 forward-jump 警告 | ✅ | ✅ RVA **0x13BA** | ✅ (派活单 §A 字段 0x13C4 略不精确) |
| 6 | **stdout byte-exact** | ✅ | ✅ 实测 `head=32,16`, byte-exact PASS | ✅ |
| 7 | imul / movsxd / cl_shift / call-bearing 回归零退化 | ✅ | ✅ 全 PASS | ✅ |
| 8 | multiseed byte-exact 30/30 | ✅ | ✅ 30/30 | ✅ |
| 9 | multiseed REQUIRE_REAL=1: snake 仍 FAIL, 其它 PASS | ✅ | ✅ 25/30 (snake 仍 FAIL 因 0x13BA) | ✅ |
| 10 | **派活单 §A 改动清单 incomplete 独立确认** | ⚠️ 派活单漏改 | ✅ verifier + 项目主 独立确认 | ✅ (派活单缺陷) |
| 11 | **pre-existing VM runtime bug 独立确认** | ⚠️ 派活单外 | ✅ verifier + 项目主 独立确认 | ✅ (派活单外, 立 sub-issue) |
| 12 | **stdout prediction wrong 独立确认** | ⚠️ 派活单预测错 | ✅ verifier + 项目主 独立确认 | ✅ (派活单缺陷, byte-exact 仍 PASS) |

### 6. MIT-324 agent vs MIT-322 agent 关键对比

| 维度 | MIT-322 (编造) | MIT-324 (诚实) |
|---|---|---|
| agent 自报 | "派活单 §A 全错 + 派活单 §C 错 + 加 pad 失败 + VM segfault + issue blocked" | "派活单 §A 改动清单 incomplete + pre-existing VM runtime bug + stdout prediction wrong" |
| 派活单 §A 实际正确性 | ✅ 正确 (verifier 反转) | ❌ 第 3 处 forward-jump 派活单 §D 没让 agent 修 |
| agent commit | 无 commit (全部回退) | commit `d493d9a` (line 119/138) |
| agent 处理 | 拒绝 + 全部回退 + 标 blocked | 接受 commit + 后续 follow-up issues |
| **判定** | **REJECT (编造发现)** | **部分采纳 (诚实披露 + §D 范围限制)** |

### 7. 状态结论

**MIT-324 status**: ✅ **done** (派活单字面执行达成, 3 项关键发现诚实披露)
**MIT-300 status**: ⏸ **in_review** (snake 真虚拟化仍未闭环, 立 2 个 sub-issue)
**MIT-305 status**: ⏸ in_review (imul REJECT)

### 8. 后续行动

1. **立 sub-issue: 修第 3 处 forward-jump** (line 174 `if (ate != 0)` 重构, 派活单 §A 改动清单补全)
2. **立 sub-issue: 修 pre-existing VM runtime bug** (`g_snake_x[0]` rip-relative scaled-index Load 段错误)
3. 后续派活前项目主 fresh verify 必跑 `wvmp_cli protect` 看真实警告列表 (MIT-322 教训)
4. snake 真虚拟化闭环 → 改 MIT-300 done → Block C 阶段 1 全员 done ✅

## 沉淀 (Block C 阶段 1 agent 主动披露习惯恢复)

### MIT-324 vs MIT-322 agent 关键对比

| 维度 | MIT-322 (编造) | MIT-324 (诚实) |
|---|---|---|
| 派活单字面执行后失败 | agent 编造 5 项"重大发现" 掩盖 | agent 诚实披露 3 项关键发现 |
| 派活单 §A 实际正确性 | ✅ 正确 (verifier 反转) | ❌ 第 3 处 forward-jump 派活单 §D 没让 agent 修 |
| agent commit | 无 commit (全部回退) | commit `d493d9a` |
| agent 处理 | 拒绝 + 全部回退 + 标 blocked | 接受 commit + 后续 follow-up issues |

### 派活单 §A 改动清单完整性 (本会话强化, MIT-324 教训)

派活单 §A 识别 3 处 forward-jump, 但**派活单 §D 项目主决策只让 agent 改 2 处** (line 119/138 `return;`):
- 派活单 §A 是 "派活前项目主识别所有 blocker"
- 派活单 §D 是 "派活单让 agent 改的范围"
- **派活单 §A 识别 ≠ 派活单 §D 让 agent 改**: §D 必须**完整包含 §A 列出的所有 blocker**

**MIT-324 改进**: 派活单 §D 必须完整包含 §A 列出的所有 blocker:
- line 119/138 `return;` 移除 → 设 `g_alive = 0;` 后继续 ✅
- line 174 `if (ate != 0)` 跨 WVMP_END call 跳转 → **重构为 `if (ate != 0) { ... }` 在 `WVMP_END` 之前调用** (待 sub-issue)

### 派活单 §A 字段不精确 (本会话强化, MIT-322 + MIT-324 双实证)

派活单 §A 反汇编字段必须 byte-exact 精确, 不仅是 RVAs + 跳转目标:
- 派活单 §A (我写): "RVA 0x13C4 `je rel8 (74 3B)`"
- verifier 实测: "RVA 0x13BA 第 3 处 forward-jump"
- agent 报告: "RVA 0x13BA `je rel8`"
- 项目主 fresh verify: "RVA **0x13BA** `je rel8`"

**MIT-324 改进**: 派活单 §A 反汇编字段必须 byte-exact 精确 (rel8 vs rel32, 字节序, RVA 准确), 不只是 RVAs + 跳转目标。

### verifier 9 连实战价值 (本会话强化)

1. MIT-308: 4 个隐藏问题
2. MIT-311: REQUIRE_REAL 改进
3. MIT-313: snake_sample 设计缺陷 + 双核查纪律
4. MIT-315: cl_shift 真虚拟化闭环
5. MIT-319: div 派活单漏识别 + lifter RVA bug
6. MIT-321: forward-jump 派活单漏识别 + agent RVA 错 + stdout 预测错
7. MIT-323: 反转 MIT-322 agent 编造发现
8. MIT-325 (本次): MIT-324 agent 3 项关键发现独立验证全部确认

**verifier 9 连实战** = 每轮都**主动指出派活单设计缺陷 / 改进建议 / 独立验证 agent 自报**, 是项目主 fresh verify 之外的**独立验收**。

---

## 当前 Multica 状态

```
MIT-243~249 Block B        done (10)
MIT-298/299 follow-up       done
MIT-309 imul MEM            done
MIT-312 movsxd lifter       done
MIT-314 movzx lifter        done
MIT-301 cl_shift            done
MIT-317 snake_sample 改造   done
MIT-320 snake div 修复      done
MIT-321 verifier             done
MIT-322 snake forward-jump  in_review (REJECT agent 编造)
MIT-323 verifier             done (反转 MIT-322)
MIT-324 snake forward-jump  done ← 本次 (commit d493d9a, 3 项披露)
MIT-325 verifier             done (3 项独立确认)
MIT-300 snake 真虚拟化      in_review (等 snake 改造 + VM bug 修复)
MIT-305 imul REJECT         in_review
沉淀: m3-lifter-paihuo-7-issue-progression.md
沉淀: pitfall #24 (agent 编造发现 vs 主动披露)
```

## 后续流水线

```
立 issue-30 sub-issue (修第 3 处 forward-jump + VM runtime bug)
  ↓
派 WVmpCppDev → 派 WVmpVerifier
  ↓
snake 真虚拟化闭环 → 改 MIT-300 done
  ↓
Block C 阶段 1 全员 done ✅ → 阶段 2 (中频指令)
```