# 项目主裁定: 部分采纳 MIT-312 (lifter movsxd 支持) + 立 snake 改造 sub-issue

## 总体评价

MIT-312 commit `8e88881` (git commit 标 "MIT-307", Multica 标 MIT-312) **采纳** (ACCEPT): **lifter movsxd 实现完整, 4 种字节形式全接住, 0 条 movsxd 警告**。

但派活单核心目标 "snake 真虚拟化闭环" **仍未达成** — 根因不是 movsxd (lifter 已修), 而是 **snake_sample 设计缺陷**: 3 个 WVMP_END (早返回分支) 违反 marker_scan 栈式配对逻辑 (首个 END 就闭合区域, 后续 END 被忽略, 跨区域跳转触发 C1 gate)。

派活单 status 改 done (lifter 部分), 立 sub-issue "snake_sample 改造 + marker_scan 配对逻辑"。

## 独立核查结果 (2026-08-25, hermes)

### 双重确认 (verifier + 项目主 fresh verify)

- **verifier 报告** (MIT-313 完成): "MIT-307 自身目标达成 ... snake 真虚拟化闭环未达成, 但根因**不是 movsxd** — snake_sample 有 3 个 WVMP_END (设计缺陷)"
- **项目主 fresh verify**: build rc=0, 292/292, ctest 15/15, snake 跑 `wvmp_cli protect` → `跳转目标块未找到（区域外/未 lift） rva=0x11E1`

### 1. git state

```
HEAD: 8e88881 (clean, main)
MIT-312 commit: 8e88881 (git message 标 MIT-307, Multica 标 MIT-312)
改动: 8 文件 +430/-2
- passes/lifter/src/x86_translate.cpp: translate_movsxd (REG-REG + REG-MEM)
- passes/lifter/tests/test_lifter.cpp: 6 lifter 单测
- ir/include/wvmp/ir/insn.hpp: ir::Op::Movsxd (新增 enum, 不改字段)
- vm/regvm/isa/include/wvmp/regvm/isa/vm_op.hpp: VmOp::Movsxd / MovsxdMem
- vm/regvm/translator/src/translator.cpp: translate_movsxd
- vm/regvm/runtime/src/asmgen.cpp: build_movsxd + build_movsxd_mem handlers
- vm/regvm/runtime/tests/test_runtime.cpp: MovsxdSemantics + 2 fuzz (5万条×5 seed)
- scripts/multiseed_e2e.sh: SAMPLES 加 wvmp_snake_sample
```

### 2. fresh verify 总览

| 项 | 结果 |
|---|---|
| HEAD | 8e88881 (clean, main) |
| build | rc=0, **292/292** |
| ctest | **15/15 PASS** (24.69s) |
| E2E byte-exact | **14/14 PASS** (verifier 跑全 14 sample) |
| **lifter movsxd 二次验证 (snake)** | ✅ **0 条 movsxd 警告** |
| snake 仍 C1 gate | ⚠️ 根因:`跳转目标块未找到（区域外/未 lift） rva=0x11E1` |
| imul 回归零退化 | ✅ imul sample 5/5 真虚拟化 (MIT-309 不破坏) |
| multiseed 5×6 byte-exact | 30/30 (含 snake 字节一致, 但 C1 gate) |
| multiseed REQUIRE_REAL=1 | 20/30 真虚拟化 (snake 仍 FAIL 因 C1 gate, imul PASS) |
| 冻结契约核查 | ✅ 仅改 lifter + ir + translator + asmgen + scripts + tests, 未追加 src3/src4 |

### 3. snake_sample 设计缺陷硬证据

```
$ grep -c "WVMP_END" passes/marker_scan/tests/snake_sample_main.cpp
3
```

**3 个 WVMP_END 位置**:
```
116: WVMP_END(tick);    ← 撞墙早返回 (匹配首个 BEGIN, 闭合区域 @ RVA 0x11ED)
136: WVMP_END(tick);    ← 撞自己早返回 (匹配失败, RVA 0x12C4 / file 0x6c4)
176: WVMP_END(tick);    ← 函数末尾真 END (匹配失败, RVA 0x141D / file 0x81d)
```

**marker_scan 配对行为** (从 protect 输出验证):
```
[warning] marker_scan: end@0x6c4 没有配对的 begin（区域被丢弃）
[warning] marker_scan: end@0x81d 没有配对的 begin（区域被丢弃）
```

**关键**: marker_scan 是**首个 BEGIN-END 配对**, 后续 END 报"没有配对的 begin"。第一个 END 在 RVA 0x11ED 闭合区域,后续 END (0x12C4 / 0x141D) 报警告被丢弃。

**C1 gate 触发**: 区域内 `je 0x11E1 → 0x11F8` 跨区域外跳, virtualize 见"跳转目标块未找到" → C1 gate。

### 4. lifter movsxd 实现核查 (派活单核心目标)

派活单 §A 列 25 条 movsxd 反汇编字节编码 (4 种形式):
- REG-REG (`48 63 /r`): 单测覆盖 ✅
- REG-MEM (RSP+disp8) (`48 63 44 24 disp8`): 单测覆盖 ✅
- REG-MEM (base+disp8) (`48 63 40 disp8`): 单测覆盖 ✅
- REG-REG (REX.B) (`49 63 /r`): 单测覆盖 ✅

**snake 跑 `wvmp_cli protect`, 0 条 movsxd 警告** — 25 条全部被 lifter 接住。

### 5. 派活单设计缺陷复盘 (3 次累积)

| 派活单 | 缺陷 | 教训 |
|---|---|---|
| MIT-300 snake | imul / movsxd 跳出 | 应反汇编 codegen + 读源文件看 API 调用 |
| MIT-309 imul | lifter 仅接 REG-REG | 反汇编列字节编码, 但**没**读 sample 源文件 |
| MIT-312 movsxd | sample 有 3 个 WVMP_END (早返回) | 反汇编 codegen, 但**没**读 snake_sample_main.cpp 看 WVMP_END 数 |

**累积教训**: 派活单派活前必须**双重核查**:
1. capstone 反汇编 codegen (MSVC /Od 实际产出)
2. **读源文件**(样本 API 调用模式, 如 WVMP_BEGIN/END 数量)

### 6. 状态结论

**MIT-312 status**: ✅ **done** (lifter movsxd 部分, 派活单自身目标达成)
**MIT-300 status**: 仍 **in_review** (snake 仍 C1 gate, 但根因是 sample 设计缺陷, 需 sub-issue 修)
**snake 真虚拟化闭环**: 留 sub-issue (派活单草稿 `.multica/issue-20-snake-region-pair.md`, 待写)

### 7. 后续行动

1. **立 sub-issue "snake_sample 改造 + marker_scan 配对逻辑"**:
   - 方案 A: 改 snake_sample 把 3 个 WVMP_END 改为 1 个 (函数末尾), 早返回路径用 set variable 标记 (不走虚拟化区域)
   - 方案 B: marker_scan 改支持嵌套 WVMP_END (栈式配对) — 风险大, 影响其它 sample
   - **推荐 A** (最小代价)
2. **派活单设计教训沉淀到 wvmp-dev 技能**:
   - 派活单派活前双重核查: 反汇编 + 读源文件
   - 样本 API 调用模式审查 (WVMP_BEGIN/END 数量, 早返回 vs 函数末尾)
3. **snake 闭环后**:
   - MIT-300 改 done
   - multiseed REQUIRE_REAL=1 snake 从 FAIL 改为 PASS

## 沉淀 (Block C 阶段 1 重要经验)

### 派活单设计 4 次经验

| 派活单 | 结果 | 关键改进 |
|---|---|---|
| **MIT-300 snake** | ❌ 失败 | imul + movsxd 跳出 |
| **MIT-301 cl_shift** | ❌ 失败 | movzx 跳出 |
| **MIT-305 imul REG-REG** | ❌ REJECT | lifter 仅接 REG-REG |
| **MIT-309 imul MEM** | ✅ done | 反汇编 §A 列字节编码 |
| **MIT-312 movsxd** | ✅ done (lifter) | 反汇编 §A 列 25 条字节编码, 4 形式覆盖 |
| **snake 闭环** | ❌ 未达成 | snake_sample 3 个 WVMP_END 设计缺陷 |

### 派活单派活前双重核查纪律

**改进前** (MIT-300): 仅看 issue 描述 + agent 自报, 派活单设计缺陷
**改进中** (MIT-309 / MIT-312): capstone 反汇编 codegen 列字节编码, 派活单 §A 列 6/25 条
**改进后** (本次): capstone 反汇编 + **读源文件看 API 调用模式**

**派活前检查清单**:
1. capstone 反汇编目标 PE, 列相关指令的 RVA + 字节 + 形式 (派活单 §A)
2. 读样本源文件, 核查 API 调用:
   - WVMP_BEGIN/END 数量 (派活单要求 1 个 BEGIN + 1 个 END 在函数末尾)
   - 早返回路径用 set variable 标记 (不调 WVMP_END)
   - 异常路径不调 WVMP_END
3. 列样本中可能触发的 codegen 形式 (类型扩展 / 除法展开 / 内存寻址)
4. 派活单 §冻结契约 显式列出允许改的字段 (src2 additive 兼容, src3/src4 须明示)

### verifier 实战价值 (3 次确认)

- **MIT-308 verifier** (imul REG-REG): 抓 4 个隐藏问题 (核心目标 / 冻结契约 / 测试盲区 / multiseed 误导)
- **MIT-311 verifier** (imul MEM): 9/9 通过 + 1 改进建议 (REQUIRE_REAL=0 默认合理)
- **MIT-313 verifier** (movsxd): ✅ lifter 达成 + 主动指出 snake_sample 设计缺陷 + 派活单建议 (反汇编 + 读源文件)

**verifier 三连抓到问题**:
1. 隐藏 4 类缺陷
2. 改进建议 (REQUIRE_REAL)
3. **派活单设计缺陷** (snake_sample 3 WVMP_END)

**verifier 是项目主 fresh verify 之外的独立验收** — 比项目主 fresh verify 更**无利益冲突**, 比项目主 fresh verify 更**敢于指出派活单设计缺陷**(因为 verifier 不参与派活单设计)。

### 流程改进累积

1. **派活单派活前反汇编** (MIT-309 引入)
2. **派活单派活前双重核查 + 读源文件** (本次强化)
3. **完成后必派 WVmpVerifier** (MIT-308 引入, MIT-311/313 验证)
4. **multiseed REQUIRE_REAL=1** 区分真虚拟化 vs C1 gate (MIT-309 引入)
5. **冻结契约白名单扩展** additive 兼容字段不撤回 (MIT-305 引入)

### 阶段 1 进度总结

**完成**:
- ✅ MIT-243~249 Block B (C1~C4)
- ✅ MIT-298/299 follow-up (callgate ctx_ + C1 gate 联动)
- ✅ MIT-309 (imul MEM 修复)
- ✅ MIT-312 (lifter movsxd 部分)

**in_review**:
- ⏸ MIT-300 (snake 真虚拟化, 等 snake_sample 改造)
- ⏸ MIT-301 (cl_shift, 等 movzx)
- ⏸ MIT-305 (imul REJECT, 已派 sub-issue MIT-309 但 verdict 没正式 close)

**待派**:
- 🕒 snake_sample 改造 sub-issue (snake 3 WVMP_END → 1 WVMP_END)
- 🕒 cl_shift movzx 修复 (留阶段 2 中频指令)
- 🕒 阶段 2 中频指令 (xchg / bswap / movzx / movsx / cmpxchg / xadd / setcc / cmovcc)