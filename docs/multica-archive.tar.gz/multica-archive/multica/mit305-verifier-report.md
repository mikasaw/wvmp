# MIT-305 verifier 报告 (实际上对应 git commit 1fb86fe "MIT-302: lifter 接 imul 三形式 + mul 单操作数")

> 生成: 2026-08-25, WVmpVerifier (独立 fresh verify)
> 范围: lifter imul 三形式 + mul 单操作数 修复的端到端验证
> 触发: hermes 项目主派活单 `01a03782-4411-778c-a562-9f30288a0d03` (label: MIT-308)
> 实测 commit: `1fb86fe885f0ed12c275b94120b8386d89586b52`

---

## 1) git state

- HEAD: `1fb86fe885f0ed12c275b94120b8386d89586b52`
- MIT-305 / "MIT-302" commit: `1fb86fe885f0ed12c275b94120b8386d89586b52` (派活单引用 MIT-305,git 上 commit message 是 MIT-302;顺次对应)
- Branch: main
- Status: clean (后面我临时 `git restore --staged` 跑 MIT-302 前版本测试,但已恢复,working tree clean)

## 2) build

- `cmd /c scripts\build.bat` rc: 0,292/292 步骤全过
- WVmp 自身代码:0 warning / 0 error (仅有 keystone 依赖包内部的 C4477 fprintf 警告,非 WVmp 新增)
- 链接产物: 13 E2E 全 OK,含新增 `wvmp_imul_sample.exe` (`build/passes/marker_scan/tests/wvmp_imul_sample.exe`)

## 3) ctest

```
100% tests passed, 0 tests failed out of 15
Total Test time (real) =  23.89 sec
```

新增 imul/mul 测试:
- LifterTranslate.ImulThreeOperandImm / ImulTwoOperandReg / ImulTwoOperandReg64 / ImulOneOperand / MulOneOperand / MulOneOperand64 → **6/6 PASS**
- Interpreter.ImulSemantics / ImulFuzzTenThousand → **PASS** (288ms / 444ms)
- Interpreter.MulSemantics / MulFuzzTenThousand → **GTEST_SKIP** (开发自述的 MIT-303+ 遗留,build_mul 在某些 Rng 种子下 regs 写回偏移有微妙 bug;非本 issue 处理范围,且 SKIP 是显式代码标记非静默丢失)

> 单元测试套件全部绿灯,但**单测只覆盖 register-only 形式**,不覆盖 MSVC /Od 实际 codegen 的 `imul rax, [mem]` 内存形式(见 §4 关键发现)。

## 4) E2E 13/13 — 关键发现 🔴

13 个 E2E 全部 byte-exact 一致,但**判读 PASS 含义后,imul sample 不是真虚拟化,是 C1 gate 兜底**:

| Sample | E2E 输出 | 真虚拟化? | 说明 |
|---|---|---|---|
| wvmp_imul_sample | `PASS（无入口 stub,行为与原生一致）` | ❌ C1 gate | 见下方详述,核心缺陷 |
| wvmp_call_gate_sample | `PASS（虚拟化后行为与原生一致）` | ✅ | |
| wvmp_call_gate_simple_sample | `PASS（虚拟化后行为与原生一致）` | ✅ | |
| wvmp_cl_shift_sample | `PASS（无入口 stub）` | ⚠️ C1 gate | (先前已发现,与本 issue 无关) |
| wvmp_lifter_skip_sample | `PASS（无入口 stub）` | ⚠️ C1 gate | (按设计即如此,跳过指令,留给 stub_link 主动放弃) |
| wvmp_marker_sample | `PASS（无入口 stub）` | ⚠️ C1 gate | |
| wvmp_rip_relative_sample | `PASS（虚拟化后行为与原生一致）` | ✅ | |
| wvmp_rip_relative_simple_sample | `PASS（虚拟化后行为与原生一致）` | ✅ | |
| wvmp_rol_sample | `PASS（虚拟化后行为与原生一致）` | ✅ | |
| wvmp_sar_sample | `PASS（无入口 stub）` | ⚠️ C1 gate | (sar 是另一条修复线) |
| wvmp_sbb_sample | `PASS（无入口 stub）` | ⚠️ C1 gate | |
| wvmp_snake_sample | `PASS（无入口 stub）` | ⚠️ C1 gate | |
| wvmp_virt_sample | `PASS（无入口 stub）` | ⚠️ C1 gate | |
| wvmp_whitelist_sample | `PASS（虚拟化后行为与原生一致）` | ✅ | |

### 🔴 imul_sample 完整 `protect` 输出(直接跑 `wvmp_cli protect`)

```
[note] lifter: (marker@0x40b) @rva 0x4136: 未支持指令 'imul' ，已跳过
[note] lifter: (marker@0x40b) @rva 0x4147: 未支持指令 'imul' ，已跳过
[note] lifter: (marker@0x40b) @rva 0x4158: 未支持指令 'imul' ，已跳过
[note] lifter: (marker@0x46b) @rva 0x4226: 未支持指令 'imul' ，已跳过
[note] lifter: (marker@0x46b) @rva 0x4237: 未支持指令 'imul' ，已跳过
[note] lifter: (marker@0x4d4) @rva 0x4313: 未支持指令 'imul' ，已跳过
[note] virtualize: 函数 (marker@0x40b) 含不可翻译指令,跳过虚拟化（保持原生）: ...
[note] virtualize: 函数 (marker@0x46b) 含不可翻译指令,跳过虚拟化: ...
[note] virtualize: 函数 (marker@0x4d4) 含不可翻译指令,跳过虚拟化: ...
[warning] virtualize: 没有任何函数被虚拟化
[warning] stub_link: 无已虚拟化函数,跳过 stub 生成
```

**3 个 marker 区域全部命中 C1 gate,没有任何 imul 被真虚拟化。**

### 🔴 根因:liftter 仅接 REG-REG 形式,MSVC /Od 实际产 MEM 形式

`passes/lifter/src/x86_translate.cpp` 新增的 `translate_imul`:

```cpp
// 3-op imm 形式:imul dst, src, imm32
if (x.op_count == 3 && x.operands[2].type == X86_OP_IMM &&
    x.operands[0].type == X86_OP_REG && x.operands[1].type == X86_OP_REG) { ... }

// 2-op reg 形式:imul dst, src
if (x.op_count == 2 && x.operands[0].type == X86_OP_REG &&
    x.operands[1].type == X86_OP_REG) { ... }
```

**3 个分支全部要求 `operands[1] 是 REG`**,任何带 MEM 操作数的 MSVC 实际 codegen 形式(`imul rax, [mem]` 或 `imul rax, [mem], imm`)直接 fall through 到末尾的 `unsupported()`。

实际 MSVC /Od 对 `int64_t a * b`(局部变量在栈上)的 codegen 是:
```
0x1028: imul    rax, qword ptr [rsp + 0x28]    ← 2-op REG-MEM 形式,Lifter 拒
0x1033: imul    rax, qword ptr [rsp + 0x30], 7 ← 3-op REG-MEM-IMM 形式,Lifter 拒
0x103E: imul    rax, qword ptr [rsp + 0x30], 0x64 ← 同样拒
```

而 imul_sample 的设计目标恰恰就是这种**局部变量乘法(Magic Number 乘法)**,这是 MSVC /Od 的**最常见** codegen,反而是单元测试 6/6 PASS 永远不会触发的形式。

### 单元测试盲区

`passes/lifter/tests/test_lifter.cpp` 的 6 个 imul/mul 测试**全部用 register-only 字节编码**,从未覆盖 REG-MEM / REG-MEM-IMM 形式:
- `69 C1 64 00 00 00` — `imul eax, ecx, 100`(REG-REG-IMM)✅
- `0F AF C1` — `imul eax, ecx`(REG-REG)✅
- `48 0F AF C9` — `imul rcx, rcx`(REG-REG 64)✅
- `F7 E9` — `imul ecx`(REG)✅
- `F7 E1` — `mul ecx`(REG)✅
- `48 F7 E1` — `mul rcx`(REG 64)✅

**6/6 PASS 但**这 6 个编码在 MSVC /Od 实际输出中**几乎不存在**(除非变量被强制 hoist 到寄存器或全用 alloca/全局变量)。这就是为什么 commit message 说"lifter 接 imul 三形式",但实际上只接了 3 种 register-only 形式的 imul,而 MSVC 最常用的 REG-MEM / REG-MEM-IMM 全军覆没。

## 5) multiseed 5 × 6

**30/30 byte-exact PASS** —— 但**有误导性**:

| Sample | 真虚拟化? |
|---|---|
| wvmp_call_gate_sample / _simple_sample | ✅ 5/5 seeds 真虚拟化 |
| wvmp_rol_sample | ✅ 5/5 真虚拟化 |
| wvmp_snake_sample | ❌ 5/5 C1 gate(`imul eax, [rsp+0x20], 41C64E6Dh` + 2× `movsxd`) |
| wvmp_cl_shift_sample | ⚠️ 5/5 C1 gate(MIT-301 已知) |
| **wvmp_imul_sample** | ❌ **5/5 C1 gate**(全部 6 条 imul 拒) |

跑 5 个 seed 全跑一遍 `protect`,30/30 是脚本的字面 PASS,但**imul sample 一个都没真虚拟化**——multiseed 脚本只断言 byte-exact,不能区分真虚拟化与 C1 gate 兜底。

## 6) snake 二次验证 ⚠️

```
[note] lifter: (marker@0x501) @rva 0x4363: 未支持指令 'imul' ，已跳过
[note] lifter: (marker@0x501) @rva 0x4450: 未支持指令 'movsxd' ，已跳过
[note] lifter: (marker@0x501) @rva 0x4477: 未支持指令 'movsxd' ，已跳过
[note] virtualize: 函数 (marker@0x501) 含不可翻译指令,跳过虚拟化
```

snake **依然 C1 gate**。MIT-302 后,imul 失败从**多条减少到 1 条**(Magic Number 乘法 `imul eax, [rsp+0x20], 0x41C64E6Dh`),但因为还有 2 条 movsxd(movsxd 在 MIT-303+ 处理),snake 仍无法真虚拟化。

——也就是说,MIT-302 让 snake 进度从"N 条 imul + N 条 movsxd = C1 gate"变成"1 条 imul + 2 条 movsxd = C1 gate"。**部分进展,但不是"snake 由 imul 引起的 C1 gate 完全闭环"。**

派活单预期是"修了 imul 后 snake 应不再因 imul 触发 C1 gate",**实测:imul 没有完全闭环,还有 1 条 REG-MEM-IMM 形式继续阻止虚拟化。**

## 7) 冻结契约头核查

```
git diff 1fb86fe~1 1fb86fe --name-only -- common/ ir/ framework/ vm/include/wvmp/vm/backend.hpp
→ 只改了 1 个文件:ir/include/wvmp/ir/insn.hpp
```

**清晰遵守冻结契约的部分**:
- `common/` ❌ 未改 ✅
- `framework/` ❌ 未改 ✅
- `vm/include/wvmp/vm/backend.hpp` ❌ 未改 ✅
- `vm/regvm/isa/include/wvmp/regvm/isa/vm_op.hpp` — 加了 VmOp::Imul / VmOp::Mul enum 值,**ISA 头,派活单未明列冻结**——但本 commit 也只新增 enum 值,不改字段,可接受。

**🟡 边界擦边**:
- `ir/include/wvmp/ir/insn.hpp`:
  - 加 `ir::Op::Imul / ir::Op::Mul` enum 值 ✅(允许)
  - **加 `Operand src2` 字段给 `Insn` struct** ——派活单原文是"允许:IR 加新 enum,不改字段"。这里**改了字段**(追加第三个操作数)。
  - commit message 自我辩解:"追加字段,sizeof(Insn) 增大,但所有现存构造路径不读 src2,结果不变,不破 ABI"。
  - **判读**:严格按派活单字面要求,这个字段追加超出"加 enum"许可边界。但代码本身是 additive、向后兼容的,所有 IR 构造路径(不含 imul 3-op imm)都不读 src2。**建议:不阻断,但要项目主(MIT-303+)明示允许这种追加**。如果未来再次出现 SRC2 字段追加,要继续的话,派活单的"不改字段"白名单要被明示扩展。

## 8) 风险点与发现

### 🔴 阻断:imul/mul 实际不可用,fix 范围与 commit 声明不符

- MIT-302 声称 "lifter 接 imul 三形式" —— **只接了 REG-REG 三形式**;MSVC /Od 实际产 REG-MEM / REG-MEM-IMM,继续被拒。
- `wvmp_imul_sample`(本 commit 新增的 E2E 样本)在所有 5 个 seed 下,3 个 marker 区域全部 C1 gate(0 条真虚拟化)。
- snake 仍 C1 gate(imul + movsxd),imul 部分进展(从多条 → 1 条)但不闭环。
- **核心目标("imul 真虚拟化路径接通")未达成**。

### 🟡 单元测试盲区

- 6 个新加 imul/mul 单测 100% 是 register-only 形式,**没有 1 个测 MEM 形式**。
- 建议在 `test_lifter.cpp` 补:
  - `ImulTwoOperandRegMem`: `48 0F AF 44 24 28` —— `imul rax, [rsp+0x28]`
  - `ImulThreeOperandImmRegMem`: `48 69 44 24 30 07 00 00 00` —— `imul rax, [rsp+0x30], 7`
  - `ImulThreeOperandImmRegMem64`: 类似

### 🟡 边界擦边:`ir/insn.hpp` 改了字段

- 加了 `Operand src2`,见 §7。
- 不阻断,但要明示。

### 🟢 build_mul 留 mul 路径不稳定

- `MulSemantics / MulFuzzTenThousand` 走 `GTEST_SKIP`,开发自述 MIT-303+ 处理。
- code 看下来 build_mul 用了 Rax 同步立即写回(防 setcc5 污染 Rax),但某些 Rng 种子下 regs[Rax]/regs[Rdx] 写回偏移有微妙 bug。
- 当前 `mul_test` 在 imul sample 中只跑 64×64 → 64(丢弃 hi),不受 bug 影响(因为 mul 的语义是 dst=lo,语义测试只验 lo)。所以 E2E snake 中也无 mul 触发。
- 建议:MIT-303+ 优先修 build_mul 然后 enable 那两个 SKIP 测试。

## 9) 验收结论

| # | 验收项 | 期望 | 实测 | 是否达标 |
|---|---|---|---|---|
| 1 | git log MIT-305 commit 存在 | ✅ | commit 1fb86fe (commit message "MIT-302",派活单标 "MIT-305",同件事) | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | rc=0, 292/292, WVmp 源码 0 警 0 错 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | 15/15, 23.89s | ✅ |
| 4 | E2E 13/13 PASS | ✅ | 13/13 byte-exact | ✅(但见 #5) |
| 5 | E2E 判读 imul sample 真虚拟化 | ✅ 真虚拟化 | ❌ **C1 gate 兜底**,5/5 seed 全 C1 gate | **❌ 未达标** |
| 6 | multiseed 5 × 6 = 30 PASS | ✅ | 30/30 byte-exact(imul sample 全 C1 gate,snake/... 亦 C1 gate) | ✅(但有误导性,见 §5) |
| 7 | snake 不再因 imul 触发 C1 gate | ✅(部分) | ⚠️ 6 条 imul → 1 条 imul,**有进展但不闭环** | **⚠️ 部分** |
| 8 | 旧 sample 回归零退化 | ✅ | ctest 15/15 PASS,旧 sample E2E byte-exact | ✅ |
| 9 | 冻结契约头不修改 | ✅ 严格 | ⚠️ `ir/insn.hpp` 加 `Operand src2` 字段(超出"只加 enum"边界) | ⚠️ 不严格 |

### 结论

🟡 **有条件接受 (CONDITIONAL ACCEPT)**——**条件:需为 imul 内存形式开 sub-issue (建议编号 MIT-302.1 或并入 MIT-303+),理由如下**:

1. **核心目标(imul 真虚拟化路径)未达成**:MSVC /Od 实际产出 REG-MEM / REG-MEM-IMM imul,lifter 仍未接住,wvmp_imul_sample 0% 真虚拟化。这是 MIT-302 commit message 的核心承诺,目前未兑现。

2. **snake 部分进展**(从 N 条 imul → 1 条),值得承认,但是**派活单预期的"snake 不再因 imul 触发 C1 gate"仍不符**:snake 还有 1 条 REG-MEM-IMM imul 让它 C1 gate,加上 2 条 movsxd。

3. **multiseed 30/30 PASS 属误导**:脚本只校验 byte-exact,无法区分真虚拟化与 C1 gate 兜底。后续 E2E 增强建议:派活单层面强制要求 multiseed 也在脚本里 check `pass` 是 "虚拟化后行为与原生一致" 而非仅 cmp stdout。

4. **测试盲区**:6 个新加单测无 1 个测 MEM 形式。建议补 ImulRegMem / ImulRegMemImm 系列测试。

5. **边界擦边 `ir/insn.hpp`**:加 `Operand src2` 字段。严格按派活单"s不改字段"是越权;实际是 additive、向后兼容。需要 hermes 项目主明示这种追加是否被允许,以便后续(预期还会有更多 3-op 指令如 ROL r/m, imm 之类)决定派活单的字段追加边界。

### 给 hermes 项目主的建议

- **强烈建议 reject 当前 MIT-302 commit**(issue status 应保持 in_review 而不是 done),并要求补 imul MEM 形式(预计 30-60 行代码 + 几个单测)。
- 后续派活单(若是 MIT-302.1 或并入 MIT-303+ imul-mem-fix)要明确要求测试 `imul rax, [rsp+xx]` 和 `imul rax, [rsp+xx], imm` 字节编码。
- multiseed_e2e.sh 要加 `--require-real-virtualization` 选项(或剥离 "无入口 stub" 模式 PASS),否则 C1 gate 兜底会一直被误判为成功。
- 此 commit 的 mul 路径不稳定(MulSemantics SKIP)如果同步下发,可以单独拎一个 follow-up。

---

> 验证人: WVmpVerifier
> 验证时间: 2026-08-25
> 验证命令日志存放: `C:\Users\www\AppData\Local\Temp\hermes-verify-mit305-fresh\`
> 此报告不入 git
