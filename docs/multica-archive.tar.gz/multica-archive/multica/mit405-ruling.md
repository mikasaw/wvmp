# MIT-405 (MIT-D1) 裁定 — 区域外跳转 8 病灶侦察 + B' 可行性确认

> Author: 接手人 (项目主) — 2026-08-29 12:00 UTC+8
> Status: **ACCEPT, push to `done`**
> Verdict: 侦察质量 = 本会话最高单 (五路互证 + 推翻派单 §A 全部 8 个函数猜测 + 修正派单两处事实错误); B' 全行 (GO) 裁决成立, 上界选型 ③ .pdata 经我独立解析 PE 复算证实

## 1. 项目主独立复算 (不依赖 verifier 任何脚本, Python struct 直读 test_target.exe)

| verifier 主张 | 我的复算 | 结果 |
|---|---|---|
| .pdata 0x549C 字节 / 1805 条 | 数据目录 index **3** (exception; 我第一次核时误用 index 6 得 2 条, 立即自我纠正) → rva=0x10D000 size=0x549C **1805 条** | ✅ |
| ackermann [D540,D5A4) / bsearch [D9B0,DA50) / xtea_enc [ED40,EE6B) / crc32 [DA50,DB70) | .pdata 逐条查 begin→end | ✅ 8 项边界全 MATCH |
| 17/17 目标落 .pdata 界内 | 抽 8 条 (epilogue/END-call 两类) 复算 | ✅ 全 IN |
| int3 扫描失效根因 = 函数间 0 字节垫 | bsearch end == crc32 begin == 0xDA50 | ✅ True |
| 派单 §A 8 个函数猜测全错 (链接序≠源序) | marker@0xc951 → RVA 0xD551 ∈ [0xD540, 0xD5A4) = ackermann (非 mul64hi) | ✅ 推翻成立 |
| "越区目标"列实为跳转指令地址 | 与 §1 三套地址空间澄清自洽 | ✅ 接受 |

**纪律核查**: worktree 隔离 (识别主仓 CLI 被 404-WIP 污染后按 §C 自建 43b3827 干净构建)、wvmpTest 基线产物零触碰、tracked 0 改动、HEAD 不变、worktree 用毕已移除 — 全 ✅。

## 2. 对派单作者 (项目主) 的两处反噬纠错 (登记)

1. **lifter_core.cpp:159 `std::to_string(item.addr)` 十进制挂 `0x` 前缀** — 该日志 bug 直接污染了我手写的 §A "目标 RVA"列。verifier 17/17 按十进制解读全对上, 定论确凿。修复列入 D2 顺带项 (§6.8)。
2. **我拍板的 D2.1"打平选②"前提不成立** — 实测 ②13/17 vs ③17/17 差 4 条, ③ 完胜。裁决改选 ③ .pdata 接受。

## 3. 裁决采纳与 D2 派单输入 (§6 素材 8 条全部收下)

- 可救集 11 + 真虚拟化 2 + 维持 gate 1 (duff `jmp rax` 间接跳转) → **404+B' 后预测 13/14**; 且 404-WIP CLI 旁证 (12 gate note 与静态预测逐一相等 + r12 sha256 已纯 cdqe 修复成功虚拟化) 与 MIT-404 在跑内容互洽
- C (双向分段) 不需要 — 0 反例静态证据成立
- ExitNative 设计要点 (终态 jmp→[rsp+SLOT] 间接、12 jcc 条件退出形态、rsp=entry 基准契约、目标不消费 flags 契约、未配平 push 潜在约束披露) — 质量达到可直接转写进 D2 §B 的程度

## 4. known compromise

- B.3② 超界形态系 4 字节补丁构造 (/Od 编译器不发自然向前跨函数跳转) — verifier 已主动披露, 补丁样本语义为确定性垃圾路径, 同因崩溃 byte-exact 保持, 论证力不受损
- RVA 仅对 sha256 bdbfff91… 二进制有效 (我复算同文件确认) — 算法鲁棒性由 .pdata 运行时读保证, 成立

## 5. close-out action

- `multica issue status MIT-405 done`
- 规划文件更新: 拍板 B' + ③ .pdata, 验收锚 12/14 → **13/14**
- **MIT-D2 实现单草拟**: 待 MIT-404 收口合入后立即派发 (避免双 agent 主仓 build/ 互踩 — 本单已实证该干扰真实存在); §A 素材 = 本 triage §6 八条

== 完 ==
