# MIT-446 (X4 x86 全管道打通) 裁定 — ACCEPT；**x86 生产可用达成**（E2E 3/3 项目主亲手 WOW64 复跑 byte-exact）；首通双缺陷 cdb 铁证；十七连满分

> 裁定人: 项目主 — 2026-09-02 01:2x | 处置: ff-merge main=`dc2f21a`, done
> 复验: agent 已自拆 worktree + 切回 main；项目主另建 `wvmp-x4`@dc2f21a 双 arch 独立重建亲跑全链

## 1. 独立复验（全部亲测）
| 项 | 实测 (@dc2f21a) |
|---|---|
| 双 arch 构建 | x64 rc=0 + x86 交叉链 rc=0 |
| **x86 E2E（本单灵魂, 我亲手）** | **3/3 PASS**: 新 CLI 打 3 x86 样本 → rc=0、stub 计数 **6/1/2 与报告逐位吻合**、PE 头直读 **machine=0x14C** ×3、**WOW64 native/packed 双跑 stdout+rc byte-exact ×3**——x86 战役"从 0 到 1"就此实证 |
| **D1 解禁本体亲验（四象限+对照）** | 新 CLI: x86decl+x86=rc0 真打壳 / auto+x86=rc0 / mismatch 双向 rc2"与目标不符"（文案维持）/ auto+x64=rc0 不扰；**旧 CLI(main@e20b383) auto+x86=rc2** 对照亲跑——放行差异=解禁本体, 非既有面变化 |
| **B.6 第一机器证明** | 我亲手双 CLI 同 seed asm_dump: old=`ffd47289…`/161,861B vs new=**同 sha 同尺寸逐字节恒等**（agent 报告 5 次复跑口径+项目主第 6 次亲验）——S64 改形×8+stub 重写+解禁, x64 码体分毫未动 |
| multiseed / ctest / 电池 / dump 门 | 亲跑 **265/265**（53 样本含 x86 池 15 首批, REQUIRE_REAL=1）/ 16/16 / WOW64 亲手 **36/36** / dump 门 PASS 60 项 |
| wvmpTest | stubs=14 + jt@0xDD84 + en=17 + 双跑 diff 0 103/103 |
| 冻结契约 | runtime.hpp/vm_op(97)/backend/lifter/marker_scan/src/sdk/**pe_writer** 全 **0 diff**；23 文件改动面逐一对照 D3 解禁清单吻合（cli/config.hpp=注释翻正）|
| 硬条款 | 命名分支+main 未动+零脏+切回 main+worktree 自拆+ff-safe+69 分钟对账（23:31→00:40 六 commit）——**十七连满分** |

## 2. #33/披露裁决（两处越字面, 全批准）
① **B.2 清单外同族残段×3**（跳转表比较链/bzhi CF 补丁/cbw stash——sz_step_ 同机制参数化, 直读 diff 核实）: 批准——与五点位同属"地址算术 S64 折 x86 no-op 静默空转"同一缺陷类, 不修则 x86 真管道留已知静默坏面, 与 B.3"不静默"立项目的直接冲突; x64 恒等零 delta 兜底; 独立可回退。D3 字面限域防的是发散, 此处是同一漏洞的封堵半径, 且主动披露——这正是解禁条款想要的行为模式。② 批次一五点合一 commit（"共享 sz_step_ 机制不可逐点拆"）: 批准, 可审计性等价。③ A.2 行号漂移按实读重测——#33 纪律正面执行。

## 3. 首通实录两缺陷（本单含金量最高的部分）
① `rep stosd` 打碎 edi——**VmOp::Ret 直退路径不经 stub 出口 pop**（runtime 恢复"进入时刻"callee-saved→caller 收到碎 edi; 实证 0xC0000029）修=edi 并入捕获恢复; ② 预载偏移顺序反（先 push 在高址, +0x1D4..0x1C8 链）——cdb edx=0x7717667C 与 0xBADB0B00 现场逐字节吻合。**"HALT 路径两缺陷均不可见/sse+callgate 样本先绿正因只走 HALT 面"**——forkface 样本(6 stub 含 Ret 直退形)是首通探测器, 442 区设计价值再现。D5 防回归: translator ×3 + 电池 StepTagS32LiveAndS64NoopGuard（no-op 复辟探测器）在位。

## 4. x86 侧白名单 gate 顺路收益（超派单设计的好东西）
stub_link x86 白名单 gate: 逐条解码 blob, 含跳表缺项 VmOp 的函数整函数保原生——把"跳表折叠 Halt"C2 类静默错在 x86 覆写 .text 前拦成 C1 显式 gate（x64 路径不经此闸, 零变化）。sse 样本设计性负例（SSE 函数整函数原生 + gate note）实证此闸工作。

## 5. 合入后基线
**main=`dc2f21a`, 权威基线 53 样本 ×5 = 265/265**（x86 池首批 15 入册）; x64 dump 底稿 `ffd47289` 续用。

## 6. X5 交接（收口波输入, 报告 §遗留已备）
样本池扩量优先级（X5 交接注记在 GAPS）+ >4 参 cdecl 扩窗评估（固定 4 dword 协议现面）+ gate 清单 G7(SSE32)/G8(Div/Idiv)/Movsxd 永久纸面 + WOW64-only 注记 + reloc 口径（对齐 x64 事实, ImageBase 声明）+ **M2.5-X 阶段宣告素材**。x87=R-SSE-only 已定稿（445 裁定 §6）入册。
