# MIT-427 (G1c movd/movq 桥) 裁定 — ACCEPT，220/220，harness 盲区修三步反证链闭环，命名分支铁律六连满分

> 裁定人: 项目主 — 2026-08-31 00:5x | 处置: ff-merge main=`35ea03d`, done
> 复验 worktree: ../wvmp-427-verify @35ea03d | run 终态 failed（"claude exited with error: exit status 1" 平台崩溃 00:38，**417/418 先例第 3 次复现**——分支交付完整照常验收）

## 1. 独立复验（全部亲测非采信自报）
| 项 | 自报 | 实测 (@35ea03d) |
|---|---|---|
| build / ctest / **multiseed** | 220/220 | ✅ rc=0 / 16/16 / **TOTAL: 220 pass / 0 fail**（44 样本×5）|
| 桥主样本 | 10 stub+7 负例 | ✅ 亲跑: **stub=10**、gate notes **9 条**（movdqa/movdqu/movq[MMX]/paddq/pcmpeqd/pmovmskb/psubq/punpckldq/punpcklqdq——比自报 7 族更细计数，cpp 函数多指令各报一条所致，族面一致）；**语义值位级手对**: movd_in=`00000000A5A5A5A5`+高64全零（装入清零✓）/ movq_in=1122334455667788 高64零✓ / movd_out=0000000012345678（截取✓）/ movq_out=89ABCDEF12345678（全宽✓）；双跑 byte-exact |
| wvmpTest 零回踩 | 待项目主 | ✅ **stub=14** + jump-table@0xDD84 + ExitNative 17 + **diff 0** 103/103——agent 明示"本单未触依赖通路请复验确认"，确认成立 |
| harness 修 | 三步反证链 | ✅ 直读 :306-327: MSYS 口径修正（rc≥128 信号映射 / 裸码≥0x80000000 或负 / 127+空 stdout 三判据）+ FAIL 分支实文; **div 设计性崩溃样本 5 seed 全绿零误伤**（日志亲 grep）——盲区修 + 反证 + 零误伤三步与报告一致 |
| enum/冻结面 | kVmOpMax=97 | ✅ XmmFromGp/GpFromXmm append-only（:580），97≤101 预算达标，跳表余量 30; runtime.hpp/backend/ir 零触及（asmgen/vm_op 为 D4 授权实现层+append-only）|
| 编码纠正链 | 双重纠正 | ✅ GAPS:178-182 直读: "**真值 paddq=66 0F D4（425 原文 D4 正确、5C=SUBPD 误），427 派单自纠 FC 亦误（FC=PADDB）**"——我两轮都没对，agent probe 实测钉死，#33 教科书案例（派单方连续两轮错被同一实测链纠正）|
| 硬条款 | — | ✅ 命名分支+main 未动+tracked 零脏+切回 main+单 commit ff-safe+时长 >3h 对账——**六连满分**（run failed 不影响交付形态认定，同 417/418）|

## 2. #33 四处推翻（全合格，采纳）
① **66 0F D6 "高 64 保持"先验推翻**（d6_probe: 与 F3 0F 7E 逐位同=全清零；mem-dest 才"仅写 8B"）——两编码统一 kBridgeFromXmm 折叠，比派单预期的语义分叉更简单
② paddq/psubq 编码双重纠正（见上表）
③ **harness rc 口径修正**: 我派单写 "rc≥0x80000000"——Git Bash 实测崩溃 rc=**139**（128+SIGSEGV 映射值），原判据在本机永不触发；修正为三判据版。**这条是派单公式错被环境实测救回的典型**
④ **/Od intrinsic 桥正例不可行**: movd/movq/_mm_add_epi64 每处必伴随 movdqa/movdqu 溢出（dumpbin 实测）→ 正例改 MASM 直写 + C++ intrinsic 函数转负例区——425 pand 同款纪律第 2 次应用

## 3. 遗留风险披露核查
① callee-saved 物理寄存器观察误用（根因=样本观察模式非 VM 缺陷，区内 Store 通路修正）——**登记为样本编写纪律**（后续 GP 方向观察勿在区域外读 callee-saved）；② B.5 残余边界（双崩+相同非空部分输出）——披露充分，无此类样本；③ 127+空 stdout 判据——div 亲验无误伤。

## 4. 排程更新
G1c 收口 → **SSE2 整数桥清零**。指令虚拟化残余: **movdqa/movdqu（agent 频率建议优先单开 G1d——intrinsic 溢出伴随=实际高频面）** + pmovmskb/pcmpeq 族 + **G8-BMI 拍板** + 档B/x87 L0/跳表扩容统裁 → 阶段收官 → 410(M3)。基线刷新: **44 样本 × 5 = 220/220**。
