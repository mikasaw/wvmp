# 项目主裁定: 采纳 MIT-317 (snake_sample 改造) + 立 div sub-issue

## 总体评价

MIT-317 commit `c17cbcf` **采纳** (ACCEPT): **派活单核心目标 (snake_sample 改造) 完全达成** — `grep -c "WVMP_END"` 从 3 降到 1, marker_scan 配对警告消失。

但 **snake 真虚拟化仍未闭环** — 派活单设计漏掉 div 指令 (`s % (GW-1)` 取模 MSVC codegen 产出 `div ecx`), 2 条 div 触发 C1 gate 兜底。这是 **派活单设计缺陷**, 不算 agent commit 缺陷。

**额外发现 (verifier 指出)**:
1. **lifter RVA 报告有 bug**: 报告 0x5087/0x5109 (不存在 div 的 .rdata 区), 实际 0x13df/0x13f5 (.text 区)。C1 gate 仍正确触发, 仅 RVA 字段误导。立 sub-issue 修 lifter RVA 报告
2. **派活单设计纪律改进**: 派活前 capstone 反汇编必须列**所有** blocker 指令 (不只是要修复的)

## 独立核查结果 (2026-08-25, hermes)

### 双重确认 (verifier + 项目主 fresh verify)

- **verifier 报告** (MIT-319 完成): 派活单核心目标达成, snake_sample 改造 3→1 WVMP_END, div 漏掉是派活单设计缺陷
- **项目主 fresh verify**: `grep -c "WVMP_END" = 1` ✅, `wvmp_cli protect` snake → "未支持指令 'div' 0x5087/0x5109" 2 条 ✅, C1 gate 兜底 ✅

### 1. git state

```
HEAD: c17cbcf (clean, main)
MIT-317 commit: c17cbcf
改动: 1 文件 (snake_sample_main.cpp, 移除 2 行 WVMP_END)
```

### 2. fresh verify 总览| 项 | 结果 |
|---|---|
| HEAD | c17cbcf (clean, main) |
| build | rc=0, 292/292 |
| ctest | 15/15 PASS |
| `grep -c "WVMP_END" snake_sample_main.cpp` | **1** (派活单核心目标) ✅ |
| E2E 15/15 byte-exact | ✅ |
| multiseed 30/30 byte-exact | ✅ |
| **snake 二次验证** | "未支持指令 'div' 0x5087/0x5109" 2 条, C1 gate 兜底 |
| **stdout 字节一致** | `alive=0 len=3 score=0 food=7,5 head=29,10 tail=27,10 ticks=15` ✅ |
| imul / movsxd / cl_shift / call-bearing 回归零退化 | ✅ |
| 冻结契约核查 | ✅ 仅改 snake_sample_main.cpp (1 文件, 测试 fixture), lifter/translator/asmgen 未动 |

### 3. snake_sample 改造核查

```
$ grep -c "WVMP_END" passes/marker_scan/tests/snake_sample_main.cpp
1   ← 派活单核心目标达成 (3 → 1)

$ wvmp_cli protect snake
[note] lifter: (marker@0x501) @rva 0x5087: 未支持指令 'div' ，已跳过
[note] lifter: (marker@0x501) @rva 0x5109: 未支持指令 'div' ，已跳过
[note] virtualize: 函数 (marker@0x501) 含不可翻译指令，跳过虚拟化（保持原生）
[warning] virtualize: 没有任何函数被虚拟化
```

**marker_scan 配对警告消失** (改造前有 `end@0x6c4 / end@0x81d 没有配对的 begin` 警告, 改造后无)。

### 4. 派活单设计缺陷 — div 漏识别

派活单 issue-20 §改动清单只列出"移除 116/136 行 WVMP_END + 保留 176 行",**没列出** snake_sample 中的其它可能触发 C1 gate 的指令。

**根因**: `s % (unsigned int)(GW-1)` MSVC /Od codegen 产出 `div ecx` (`f7 f1` 字节), lifter 白名单无 `div`, 触发 C1 gate 兜底。**派活单派活前 capstone 反汇编应已识别这条 div** (与 movzx / movsxd / imul 同样的"白名单外指令"陷阱)。

**派活单设计纪律改进**:
- 派活单派活前 capstone 反汇编必须列**所有未支持指令** (不仅是要修复的, 还包括 blocker 指令)
- 派活单 §串行纪律"不重写 snake 其它部分" 应明确 "派活单派活前已识别所有未支持指令, 派活单范围限定只删 WVMP_END + 处理 §A 列出的指令"
- 派活单设计漏掉 blocker 是派活单设计缺陷, 不是 agent commit 缺陷 (agent 严格遵守派活单 §串行纪律"不重写 snake 其它部分")

### 5. 额外发现 — lifter RVA 报告 bug (verifier 主动指出)

verifier 抓到的隐性问题:

- agent 报告 RVA 0x13df/0x13f5 (反汇编看到的 .text 区 div 实际位置)
- 项目主 fresh verify 看 lifter 输出 RVA 0x5087/0x5109 (lifter 内部 rva 报告, 但 0x5087 在 .rdata 区, 不是代码)
- **RVA 字段误导**, 但 C1 gate 仍正确触发 (lifter 跳过 div, virtualize 兜底)
- 立 sub-issue: lifter RVA 报告修复

### 6. 派活单验收逐条核对 (12 项, 9 通过 + 3 派活单设计缺陷)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-317 commit 存在 | ✅ | ✅ HEAD `c17cbcf` | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E 15/15 byte-exact | ✅ | ✅ 15/15 | ✅ |
| 5 | **WVMP_END 数 = 1** (派活单核心目标) | ✅ | ✅ grep -c = 1 | ✅ |
| 6 | **snake stdout 字节一致** | ✅ | ✅ 一致 | ✅ |
| 7 | **multiseed REQUIRE_REAL=1 snake 行为** | snake 仍 FAIL (div) | ✅ div 警告 2 条, C1 gate 兜底 | ✅ (派活单设计预期外) |
| 8 | **snake 二次验证 (project owner 独立)**: 完整输出 | div 警告, 无 movsxd/imul | ✅ div 0x5087/0x5109, 无其它 | ✅ |
| 9 | **div 指令字节编码验证** | capstone 反汇编 | ✅ (verifier 验证 div 0x13df/0x13f5 = `f7 f1` div ecx) | ✅ |
| 10 | imul / movsxd / call-bearing / cl_shift 回归零退化 | ✅ | ✅ 全 PASS | ✅ |
| 11 | **派活单设计缺陷确认**: §A 没列 div | ✅ 确认 | ✅ 派活单设计漏掉 | ✅ (派活单缺陷, 不算 agent) |
| 12 | 冻结契约核查 | 仅改 snake_sample | ✅ 仅改 1 文件 (测试 fixture) | ✅ |

### 7. 状态结论

**MIT-317 status**: ✅ **done** (snake_sample 改造部分, 派活单核心目标达成)
**MIT-300 status**: ⏸ **in_review** (snake 真虚拟化仍 C1 gate 因 div, 需后续 sub-issue 处理 div)

### 8. 后续行动

1. **立 sub-issue snake_sample 改造 div** (推荐方案 A: snake_sample 改用 uint32_t 避免取模):
   - `s % (unsigned int)(GW-1)` 改为 `s & (GW-2)` (GW=32 即 2 的幂)
   - 或 lifter 接 div 指令 (1-2 天工作量, 模板化)
   - **推荐方案 A** (最小改动, snake_sample 改用 uint32_t)
2. **立 sub-issue lifter RVA 报告修复** (verifier 抓到的额外发现)
3. **snake 闭环后**: 改 MIT-300 → done, Block C 阶段 1 全员 done
4. **派活单设计纪律改进沉淀到 wvmp-dev 技能**

## 沉淀 (Block C 阶段 1 完整经验固化)

### 派活单设计 6 次复盘 (5 次失败 + 1 次成功)

| # | 派活单 | 派活前核查 | 失败模式 | 教训 |
|---|---|---|---|---|
| 1 | MIT-300 snake | ❌ | imul + movsxd 跳出 | 应反汇编 + 读源文件 |
| 2 | MIT-301 cl_shift | ❌ | movzx 跳出 | 应反汇编 |
| 3 | MIT-305 imul REG-REG | ❌ | lifter 仅 REG-REG | 应反汇编 |
| 4 | MIT-309 imul MEM | ⚠️ 仅反汇编 | ✅ (派活单 OK) | 应反汇编 + 读源文件 |
| 5 | MIT-312 movsxd | ⚠️ 仅反汇编 | snake_sample 3 WVMP_END 派活单设计缺陷 | 应反汇编 + 读源文件 |
| 6 | MIT-314 movzx | ✅ 反汇编 + 读源文件 | ✅✅ (派活单 + agent 都 OK) | 双核查纪律生效 |
| 7 | **MIT-317 snake_sample** | ⚠️ 反汇编 (但没列 div) | **派活单漏掉 div** | 应反汇编 + 列所有未支持指令 |

**MIT-317 教训**: 派活单 §A 反汇编必须列**所有未支持指令**, 包括"派活单派活前已识别但不修复"的 blocker 指令(如 div)。**派活单派活前反汇编纪律扩充**: 不只列"派活单要修复的指令" + 列"已识别但不修复的 blocker 指令"。

### verifier 6 连实战价值

1. **MIT-308 verifier**: 抓 4 个隐藏问题
2. **MIT-311 verifier**: REQUIRE_REAL 改进建议
3. **MIT-313 verifier**: lifter 达成 + snake_sample 设计缺陷 + 派活单双核查纪律建议
4. **MIT-315 verifier**: 9/9 通过, cl_shift 真虚拟化闭环确认
5. **MIT-317 verifier (本次)**: snake_sample 改造达成 + 派活单漏掉 div 派活单设计缺陷确认 + **额外发现 lifter RVA 报告 bug**

**verifier 五连实战**: 每轮都主动指出派活单设计缺陷或改进建议, 是项目主 fresh verify 之外的**独立验收**。

### 派活单设计纪律扩展 (本轮沉淀)

| 旧纪律 (MIT-313 强化) | 新纪律 (MIT-317 扩展) |
|---|---|
| capstone 反汇编 codegen (§A 列字节编码) | capstone 反汇编 codegen (§A 列字节编码) |
| 读源文件核查 WVMP 数量 (避免 MIT-300/312 缺陷) | 读源文件核查 WVMP 数量 + **列所有未支持指令 (包括 blocker)** |
| 列样本中可能触发的 codegen 形式 | 列样本中可能触发的 codegen 形式 + **识别每条未支持指令的源对应** (e.g. `s % GW-1` → div) |
| 冻结契约显式列出允许改的字段 | 冻结契约显式列出允许改的字段 |

### 派活单漏 blocker 完整捕获 (本次)

派活单 issue-20 §改动清单只列了"移除 116/136 WVMP_END + 保留 176 WVMP_END", 没列:
- `s % (unsigned int)(GW-1)` → `div ecx` (MSVC /Od codegen, byte `f7 f1`)
- 这是 `tick()` 函数内 `new_food = (int)(s % (unsigned int)(GW-1))` 触发的

**派活单下次派活前反汇编纪律强化**:
1. capstone 反汇编列所有指令 (not_mnemonic: mov/add/.../div/mul/cdq/cqo/xchg/bswap/...)
2. 每条指令**标注**它在源文件哪里被触发 (e.g. `s % GW-1` → div ecx)
3. 派活单 §A "所有未支持指令列表" 必须明示哪些修复 / 哪些不修复 / 哪些是 blocker
4. 派活单 §验收 应验证"派活单列出的指令都修了" + "派活单标 blocker 的指令**确认**仍是 blocker"