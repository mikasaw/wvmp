# MIT-442 (X2a 形级 fork 面收口) 裁定 — ACCEPT；#33 双推翻 + D4 红线首战 + 保存区冲突 E2E 实证；十三连满分

> 裁定人: 项目主 — 2026-09-01 13:3x | 处置: ff-merge main=`5ce27c7`, done
> 复验: 亲用 agent 保留 worktree wvmp-x2a@5ce27c7（复用零重建，437/438 同款配合）

## 1. 独立复验（全部亲测非采信自报）
| 项 | 实测 (@5ce27c7) |
|---|---|
| ctest / **multiseed** | 亲跑 **16/16** / **TOTAL: 250 pass / 0 fail**（50 样本×5，245 既有零回踩 + forkface 5/5）|
| **D3 x64 全链实证** | 亲手跑 forkface: **3 stub + byte-exact 全串**（`leave bal=0 ret=6b … s16a=8023 s16b=7fdc s16c=ff80 cwde=ffff8123`——leave 栈平衡/IAT 语义/S16 截断全对）|
| **D4 停手（红线首战）** | call [mem] 交付=**gate note 而非硬做**——asmgen 直读实证 build_callgate 只吃 aux 翻译期 RVA（:1334-1336 无 reg 值目标通路）；agent 同时**戳穿我派单素材的一个错觉**："call reg 已在白名单可直用"仅 lifter 级，translator 对 Reg/Mem 一向 skip→runtime 从未有 call-reg E2E。**lifter 开口+X3 挂账+负例区 2/2b 钉死**——完全符合 D4"停手评论披露别硬改"，验收 §D.2 该项偏差如实披露 ✓ |
| 保存区冲突实证（#33②） | 区内 push 撞 stub 保存区（[ns-8..ns-0x40]）首版分叉→**规则化"guest 栈写恒 ≥ ns"**+样本重设计——438 build_ret"写穿"登记面的 E2E 实证，转 X3 epilogue 设计约束输入 ✓ |
| **S16 裁决（D2 双向授权）** | 实测=**通→收**：G3 时代"S16 现成"声明首次真验成立（size_chain 4 路+movzx 读+别名合并写回全链电池）；两例外收口（S16 push/pop→gate **顺带修复旧静默错形**——旧码 S16 push 走 8B stride，直读 translator 注释+skip 实现核实；S16 串形维持砍面）——**"修复既有静默错形"是本单第 4 个盲区回报** |
| 载体域对账 | 直读: kStrPlainBase=23..27 + kExtCbw=28，"与 0..27 分区连续零重叠"双侧域注在位（419 铁律第 5 次执行）|
| **D4/冻结机器证明** | `git diff -- asmgen marker_scan/src sdk = 0 行` ✓；runtime.hpp/backend/vm_op/ir 零触；**kVmOpMax=97 不动**（六块全折条兑现）|
| wvmpTest 零回踩 | stubs=14 + jt@0xDD84 + en=17 + 双跑 diff 0 103/103 ✓ |
| 互斥审计 | 437 扫描面/438 Ret 面零 diff ✓ |
| 硬条款 | 命名分支+main 未动+零脏+ff-safe+62 分钟对账——**十三连满分** |

## 2. #33 判定（双推翻全合格）
① "call [mem] 零新 VmOp 高置信"（我 A.2 预判）被推翻——真因不在 op 面在 callgate 协议面；agent 未越 D4 硬凑，lifter 半程+挂账精确。**采纳并升格为 X3 硬输入**（CallGate reg-target 通路，X3 单 §A 素材第 1 项）。② leave 预判的"区内 push prologue"形态被 E2E 证伪——保存区规则化是比 leave 本身更值钱的发现。

## 3. 合入后基线与 X3 输入清单
**main=`5ce27c7`，权威基线 50 样本 × 5 = 250/250**。X3（asmgen XL，拆 2-3 张）挂账包已齐：
1. CallGate reg-target 通路（call [mem]/call reg 折条收口，lifter/translator 面已就位）
2. 区域内 push vs stub 保存区：spill/栈基设计（guest 栈写 ≥ns 规则 或 保存区重排）
3. pop 宽度/S16 串形元素宽参数化 + 池 14→6 spill/zero5 重构（X0 §3 主面）
4. shld/shrd、cwd、S16 push 语义若需真支持——一并评估
5. dump 门 WARNING 审阅面统一处理（438 登记随此单）
6. **x87 三路线 D1 一页备忘**（X3 交报时附）

## 4. 遗留（非阻断）
build 环境注记（VS Installer 目录须在 PATH 首位供 vswhere——环境侧未改仓，登记）；x86 纸级维持（§F.1 既定，X5 真 E2E）；未来真实 PE 含区内 prologue 函数整函数保守 gate（正确但打折，X3 可解）——三条如实入册。
