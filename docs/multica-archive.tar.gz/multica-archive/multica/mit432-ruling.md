# MIT-432 (G9r 侦察三合一) 裁定 — ACCEPT，三路全出数零跳过，**P1 现网缺口项目主独立复现认定**；收官排波按 §4 拍板

> 裁定人: 项目主 — 2026-08-31 12:3x | 处置: ff-merge main=`624e900`, done
> 复验: @624e900（纯文档单, 单文件 216 行, 零产品代码 diff 亲验）

## 1. 独立复验
| 项 | 实测 |
|---|---|
| 交付形态 | ✅ 命名分支单 commit ff-safe + `.multica/mit-G9r-triage.md` 216 行全读 + main 未动零脏 + 切回 + spike worktree 已拆（worktree list 亲验只剩主仓）+ ≈100 分钟对账 |
| **🔴 P1 rol/ror flags 分叉——项目主亲手独立复现（406 铁律）** | ✅ 我**按报告文本独立重建**样本（MASM 自含 marker 桩，不经 agent 之手）：native `ror_zdiv=0 shl_zdiv=0` → main 0ac661a CLI protect（2 stub）→ packed **`ror_zdiv=1`** shl 对照一致——**DIVERGENCE 复现成立**；注释根因直读 `asmgen.cpp:2502-2504`（把 SHL 组的 ZF/SF/PF 语义安到 ROL/ROR 头上，与 SDM "仅 CF/OF" 冲突）——**定性=现网正确性缺口，非能力缺口，非本波引入（230/230 盲区=无"rotate 后消费 ZF"形态）** |
| 路1 数字抽查 | ✅ 424 重叠项对账吻合（rorx 288/1088、mulx 898、shlx+pdep 42）且**自测/引用逐条标注**；punpck 粒度分裂表（d/q 88-100% vs codec b/w 73%）——推翻我"q 粒度全包"预判的正确方向；B 组 14 客户 exe 全零+movaps 对照组有效=扫描方法自证 |
| 路2 数字抽查 | ✅ flags 9 指令 SDM×probe 双列齐（对照组自证 probe 能区分写/不写）；**mulx Zen5 连 CF 都不写=厂商分叉实锤**（择一决策留实施单）；"rorx 族零新 op"半推翻（eager flags 模型冲突，asmgen:542-556 直读吻合）——**D3 红线必要性被证实**；载体域 22 起+230 亲验一致；E2E 6 gate+stub=1+byte-exact |
| 路3 spike 核实 | ✅ 单行 diff 内嵌 + build 408/408 + ctest 16/16 + **multiseed 230/230**；机制直读吻合（:194 唯一常数点、:14 注释掩码自动派生、全仓零硬编码 0x7F——我 grep 亲验）；触发点精确：x87 L0(178>128) 唯一必然、ymm 恰临界、BMI ≤102 不触发 |
| 反方陈述义务 | ✅ §4 数字备齐（库域高频 vs 客户态 14/14 全零="假想需求"、P1 缺口独立于收官争议）——D 条款逐项勾齐 |

## 2. #33 判定（合格，采纳）
"rorx 零新 VmOp"半推翻（值✓ flags✗）/ "lqdq 零新 op"基本成立非零成本 / "扩容 S 级"实锤 / 三族 gate 预判成立。**blsr/blsi/blsmsk 语料=0**（G8 蓝图安全裁窄——派单 A.3 列举被我自己的先验带偏，probe 纠正）。

## 3. 附带发现登记
- §6.2 kStubWindow 幻影 begin **第二例复现**（424 §3.2 同款）——收紧建议挂任意 marker_scan 触碰单（观察清单）
- §6.3 branchy 前向分支目标块须同批 lift——**BMI/尾族实施单样本设计硬约束（影子样本必须单基本块）**，立单时注入派单
- §6.4 mulx Intel-侧"写 CF"为 SDM 文本记忆（中置信）——G8b 实施前复核当前版 SDM

## 4. 排波裁定（项目主拍板 2026-08-31）
1. **P1 修复单 = 立即独立先行**（无论收官与否都必须修——现网正确性缺口；机制=flags_tail partial-preserve，同时是 G8a ③ 的前置半成品）
2. G8a 入不入收官波 = **待项目主对用户呈现选项后定**（§4 正反数字已备）
3. 扩容：不单独立波，挂触发阈值（kVmOpMax+1≥128 的实施单内置前置 commit）——采纳
4. 文档联动草案 §5 五条 → 随 P1 单与收官文档波落地
- 基线不变 230/230（零代码单）；triage 落 main 后成 G8a/G8b/尾族/扩容四决策的权威数据源
