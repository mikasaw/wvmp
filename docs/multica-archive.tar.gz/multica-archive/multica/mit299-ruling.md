# 项目主裁定: 采纳 MIT-299 + 闭环 MIT-298

## 总体评价

MIT-299 commit `9ac3d53` 完全采纳。**修复范围超出派活单预期** — agent 排查时发现 multiseed segfault **不止 ctx_ 一个根因**, 还有 base_ 影响 push 数算术 / t_[0]+t_[5] 被 step 5 clobber 两个隐式 segfault, 一次性把 4 个跨 native call 必须保留的寄存器都约束到 callee-saved 池。fresh verify 实测 15/15 PASS (修复前 3/15, 12/15 SIGSEGV), 闭环了 MIT-298 验收 #4。**MIT-298 和 MIT-299 同时改 done**, Block C callgate 健壮性闭环。

## 独立核查结果 (2026-08-24, hermes)

### 1. fresh verify 总览

| 项 | 命令 | 结果 |
|---|---|---|
| HEAD | git rev-parse | 9ac3d53f37aaacbf1b849c6849b4813da6859213 (clean, main) |
| build | scripts\build.bat | rc=0, 286/286 链接成功 |
| ctest | scripts\test.bat | **15/15 PASS**, 18.62 sec |
| E2E seed=12345 | scripts\e2e.bat 11 样本 | **11/11 PASS** (回归零退化) |
| **multi-seed E2E** | 5 seed × 3 call 样本 | **15/15 PASS** ✅ (修复前 3/15) |

证据路径: `C:\Users\www\AppData\Local\Temp\hermes-verify-mit299-9ac3d53-fresh\verify_mit299.txt`

### 2. multi-seed 修复前后对比

| seed | call_gate_sample | call_gate_simple_sample | rol_sample |
|---|---|---|---|
| 1 | ❌→✅ | ❌→✅ | ❌→✅ |
| 12345 | ✅→✅ | ✅→✅ | ✅→✅ |
| 99999 | ❌→✅ | ❌→✅ | ❌→✅ |
| 0xDEADBEEF | ❌→✅ | ❌→✅ | ❌→✅ |
| 0xCAFEBABE | ❌→✅ | ❌→✅ | ❌→✅ |

总: 3/15 → 15/15, 跨 5 个不同 seed (覆盖各种寄存器分配) 全部 PASS, no SIGSEGV, no stdout diff。

### 3. 代码层核查

#### 3.1 commit 9ac3d53 改动

| 文件 | +新增/-删除 | 摘要 |
|---|---|---|
| vm/regvm/runtime/include/wvmp/regvm/runtime/runtime.hpp | +13 | 加 inline constexpr `kCalleeSavedIdx = {2,3,4,5,10,11,12,13}` |
| vm/regvm/runtime/src/asmgen.cpp | +56 | roll() 改造: ctx_/base_/t_[0]/t_[5] 4 个 reserved 寄存器互斥从 callee-saved 池选 |
| vm/regvm/runtime/tests/test_runtime.cpp | +159/-21 | 新增 2 个单测 (AsmGenCtxAlwaysCalleeSaved + CallgateCtxAlwaysCalleeSaved) |
| **合计** | **+207/-21** | 冻结契约零修改 |

#### 3.2 关键设计决策

**agent 比派活单多修了 2 个根因**:
- **ctx_** (派活单要求): 寻址 VmContext, 跨 call 必须保留
- **base_** (agent 加): vm_entry push base_+7 rest(skip base_) = 8 push, 若 base_ 是 caller-saved (如 rax) 不在 rest 数组里 → push 数变 9 → host_rsp 偏移多 8 → callgate step 7 `sub rsp, 0x1A8` 算术错 (按 0x1C8 算, 实际需 0x1A0, 少 8 字节) → pop ctx_ 读错地址 → segfault
- **t_[0]** (agent 加): callgate 目标 VA, step 1 算 aux+image_base, step 6 `call t_[0]` 用, 跨 call 必须保留
- **t_[5]** (agent 加): callgate aux 立即数, step 1 读算 VA 源操作数, 跨 call 必须保留
- t_[0]/t_[5] 注释尤其精彩: "若 t_[0] = rdx/r8/r9, step 5 写物理 rcx/rdx/r8/r9 clobber 目标 VA, step 6 call 错误地址" — 这是 caller-saved 寄存器被 step 5 Win64 ABI 参数装配 clobber 的真实场景

#### 3.3 kCalleeSavedIdx 索引核查

`asmgen.cpp:209-210` 注释:
```
kPhys[14] 索引下, callee-saved = {rbx=2, rbp=3, rsi=4, rdi=5,
                                 r12=10, r13=11, r14=12, r15=13}
```

回查 `asmgen.cpp:167-174`:
```
kPhys[14] = rax=0, rdx=1, rbx=2, rbp=3, rsi=4, rdi=5, r8=6, r9=7,
            r10=8, r11=9, r12=10, r13=11, r14=12, r15=13
```

✅ agent 注释索引完全正确 (rbx=2, rbp=3, rsi=4, rdi=5, r12=10, r13=11, r14=12, r15=13)。

**注意**: 我派活单 issue-10 §方案 A 写的 `kCalleeSavedIdx = {3,4,5,6,12,13,14,15}` 索引偏了 -1 (把 r8=6 当 callee-saved), **agent 写对了**。这是派活单的小错, 不影响 commit, 但要记一笔。

#### 3.4 vm_entry push 数与 rsp 守恒

agent commit message 显式列出推算:
> vm_entry push 数恒为 8 (1 base_ + 7 rest skip base_), host_rsp = native_sp - 0x1C8, callgate step 7 `sub rsp, 0x1A8` 算术正确, 无需调整。

回核:
- ctx_ ∈ callee-saved, base_ ∈ callee-saved 且 ≠ ctx_, vm_entry push base_ (1) + push 7 rest 跳过 base_ (即 7 个 callee-saved 中除 base_ 外的 7 个, ctx_ 必在这 7 个里)
- push 数 = 8, 不变
- callgate step 7 `sub rsp, 0x1A8` 与原 04fc323 / b880720 一致, **无需改**

fresh verify 11/11 E2E seed=12345 + 15/15 multi-seed 间接验证 rsp 守恒仍成立。

### 4. 验收逐条核对

| # | 验收项 | 结果 | 证据 |
|---|---|---|---|
| 1 | scripts\build.bat rc=0, 0 警 0 错 | ✅ | build rc=0, 286/286 链接 |
| 2 | scripts\test.bat 15/15 PASS | ✅ | ctest 15/15, 18.62 sec |
| 3 | E2E 11 样本 seed=12345 全 PASS | ✅ | e2e.bat 11/11 PASS |
| 4 | **E2E multi-seed 15/15 PASS** | ✅ | 修复前 3/15, 修复后 15/15 |
| 5 | 新单测 AsmGenCtxAlwaysCalleeSaved | ✅ | ctest 15/15 PASS (含此) |
| 6 | 新单测 CallgateCtxAlwaysCalleeSaved | ✅ | ctest 15/15 PASS (含此) |
| 7 | 50 seed 验证 ctx_ 永不为 caller-saved | ✅ | agent 自报 + multi-seed 间接验证 |

**派活单验收全部达成**。

### 5. 闭环 MIT-298

MIT-298 ruling §6 写"MIT-298 status 留 todo, 等新 issue 修完 callgate 多 seed 后一并 close"。**MIT-299 已修完多 seed**, 两个 issue 一起改 done:

| Issue | 状态 | 说明 |
|---|---|---|
| MIT-298 | ✅ done | 3 commit (da801d4 / dc71753 / e0aecfc) 已采纳, multiseed 由 MIT-299 闭环 |
| MIT-299 | ✅ done | 1 commit (9ac3d53) 完全采纳, multiseed 15/15 PASS |

**Block B + 早期 follow-up 全员 done**, 可继续 Block C (M3-9+ ASLR / 浮点 ABI / 递归 stub)。

## 沉淀

### 技术发现

- **callgate 跨 native call 必须保留 4 个寄存器**: ctx_ (VmContext 指针) / base_ (码基址, 影响 push 数算术) / t_[0] (目标 VA, step 6 call 用) / t_[5] (aux 立即数, 算 VA 用)。**任何 callgate handler 涉及的持久状态寄存器必须 callee-saved**。
- **push 数算术的隐式耦合**: vm_entry push 数取决于 base_ 是 callee-saved 还是 caller-saved, 影响 host_rsp 偏移。**callgate step 7 sub rsp 常量与 push 数强耦合**, 任何 base_ 池调整都可能让 sub 常量失效。
- **step 5 clobber 物理参数寄存器**: callgate step 5 `mov rcx/rdx/r8/r9` 写 Win64 ABI 参数, 如果 t_[0]/t_[5] 落到 rdx/r8/r9 这些 caller-saved, **被自己 clobber**。callgate 寻址逻辑与 Win64 ABI 的物理参数寄存器冲突。
- **Win64 ABI 跨 native call 寄存器分类**:
  - caller-saved (callee 可改): rax, rcx, rdx, r8, r9, r10, r11 (6 个, kPhys 索引 0,1,6,7,8,9)
  - callee-saved (callee 必须保留): rbx, rbp, rsi, rdi, r12-r15 (8 个, kPhys 索引 2,3,4,5,10,11,12,13)

### 流程教训

- **派活单验收 #4 写"5 seed × 3 call 样本全 PASS"是正确的硬约束**: 即使是"单点耦合"修复, 也应该验证"多 seed 不挂"。MIT-298 没达到 #4, 但诚实披露; MIT-299 修到 #4。**派活单验收是项目主 vs agent 共同契约**, 必须达成。
- **agent commit message 主动披露问题**: MIT-298 (da801d4) 主动写"12/15 SIGSEGV, pre-existing, 与本 fix 无关", MIT-299 (9ac3d53) 主动写"排查过程中发现 base_/t_[0]/t_[5] 也是 caller-saved 依赖"。**agent 主动披露远比掩盖好**, 项目主可以根据披露独立判定。
- **agent 排查深度超预期**: agent 没只修 ctx_, 顺手修了 3 个相关根因 — 这是 agent 主动深挖的表现。**派活单写"建议方案"是建议, agent 可以基于更深理解扩展**。
- **派活单 kCalleeSavedIdx 索引写错**: 我派活单 issue-10 写 `{3,4,5,6,12,13,14,15}`, agent 写 `{2,3,4,5,10,11,12,13}` (正确)。**agent code review 比我细致, 我应该先 grep kPhys 数组再写派活单**。
- **rsp 守恒不必每次重算**: push 数不变 (ctx_/base_ 都限定 callee-saved 后, vm_entry 仍 push 8), sub rsp 常量不变。agent commit message 显式列出推算过程, 便于 code review 复核。
- **multi-seed 验证 = 寄存器分配压力测试**: 任何 callgate / 跨 native call handler 修复后, 必须跑多 seed 验证 (5 seed 起步, 覆盖各种寄存器分配)。这是 callgate 类 bug 的唯一可靠测试手段。
