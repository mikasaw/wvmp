# MIT-428 (G1d movdqa/movdqu 折叠) 裁定 — ACCEPT，230/230，零新 VmOp 教科书折叠单 + 427 翻转闭环，硬条款七连满分

> 裁定人: 项目主 — 2026-08-31 03:0x | 处置: ff-merge main=`0ac661a`, done
> 复验 worktree: ../wvmp-428-verify @0ac661a

## 1. 独立复验（全部亲测非采信自报）
| 项 | 自报 | 实测 (@0ac661a) |
|---|---|---|
| build / ctest / **multiseed** | 230/230 | ✅ rc=0 / 16/16 / **TOTAL: 230 pass / 0 fail**（46 样本×5，220 既有全含）|
| 新主样本 | 15 stub（12 MASM+3 intrinsic 翻转）| ✅ 亲跑: **stub=15**、4 gate 族（pmovmskb/punpcklqdq/vmovdqa32/vpaddd——负例四族精确命中）、byte-exact |
| **427 桥样本翻转**（本单审计核心）| 10→11 + 精确演进 | ✅ 亲测: **stub=10→11**（cpp_movdqu_neg 完全翻转）、gate 族 9→7（movdqa/movdqu 摘除，**punpckldq/punpcklqdq 按 D4 原样保留**+paddq/psubq/pmovmskb/pcmpeqd/MMX movq 不动）、双跑 byte-exact——**对账表逐函数与实测一致，零静默变数** |
| wvmpTest 零回踩 | 14/14 | ✅ stubs=14 + jump-table@0xDD84 + ExitNative 17 + **diff 0** 103/103 |
| **D1 零新 VmOp** | 97 不动 | ✅ **vm/regvm/ 全层零 diff**（diff 10 文件全在 lifter/tests/样本/脚本/文档——比 426 更干净一档，连 translator 都没动）；dump 门 25 handler 恒等机器证明；kVmOpMax=97 |
| §A.4 方向矩阵 | 24 形 probe | ✅ 直读 :2433-2434 两 case（Movaps/Movups, S64 与 :2409 movaps 同构）+ :1674-1675 VEX Fam::Mov 扩挂——**7F 反写"手动换位"预判被实测推翻**（capstone 恒归一化 dst-first，零修正即正确）|
| 硬条款 | — | ✅ 命名分支+main 未动+零脏+切回+单 commit ff-safe+51 分钟对账——**七连满分** |

## 2. #33 三处（合格，采纳）
① **派单 §F.2 "7F 反写需调度层修正"推翻**——probe 实测 capstone 两编码均 dst-first 归一化，翻译层零修正（我的陷阱预判过度，方向矩阵本身按 §B.5 义务全形钉了 24 行，价值在确证而非修正）；② C4 3B 编码 pp=F3 位误编（0x7F→0x7A）probe 自查纠正——**单测注释钉死**，MASM 手编纪律第 3 次应用；③ 负例 ymm 探针首版 16B 落盘窗越界（32B 写栈损坏 rc=3）→ o[4]+nsrc[8] 全宽窗修复——**样本先行 native 全绿再入 multiseed 的 427 纪律生效**（若走 427 修好的 crash guard，该样本会被 harness 直接 FAIL 拦下——盲区修与样本纪律双保险闭环的实证）。

## 3. D2 对齐语义对账（超预期干净）
build_movaps/build_movups handler **唯一差异=中间行助记符**，槽位读写全走 movups（:1188 375 D2 既有判）——无分叉需统一；live 非对齐 movdqa trap 无法 byte-exact 钉（native #GP 崩 vs VM 宽松）→ movups 宽松语义位级钉 + GAPS 文本，处理正确。

## 4. 排程更新
**SSE/整数传送残余清零**。指令虚拟化阶段剩余:
- **拍板项**: ① pmovmskb/pcmpeq/punpck 族（427-428 两单负例常客，频率证据弱于 movdqa——待拍板）② G8-BMI（rorx/mulx 高频但 GP 域新载体设计）
- **统裁项**: 档B ymm + x87 L0 + 跳表 128→256（三 hinge 一张前置单）
- → 阶段收官 → 重启 410 (M3)
- 基线刷新: **46 样本 × 5 = 230/230**。
