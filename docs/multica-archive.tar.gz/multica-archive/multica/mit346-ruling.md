# 项目主裁定: 采纳 MIT-346 verifier 报告 + 接受 MIT-345 (movzx 8→16/16→64) — Block C 阶段 2 第 6 条 done

## 总体评价

MIT-346 verifier 报告 (verifier 第 18 连实战) **接受** MIT-345 (commit `d205f52` movzx 8→16/16→64 指令支持): **12 项全部通过**, 11 分钟跑通, **派活单 §A 假设错改修复方向验证 (pitfall #33 实战体现)**。verifier 独立 fresh verify 双重确认:
- ✅ Build 302/302 0 errors
- ✅ CTest 15/15 PASS
- ✅ cl_shift E2E BYTE-EXACT MATCH (`e=ab f=abcd` 证实 8→16 和 16→64 zero-extension)
- ✅ Multiseed 5×11 REQUIRE_REAL=1: 55/55 PASS (real virtualization, not C1 gate fallback)
- ✅ Snake byte-exact: Block C 阶段 1 closure maintained
- ✅ Code verification: lifter 扫 `ci.bytes[1..3]` 找 `0xB6/0xB7`, translator 编码 `src_size` 进 `aux[0] & 0x3`, asmgen 用 `cmp/jne` 选 byte/word ptr, T1/T6 register conservation 正确 (pitfall #36/#37)
- ✅ Frozen contract: 仅 `ir/include/wvmp/ir/insn.hpp` touched (additive enum allowed), 无其它冻结头

**派活单 §A 假设错改修复方向验证 (pitfall #33 实战体现)**: Agent fix 正确识别真根因 (asmgen byte ptr hardcoding, 不是 3-layer missing)。

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 实证** (11 分钟):
- Code verification: lifter 扫 `ci.bytes[1..3]` 找 `0xB6/0xB7` (派活单没建议, agent 自主找到修复方向)
- Translator 编码 `src_size` 进 `aux[0] & 0x3` (验证 pitfall #34 additive enum append-only)
- asmgen 用 `cmp/jne` 选 byte/word ptr (修复硬编码 bug)
- T1/T6 register conservation 正确 (验证 pitfall #36/#37)
- 派活单 §A 假设错改修复方向验证 (pitfall #33 实战体现)

**项目主 fresh verify** (本轮上一节, MIT-345 ruling):
- HEAD `d205f52` ✅
- native cl_shift stdout = `a=deadbeed8c7475be b=123456789a76204a c=65024 d=2000 e=ab f=abcd` ✅ (e=0xab 0x00ab, f=0xabcd 0x000000000000abcd 全零扩展正确)
- fresh protect: 6 个入口 stub 生成, .wvmp 节 22210 字节 @ RVA 0xB000 ✅
- **protected cl_shift stdout == native cl_shift stdout** → **MOVZX 8→16/16→64 BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

## 🟡 1 项非阻断发现 (派活单文档不准确, 但接受 MIT-345)

verifier 报 派活单有 2 处文档不准确 (但**不**阻塞接受):
1. **派活单 claim `Movzx=53` 在 Cmpxchg=52 之后**, 实际 MIT-315 已加 Movzx 在较早位置 (早期派活单沿用, Movzx 在 MIT-314 已加, enum 顺序沿用)
2. **派活单 expect `48 0F B7+rm` 形式**, MSVC /Od 在此代码路径不 emit 该形式 (MSVC codegen 优化后用 8/16/32/64-bit movzx, 但测试 fixture codegen 实际用 `66 0F B7` + `48 0F B7` 形式)

但 MIT-345 commit **实际功能正确**, build/ctest/multiseed/byte-exact 全 PASS — **派活单 §D 文档错误, 不影响功能**。

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-345** | ✅ **done** | movzx 8→16/16→64 指令支持 (Block C 阶段 2 第 6 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 第 6 条 done ✅ (verifier 第 18 连实战接受, 阶段 2 推进, 6 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **51** (MIT-300 ~ `d205f52`) |
| lifter 白名单 | **~46 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + cmpxchg + **movzx 8→16/16→64**) |
| 真虚拟化样本 | **16 个** (cl_shift_sample 现在含 4 种 movzx 形式) |
| ctest | **15/15** PASS |
| E2E byte-exact | **20/20** (含 cl_shift movzx 8→16/16→64) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |
| **verifier 实战** | **18 连** (含 MIT-346 verifier 第 18 连实战接受 MIT-345) |
| wvmp-dev SKILL.md pitfall | **38 个** |

## 后续流水线

1. **立 Block C 阶段 2 第 7 条派活单** (movsx / popcnt / lzcnt / tzcnt)
 - 推荐下一条: **movsx** (与 movzx 对偶, 派活单限定必派, sign-extend 字节模板 `0F BE/BF`)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 38 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber T1 → T6 save** + **src_size 字段** (movzx 特有) + **acc 字段** (cmpxchg 特有)
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (Block C 阶段 2 第 6 条 done, MIT-345 派活单 §A 假设错改修复方向 pitfall #33 实战)

### 关键沉淀 (本会话)

- ✅ **pitfall #33 派活单 §A 假设不一定是真根因 — MIT-345 实战体现**: agent 实证 MIT-315 cl_shift 闭环已修 8→32/16→32/8→64, **唯一真问题** 是 `build_movzx` 硬编码 `byte ptr` 读源, agent 改修复方向: 加 `src_size` 字段 (IR) + 扫 `ci.bytes[1..3]` 找 `0xB6`/`0xB7` (lifter) + 编码进 `aux[0]` (translator) + 运行时 `cmp/jne` 选 byte/word ptr (asmgen)
- ✅ **4 次派活单 §A 假设错改修复方向实战** (MIT-332/335/345 + cherry-pick `6d96b24`): 沿用诚实披露风格 (不是编造 MIT-322)
- ✅ movzx 8→16/16→64 5/5 真虚拟化 (cl_shift 派活单派发**前**已有 movzx 8→32/16→32/8→64, **本次补充** 8→16/16→64)
- ✅ native/protected BYTE-EXACT MATCH (e=0xab movzx 8→16 期望 0x00ab, f=0xabcd movzx 16→64 期望 0x000000000000abcd, 全零扩展正确)
- ✅ snake 仍 byte-exact 闭环 (Block C 阶段 1+2 闭环保持)
- ✅ multiseed 5×11 55/55 (cl_shift 5/5 + 其它 10 样本 5/5)
- ✅ **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345 没掉进此模式, agent 跑了 25/40 分钟真完成)
- ✅ **沿用 cl_shift_sample** (不新创建 sample, 沿用 MIT-314 模式 + cl_shift_sample_asm.asm 更新)

### 🟡 派活单 §D 文档错误 (非阻断, 但需沉淀)

verifier 报 派活单有 2 处文档不准确:
1. **派活单 claim `Movzx=53` 在 Cmpxchg=52 之后**, 实际 MIT-315 已加 Movzx 在较早位置 (早期派活单沿用, Movzx 在 MIT-314 已加, enum 顺序沿用)
2. **派活单 expect `48 0F B7+rm` 形式**, MSVC /Od 在此代码路径不 emit 该形式

**未来派活单 §D 改动清单必精确化**:
- ✅ enum 顺序必跑 `grep "VmOp::" vm_op.hpp` 实际验证, 不盲沿用前派活单
- ✅ codegen 字节模板必 capstone 反汇编实际 codegen 验证, 不盲沿用前派活单
- ✅ agent commit message 必显式列"enum 顺序 + codegen 字节实证" 提示

### 阶段 2 派活单模板 (本会话强化, MIT-345 实战后)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Movzx=53 之后 append-only) **必 capstone 实证**
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337/341 实证)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **src_size 字段** (movzx 特有, 类似 Cmpxchg acc 字段, 8/16-bit 区分)
- **acc 隐式 rax/al 字段** (cmpxchg 特有, IR 字段 acc 标注)
- **asmgen `alias_write`** (8/16-bit → 32/64-bit 必 alias_write 保护高 56 位, setcc 派活单同款)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345 没掉进此模式): 沿用 pitfall #29 重新派遣纪律
- **派活单 §A 假设不一定是真根因** (pitfall #33, MIT-332/335/345 实战体现): 派活单 §A 作为"初始假设", 允许 agent 改修复方向
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only) **必 capstone 实证**
- 冻结契约核查

---

## 引用链

- `m3-lifter-paihuo-11-issue-progression.md` (16 节点完整演进)
- `mit344-ruling.md` (MIT-341 verifier 接受)
- `mit345-ruling.md` (movzx 8→16/16→64 ruling, 采纳)
- `mit346-ruling.md` (MIT-345 verifier 接受) ← 本文
- `issue-42-movzx-816-1664-instructions.md` (MIT-345 派活单)
- `issue-43-mit345-verifier-instructions.md` (MIT-346 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit345-movzx-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/345 实战体现)
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345 没掉进此模式)