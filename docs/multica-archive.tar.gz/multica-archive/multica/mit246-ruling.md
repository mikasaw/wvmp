## 项目主裁定: 采纳 MIT-246 (C2-Sbb) 当前实现

### 独立核验结果 (2026-08-24, hermes)

**1. 代码层核验** — 读 `vm/regvm/runtime/src/asmgen.cpp` 实际改动:
- `:896` `build_sbb(u64 dispatch)`: **与 build_adc 结构对称**, 仅 native 指令替换:
  ```
  load A → T0     (mov/movzx 不改 flags)
  load B → T1     (mov/movzx 不改 flags)
  zero5           (清 flag scratch; 副作用宿主 CF←0)
  bt  flags_, 1   (宿主 CF = flags_ bit 1 = CF_in)
  sbb  T0, T1     (CPU 完成 A-B-CF_in, flags 由 setcc5 捕真值)
  setcc5
  ```
- `:971` handler 表注册 `{int(VmOp::Sbb), "sbb", &AsmGen::build_sbb}`
- 注释 `:893-895` 主动写明: "build_binary("sub") 用 zero5 把宿主 CF 清零, 不会保留 CF_in;
  bt flags_, 1 路径绕开 zero5 的清零范围 (同 Adc, zero5 仅清 {T3,T4,T6,T7,T9})"

**2. 行为层核验** — fresh 实跑 build + ctest + e2e.sh:
- `scripts\build.bat`: rc=0, 0 错 0 警
- `scripts\test.bat`: `100% tests passed, 0 tests failed out of 15`
- `wvmp_regvm_runtime_tests --gtest_filter=*Sbb*`: 2 tests PASSED
  - `Interpreter.SbbE2EMirrorChain` PASS (40 ms) — **"Mirror Chain" 命名暴露
    agent 主动把 Sbb 视为 Adc 的镜像 (borrow 镜像 carry)**
  - `Interpreter.SbbFuzzTenThousand` PASS (372 ms, 5 万条真执行 fuzz)
- `scripts\e2e.sh wvmp_sbb_sample.exe`: rc=0, 含 PASS (虚拟化路径)
- git working tree 干净 (8/8 PASS)

详见 `C:\Users\www\AppData\Local\Temp\hermes-verify-fix-cli-fresh4\verify_mit246.txt`

### Intel SDM 对齐核验

agent 实现的 flags 语义 = Intel SDM Vol. 2 SBB 条目:

| flag | agent 行为 | Intel SDM 实际 | 对齐 |
|---|---|---|---|
| CF | `setc` 捕获 host 真值 = borrow (CF=1 = 借位发生) | 借位 (与 ADC 的 carry 反转) | ✅ |
| OF | `seto` 捕获 host 真值 | dst 与 src 符号相反 + 结果与 dst 符号相反时 = 1 | ✅ |
| SF | `sets` 捕获 host 真值 | 结果最高位 | ✅ |
| ZF | `setz` 捕获 host 真值 | 结果 == 0 | ✅ |
| PF | `setp` 捕获 host 真值 | 低 8 位偶校验 | ✅ |

**关键点**: CF 语义在 Sbb 与 Adc 之间**反转**:
- ADC: CF=1 表示 carry (加法上溢)
- SBB: CF=1 表示 borrow (减法下溢)

agent 抓到了这个差异 (测试名 `SbbE2EMirrorChain` 即体现), 没把 borrow 当 carry 处理.

### 与 Adc 的镜像设计 (5 万条 fuzz 验证)

`SbbFuzzTenThousand`: 5 Rng × 10000 = 50000 条随机 (a, b, cf_in) →
与 C++ 参考全减 bit-exact 比对, 372 ms 跑通.

`SbbE2EMirrorChain`: 验证多精度减法 borrow 链路 (与 MIT-245 Adc
`add+adc` 链路镜像), 确保跨指令 CF_in 传播正确.

### MIT-246 验收

- 代码 ✅ (commit 104d3d3)
- 测试 15/15 ✅ (含 SbbE2EMirrorChain + SbbFuzzTenThousand 5 万条)
- E2E ✅ (虚拟化路径, 含 borrow 链路)
- Working tree 干净 ✅

请 (agent) 把 status 改 `done`. 后续 MIT-247 (C2-Rol/Ror) 由项目主单独派单,
**严格串行纪律不变**: 一个 issue done 才派下一个.

================================================================
MIT-247 (C2-Rol/Ror) 派单前置准备
================================================================

下一站是 MIT-247 (C2-Rol/Ror), 它与 MIT-244 (Sar) 同属"移位类"但更复杂:
- **两个 handler** (Rol + Ror), 都是循环移位
- **CF = 移出的位** (不是末位, 是循环移位的对应端)
- **OF 仅 1 位移位时按结果最高两位异或** (Sar/Adc/Sbb 没这条规则)
- **lifter TODO 解除** (x86_translate.cpp:374 处 rol/ror 当前是 TODO() 跳过)

项目主会在 MIT-246 done 后单独派单 MIT-247, 在 issue 描述里给关键
技术点提示, 避免 agent 重复踩 MIT-244 的 CF 语义坑.
