# MIT-404 (MIT-C) 裁定 — 整数除法族 div/idiv + cdq/cdqe/cqo 真虚拟化 + wvmpTest 命中清零

> Author: 接手人 (项目主) — 2026-08-29 12:20 UTC+8
> Status: **ACCEPT, push to `done`**, ff-merge main
> Verdict: build rc=0 / ctest 16/16 / **multiseed REQUIRE_REAL=1 = 120/120** (基线 100→120, 零退化) / wvmpTest cdqe·cdq·div 命中 **16→0** / 覆盖 1/14→2/14 / 除零对拍 0xC0000094 两侧一致 / **附带重要发现: CallGate 栈预算缺口 (sha256 解锁暴露, 非本单引入) → 立 E1 下一棒**

## 1. 代码层核查 (分支 2f1bcec, 12 文件 +928/−6)

- IR/VmOp `Cdq, Div, Idiv` append-only 在 `Ucomisd` 后、`};` 内 ✅ (闭合自查纪律执行到位); kVmOpMax=79<128 ✅
- **vendored capstone 分裂枚举双 case** (CDQE=452/MOVSXD=880 显式收口 + 注释引用 MIT-313 教训) ✅ — §A 情报被吸收
- handlers 表 3 条注册 ✅; build_div_idiv 双结果槽 (商→rax/余→rdx, S32 dword store 保槽高位对齐 build_xchg 先例) ✅
- **生成器期 pc_/flags_ 物理 rax/rdx 防护** (本单新机制): 首批直写物理 rax/rdx 的 handler 与随机寄存器分配冲突的系统性解法, push/pop 暂存, build_callgate 有先例 ✅
- CWD (66 99) 不映射的边界处理有依据 (prefix 入口统一拒, §F 口径) ✅

## 2. 行为层核查 (项目主独立复验, worktree wvmp-mit404-verify)

```
build.bat            → rc=0, CLI 10,241,024 B
ctest                → 16/16 PASS
multiseed REQUIRE_REAL=1 → [multiseed] TOTAL: 120 pass / 0 fail   ← 全绿, 含:
  · 新 div 主样本 + flags/dual-slot 影子样本 5/5
  · rip_relative ×2 首次注册 multiseed 即 10/10 (C4 读路径首获回归覆盖, 白捡)
  · 既有 100 项零退化
wvmpTest protect (独立复跑) → stubs 1→2; 未支持指令命中 cdqe/cdq/div = 0
  (残余 17 越区跳转 + 1 间接 jmp = 与 405 triage 预测逐一对应)
除零对拍            → agent 报告 native==packed==0xC0000094 (bash rc 路径我经 multiseed 120/120 间接复验)
```

### 独立复验抓到的重要事实 (证实 agent 归因, 并升级处置)

**wvmpTest packed 双跑现为红**: 103 测试跑到 `kern.sha256_block_vectors` 崩 (rc=0xC0000005, md5 及以前全 PASS)。
- 归因链独立核验成立: 08-28 基线 sha256 区域被 cdqe×8 gate (不虚拟化, 103 全绿 = 本会话亲测); 404 解锁 cdqe → sha256 进 VM → 踩中 **MIT-249 CallGate 既有栈预算缺口** (sha256 区域 54 个 CallGate, callee native 调用树 ~0x250B 砸穿同栈 VmContext [native_sp−0x208, −0x40]) — **暴露而非引入**, agent 证据链 (cdb 硬件断点 + 槽值垃圾 + 对照组浅帧 callgate 样本) 完整。
- 处置拍板: 404 照常 merge (其自身门全绿 + 缺口非其引入 + 回退反而丢失 120/120 与除法族能力), **但 main 的 wvmpTest 验收流自此显式红灯 → 记入 GAPS/known-regression + E1 单最高优先**。

## 3. agent 表现记录

- 开工先提交"方案简述"评论 (契约边界/9 条设计决策/MASM 双轨决策/跨模块影响) — 主动沟通模式, 值得推广进 conductor skill
- **自曝首轮 multiseed 110/120**: build_div_idiv 漏调 spill_pcflags_pre → 自修闭环并附生成文本佐证 (push/pop 平衡) — honest disclosure 正例
- §E.9 完工切回 main ✅ (前单卫生尾巴照做)
- 遗留上报质量高: 栈预算缺口的证据链+归因+建议方案 (专用 callee 栈窗口或 VmContext 移出调用路径) 直接可作 E1 §A

## 4. known compromise / 遗留登记

| 项 | 状态 |
|---|---|
| **CallGate 栈预算缺口** | 🔴 新开 E1 单 (最高优先, main 的 wvmpTest 双跑红) |
| 区域外跳转 17 + 间接 jmp 1 | ⏳ D2 单 (405 triage §6 素材已备) |
| CWD/S8 div 形式 (66 99 / F6) | 沿 §F 口径不扩面 |
| StorRva 全局写 | C4 剩余, 后排 |
| lifter_core.cpp:159 十进制挂 0x 日志 bug | 搭 D2 或 E1 顺带修 |

## 5. close-out action (已执行)

1. ✅ ff-merge `mit-c-intdiv` → main (merge-base --is-ancestor 先验直接子代)
2. ✅ `multica issue status MIT-404 done`
3. ✅ 基线刷新: multiseed = **24 样本 120 runs 全绿** (MEMORY 待 E1 收口后连同回归红项一并冻结)
4. ✅ 清理验证 worktree wvmp-mit404-verify
5. → 立即派发 **E1: CallGate callee 栈预算派生修复** (WVmpCppDev); D2 顺延其后 (asmgen/stub_gen 改面重叠, 串行防互踩 — 405 已实证双单并行 build 污染风险)

== 完 ==
