# MIT-425 (G1b SSE 收官包) 裁定 — ACCEPT，200/200 满贯，指令虚拟化阶段 SSE 线清零，命名分支铁律四连满分

> 裁定人: 项目主 — 2026-08-30 18:4x | 处置: ff-merge main=`e652eff`, done
> 复验 worktree: ../wvmp-425-verify @e652eff

## 1. 独立复验（全部亲测非采信自报）
| 项 | 自报 | 实测 (@e652eff) |
|---|---|---|
| build / ctest / **multiseed** | 200/200 | ✅ rc=0 / 16/16 / **TOTAL: 200 pass / 0 fail**（40 样本×5，超派单预估 195-200 上限） |
| 新主样本 fin | 真虚拟化 | ✅ 亲跑: **14 stub**、mul 语义 hex 手对（mulsd=402E…=6.5×3.5 系正确值 / mulps_mem 含 rip 源）、paddq gate note 在位、双跑 byte-exact |
| 411 负例翻转（§B.4 重点） | memop 转正 | ✅ 亲测: sse_memop 样本 11→**12 stub**、andnps gate note 消失、byte-exact——**翻转带对账注释**（"MIT-411 时代为负例→425 起正例"写进样本头注释，审计链干净） |
| wvmpTest 零回踩 | 14/14 | ✅ stubs=14 + jump-table@0xDD84 + ExitNative 17 + 双跑 **diff 0** 103/103 |
| D2 载体方案 | Op::Mul+src2=imm(14..18) | ✅ 直读: 域 14..18 与 string 0..4 / lock 5..13 **分区连续零碰撞**；**第 4 次 imm 载体踩坑→已按 419 教训"动手前全域对账"**（GpMulUnaffectedByMarkerDomain 回归用例预写，非事后补）——对账纪律闭环生效实证 |
| enum/冻结面 | 86→95 预算内 | ✅ kVmOpMax=95（+5: Mulss/Mulsd/Mulps/Mulpd/Andnps，Btc 后 append-only 注释合规）；runtime.hpp/ir::Op/backend.hpp/callgate/lock 面零触及（diff 17 文件无其一）；**跳表余量 128−95=33 守住** |
| #79 门 | 双门 PASS | ✅ dump 注册表新 handler 12 处命中；静态门 fin 样本 byte-exact 亲验 |
| 硬条款 | — | ✅ 命名分支 `mit-g1b-sse-finale` + main 未动 + tracked 零脏 + 切回 main + 单 commit ff-safe + 72 分钟对账——**四连满分** |

## 2. #33 两处修正（合格，采纳）
① **andnps 折叠方案被实测改道**: 派单先验"Not+And 双折"——agent 实测 andnps 语义 NOT(dst)&src 的 dst 侧非纯位运算可折（Not 折条要写回中间态），选**单新 VmOp Andnps** 更干净；pd/整数 pandn 按 411 ps/pd 互认折叠到同 op（pandn 与 andnps 逐位同语义 SDM 实证）——**R3 债清偿但实现路径与派单不同，披露完整**。
② **mulps/mulpd 的 Size 标签方案**: 未走派单暗示的 aux 扩位（D2 禁区），复用 Addss 族既有 cond_or_size=ir::Size 约定（Mulps/S64=Mulpd 判别位）——零新位域，与 371 时代布局天然一致。
（mul 族"纯 C++ 天然高频"先验 ③ 验证成立: g_da 浮点乘链直接入面。）

## 3. 交付面清单
R1 ✅ mulss/sd/ps/pd 全 4 形态×(reg-reg+reg-mem 含 rip) | R3 ✅ andnps/andnpd/pandn | R2 档① ✅ pand/por/pxor（XmmLoad/Store 16B 通路复用 408）| §B.4 翻转 ✅ | GAPS:152 精确化 + :194 stale 修复 ✅ | R2 档② movd/movq+paddq 砍面 → **G1c 登记**（D3: movd 是 G6a 前置，派 G6a 时携带）

## 4. 排程更新
SSE 三债清零 → **指令虚拟化阶段剩余 = G6a(VEX.128, 424 已拍板 R2) → [G8-BMI 拍板] → [G7 P1 统裁]** → 阶段收官 → 410(M3)。基线刷新: **40 样本 × 5 = 200/200**。
