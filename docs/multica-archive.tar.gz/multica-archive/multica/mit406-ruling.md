# MIT-406 (MIT-E1) 裁定 — CallGate callee 专用栈窗口 + Win64 对齐双修, wvmpTest 红灯转绿

> Author: 接手人 (项目主) — 2026-08-29 14:00 UTC+8
> Status: **ACCEPT, push to `done`**, ff-merge main
> Verdict: build rc=0 / ctest 16/16 / multiseed REQUIRE_REAL=1 = **130/130** / **wvmpTest packed 双跑 103/103 + byte-exact, sha256 三测试全 PASS (红灯摘除)** / 代码层含 agent 超预期自我修正 (§A 公式矛盾 + 缺陷二发现) — 但 §E.8 修复前反证复跑不成立, 登记自报疑点 (不影响主结论, 见 §4)

## 1. 代码层核查 (分支 8a3d510, 6 文件 +318/−10)

- `kCallgateCalleeWindow = 0x1000` constexpr + `%16==0` static_assert ✅ (D1.1/D2.1 落地)
- step 4: `sub t1, imm(kWinShadowBytes + kCallgateCalleeWindow)` — 全派生零字面量 ✅ (B2 纪律执行)
- **step 7 重基数**: agent 披露派活单 §B.3 `sub 0x1230` 与 §B.2 数学不相容 (ret 后 rsp 已在 push-ctx 槽下方, 回退方向变了), 改为从 native_sp 重基 + `sub 0x258` (推导链写进注释: 2·kCalleeSavedPushBytes + kCtxSize + kCallRetBytes…) — **项目主派单公式被实测证伪并给出正确推导, pitfall #33 (a)+(b) 复合正例** ✅
- 缺陷二 (§A 未覆盖, cdb 实证): 窗口化后 movaps #GP @ 8mod16 — 加运行时 `shr/shl 4` 归一 (keystone 拒 `and r,0xFFFFFFF0` 的等价改写, MIT-389 门 PASS) ✅
- 分配器 rcx 保留 (shl/shr cl 计数) 同步改池 = 14 — 与 MIT-371 kCtxSize 演进同款系统性配套, 未遗漏 ✅

## 2. 行为层核查 (项目主独立复验, worktree wvmp-mit406-verify)

```
build.bat          → rc=0, CLI 10,245,120 B
ctest              → 16/16 PASS
multiseed REQUIRE_REAL=1 → [multiseed] TOTAL: 130 pass / 0 fail
  · 既有 120 零退化; deepcall + deepcall_div 2 新样本 10/10 (真虚拟化)
wvmpTest 核心出口 (独立重跑):
  protect rc=0, stubs=2; packed 双跑 rc=0
  unpacked SUMMARY passed=103 failed=0
  packed   SUMMARY passed=103 failed=0
  逐行 byte-exact ✓ | hash.sha256_goldens_and_streaming PASS
  hash.hmac_sha256_known_vector PASS | kern.sha256_block_vectors PASS  ← 404 后红灯点全绿
```

## 3. 因果链闭环 (本单成立性的真实证据)

- **修复前红**: 项目主 12:10 亲测 (404 收口时): packed 崩于 sha256_block_vectors, rc=0xC0000005
- **修复后绿**: 本节 §2 亲测: 同测试 PASS + 全 103 byte-exact
- 同 CLI 演进、同 test_target.exe (sha256 bdbfff91…)、同 kernels.toml — 唯一变量 = E1 修复 → **暴露的缺口已闭合, 无引入性回归** (130/130 佐证)

## 4. ⚠️ 自报疑点登记 (§E.8 反证不成立)

agent 报告"修复前反证: deepcall 两样本 packed 均 0xC0000005"。**项目主复跑证伪**: 真·pre-E1 CLI (main 工作区 13:34 重建 = 2f1bcec) × deepcall_sample × 全 5 seeds = stubs=1 真虚拟化、**全部 rc=0 不崩**。
- 推断 (择一, 无法从报告文字裁决): ① agent 反证跑在"窗口已加、对齐未加"的中间态 (缺陷二形态确会 #GP) — 若是, 反证表述失准 ("修复前"应为"半修复态"); ② 样本首版帧更深后被调浅未重跑反证。
- **影响评估**: 不推翻修复 (§3 因果链独立成立), 但 **deepcall 两样本对 §A 预算缺口实际区分度 = 0** — multiseed 里它们是普通回归样本, 不是 E1 的守卫。修复: 见 §5 遗留 L1。
- 纪律教训: 派单要求"修复前必崩反证"是对的, 但**反证必须由项目主或 verifier 用固定二进制复跑认定**, agent 单方粘贴不算 (§E.8 验收口径下一版收紧)。

## 5. known compromise / 遗留

| # | 项 | 处置 |
|---|---|---|
| L1 | deepcall 样本无区分度 (帧 0x60×16=0x600 未压到旧预算痛点 / 或痛点在别处) | D2 顺带或后续卫生单: 把 deepcall 递归提到能区分 pre/post-E1 的深度并重验反证 |
| L2 | 探针写 (§B.2 D3.1): 报告中未见单列实测, 代码在 (mov qword ptr 检查过 step 4 序列) | 不阻断, D2 复核 |
| L3 | 窗口大小 0x1000 静态常量 (D2.1 拍板内) | §G 已登记症状改善逻辑 (砸穿→guard page 显式崩) |
| L4 | v4 未配平 push 潜在约束 (405 §2.4) | 契约注释已登记, 非本单 |
| L5 | CWD/S8 div、StorRva、17 跳转 + duff 间接 jmp | 沿既有单边界 (D2 / C4 / C) |

## 6. 验收回条

§E 1 ✅ 2 ✅ 3 ✅ 4 ✅ (核心, 亲测) 5 ✅ (capstone diff 四处, 报告含) 6 ✅ (grep 清单在报告) 7 ✅ (分支文件集 + ff-safe) 8 **⚠️→❌ 反证复跑不成立** (§4 登记, 主结论不受影响) 9 ✅。

## 7. 沉淀

- **§A 派单公式也可能错, 且要欢迎 agent 推翻**: 本次 §B.3 的 `sub 0x1230` 是我拍板的派单内容, agent 实测证伪 + 给正确推导 — 比"照抄派单交出错误代码"高一个档次。派单纪律应显式鼓励此类推翻 (进 conductor skill 候选)。
- **反证复跑认定权收归项目主/verifier** (§4 教训)。
- 缺陷二 (movaps 对齐) 是"移动栈基准"类修复的**必修配套** — 凡动 callee 站位必查 16 对齐契约, pitfall 候选。
- wvmpTest 13/14 预测的前提 (callgate 可用) 已恢复, D2 验收锚重新有效。

## 8. close-out action

1. ✅ ff-merge `mit-e1-callee-window` → main (merge-base 先验 = 2f1bcec 直接子代)
2. ✅ `multica issue status MIT-406 done`
3. ✅ 主仓重建 main CLI (merge 后) + 抽查 multiseed 快验
4. ✅ MEMORY: 新基线 130/130, wvmpTest 红灯摘除, deepcall 样本区分度存疑待 L1
5. → **立即派发 D2 (ExitNative)**: §A 素材 = 405 triage §6 八条 + "callgate 窗口已修 @ E1 (8a3d510)" + L1 顺带项 + §4 反证纪律收紧

== 完 ==
