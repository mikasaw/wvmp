# MIT-408 (MIT-C4b) 裁定 — SSE memory 形式全线支持, GAPS C4 收口, 基线刷新 145/145

> Author: 接手人 (项目主) — 2026-08-29 19:20 UTC+8
> Status: **ACCEPT, push to `done`**, ff-merge main
> Verdict: build rc=0 / ctest 16/16 / multiseed REQUIRE_REAL=1 **145/145**
>          / wvmpTest 13/14 + 17 站点 + 双跑 103/103 byte-exact 零回踩
>          / 新 rip 主样本 stub=1 真虚拟化 + byte-exact (项目主亲测)

## 1. 项目主独立复验 (worktree wvmp-mit408-verify @ bbc93e6, 3-commit 链)

| 项 | agent 自报 | 实测 |
|---|---|---|
| build / ctest | rc=0 / 16/16 | ✅ BUILD_EXIT=0 / **16/16** |
| **multiseed REQUIRE_REAL=1** | 145/145 (29 样本) | ✅ **TOTAL: 145 pass / 0 fail** |
| wvmpTest 零回踩 | 13/14 + 103/103 | ✅ stubs=**13** + exit-native=**17** 站点全在 + packed rc=0 + **真实 diff 0 行** |
| 新样本真虚拟化 | 主 1 stub / 影子 5 | ✅ 我亲跑 `wvmp_sse_rip_sample`: protect rc=0 **stub=1**, native/packed 输出 **byte-exact** (g_d/g_f/数组/对齐组全值一致) |
| enum (#34) | +6, kVmOpMax=86 | ✅ `Movsd,Addsd,Subsd,Divsd` + `XmmLoad,XmmStore }` 括号内 append, 86<128, 表注册 6/6 |
| 冻结契约 | 零触碰 | ✅ diff --stat 无 runtime.hpp/framework/backend.hpp; callgate/kExitSlotDepth 未动 |
| 硬条款 (407 v2 起) | CLEAN+切回 main | ✅ 主工作区 tracked 0 脏 + 在 main——**连续第二单满分** |

## 2. 技术评价

- **D1 选型 = 授权范围内最优混合**: XmmLoad/XmmStore 专用原语 (aux=宽度 4/8/16) + rip→RVA 复用既有 LeaRva 通道——比派单预测的"+1~2 值"多花 4 个枚举换 sd 族 (movsd/addsd/subsd/divsd) 补全, **理由成立**: §A.1 需求实测证实 MSVC /Od 对 double 全局必产 movsd/addsd, 不做 sd 族则 double 样本无法真虚拟化; (ir::Op, Size::S64) 双语义编码绕开 ir::Op 冻结枚举——无歧义论证在报告, 采纳
- **GP 双槽 (v18..v23) 作 16B 临时的取舍干净**: 避开 kCtxSize 全链改动 (callgate/ExitNative/stub 三消费点), 6 槽预算 ≤5 核算 + 影子样本 ctx.xmm 读回实证 (#79 纪律执行到位)
- **D3 砍面授权内**: `add/sub [mem],xmm` 双访存形态 lifter/translator 双拒→C1 gate, 留 C4c——按派单"不算失败"条款, 矩阵逐格标注清楚
- 17 个既有 ALU/ucomis handler 加 src 双语义分支, reg≥24 路径文本逐字节不变——verifier 常量闸不稀释的自觉值得肯定

## 3. 瑕疵 (非阻断, 记录)

1. multiseed 注释头"Total: 28 samples × 5 seeds = 140 runs"与自身 SAMPLES 数组 (29) 差 1——影子样本注册后注释未跟改 (数字瑕疵, 实测 145 正确); 下单顺带修
2. movapd/movupd mem 与 subps/divps/xorps 系 mem 源"同通路未逐助记符直测"——遗留①②如实披露, 结构等价论证成立, 接受

## 4. known compromise (继承报告遗留面)

- C4c 候补: `add/sub [mem],xmm` 双访存形态
- comiss/comisd 不在本单面 (仅 ucomis 系)
- AVX/x87/SSE2 整数族照旧 gate

## 5. 处置与基线

1. ff-merge bbc93e6 → main; MIT-408 → done
2. **multiseed 基线刷新: 29 样本 × 5 seeds = 145/145** (旧 135/135 作废)
3. GAPS.md C4 节 agent 已重写收口 (B.6 达成)——GAPS 正册缺口序: C1 done / C2 superseded / C3 done (B2+E1) / **C4 done (本单)** / C5 x86 仍开放
4. 下一棒候选更新: **r06 间接 jmp (14/14 最后一格)** / C4c 双访存小单 / Block F/G 保护强度线 / C5 x86

## 6. 沉淀

- SSE 五连单 (371-376) 当年"派活单限定 REG-REG"埋下的 mem 形式债, 本单一把还清——**派活单砍面时必须在 GAPS/backlog 留钩子**, 否则缺口隐身 (本单直到 407 收口后侦察才浮出)
- "报告数字与预测不一致先查自己口径"模式再次生效: 145 vs 预测 140 差异 = agent 主动注册影子样本 (加分项, 披露在先)
