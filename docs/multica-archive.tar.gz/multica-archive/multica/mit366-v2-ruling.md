# 项目主裁定: MIT-366 v2 (Multica MIT-364 verifier, verifier 第 23 连实战) — 🟡 有条件接受 (核心目标 1 pitfall 沉淀 ✅ + 核心目标 2 capstone 验证脚本 commit 🟡 PARTIAL)

## 总体评价

MIT-366 v2 (Multica 编号 MIT-364 verifier, verifier 第 23 连实战) **🟡 有条件接受** (1 项非阻断: scripts/disasm_cl_shift_check.py 不存在, agent 跑了验证但漏了 commit step, 立 sub-issue #3 修复): **MIT-358 派活单核心目标 1 (pitfall 沉淀) 已达成 ✅**, **MIT-358 派活单核心目标 2 (capstone 验证脚本 commit) PARTIAL**, verifier 跑了 3 分钟真完成, 没掉进 8 步 completed 假完成模式 (model 修复后).

**关键发现 — verifier 独立确认 MIT-358 派活单核心目标 1 (pitfall 沉淀) 已达成 ✅**:
- ✅ **pitfall #39 完整版** (SKILL.md line 133, MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充, MIT-349 popcnt + MIT-353 lzcnt/tzcnt + MIT-358 capstone 反汇编实际偏移验证)
- ✅ **pitfall #44** (MASM helpers 距 marker_begin > kStubWindow=64 需 64-NOP 填充 早期短版本, SKILL.md line 137)
- ✅ **pitfall #46** (x64 calling convention 寄存器传值 RCX 不是 [rsp+0Ch], SKILL.md line 139)
- ✅ **pitfall #47/#49** (派活单 §D 期望值必 Python bit-count 公式校准 + hex/decimal 区分, SKILL.md line 140)
- ✅ **pitfall #48** (派活单 pitfall 候选必 fresh verify 实证 — 反向坑, SKILL.md line 141)
- ✅ **pitfall #50** (派活单派发前项目主 fresh verify 必跑 dumpbin + capstone + git fsck + Python 公式校准 多维验证, SKILL.md line 142)
- ✅ **pitfall #51** (Block C 阶段 2 收尾 sub-issue 模式, SKILL.md line 143)

**核心目标 2 (capstone 验证脚本 commit) 🟡 PARTIAL — 派活单 §A 假设错, MIT-355 错误方翻转教训强化**:
- ❌ `scripts/disasm_cl_shift_check.py` 不存在 (派活单派发**前**项目主 fresh verify 假设 "agent 会 commit capstone 验证脚本", 派活单 §A 假设错)
- ✅ agent 跑了验证 (capstone 反汇编验证 6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64, MIT-349/353 实证保持), 但**漏了 commit step** (派活单核心目标 2 PARTIAL, agent 实际部分达成)
- ✅ **错误方翻转教训强化**: 派活单 §A 假设 "agent 会 commit 脚本", agent 实际跑了验证但没 commit, 沿用 MIT-355 错误方翻转教训强化, **派活单描述错 agent 实际正确** (派活单核心目标 1 已达成 + 派活单核心目标 2 PARTIAL), verifier 独立确认 pitfall 沉淀 ✅ + cl_shift byte-exact ✅

**15/15 测试套件全绿 ✅ + 回归零退化 ✅**:
- ✅ ctest 15/15 PASS (含 popcnt/lzcnt/tzcnt 语义测试 + Sar/Adc/Sbb/Rol/Ror 万条 fuzz)
- ✅ 回归零退化: snake/cl_shift sample byte-exact match, frozen contract 保持 (Block C 阶段 1+2 闭环保持)

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 报告** (MIT-366 v2 完成, 3 分钟跑通, model 修复后):
- Verification complete. Report posted to MIT-366 as comment `01a04197-0f1e-7a82-b070-57593289730c` in the triggering thread.
- **Conclusion: 🟡 有条件接受**
- **核心目标 1 (pitfall 沉淀)**: ✅ PASS — pitfall #39 完整版 + pitfall #44/#46/#47/#49/#48/#50/#51 全部到位 (SKILL.md line 133, 137, 139-144)
- **核心目标 2 (capstone 验证脚本 commit)**: 🟡 PARTIAL — `scripts/disasm_cl_shift_check.py` 不存在, agent 跑了验证但漏了 commit step (立 sub-issue #3 修复)
- **15/15 测试套件全绿**: PASS — 含 popcnt/lzcnt/tzcnt 语义测试 + Sar/Adc/Sbb/Rol/Ror 万条 fuzz
- **回归零退化**: PASS — snake/cl_shift sample byte-exact match, frozen contract 保持
- **错误方翻转教训强化**: 派活单 §A 假设错 agent 会 commit 脚本, agent 实际部分达成 — verifier 独立确认 pitfall 沉淀 ✅ + cl_shift byte-exact ✅
- Issue status updated to `done`.

**项目主 fresh verify** (本轮, MIT-366 v2 ruling):
- HEAD `d3bf762` (MIT-365 v2 commit, MIT-366 v2 verifier 没新 commit, verifier 不 commit 只改 issue 评论)
- ✅ pitfall #39/#44/#46/#47/#49/#48/#50/#51 全部到位 (SKILL.md line 133, 137, 139-144)
- 🟡 `scripts/disasm_cl_shift_check.py` 不存在 (派活单核心目标 2 PARTIAL, 立 sub-issue #3 修复)
- ✅ 15/15 测试套件全绿 + 回归零退化 (Block C 阶段 1+2 闭环保持)

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-358 verifier (MIT-366 v2)** | 🟡 **done (有条件接受)** | Multica MIT-364 verifier, MIT-358 验证, **核心目标 1 ✅ + 核心目标 2 🟡 PARTIAL + 15/15 测试套件全绿 ✅ + 回归零退化 ✅**, 立 sub-issue #3 修复 capstone 验证脚本 commit |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (🟡 1 项非阻断) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |
| **MIT-330** | ✅ done (verifier 独立确认) | snake 真虚拟化 byte-exact 闭环 (上线 P0 #1 修复, MIT-367 v2 verifier 独立确认 ✅) |
| **MIT-350** | ✅ done (MIT-365 v2 ACCEPT) | Multica MIT-350 现实世界 exe 回归测试集扩展 (上线 P0 #2 中期派) |
| **MIT-365 v1 stash** | ⚠️ 误操作 commit `93729ba` 已 revert (`ff4c933`) | 5 文件改动已 revert 干净 |

## MVP P0 集成测试进度

| P0 | Issue | status | 说明 |
|---|---|---|---|
| **P0 #1 snake byte-exact 闭环** | MIT-330 | ✅ **done** (MIT-367 v2 verifier 独立确认 ✅) | snake 真虚拟化 byte-exact 闭环, verifier 独立确认 Zero code changes, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 |
| **P0 #2 现实世界 exe 回归测试集** | MIT-350 | ✅ **done** (MIT-365 v2 ACCEPT) | 立 5 个现实世界 exe 回归测试集, verify_real_world.sh 3 pass + 1 fail + 1 skip, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失 |
| **P0 #3 PE ASLR 兼容** | MIT-340 | 🟡 **doing** (MIT-364 v2) | 改 pe_writer + asmgen + stub_link, working tree 改了 6 PE 关键文件, agent 还在跑 25 分钟, **MIT-340 v2 commit 后需 rebuild wvmp_cli.exe + 启 EV 代码签名证书才能跑通**, 沿用 P0 #4 上线 P0 #4 派活单 |

## 后续流水线

1. **MIT-364 v2 commit + rebuild wvmp_cli.exe + verifier 复跑 protected snake 验证**:
 - MIT-364 v2 commit 后, rebuild `build/cli/wvmp_cli.exe` (用 commit 后编译, 不是 working tree 编译)
 - verifier 复跑 protected snake 验证 (MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 + MIT-340 派活单核心目标 ASLR/FORCE_INTEGRITY 兼容, **但需要 EV 代码签名证书才能跑通** — 沿用 P0 #4 上线 P0 #4 派活单, 派发**前** EV 证书到位)
 - **如果** MIT-340 派活单 §D 决策 5 备选方案 (不启用 FORCE_INTEGRITY) 被选, MIT-340 commit 后 verifier 复跑 protected snake 验证 (不启用 FORCE_INTEGRITY, snake 跑通 rc=0 + identical stdout → BYTE-EXACT MATCH, 派活单核心目标达成)
2. **立 sub-issue #3 (commit capstone 验证脚本)**:
 - 派发新 agent 派活单 commit `scripts/disasm_cl_shift_check.py` 到 wvmp-dev, 沿用 MIT-358 agent 验证的 capstone 反汇编逻辑 (6 MASM helpers 最小间距 = 70 字节 > kStubWindow=64)
 - 派活单限定: 仅改 scripts/disasm_cl_shift_check.py, 不改其他文件
3. **派 WVmpVerifier (verifier 第 24 连实战, MIT-367 v2)**: 验证 MIT-330 done ✅, 5 分钟真完成 ✅ (上一节已派发)
4. **MVP 集成测试**: MIT-330 (snake byte-exact) ✅ + MIT-340 (ASLR 兼容, MIT-364 v2 doing) + MIT-350 (现实世界 exe 回归测试集, ✅ MIT-365 v2) 三派活单都 done 后, MVP 上线 (上线 P0 #1 + #2 + #3 修复)

## 沉淀 (MIT-366 v2 verifier 第 23 连实战 🟡 有条件接受 + MIT-355 错误方翻转教训强化 + 立 sub-issue #3)

### 关键沉淀 (本会话)

- ✅ **MIT-358 派活单核心目标 1 (pitfall 沉淀) 已达成 ✅** (verifier 第 23 连实战独立确认, 3 分钟跑通): pitfall #39 完整版 + pitfall #44/#46/#47/#49/#48/#50/#51 全部到位 (SKILL.md line 133, 137, 139-144)
- 🟡 **MIT-358 派活单核心目标 2 (capstone 验证脚本 commit) PARTIAL** (verifier 第 23 连实战实证): `scripts/disasm_cl_shift_check.py` 不存在, agent 跑了验证但漏了 commit step (立 sub-issue #3 修复, 派活单 §A 假设 "agent 会 commit 脚本" 真错, MIT-355 错误方翻转教训强化)
- ✅ **15/15 测试套件全绿 + 回归零退化** (Block C 阶段 1+2 闭环保持)
- ✅ **错误方翻转教训强化** (派活单描述错 agent 实际正确, verifier 必独立确认, MIT-355 错误方翻转教训强化)

### MIT-355 错误方翻转教训强化 (本会话强化模式 7, MIT-366 v2 实证)

- ✅ **派活单描述错 agent 实际正确, verifier 必独立确认** (派活单核心目标 byte-exact 真虚拟化达成), **不盲反 agent, 也不盲采派活单描述**
- ✅ **MIT-366 v2 实证**: 派活单派发**前**项目主 fresh verify 假设 "派活单核心目标 2 = agent commit capstone 验证脚本", **派活单 §A 假设错** (派活单派发后项目主 fresh verify 实证 "派活单核心目标 2 PARTIAL, agent 实际部分达成, agent 跑了验证但漏了 commit step")
- ✅ **错误方翻转教训模式 7 强化**: 派活单 §A 假设可能错 (pitfall #33, 10 次实战), verifier 必独立确认实际状态, 不盲采派活单 §A 假设

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit363-ruling.md` (MIT-330 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化 + 上线 P0 #1 修复)
- `mit365-v2-ruling.md` (MIT-365 v2 ✅ ACCEPT + 派活单核心目标 pitfall 实证 + 新 pitfall #53 候选)
- `mit367-v2-ruling.md` (MIT-367 v2 verifier 🟡 有条件 FAIL + 新 pitfall #54 候选 MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥 + MVP P0 #1 独立确认 ✅)
- `mit366-v2-ruling.md` (MIT-366 v2 verifier 🟡 有条件接受 + 核心目标 1 pitfall 沉淀 ✅ + 核心目标 2 capstone 验证脚本 commit 🟡 PARTIAL + 立 sub-issue #3 修复) ← 本轮
- `issue-56-mit358-verifier-instructions.md` (MIT-366 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-330 实证 #10 派活单 §A 假设错 LoadRva/StoreRva 已实施 since M2-8, MIT-355 错误方翻转教训强化, MIT-358 实证 pitfall #39/#44/#46/#47/#49/#48/#50/#51 沉淀)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358/363/365 v2/367 v2 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9/3/4/3/5 分钟真完成, MIT-364 v2 doing, MIT-366 v2 完成)
- `pitfall #53 候选` **sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (MIT-365 v2 实证, MIT-364 agent 改 pe_writer/stub_link 但没 commit)
- `pitfall #54 候选` **MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥** (MIT-367 v2 verifier 实证)
- `pitfall #55 候选` **regvm_runtime_tests 并行 flake** (MIT-367 v2 verifier 实证, 顺序执行 100% PASS)
- ✅ **MIT-330 ✅ ACCEPT (verifier 独立确认, MVP P0 #1 修复)**: snake 真虚拟化 byte-exact 闭环
- ✅ **MIT-350 ✅ ACCEPT (MVP P0 #2 修复)**: 5 个现实世界 exe 回归测试集
- 🟡 **MIT-340 doing (MVP P0 #3 修复中)**: MIT-364 v2, agent 还在跑 25 分钟, working tree 改了 6 PE 关键文件