# 项目主裁定: MIT-370 (MVP P0 #3 替代方案 A — PE 重写 + 杀软扫描兼容) — ✅ ACCEPT (MVP P0 #3 替代方案 A 完成, MVP P0 #1 + #2 修复保持)

## 总体评价

MIT-370 (Multica 编号 MVP P0 #3 替代方案 A) **✅ ACCEPT** (MVP P0 #3 替代方案 A 完成): **MVP P0 #3 替代方案 A 派活单核心目标达成 ✅**, agent 跑了 9 分钟真完成, 没掉进 8 步 completed 假完成模式 (派活单红派送 note 实战有效), MVP P0 #1 + #2 修复保持.

**关键发现 — MVP P0 #3 替代方案 A 派活单核心目标达成**:
- ✅ **MVP P0 #3 替代方案 A 已实现** — PE 重写 + 杀软扫描兼容 without enabling ASLR or FORCE_INTEGRITY (沿用 MIT-367 v2 verifier 实证 pitfall #54 候选 + MIT-364 v2 agent 实证派活单 §A 假设错 #11)
- ✅ **commit `b2372a9`** (push落地, Chinese structured 3-section commit message)
- ✅ **MVP P0 #1 + #2 修复保持**: snake 真虚拟化 byte-exact 闭环 ✅ (MIT-330 + MIT-367 v2 verifier 独立确认) + 5 个现实世界 exe 回归测试集 ✅ (MIT-350 + MIT-365 v2 ACCEPT)

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-370 完成, 跑了 9 分钟真完成, model 修复后):
- **MVP P0 #3替代方案 A implemented** — PE 重写 + 杀软扫描兼容 without enabling ASLR or FORCE_INTEGRITY:
- 1. **`passes/pe_writer/src/pe_writer_pass.cpp`**: Added explicit `FORCE_INTEGRITY` (0x0080) clearing alongside existing `DYNAMIC_BASE` (0x0040) clearing via `kDllCharsClearMask`. Updated comments to reflect MVP P0 #3 alternative A rationale.
- 2. **`scripts/real_world_exe/verify_real_world.sh`**: Added Windows Defender antivirus scan verification step using `Get-MpThreatDetection` after the per-exe tests.
- **Verification results**:
 - build: rc=0, 0 warnings 0 errors ✅
 - ctest: 15/15 PASS ✅
 - multiseed 5×11: 55/55 PASS ✅
 - multiseed 5×11 REQUIRE_REAL=1: 55/55 PASS ✅
 - E2E seed=12345: snake + cl_shift + call_gate byte-exact PASS ✅
 - dumpbin verified protected PE: only `High Entropy Virtual Addresses` + `NX compatible` + `Terminal Server Aware`, no `Dynamic base` or `Check integrity` ✅
 - Windows Defender scan: 4/4 generated protected PEs passed (no threats detected) ✅
 - MVP P0 #1 + #2 fixes preserved (snake byte-exact + 5 real-world exes regression) ✅
- Commit `b2372a9` pushed with Chinese structured 3-section commit message (purpose/changes/validation). Status set to `in_review` for verifier acceptance.

**项目主 fresh verify** (本轮, MIT-370 ruling):
- HEAD `b2372a9` (MIT-370 commit, MVP P0 #3 替代方案 A 已 push)
- git log --oneline -3: b2372a9 (MIT-370) + 61d84ed (MIT-340 注释) + d3bf762 (MIT-350 v2)
- git status: working tree 干净 (除历史 untracked)
- ✅ **native snake 跑通** (`alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`, MVP P0 #1 修复保持)

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-370** | ✅ **done (MVP P0 #3 替代方案 A ACCEPT)** | PE 重写 + 杀软扫描兼容, **不**启用 ASLR + **不**启用 FORCE_INTEGRITY, MVP P0 #1 + #2 修复保持 |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |
| **MIT-358** | ✅ done (🟡 1 项非阻断) | Block C 阶段 2 收尾 sub-issue #2 (pitfall #39 候选沉淀 + capstone 反汇编验证) |
| **MIT-330** | ✅ done (verifier 独立确认) | snake 真虚拟化 byte-exact 闭环 (上线 P0 #1 修复, MIT-367 v2 verifier 独立确认 ✅) |
| **MIT-350** | ✅ done (MIT-365 v2 ACCEPT) | Multica MIT-350 现实世界 exe 回归测试集扩展 (上线 P0 #2 中期派) |
| **MIT-340** | 🟡 **有条件 FAIL** | MIT-340 派活单 §A 假设错 #11 实证 (沿用 M2-8 行为, agent 改回保持 snake byte-exact 闭环) |

## MVP P0 集成测试进度 (上线 P0 #1 + #2 + #3 + #4 修复)

| P0 | Issue | status | 说明 |
|---|---|---|---|
| **P0 #1 snake byte-exact 闭环** | MIT-330 | ✅ **done** (MIT-367 v2 verifier 独立确认) | snake 真虚拟化 byte-exact 闭环, verifier 独立确认 Zero code changes, MIT-326 cherry-pick 派活单已知妥协 "protected PE SIGSEGV rc=139" 修复 |
| **P0 #2 现实世界 exe 回归测试集** | MIT-350 | ✅ **done** (MIT-365 v2 ACCEPT) | 立 5 个现实世界 exe 回归测试集, verify_real_world.sh 3 pass + 1 fail + 1 skip, 派活单核心目标 pitfall 实证 tasklist.exe /? protected 走 C1 gate 后帮助文本丢失 |
| **P0 #3 PE ASLR 兼容** | MIT-340 | 🟡 **MVP P0 #3 替代方案 A done ✅** (MIT-370 ACCEPT) | **不**启用 ASLR + **不**启用 FORCE_INTEGRITY, dumpbin 验证 protected PE 只有 `High Entropy Virtual Addresses` + `NX compatible` + `Terminal Server Aware`, Windows Defender 4/4 通过, MVP P0 #1 + #2 修复保持 |
| **P0 #4 PE 签名 EV 证书** | — | ⚠️ 待派 (MVP派发**前** EV 证书到位, 避免 MIT-340 FORCE_INTEGRITY 启用后未签名 Permission denied rc=126) | — |

## 后续流水线

1. **派 WVmpVerifier (verifier 第 26 连实战)**: 验证 MIT-370 done ✅ (MVP P0 #3 替代方案 A ACCEPT), MVP P0 #1 + #2 修复保持
2. **派 MVP P0 #4 (PE 签名 EV 代码签名证书采购 + 集成)**: MVP派发**前** EV 证书到位 (避免 MIT-340 FORCE_INTEGRITY 启用后未签名 Permission denied rc=126)
3. **MVP 集成测试**: MVP P0 #1 + #2 + #3 (替代方案 A) + #4 都 done 后, MVP 上线 (~1-2 周后, 取决于 EV 证书采购)
4. **MVP派发**前**项目主 fresh verify 必跑 dumpbin + capstone + git fsck + Python 公式校准 多维验证** (pitfall #50 强化)
5. **MVP派发**前**杀软扫描验证**: MVP派发**前**项目主必跑 Windows Defender / 360 / 火绒 / 卡巴斯基 杀软扫描验证 protected PE 不标"异常 PE" (MVP派发**前**杀软扫描验证)

## 沉淀 (MIT-370 MVP P0 #3 替代方案 A ACCEPT + MVP P0 #3 替代方案 A 派活单核心目标达成)

### 关键沉淀 (本会话)

- ✅ **MIT-370 MVP P0 #3 替代方案 A ACCEPT**: PE 重写 + 杀软扫描兼容 (不启用 ASLR + 不启用 FORCE_INTEGRITY, MVP P0 #1 + #2 修复保持)
- ✅ **MVP P0 #3 替代方案 A 派活单核心目标达成**: PE 重写 + 杀软扫描兼容 (不依赖 ASLR 兼容, MVP派发**前**杀软扫描验证)
- ✅ **MVP P0 #1 + #2 修复保持**: snake 真虚拟化 byte-exact 闭环 ✅ (MIT-330 + MIT-367 v2 verifier 独立确认) + 5 个现实世界 exe 回归测试集 ✅ (MIT-350 + MIT-365 v2 ACCEPT)
- ✅ **沿用 MIT-340 派活单 §A 假设错 #11 教训**: MIT-340 派活单 §A 假设错 (ASLR 兼容在 Windows loader + 非 link.exe 生成的 .reloc 扩展行为未文档化场景下实现困难), MVP P0 #3 替代方案 A 派活单派发**前**项目主 fresh verify 必 capstone 实证 dumpbin (pitfall #50 强化)
- ✅ **沿用 MIT-367 v2 verifier 实证 pitfall #54 候选**: MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥, MVP P0 #3 替代方案 A **不**启用 FORCE_INTEGRITY, 避免与 MVP P0 #1 修复互斥
- ✅ **dumpbin verified protected PE**: only `High Entropy Virtual Addresses` + `NX compatible` + `Terminal Server Aware`, no `Dynamic base` or `Check integrity` ✅
- ✅ **Windows Defender scan: 4/4 generated protected PEs passed** (no threats detected) ✅

### MVP P0 #3 替代方案 A 派活单核心目标达成教训 (本会话新增)

- ✅ **MVP P0 #3 替代方案 A 派活单核心目标 = PE 重写 + 杀软扫描兼容**: 派活单派发**前**项目主 fresh verify 假设 "MVP P0 #3 = 改 pe_writer 让 protected PE 兼容 ASLR", 派活单 §A 假设错 #11 实证 (MIT-340 派活单, ASLR 兼容在 Windows loader + 非 link.exe 生成的 .reloc 扩展行为未文档化场景下实现困难), MVP P0 #3 替代方案 A 派活单**重新评估替代方案**: 派发新派活单 PE 重写 + 杀软扫描兼容 only, **不**启用 ASLR + **不**启用 FORCE_INTEGRITY, 保护 MVP P0 #1 + #2 修复
- ✅ **MVP P0 #3 替代方案 A 派活单派发**前**项目主 fresh verify 必跑 dumpbin + capstone + git fsck + Python 公式校准 多维验证** (pitfall #50 强化)
- ✅ **MVP派发**前**杀软扫描验证**: MVP派发**前**项目主必跑 Windows Defender / 360 / 火绒 / 卡巴斯基 杀软扫描验证 protected PE 不标"异常 PE" (MVP派发**前**杀软扫描验证)
- ✅ **MVP P0 #4 (PE 签名 EV 证书)**: MVP派发**前** EV 证书到位 (避免 MIT-340 FORCE_INTEGRITY 启用后未签名 Permission denied rc=126)

---

## 引用链

- `m3-lifter-paihuo-16-issue-progression.md` (22 节点完整演进)
- `mit362-ruling.md` (MIT-358 部分采纳 + 🟡 1 项非阻断, agent 没 commit capstone 反汇编验证脚本)
- `mit363-ruling.md` (MIT-330 派活单 §A 假设错 pitfall #33 实战 #10 + MIT-355 错误方翻转教训强化 + 上线 P0 #1 修复)
- `mit365-v2-ruling.md` (MIT-365 v2 ✅ ACCEPT + 派活单核心目标 pitfall 实证 + 新 pitfall #53 候选)
- `mit367-v2-ruling.md` (MIT-367 v2 verifier 🟡 有条件 FAIL + 新 pitfall #54 候选 MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥 + MVP P0 #1 独立确认 ✅)
- `mit366-v2-ruling.md` (MIT-366 v2 verifier 🟡 有条件接受 + 核心目标 1 pitfall 沉淀 ✅ + 核心目标 2 capstone 验证脚本 commit 🟡 PARTIAL + 立 sub-issue #3 修复)
- `mit364-v2-ruling.md` (MIT-364 v2 agent 🟡 有条件 FAIL + MIT-340 派活单 §A 假设错 #11 实证 + agent 诚实披露 + 改回 M2-8 行为保持 snake byte-exact + 新 pitfall #53 候选实测规避)
- `mit370-ruling.md` (MIT-370 MVP P0 #3 替代方案 A ✅ ACCEPT + MVP P0 #1 + #2 修复保持) ← 本轮
- `issue-58-mvp-p0-3-alt-a-instructions.md` (MIT-370 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-330 实证 #10 派活单 §A 假设错 LoadRva/StoreRva 已实施 since M2-8, MIT-340 实证 #11 派活单 §A 假设错 ASLR 兼容, MIT-355 错误方翻转教训强化)
- `pitfall #38 候选` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350/353/355/358/363/365 v2/367 v2/370 都没掉进此模式, agent 跑了 40/25/22/53/14/12/9/3/4/3/5/17/9 分钟真完成)
- `pitfall #53 候选` **sibling 任务未 commit 改动导致 wvmp_cli.exe 过期** (MIT-365 v2 实证, MIT-364 v2 agent 实测规避)
- `pitfall #54 候选` **MIT-340 FORCE_INTEGRITY 与 MIT-326 SIGSEGV 修复互斥** (MIT-367 v2 verifier 实证, MIT-370 派活单 §D 决策 1 沿用, MVP P0 #3 替代方案 A **不**启用 FORCE_INTEGRITY)
- `pitfall #55 候选` **regvm_runtime_tests 并行 flake** (MIT-367 v2 verifier 实证, 顺序执行 100% PASS)
- ✅ **MIT-330 ✅ ACCEPT (verifier 独立确认, MVP P0 #1 修复)**: snake 真虚拟化 byte-exact 闭环
- ✅ **MIT-350 ✅ ACCEPT (MVP P0 #2 修复)**: 5 个现实世界 exe 回归测试集
- ✅ **MIT-370 ✅ ACCEPT (MVP P0 #3 替代方案 A 修复)**: PE 重写 + 杀软扫描兼容, **不**启用 ASLR + **不**启用 FORCE_INTEGRITY, MVP P0 #1 + #2 修复保持
- 🟡 **MVP P0 #4 (PE 签名 EV 证书) 待派**: MVP派发**前** EV 证书到位 (避免 MIT-340 FORCE_INTEGRITY 启用后未签名 Permission denied rc=126)