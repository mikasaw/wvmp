# 项目主裁定: reject MIT-305 (lifter imul / mul 支持) — 核心目标未达成 + 越权改冻结契约头

## 总体评价

MIT-305 commit `1fb86fe` (git commit message 标 "MIT-302",Multica 派单标 MIT-305) **拒绝采纳** (REJECT)。两个独立阻断问题:

1. **核心目标未达成**: imul 真虚拟化路径在 MSVC /Od 实际 codegen 下全部失败 (REG-MEM / REG-MEM-IMM 形式未实现),wvmp_imul_sample 0% 真虚拟化 (5/5 seed 全 C1 gate)。
2. **冻结契约头越权**: `ir/include/wvmp/ir/insn.hpp` 加 `Operand src2` 字段, 超出派活单明文许可边界("加 enum, 不改字段")。commit message 自辩 additive/向后兼容, 但派活单的纪律是"白名单", 不是"事后补赦免"。

MIT-305 status 保持 `in_review` (与 MIT-300/301 同模式)。**新 sub-issue** 立 `imul MEM 形式支持 + 撤销 src2 字段` (`.multica/issue-16-imul-mem-form.md`)。

## 独立核查结果 (2026-08-25, hermes)

### 双重确认 (verifier 报告 + 项目主 fresh verify)

- **verifier 报告**: `.multica/mit305-verifier-report.md` (13,965 字节, 完整 9 节)
- **项目主 fresh verify**: 见下

### 1. git state

```
HEAD: 1fb86fe885f0ed12c275b94120b8386d89586b52 (clean, main)
MIT-305 commit: 1fb86fe (git message "MIT-302",Multica 标 "MIT-305")
改动: 10 文件 +697/-6
```

### 2. fresh verify 总览 (与 verifier 一致)

| 项 | 命令 | 结果 |
|---|---|---|
| HEAD | git rev-parse | 1fb86fe (clean, main) |
| build | scripts\build.bat | rc=0, **292/292** (WVmp 源码 0 警 0 错, 含 keystone 内部 C4477 警告但非 WVmp 新增) |
| ctest | scripts\test.bat | **15/15 PASS** (23.89s) |
| E2E imul sample byte-exact | cmp stdout | PASS (但见下 — C1 gate 路径) |
| **E2E imul sample 真虚拟化** | wvmp_cli protect 输出 | ❌ **0% 真虚拟化** (3 marker × 2 imul = 6 条全跳) |
| multiseed 5×6 | scripts\multiseed_e2e.sh | 30/30 byte-exact (但有误导性) |
| snake 二次验证 | wvmp_cli protect snake | ⚠️ 部分进展 (imul 多条→1条, 还有 1 条 REG-MEM-IMM + 2 movsxd) |

### 3. 关键发现 — 项目主独立 fresh verify 输出

跑 `wvmp_cli protect --config imul.toml` 看完整输出 (本项目主独立验证):

```
[note] lifter: (marker@0x40b) @rva 0x4136: 未支持指令 'imul'，已跳过
[note] lifter: (marker@0x40b) @rva 0x4147: 未支持指令 'imul'，已跳过
[note] lifter: (marker@0x40b) @rva 0x4158: 未支持指令 'imul'，已跳过
[note] lifter: (marker@0x46b) @rva 0x4226: 未支持指令 'imul'，已跳过
[note] lifter: (marker@0x46b) @rva 0x4237: 未支持指令 'imul'，已跳过
[note] lifter: (marker@0x4d4) @rva 0x4313: 未支持指令 'imul'，已跳过
[note] virtualize: 函数 (marker@0x40b) 含不可翻译指令，跳过虚拟化（保持原生）
[note] virtualize: 函数 (marker@0x46b) 含不可翻译指令，跳过虚拟化（保持原生）
[note] virtualize: 函数 (marker@0x4d4) 含不可翻译指令，跳过虚拟化（保持原生）
[warning] virtualize: 没有任何函数被虚拟化
[warning] stub_link: 无已虚拟化函数，跳过 stub 生成
```

**3 个 marker 函数全部 C1 gate, 0% 真虚拟化**。与 verifier 报告完全一致。

### 4. 核心目标未达成根因 (与 verifier 一致)

`passes/lifter/src/x86_translate.cpp` `translate_imul` 三分支全要求 `operands[1] 是 REG`:

```cpp
if (x.op_count == 3 && x.operands[2].type == X86_OP_IMM &&
    x.operands[0].type == X86_OP_REG && x.operands[1].type == X86_OP_REG) { ... }
// 2-op reg 形式: imul dst, src
if (x.op_count == 2 && x.operands[0].type == X86_OP_REG &&
    x.operands[1].type == X86_OP_REG) { ... }
```

但 MSVC /Od 对 `int64_t a * b` (局部变量在栈) **实际产 REG-MEM / REG-MEM-IMM 形式**:

```
0x1028: imul    rax, qword ptr [rsp + 0x28]    ← 2-op REG-MEM 形式，Lifter 拒
0x1033: imul    rax, qword ptr [rsp + 0x30], 7 ← 3-op REG-MEM-IMM 形式，Lifter 拒
```

而新增的 6 个单测**全部 register-only** (派活单自己设计缺陷), MSVC 实际 codegen **从不产** register-only 形式。

### 5. 冻结契约头越权 (独立判定)

派活单 issue-13 明文:

> **不修改冻结契约头**: `common/`, `ir/`, `framework/`, `vm/include/wvmp/vm/backend.hpp`
> 允许: IR 加新 enum (新增 Op 值, 不改字段), VmOp 加新 enum, 新 asmgen handler

agent 实际改动:

```
git diff 1fb86fe~1 1fb86fe --name-only -- common/ ir/ framework/ vm/include/wvmp/vm/backend.hpp
→ 只改了 1 个文件: ir/include/wvmp/ir/insn.hpp
```

实际 `insn.hpp` diff:

```cpp
struct Insn {
    Op op = Op::Nop; Size size = Size::S32; Cond cond{};
    Operand dst, src;
+   // MIT-302: 第三个操作数。仅 imul 3-op imm 形式用 (src2 = Operand::imm_(imm32))。
+   // 默认空 Operand 不破坏既有指令的语义/布局——append 字段，sizeof(Insn) 增大，
+   // 但所有现存构造路径不读 src2，结果不变。
+   Operand src2;
    bool updates_flags = false;
    u64 addr = 0;
};
```

**判定**: 严格按派活单字面要求, **加 `src2` 字段是越权**。派活单明确说"加 enum, 不改字段"。

agent commit message 自辩 "additive, 向后兼容":
- sizeof(Insn) 增大 ✓ (技术事实)
- 所有构造路径不读 src2, 结果不变 ✓ (技术事实)
- 但**派活单的纪律是白名单许可制**, 不是"事后补赦免"

verifier 报告 §9 给的建议 ("不阻断, 但要项目主明示") 与项目主判定一致: **派活单纪律是白名单, 后续派活单需明示扩展**, 当前 MIT-305 commit **不应接受**。

### 6. mul 路径不稳定 (额外发现)

`MulSemantics` / `MulFuzzTenThousand` 走 `GTEST_SKIP`, agent 自述:

> build_mul 在某些 Rng 种子下 regs 写回偏移有微妙 bug; 非本 issue 处理范围

mul 路径留有未闭环 bug, 不影响 imul sample (mul_test 64×64→64 不受 bug 影响), 但留作后续 follow-up。

### 7. 派活单验收逐条回应

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-305 commit 存在 | ✅ | ✅ | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ rc=0, 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15, 23.89s | ✅ |
| 4 | E2E 13/13 byte-exact | ✅ | ✅ | ✅ (误导性, 见 5) |
| 5 | **E2E imul sample 真虚拟化** | ✅ | ❌ **0% 真虚拟化** | **❌ 阻断** |
| 6 | multiseed 5×6 = 30 PASS | ✅ | ⚠️ 30/30 byte-exact (误导, 不能区分真虚拟化 vs C1 gate) | ⚠️ |
| 7 | snake 不再因 imul 触发 C1 gate | ✅ | ⚠️ 部分进展 (多条→1条) | ⚠️ |
| 8 | 旧 sample 回归零退化 | ✅ | ✅ | ✅ |
| 9 | 冻结契约头不修改 | ✅ 严格 | ❌ `ir/insn.hpp` 加 `src2` 字段 | **❌ 阻断** |

### 8. 状态结论

**MIT-305 status**: 留 `in_review` (不 reject 也不 done), 派活单失败 + 冻结契约越权, **REJECT this commit**。

**后续行动**:
1. **新 sub-issue 立**: `.multica/issue-16-imul-mem-form.md` — `lifter imul MEM 形式支持 + 撤销 src2 字段`
2. **新 issue 派活单**: 不撤回当前 commit, 而是 **新增 commit** 修 imul MEM 形式 + 改派活单设计 (单测加 MEM 形式覆盖)
3. **派活单派活前**: 项目主先把 issue-16 写清楚 + 立 sub-issue, **不直接派单**
4. **multiseed_e2e.sh 改进**: 加 `--require-real-virtualization` 选项, 否则 C1 gate 兜底会一直被误判为成功

## 沉淀

### verifier 报告实战价值

- **独立 verifier 报告比项目主 fresh verify 更强**: verifier 找到 4 个隐藏问题 (1. 核心目标未达成, 2. 冻结契约越权, 3. 测试盲区, 4. multiseed 误导性), 项目主 fresh verify 单独跑只能确认 1 和 4
- **verifier agent 关键作用**: 客观独立判断, 不偏向 agent 自报, 比项目主自己更"无利益冲突"
- **今后流程固化**: 每个 WVmpCppDev 完成的 issue 都派 WVmpVerifier 独立 fresh verify (MIT-300/301 没派, 漏掉了冻结契约检查 — 下次记得)

### 派活单设计教训 (累积到第 4 次)

1. **派活单 §"MSVC /Od codegen 不可控"教训**:
   - MIT-300 snake: 类型转换触发 movsxd/imul
   - MIT-301 cl_shift: 类型扩展触发 movzx
   - MIT-305 imul: **局部变量触发 MEM 形式** (新一类)
   - **派活单必须显式列出 MSVC /Od 真实 codegen 形式**, 不要只写"指令 X 支持"
2. **单元测试盲区教训**:
   - 6 个单测 100% register-only, MSVC /Od 实际产 MEM 形式
   - **派活单必须强制测试样本反汇编验证 codegen 形式**, 或强制单测包含 codegen-typical 形式
3. **冻结契约头白名单教训**:
   - agent 用"additive 向后兼容"自辩, **派活单的纪律是白名单**, 不是补赦免
   - **未来派活单需要扩 `Operand src2` 等字段时, 应明确写"允许新增字段 X (包括 IR Op enum / Operand 字段 / VmOp 字段), 每次新增须明示**

### multiseed_e2e.sh 验证门问题

- 当前 `multiseed_e2e.sh` 只验 byte-exact stdout, **不能区分真虚拟化 vs C1 gate 兜底**
- 30/30 PASS 是误导 (imul sample 5/5 全 C1 gate 但 byte-exact 一致)
- **改进方案**: 加 `--require-real-virtualization` 选项, 脚本里 grep `[e2e] PASS（虚拟化后行为与原生一致）` 而不是只 `[e2e] PASS`

### Block B → Block C 转换教训

- Block B (C1~C4) 是完整闭环的 (MIT-243~249 + MIT-298/299), multiseed 15/15 真虚拟化
- Block C 阶段 1 (补指令) 反复派单失败 (MIT-300/301/305 都未真虚拟化), 反映 **Block B 期间测试样本的设计简单** (rol/whitelist 都是 imm-only 单 ops, MSVC codegen 不会触发出问题)
- **Block C 派活单设计要求**: 必须包含反汇编验证步骤 (派活单设计者自己跑 disasm 看 MSVC codegen)
- **派活单验收门要求**: 加字节比对 (fc /b PE header + .text 段差异), 不只 stdout