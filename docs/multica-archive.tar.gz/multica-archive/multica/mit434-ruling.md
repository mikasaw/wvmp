# MIT-434 (G8a BMI 折条款目) 裁定 — ACCEPT，240/240，三陷阱全拆+asmgen 零 diff，命名分支铁律九连满分（含 attempt-1 平台弃单重触发史）

> 裁定人: 项目主 — 2026-08-31 15:4x | 处置: ff-merge main=`df3c2f1`, done
> 复验 worktree: ../wvmp-434-verify @df3c2f1 | 注: attempt-1（01a05658）= 平台工具集缺失弃单（2 分钟零污染），status+rerun 处置后 attempt-2（01a05660）95 分钟正常交付——本裁定针对 attempt-2

## 1. 独立复验（全部亲测非采信自报）
| 项 | 自报 | 实测 (@df3c2f1) |
|---|---|---|
| build / ctest / **multiseed** | 240/240 | ✅ rc=0 / 16/16 / **TOTAL: 240 pass / 0 fail**（48 样本×5）|
| BMI 主样本 | 16 stub + 7 gate | ✅ 亲跑: **stub=16**、gate notes 恰 7 条（mulx/pdep/pext/blsr/**bextr/blsi/blsmsk**——后三条超出派单负例清单，agent 按 432 §6.4 裁语料族全钉）、native/packed stdout **逐行 identical**、bzhi_bnd=`12345678 c=1` 原值+CF=1 **印证边界推翻已落地** |
| wvmpTest 零回踩 | 14/14 | ✅ stubs=14 + jump-table@0xDD84 + ExitNative 17 + **diff 0** 103/103 |
| P1 面原样 | 5/5 | ✅ 亲测 flags_rol 在 434 分支 packed byte-exact（ror_zdiv=0 全对）|
| **asmgen 零 diff** | "逐字节零触碰" | ✅ `git diff cdc218d..df3c2f1 -- asmgen vm_op 层 = 0 行`——**强于 433 的"新增函数不改旧"**，本单连新增函数都不需要（D1(i) 变体=translator 层 GetFlags/SetFlags 包裹，G3 微程序先例）；dump 门 handler 集合恒等=机器证明成立 |
| 陷阱② 载体对账（一票否决项）| src2 存在性判据 | ✅ 直读: `kFlagless=22` 域注+op 限定+`BmiNativeRorImmNotIntercepted`（lifter:3152）/`BmiPlainAndSubUnaffectedByCarrierKind`（translator:1639）**双回归钉在位**——"ror eax,24 结构不误拦"成立（原生 shift count 走 src 槽 src2 恒 None，**存在性判据绕开值域碰撞=漂亮解法，432 蓝图的 src2 值域方案被我预判带偏但 agent 未照抄**）|
| 冻结面 | 零触 | ✅ runtime.hpp/ir::Op/backend/callgate/载体域 0..21 零重排；kVmOpMax=97（D1(i) 对应预算）|
| 硬条款 | 47 分钟 | ✅ 命名分支+main 未动+零脏+切回+ff-safe——**九连满分**（时间戳对账 14:36:54→15:23:58=**47.1 分钟** 与自报吻合，项目主复算；run 平台窗口 13:52→15:27 含平台调度段）|

## 2. #33 三处实测修正（合格，采纳）
① **bzhi 边界（index≥N）推翻 432 §2.1 预判**：真值=value 原值不变+CF=1（非"结果 0/CF=0"）——折条升级为 mask-clamp+Cmovcc+CF 补丁 16-op 微程序，**值+五位 flags 含边界全对齐**（Zen5 probe 三路互证）；② **操作数 mem-ability 反转**：andn 的 r/m 在第三操作数（AND 项）、shlx 族在第二（value 项）——SDM 记法直读会得相反结论，ml64 逐形双验为准（**§B.4 cnt-in-reg 新形态通路全链实测**）；③ index 用 SRC2[7:0]（0x105→5）Movzx 钉入。

## 3. 登记（非阻断）
- 中段 flags 短暂覆写（GetFlags/SetFlags 包裹窗内 ctx+0x98 瞬变）——无观测者论证同 432 §F.3，G8b 若换 (ii) 方案自然消除；
- flagless 字节码 +2 word/dispatch——rorx 高频面性能账在 G8b 拍板时一并复议；
- And/Sub src2≠None 判据的生产者唯一性靠 lifter 分支约束（无值域可核）——域注双侧警示+回归钉已是最强可行防线。

## 4. 裁定与排程
ACCEPT，ff-merge main=`df3c2f1`，基线 **48 样本 × 5 = 240/240**。选A 队列推进: 433 P1 ✓ → **434 G8a ✓** → **收官文档波**（GAPS/STATUS: 三族分层 gate 定稿 + G8b/blsr 残余 + §5 五条联动 + lqdq/hqdq 顺路项与 kVmOpMax 行刷新，单张 S-M 收口单）→ **指令虚拟化阶段收官** → 重启 410 (M3)。
