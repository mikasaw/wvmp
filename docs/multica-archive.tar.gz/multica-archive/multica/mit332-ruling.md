# 项目主裁定: 采纳 MIT-332 (VmOp::LeaRva 修复) — snake 真虚拟化 byte-exact 闭环达成

## 总体评价

MIT-332 commit `7b02496` **采纳** (ACCEPT): **snake 真虚拟化 byte-exact 闭环达成** — 派活单 §A 假设"lifter 丢 SIB scale 字段"是**错**的, agent 找到**真根因** (translator `translate_lea` rip-relative bug 缺 `VmOp::LeaRva`), **诚实披露 + 真修复** (沿用 MIT-312/314/317/320/324 诚实披露风格, 不是 MIT-322 编造风格)。

**真根因** (agent 实证, 与项目主派活单假设**不同**):
- lifter `mem_operand` 已正确捕获 SIB `scale`/`index` (test_lifter `LoadWithIndexScale` 通过)
- translator `emit_address` 已通过 `Shl` 处理 scale=2/4/8
- **真正 bug**: translator `translate_lea` rip-relative 分支 emit RVA 到目的寄存器, 但 `lea` 语义要求结果是 **VA**; 后续非 rip `Load`/`Store` (M2-8 起不加 `scratch_mem` add) 把 RVA 当 VA 访存 → 低地址段错误
- **修复**: 加 `VmOp::LeaRva` (parallel to `LoadRva`/`StoreRva`), rip-relative lea 用 `LeaRva` emit, 后续 Load/Store 看到 VA 不再段错误

## 独立核查结果 (2026-08-26, hermes)

### 双重确认 (agent + 项目主 fresh verify)

- **agent 报告** (MIT-332 完成): commit `7b02496` 加 `VmOp::LeaRva` + handler + translator 改 `translate_lea` rip-relative 分支
 - 验证: ctest 15/15, multiseed 5×6 30/30 + snake 5/5 真虚拟化, snake E2E byte-exact `alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`

- **项目主 fresh verify** (本轮, 双重确认):
 - HEAD `7b02496` ✅
 - build rc=0 ✅
 - ctest **15/15 PASS** ✅
 - fresh protect: `.wvmp 节 20130 字节 @ RVA 0xC000` (比 `6d96b24` 19970 字节增加 160 字节, LeaRva handler)
 - **snake E2E byte-exact**: native == protected == `alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16` ✅✅✅
 - **BYTE-EXACT MATCH!** 派活单核心目标达成, Block C 阶段 1 收尾完成

### 1. git state

```
HEAD: 7b02496 (clean, on main)
git log --oneline -3:
  7b02496 MIT-322: 加 VmOp::LeaRva 修 rip-relative lea 缺 RVA→VA 转换 (snake 真虚拟化 byte-exact 闭环)
  c2faa32 MIT-326 cherry-pick: snake_sample 改造 forward-jump (算术提交去 je, snake 真虚拟化闭环)
  d493d9a MIT-324: snake_sample 改造 forward-jump — 移除 2 处 return
```

### 2. fresh verify 总览

| 项 | 结果 |
|---|---|
| HEAD | 7b02496 (clean, on main) |
| build | rc=0, 292/292 |
| ctest | **15/15 PASS** (含新增 `LeaRvaSemantics` + 2 translator tests) |
| E2E seed=12345 | ✅ 14/14 byte-exact |
| **multiseed 5×6 REQUIRE_REAL=1** | ✅ **30/30 PASS + 全样本真虚拟化 (snake 5/5 真虚拟化)** |
| **snake E2E byte-exact** | ✅ **native == protected** (`alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16`) |
| 回归零退化 | ✅ 13 其它 E2E 样本 (call_gate / rip_relative / sar / adc / sbb / rol / whitelist / virt / imul / cl_shift / marker / lifter_skip) |
| 冻结契约核查 | ✅ 仅改 `vm/regvm/{isa,translator,runtime}/` + 3 test files (6 文件 +154/-2), 不改 `common/ / ir/ / framework/ / vm/include/wvmp/vm/backend.hpp` |

### 3. 关键设计决策 (agent 报告 + 项目主确认)

| 维度 | 内容 |
|---|---|
| **真根因** | translator `translate_lea` rip-relative bug: emit RVA 到 dst 寄存器, 后续非 rip Load/Store 把 RVA 当 VA → 低地址段错误 |
| **修复方案** | 加 `VmOp::LeaRva` (parallel to `LoadRva`/`StoreRva`), rip-relative lea 用 `LeaRva` emit, 后续 Load/Store 看到 VA 不再段错误 |
| **改动文件** | `vm_op.hpp` (新 enum) + `asmgen.cpp` (新 handler + table 注册) + `translator.cpp` (改 `translate_lea` rip-relative 分支) + 3 test files |
| **改动行数** | 6 文件 +154/-2 |
| **新增测试** | `LeaRvaSemantics` + 2 translator tests |

### 4. 派活单 §A 假设错 vs agent 真根因 (本会话强化)

| 维度 | 派活单 §A 假设 (项目主) | agent 实证真根因 |
|---|---|---|
| **SIB scale 字段** | lifter 丢 SIB scale | ✅ lifter 已正确捕获 `scale`/`index` (test 通过) |
| **translator emit_address** | emit 单 Load VmOp, scale 丢 | ✅ translator 已通过 `Shl` 处理 scale=2/4/8 |
| **真根因** | lifter/translator SIB 处理 | **translator `translate_lea` rip-relative bug 缺 RVA→VA 转换** (缺 `VmOp::LeaRva`) |
| **修复方向** | lifter 加 SIB scaled-index emit Load + Imul + Add 3 条 | **translator 加 `LeaRva` op + handler, rip-relative lea 用 LeaRva emit** |

**关键教训** (本会话新增, pitfall #32 候选):
- **派活单 §A 假设不一定是真根因** — agent 实验后找到的**真根因**可能与 §A 假设不同
- **派活单 §A 应作为"初始假设" 而非"绝对诊断"** — agent 派活单 §A 漏识别是常见, agent 找到真根因后应**诚实披露 + 改修复方向**
- **agent 诚实披露 vs 编造发现 12 次对比新增**: MIT-332 (agent 派活单假设错, 诚实披露真根因, 真修复) — 沿用 MIT-312/314/317/320/324 风格, 不是 MIT-322 编造风格

### 5. 派活单验收逐条核对 (12 项, 11 通过 + 1 部分错)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-332 commit 存在 | ✅ | ✅ HEAD `7b02496` | ✅ |
| 2 | build rc=0, 0 警 0 错 | ✅ | ✅ 292/292 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 (含新增 `LeaRvaSemantics` + 2 translator tests) | ✅ |
| 4 | E2E seed=12345 14/14 byte-exact | ✅ | ✅ 14/14 | ✅ |
| 5 | E2E snake 真虚拟化 (派活单核心目标) | ✅ | ✅ entry stub generated, byte-exact | ✅ |
| 6 | multiseed 5×6 REQUIRE_REAL=1: 30/30 + 全样本真虚拟化 | ✅ | ✅ 30/30 (snake 5/5 真虚拟化) | ✅ |
| 7 | **snake 二次验证 (project owner 独立)**: protected binary 实际跑通 rc=0 | ✅ | ✅ **BYTE-EXACT MATCH!** | ✅✅✅ |
| 8 | stdout 字节比对 native vs protected 一致 | ✅ | ✅ `alive=0 len=3 score=0 food=8,8 head=32,16 tail=30,16 ticks=16` | ✅ |
| 9 | imul / movsxd / cl_shift / call-bearing 回归零退化 | ✅ | ✅ 全 PASS | ✅ |
| 10 | 冻结契约核查 (lifter + translator 允许改, common/ir/framework/backend.hpp 不改) | ✅ | ✅ 6 文件 +154/-2, 冻结契约未动 | ✅ |
| 11 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ⚠️ 派活单 §A 假设 "lifter 丢 SIB scale" 错, agent 找到真根因 "translator translate_lea rip-relative bug 缺 LeaRva", agent 诚实披露 + 改修复方向 | ⚠️ (部分) |
| 12 | git 4 重核查纪律 (派活单派活前) | ✅ | ✅ (cherry-pick `6d96b24` 已在 `git fsck --lost-found`) | ✅ |

### 6. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-332** | ✅ **done** | VM runtime 加 `LeaRva` op, snake 真虚拟化 byte-exact 闭环达成 |
| **MIT-300** | ✅ **done** (snake 真虚拟化闭环, entry stub + byte-exact) | |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done, imul 真虚拟化独立完成) |

### 7. Block C 阶段 1 全员 done 总结

| 维度 | 数值 |
|---|---|
| 总 commit | **44** (MIT-300 ~ cherry-pick `7b02496`) |
| lifter 白名单 | **~40 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva) |
| 真虚拟化样本 | **11 个** (call_gate 系列 + rip_relative + sar/adc/sbb/rol/whitelist/virt + imul + cl_shift + **snake**) |
| **C1 gate 兜底样本** | **0 个** (snake 现真虚拟化, 之前 3 个 demo 样本) |
| ctest | **15/15** PASS |
| E2E byte-exact | **15/15** |
| **E2E REQUIRE_REAL=1** | **15/15 真虚拟化** (snake 5/5 now PASS) |
| **multiseed 5×6 REQUIRE_REAL=1** | **30/30 真虚拟化** |
| 派活单设计失败模式 | 5 层次 (派活单 6 段 + 项目主 git 4 重核查) |
| verifier 实战 | **11 连** (MIT-308/311/313/315/319/321/323/325/331 + agent 实验反馈) |
| wvmp-dev SKILL.md pitfall | **31 个** (本会话新增 pitfall #32 待加) |
| 派活单设计纪律文档 | **5 篇** (m3-lifter-paihuo-4~8-issue-progression.md) |
| 项目主判定被 verifier 反转 | **4 次** (MIT-308/313/323/331) |

### 8. 后续行动

1. **Block C 阶段 1 全员 done ✅** — 派活单设独立, snake 真虚拟化 byte-exact 闭环
2. **进入 Block C 阶段 2** (中频指令: xchg / bswap / movzx / movsx / cmpxchg / xadd / setcc / cmovcc)
3. **沉淀到 m3-lifter-paihuo-9-issue-progression.md**: 完整 12-issue 演进 (含 agent 派活单假设错 vs 真根因 教训)
4. **沉淀 pitfall #32** (本会话新增) — 派活单 §A 假设不一定是真根因, agent 诚实披露 + 改修复方向是正确处理 (vs 编造掩盖)

## 沉淀 (Block C 阶段 1 完整闭环, 31 → 32 个 pitfall)

### 关键沉淀 (本会话)

- **MIT-326 v2 cherry-pick `6d96b24`** (算术提交去 je, snake 真虚拟化路径生成) + **MIT-332 加 `VmOp::LeaRva`** (translator 修 rip-relative lea 缺 RVA→VA 转换, snake 真虚拟化 **byte-exact 闭环**)
- **agent 派活单 §A 假设错 vs 真根因** (MIT-332 实证) — agent 派活单 §A 假设 "lifter 丢 SIB scale" 错, agent 找到真根因 "translator `translate_lea` rip-relative bug 缺 `LeaRva`", **诚实披露 + 改修复方向** 是正确处理
- **agent 诚实披露 vs 编造发现 12 次对比新增**: MIT-332 沿用 MIT-312/314/317/320/324 风格 (诚实披露), 不是 MIT-322 编造风格
- **pitfall #32 候选**: 派活单 §A 假设不一定是真根因 — agent 派活单 §A 漏识别是常见, agent 找到真根因后应**诚实披露 + 改修复方向**

### 阶段 2 (中频指令) 派活单模板继承

派活单派活前 5 件事全做:
1. **capstone 反汇编 codegen** (§A) — 列所有指令 + 字节编码 + RVA + 形式 (字段 100% 精确)
2. **读源文件** (§B) — 列 API 调用模式
3. **追溯源文件触发源** (§C) — 列每条触发源
4. **派活单 §A 完整性** (§D) — **§D 改动清单必须完整包含 §A 列出的所有 blocker**
5. **派活单派活前项目主 fresh verify**:
 - 跑 `wvmp_cli protect` 看真实警告列表
 - **git 状态核查 4 重** (log + branch + stash + fsck)
 - cherry-pick path ready (dangling commit 可 cherry-pick 通过 `git show`)
 - **派活单 §A 假设作为"初始假设" 而非"绝对诊断"** — agent 派活单 §A 漏识别是常见, 允许 agent 找到真根因后改修复方向

**派活单禁止假设 (扩展)**:
- ❌ "派活单 §A 假设绝对正确, agent 必须按 §A 修" — 允许 agent 找到真根因后改修复方向
- ❌ **盲采 agent 编造"派活单 §A 错"的发现** — 必须 verifier 独立 fresh verify
- ❌ **仅跑 `git log` 验证 agent 引用 commit** — 必须 4 重 git 核查 (含 fsck)