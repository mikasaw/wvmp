# MIT-G5r triage 报告 — x87 FPU 支持侦察：形态枚举 + 真实世界频率实测 + ST 模型成本 + 路线裁决

- verifier: WVmpVerifier (裁定型 / 纯侦察, 零产品代码改动, 未采纳任何开发侧结论——本单无开发参与)
- 静态基线: main `92928e0` (MIT-413, 2026-08-29 22:09); CLI = `build/cli/wvmp_cli.exe` (mtime 22:45 > HEAD, 新鲜 main 产物)
- 实验环境: `%TEMP%\mit416_x87\` (26 个真实二进制扫描 + 30 个探针/E2E 产物 + 1 个 MASM x87 模块 + 1 个 MASM 标记模块), **主仓零写入、零 git 操作**
- 采集时间: 2026-08-29 22:49–23:45 (+0800), 全部数字来自实测输出粘贴
- 结论置信度: **高** (编译器实测 + capstone 线性扫描 + dumpbin 点检 4/4 + E2E 双样本复现 + callgate 源码直读, 五路互证)
- ⚠️ **并发状态披露**: 主工作区 22:49 在 main 干净状态 (仅 .hermes 未跟踪文件); 本侦察全程零 git 操作 (MIT-415/G3 并发期不扰动, 412 例外注记纪律); 交付物 `.multica/mit-G5r-triage.md` 为 gitignored drop, 不触碰任何 tracked 文件
- run 对账: 22:48:26 (started_at) → 23:45 (本报告成稿), 实测约 57 分钟 ≥ 30 分钟红线

## §0 结论 (裁定)

**B.1 四组真实世界频率实测完毕 (数字支撑 §2):**

| 编译器/生态 | 样本 | x87 密度 (指令占比) | 结论 |
|---|---|---|---|
| MSVC x64 (本机唯一编译器 + System32 + python + 本仓) | 8 个真实二进制 + 7 个探针 | **≈ 0** (0.0000–0.0032%, 全部为线性解码数据伪影) | x64 世界 x87 事实灭绝 |
| MSVC x86 **默认** (/arch:SSE2 实测默认) | 9 个探针 | **≈ 0** (仅 CRT 残余 fld/fstp/fnclex 3–4 条/二进制) | v145 x86 默认不产 x87 |
| MSVC x86 **显式 /arch:IA32** (旗标实测存在, cl /help 原文 "用 x87 进行浮点") | 6 个探针 | **2.17%–11.45%** (fp32 最重) | x87 只在这个旗标下涌出 |
| **SysWOW64 (真实 32 位世界, MSVC x86 各年代)** | 7 个 OS 组件 | **0.013%–0.879%** (msvcrt 0.879% 全超越族) | 32 位 OS 运行时仍真用 x87 |
| **mingw x64 (Git for Windows 实测)** | 10 个二进制 | **0.0006%–2.12%** (msys-2.0.dll 1.02% = 4986 条全族) | mingw x64 long double = x87 实锤 |
| 手写 asm (MASM x64 实测可编译可执行) | 2 个探针 | 单函数 0.64% (8 条) | x64 上唯一合法 x87 入口 |

**项目主 §A 先验逐条裁定 (修正 2 条):**
1. "long double: MSVC=double 不产" — **✅ 成立** (x64_fp80.exe = 0 条; x86 同)
2. "volatile float 某些 /O1 路径产 x87" — **❌ 推翻** (volatile_fp 在 /O1 /O2 /arch:IA32 全矩阵 = 0–2.2%, 无 volatile 特有 x87 涌出; 那条 fnclex 是 CRT 启动残余)
3. "32 位目标 x86 主战场, 浮点几乎必走 x87" — **⚠️ 修正**: v145 x86 **默认 /arch:SSE2** (cl /help 原文), 显式 /arch:IA32 才涌出 x87 (2.2–11.4%); 真实 32 位世界 x87 集中在 **OS 运行时/CRT** (msvcrt.dll 0.879% 全超越族 / ntdll 0.22% / user32 0.09% 含 fbld/fbstp/fcmov/fsincos), 应用代码本身很低 (iexplore.exe 0.035%, VMware autostart-helper 0.045%)
4. "clang-cl/mingw x64 产 80-bit x87" — **✅ 成立** (本机无 mingw 编译器, 用 Git for Windows 真实 mingw 产物实测: msys-2.0.dll 4986 条 = 1.02%, 含 tbyte 访存 + fyl2x/fyl2xp1 全对数族)

**当前行为链 (E2E 实测):** x87 指令在标记区域内 → lifter 报 "未支持指令 'fld' 已跳过" → C1 gate → 整函数保持原生 → 输出 byte-identical。**现状已是"半 R3"**——x87 出现在 x64 输入时保护壳自动退回原生, 不产坏壳。

**新发现 P0 (非 x87 专属, 当前 SSE 世界即中招):** **VM CallGate 不传浮点参数/返回值** — 标记区域内对带 double/float 参数的 native 调用 (含纯 SSE 实现), 虚拟化后**静默错乱** (实测: 13 → 4.5, rc 5→2; 7.9155 → 4.5, rc 0→2)。根因: asmgen.cpp:1189-1265 callgate 只搬 RCX/RDX/R8/R9 + 只回写 RAX, **不碰 xmm0..3** (Win64 FP 参数/返回值槽)。GAPS C3 节未记录 (该节仍是 pre-M2-9 "翻译器直接 skip" 旧文)。**对 x87 的意义**: 即使补了 x87 handler, 区域内调 CRT 数学函数 (sin/cos——x86 IA32 编译器产物的超越函数入口) 仍会经此通路错乱 → **这是 x87 任何路线的前置依赖**。

**路线裁决: R3 文档化立即 + callgate FP 修复独立 P0 + R2 随 G7 捆绑评估; R1 不排波** (数字支撑 §5)。L0 骨架 (ST 槽模型) 仅作设计预研, 不立项。

## §1 B.1 形态枚举 (8 组, 真实出现频率 = 实测样本中命中密度, 非理论全集)

| # | 家族 | 指令 | 真实世界频率 (实测样本命中) | 证据 |
|---|---|---|---|---|
| 1 | 数据传输 | fld/fst/fstp/fild/fist/fistp/fbld/fbstp/fld1/fldz/fldpi/fldl2e/fldl2t/fldlg2/fldln2 | **高** (任何含 x87 的样本必有) | msvcrt 1088 条 / ntdll 435 / shell32 548 / msys 3564; kernel32 仅 fld/fstp/fbstp 21 条 |
| 2 | 算术 | fadd/fsub/fmul/fdiv(±r,±p)/fi*/fabs/fchs/fsqrt/frndint/fprem/fprem1/fscale/fxtract | **高** | msvcrt 884 / ntdll 367 / shell32 742 / user32 173; **fsqrt/fprem1/fscale 集中** (msvcrt fsin 归约循环点检实证) |
| 3 | 超越 | fsin/fcos/fsincos/fptan/fpatan/f2xm1/fyl2x/fyl2xp1 | **中** (仅 CRT/运行时实现, 编译器不直产) | msvcrt 20 (fsin/fcos/fptan/fpatan/f2xm1/fyl2x 全) / ntdll 16 / msys 34 (含 fyl2xp1) / user32 fsincos 1 / shell32 fsincos 1; **MSVC 探针 (含 /arch:IA32) 零直产** — 全部走 CRT call |
| 4 | 比较 | fcom/fcomp/fcompp/fucom*/fcomi/fcomip/fucomi/fucomip/ftst/fxam | **中** | msvcrt 107 / ntdll 69 (含 fcomi) / shell32 112 / user32 22 (含 fucomi) / msys 408 (fcomi/fucompp/fxam) |
| 5 | 条件移动 | fcmovb/be/e/nb/nbe/ne/nu/u (8) | **低–中** (仅老 CRT/运行时) | msvcrt 59 / ntdll 16 / user32 6 / gdi32 1 / msys 25; 探针与微软应用代码零命中 |
| 6 | 状态控制 | fldcw/fnstcw/fnstsw/fstsw/fclex/fnclex/finit/fninit/fldenv/fnstenv/fnsave/frstor/fnop | **中** (含"上下文保存"成对形态) | msvcrt 380 / ntdll 129 / shell32 136 / msys 213; **fldcw 0x27F 降精度实锤** (msvcrt fsin 前, 点检) |
| 7 | 常数加载 | fld1/fldz/fldpi/fldl2e/fldl2t/fldlg2/fldln2 | **中** | msvcrt/ntdll/shell32/msys/ole32 全命中; 探针 IA32 产物 fld1/fldz 高频 (编译器直产) |
| 8 | 杂项/栈管理 | ffree/fincstp/fdecstp/fxch/fnop | **低–中** (fxch 高频, ffree 低) | fxch: msvcrt/ntdll/msys 密集 (栈操作语义); ffree: user32/msvcrt/ntdll/shell32 各 1–4 |

**反例逐条**: ① BCD (fbld/fbstp) 不是理论形态 — kernel32/user32/gdi32/msvcrt/ntdll/shell32/ole32 真实命中 (ntdll RtlFloatToBcd 系); ② fcmov 仅出现在 CRT/运行时, 探针 (新编译器) 零命中 — 新代码不会产; ③ fsin 等超越在 **用户代码** 零直产 (MSVC/GCC 都 call CRT), 只在 CRT 实现里出现 — 对 handler 面意味着"被保护方代码几乎不会直接含超越指令"。

## §2 B.1 频率实测 (样本集 + 统计方法 + 反例)

**样本集 (26 个真实二进制, 全部本机文件):**
- MSVC x64: System32 cmd/notepad/conhost, python314.dll, 本仓 wvmp_cli.exe + wvmp_adc_sample.exe
- MSVC x86 各年代 (SysWOW64): kernel32/user32/gdi32/msvcrt/ntdll/shell32/ole32
- mingw x64 (Git for Windows): msys-2.0.dll/bash/perl/msys-crypto/msys-expat/msys-gcc_s/libcurl/libssl/libcrypto/zlib
- 32 位第三方: iexplore.exe (IE11), VMware autostart-helper.exe
- 探针矩阵: 6 个源 (fp64/fp32/fp80/stddev/volatile_fp/ctrlfp) × {x64 /O2, x86 默认 /O2, x86 /arch:IA32, x86 /arch:SSE2, /O1} + x87asm (手写) + MASM x64 模块 ×2

**统计方法**: pefile 取可执行节 → capstone 线性反汇编 (CS_MODE_32/64) → 全 mnemonic 精确匹配 8 家族集合 → 每二进制输出 x87/总指令。**披露**: 线性解码会把合并进 .text 的数据表解码成伪影指令 — 本报告用 dumpbin 对伪影样本点检 **4/4 命中数据形态** (wvmp_cli.exe 的 206 条 fprem1/fldenv/fadd/fldcw 全部为 `D9 24 00`/`DC 05 00 B3` 类重复表字节); 相反 msvcrt/ntdll/msys 的命中**点检 2/2 为真实代码** (msvcrt fsin: fnstcw→fldcw 0x27F→fsin→fnstsw/sahf→fprem1 归约循环完整函数; msys fyl2x: fldln2/fxch/fyl2x/fstp tbyte 完整对数实现)。伪影与真实代码可区分, 报告数字对 x64 侧略偏大 (真实 ≈ 0)。

**30 分钟以上红线**: 实测 57 分钟 (22:48:26→23:45), 与 run 对账无出入。

## §3 B.2 架构适配成本 (不实施, 量化)

**ST(0..7) 栈模型 → 槽模型**: VmContext 现为 `regs[32]` + `xmm[8]@0x140` + kCtxSize 派生式 (0x1C8, runtime.hpp:103)。x87 需要 8 个 80-bit 栈槽 + TOP 指针 + 空满/栈溢出标志。方案空间:
- **(a) 8×16B 槽区 (同 xmm[8] 模式)**: kCtxSize 0x1C8→0x248 (+0x80), 80-bit 装 10B + 6B pad; handler 用 movups 同构通路 — **推荐**, 与 MIT-371 xmm 槽完全同构, stub/asmgen 的 kCtxSize 派生链自动跟随 (MIT-B2 纪律已铺路)
- (b) 借 regs[32] GP 双槽 (16B 覆盖 vN+vN+1, XmmLoad 先例): 省 kCtxSize 但把 ST 语义混进 GP 池, 与 XmmLoad 双语义寻址 (reg<24 vs ≥24) 冲突面大, 不推荐
- 核心难点不是槽位大小而是**栈拓扑**: ST 是"TOP 指针 + 环绕 8 槽"的硬件栈 (fld push / fstp pop / fxch 交换 / 栈溢出置 C1+SF), 不是随机访问寄存器文件 — handler 需维护 TOP (可放 regs[18] 类 scratch 或专用槽), 每条指令做空/满检查。**量化: 新 VmOp 约 60-80 个 (全族), 每个 handler 平均比 SSE 同类多 ~6 条汇编 (TOP 检查 + 槽寻址)**。

**80-bit extended**: 内存态 = 10B tbyte (15 位指数 + 64 位尾数 + 1 位符号); 寄存器态 = 双 u64 槽 (C2-Sar/Adc 128 位双寄存器先例直接复用, 10B 用 16B 槽装余 6B pad)。**RNDMODE/PC 分叉**: x87 结果由控制字 PC (24/53/64 位精度) + RC (舍入) 决定, 与 SSE 同表达式结果**可能不同** (双舍入) — 语义等价性两条路: (i) **native 直执行** — 当代 x86 硬件 x87 微码全实现 (实测 x64 MASM fsqrt/fmul 序列正确执行 hypot=5), handler 直接执行原指令, 结果天然逐位保真, **无需软件仿真数学** — 这是 x87 相对 SSE 的最大红利 (SSE 是寄存器-寄存器, x87 是栈机, 但执行仍是单条原生指令); (ii) 软件仿真 — 80-bit 算术库, 工作量爆炸, 不推荐。**结论: handler 全部走 native 直执行, 成本集中在栈模型/访存/flags/控制字, 数学零成本**。

**flags 通路**: VM flags 槽 5 位 (ZF=bit0, CF=bit1, OF=bit2, SF=bit3, PF=bit4, vm_reg.hpp:23-27)。x87 条件码 C3/C2/C0 与 ZF/PF/CF **直接同构** (fcomi 直置 ZF=C3, PF=C2, CF=C0; fstsw/sahf 传统通路同构) → 翻译通路现成, 复用 setcc5 同类机制即可。**无槽位**: C1 (栈上下溢 + 舍入方向) 与 ES/SF (异常/栈错) 需 ST 槽区侧存 (如 ST 槽 + 1 个 16-bit status/control word 槽)。OF/SF 位 x87 不触及, 天然兼容。

**超越函数 handler 可行性**: 每条 = 单条原生指令 (fsin 等, 硬件微码), **native 直执行可行且推荐** (CPU 支持实测; 参数归约 fprem1 循环在 msvcrt 是软件侧 CRT 逻辑, 在硬件 fsin 是微码内建 — 两者都无需 VM 实现数学)。真正的工作: 栈操作 + 槽寻址 + (fstsw 形态的) flags 抽取。

**控制字/环境状态**: 真实代码**会动** x87 控制字 (msvcrt fsin 前 fldcw 0x27F 降精度, 点检实证) → VM 需维护 16-bit CW + 16-bit SW 状态槽 (fldcw/fnstcw/fnclex/finit 必须实现, 不能只做数据传输/算术); 注意 **v145 MSVC 的 _controlfp 走 MXCSR 不走 fldcw** (实测 stmxcsr), 但老 CRT/手写代码动 CW 是真实存在。**fldenv/fnsave/frstor (上下文保存, ntdll/msvcrt 命中) 是重量级形态, 建议 L3 或 gate**。

**callgate 前置**: 见 §6 — 浮点参数/返回值通路缺失, 任何路线先修。

## §4 B.3 工作量分级 + 拆单蓝图 (L0→L4, 每级前置依赖 + SSE 复用点)

| 级 | 内容 | 前置 | SSE 复用点 | 量级 |
|---|---|---|---|---|
| **L0 最小闭合** (能跑老代码基础算术) | ST 栈模型 (8×16B + TOP + 空满) + fld/fstp/fild/fistp (m32/64/80 宽度链) + fadd/fsub/fmul/fdiv/fabs/fchs/fsqrt + fld1/fldz + fldcw/fnstcw (CW 槽) + fstsw/fnstsw + fcomi/fcomip (flags 通路) + x87 寄存器状态 stub 出口同步 | **P0: callgate FP 参数修复 (§6)**; ST 槽区落 VmContext (kCtxSize 0x248) | marker_scan 注册模式 (sse_*_sample 影子样本先例); asmgen handler 模板 (XmmLoad 双语义寻址同构 → ST 槽寻址); width chain (4/8/16 → 加 10B tbyte 链) | **XL** (栈模型基建 + ~30 handler) |
| **L1 比较/条件** | fcom/fcomp/fcompp/fucom*/ftst/fxam + fcmovcc 8 条 + fstsw/sahf 通路 | L0 | flags 槽机制现成 (C3/C2/C0 ↔ ZF/PF/CF 直映) | M |
| **L2 超越族** | fsin/fcos/fsincos/fptan/fpatan/f2xm1/fyl2x/fyl2xp1/fprem/fprem1/fscale/fxtract/frndint — 全 native 直执行 | L0 (栈+访存就够) | 无 (原生单条指令) | **S/M** (每条 handler 只是栈形态编码, 无数学) |
| **L3 状态/上下文** | finit/fninit/fclex/fnclex/fldenv/fnstenv/fnsave/frstor/fnop/free/fincstp/fdecstp + 异常状态位 (ES/PE/UE/OE/ZE/DE) + CW/SW 全语义 | L0 | — | M |
| **L4 全族补齐** | fbld/fbstp (BCD, ntdll/user32 真实命中), 常数加载全 7 条, fldpi 等 | L0 | — | S |

**依赖链**: P0 (callgate FP) → L0 (ST 基建) → {L1 ∥ L2 ∥ L3} → L4。**L0 为唯一 XL 且无并行替代, 排期锚点**。全族估 ~80 新 VmOp — 注意跳表 128 项已有 80 用 (kVmOpMax+1=80, asmgen static_assert), **x87 全族会把跳表撑爆** → 需跳表扩容 128→256 (改 kTableEntries, 一处) 或分族复用编码 — 这是拆单蓝图必须预埋的基建改动。

## §5 B.4 路线建议 (数字支撑 + 每路第一张前置单草案)

**裁决输入汇总**: x64 世界 x87 ≈ 0 (MSVC 灭绝 + 手写 asm 是唯一入口); mingw 世界 0.01–2.1% 且集中在 msys runtime/CRT 类库 (被保护方产品代码几乎不直接含 x87); 32 位世界 0.01–0.88% 且集中在 OS 运行时。

- **(R3) 永久 gate + 文档化 — 推荐立即执行 (S 级, 1 单)**: 实测现状已是"半 R3" (C1 gate 自动保持原生, byte-identical); 缺口 = 文档面。前置单草案 `MIT-G5r-R3`: ① GAPS Block A "不支持面" 扩 x87 明确声明 (现仅 GAPS.md:132 一行 "AVX/x87/SSE2 整数族") → 补全 "x87 全族 (D8-DF): C1 gate 保持原生, 无虚拟化" + 频率数据摘要; ② STATUS.md 同步; ③ multiseed 加 1 个 x87 样本 (MASM 模块, 本 triage 已验证形态) 钉住"gate 后行为一致"回归 (REQUIRE_REAL 无 stub 断言兼容 — 该样本预期 0 stub + byte-identical)。**若选此路, 第一张前置单 = 上述 1 单 (S, ~0.5 天)**。
- **(R2) 32 位目标捆绑 — 随 G7 P1 立项时评估 (不单独投)**: G7 若做 x86 目标, x87 是硬耦合 (x86 目标若强制 /arch:SSE2 则几乎无 x87; 若不强制, IA32 代码 2.2–11.4% 是主流浮点) → 建议 G7 立项时按 "x86 目标默认拒绝 IA32 浮点路径 (文档化)" 或 "捆绑 L0" 二选一, **本单不拆**。前置单草案 (G7 立项时引用): `G7x-9` x87 L0 捆绑评估 (ST 模型 + fld/fstp/fadd/fmul 闭合, XL)。
- **(R1) 全量 x87 排波 — 不推荐现在投 (数字支撑不足)**: x64 世界频率 ≈ 0 (0.003% 且全是伪影), 唯一真实入口是 mingw runtime/手写 asm — 为保护这类输入投 ~80 handler + 跳表扩容 + XL 栈基建, 收益/成本比最低。若未来 x86 (G7) 立项且走 IA32, R1 蓝图 (§4 L0-L4) 直接生效。前置单草案 (若立项): `G5r-L0` = §4 L0 + 跳表 128→256 扩容 (预埋基建)。

**综合推荐: R3 立即 (S) + callgate FP 修复独立 P0 (见 §6) + R2 挂 G7 评估 + R1 backlog 留蓝图。** 不选纯 R3 的原因: callgate FP 参数缺口是**当前 SSE 世界**的静默错乱 (与 x87 无关), 修复它同时是 x87 任何路线的前置。

## §6 新发现耦合点 (派单 §A.2 未列)

1. **VM CallGate 浮点参数/返回值缺失 (P0, 实测 + 源码双证)**: asmgen.cpp:1189-1265 `build_callgate` — step 0/5 只搬 regs[1]=RCX/regs[2]=RDX/regs[8]=R8/regs[9]=R9, step 10 只回写 RAX (`mov [ctx+0x10], rax`); **无 xmm0..3 参数、无 xmm0 返回值**。E2E 复现 (双样本): 标记区域内 `r = f(3.0,4.0) + f(1.5,2.5)` 两种实现 (MASM x87 callee / noinline SSE callee) 原生输出 7.9155/13 (rc 0/5) → 保护后 **4.5 (rc 2)** 静默错乱; 纯 SSE 样本复现证明**非 x87 专属**。影响: 任何区域内调用带 FP 参数的 native 函数 (printf 变参是 int 通路不受影响, CRT 数学函数 sin/pow 等全中招)。GAPS C3 节未记录 (仍是 pre-M2-9 旧文)。修复面: callgate step 0/5 加 movups ctx.xmm[0..3]→物理 xmm0..3 (宽度按调用点类型, 保守 16B), step 10 加 movups 物理 xmm0→ctx.xmm[0]; 翻译器需传 FP 参数存在性/个数 aux。**建议: 独立 P0 派活单 (M 级)** — 顺带解决"区域内调 CRT 数学"这一 x87 现实路径。
2. **跳表 128 项容量**: kTableEntries=128, kVmOpMax+1=80 — x87 全族 (~80) 需 128→256 扩容 (一处常量 + 二遍法回填), 拆单蓝图预埋。
3. **fldcw 降精度模式**: 真实 CRT 代码用 0x27F (53-bit PC) — L0 必须含 CW 槽, 不能假设 x87 恒 80-bit 全精度; 否则与 SSE 同表达式结果分叉不可控。
4. **MSVC x86 默认 /arch:SSE2 (先验修正)**: 32 位老代码 (CRT/OS 组件) 才是 x87 主来源; 新编译 x86 默认 SSE — G7 立项时"x86 浮点=SSE"假设需要 /arch:IA32 分档。
5. **_controlfp 在 v145 走 MXCSR (即使 /arch:IA32, 实测 stmxcsr)**: fldcw 通路只在老 CRT/手写代码/mingw 出现 — 状态控制组实现优先级可下调但不可砍 (ntdll/msvcrt 真实命中)。

## §7 结论

✅ **推荐 R3 文档化先行 (S 级 1 单) + callgate FP 参数修复独立 P0 (M 级 1 单)**; R1 全量 x87 不排波 (x64 频率 ≈ 0 支撑不足, 蓝图 §4 留档), R2 随 G7 P1 立项捆绑评估。全部数字 = 本机实测 (26 真实二进制 + 30 探针/E2E 产物), 方法、样本集、反例逐条披露, 与 run 时间对账 57 分钟。

== MIT-G5r triage 完 ==
