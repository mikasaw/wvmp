# MIT-451 (X5b x86 保存区冲突修复) 裁定 — ACCEPT；mul64hi 崩溃销账（103-kernel 双跑 diff-0 达成亲验）；D1 数据先行模范兑现；十九连满分

> 裁定人: 项目主 — 2026-09-02 18:1x | 处置: ff-merge main=`ae194d3`, done
> 复验: agent worktree 自拆 + 主仓 .deps 零命中自证（450 新坑纪律首次执行）；项目主另建 `wvmp-x5b`@ae194d3 双 arch 独立重建全链亲跑
> 平台事故注记: attempt-1 `daemon restarted while task was in flight`（事故族第 7 起新子类）→ 平台自动重开 attempt-2 completed——未干预（445 分型 ② 的先例复用）

## 1. 独立复验（全部亲测）
| 项 | 实测 (@ae194d3) |
|---|---|
| **反证双侧（本单灵魂, 我亲手）** | 修复前 main CLI 打 wvmpTest x86 → native 103/103 绿、packed **rc=0xC0000005 崩溃复现**（无 SUMMARY）；修复后分支 CLI → packed **rc=0 SUMMARY 103/103**、双跑逐 kernel **diff 0**——**450 遗留 1 正式销账，x86 生产态 C2 尾巴割除** |
| **mul64hi 修复形态亲验** | 新 CLI 打壳 stubs=0 + **stack-depth-gate=1**——mul64hi（net=64B 区外延迟清栈形）转 C1 显式 gate 保原生（D5 宁窄勿宽），非硬虚拟化——**与报告"唯一剩余 gate 区"逐位吻合** |
| 新样本抽跑 ×3 | pushform **真虚拟化 stub=1**（guard 吃 push 形）/ guardover **depthgate=1**+byte-exact（超预算 gate 形）/ jmptbl **stub 1→4**（450 gate 负例翻正）——machine=0x14C ×3、WOW64 byte-exact ×3 |
| **D6 x64 恒等铁证** | 双 CLI 同 seed asm_dump 均 `ffd47289…`/161,861B 逐字节恒等；**x64 wvmpTest stubs=14 + 新增 stack-depth-gate=0 + 双跑 diff 0**——D4"x64 共享 gate 但零行为变"兑现 |
| multiseed / ctest / 电池 / dump 门 | 亲跑 **315/315**（63 样本：池 11→13 +pushform/guardover）/ 16/16 / **37/37**（WOW64 亲手，+guard 用例）/ PASS 60 项 |
| 冻结契约 | runtime.hpp/vm_op(97)/backend **0 diff**；`kX86GuardBytes=128` 单源 + `kX86ExitSlotDepth = G+16+kCtxSize+0x80` 派生 + **static_assert==0x2D8**（尺寸单一来源纪律满分）；21 文件全落 D3 解禁清单 |

## 2. D1「数据先行」模范兑现（B.1 表 = 全部裁决的地基）
纯 gate (i) 存活率 **64.3%**（9/14）vs guard (v)@128B **92.9%**（13/14）、@256/@512 无增益 → **N=128 = p99(64B)×2 余量**——离线工具 `measure_x86_stack_depth.py` 镜像产品 walk 规则（非拍脑袋），guard 深度决策的每个数字可复算。我派单预埋的"存活率 <60% 停手提议 (ii)"未触发。

## 3. #33 判定（双合格）
① 跳表匹配器**两点变三点**——派单点名 :403/:457 之外实测补第 3 处（mov-imm 基址载入同族 S64 判据）+ 4B delta **dword 回绕语义**（负 delta 补码=MSVC x86 .text 尾随表常态，这个形不处理 jmptbl 翻正就是假的）。② B.4 载体域**零新增**：dst=Reg 判别走 `b_kind=None` 既有编码位——我派单"禁开新值域=停手"的红线用巧解绕过（单 VmOp 保住、lifter 四 case x86 专属、x64 照旧 G4 残余 gate）。另：位号 `and 0x1F` 语义修正（x86 SDM 掩码, 444 移位掩码同族知识点复用）。

## 4. 遗留风险核准（D5 划界合格）
1. **mul64hi 类（区外延迟清栈/Halt 出口 esp=ns vs 真实 ns−d）= 永久 gate**，后续项 **esp-resync 前瞻**（静态验证 end_rva 后 `mov esp,ebp` 型重同步再放行）——登记正确；
2. **x86 下一最大 gate 面 = "跳转目标块未找到" 17 处**（wvmpTest 主导, X5 已实录非本单范围）——按族提单素材, X5c/未来单；
3. callgate >8 dword 仍超窗（本单 4→8 行使 X5 留的备选，arg_count 静态通路后续裁决）/ push-imm 形照旧 gate——两条均如实点名；
4. walk 折打面三条（未知基负位移/diamond 线性 carry/未别名 mov esp,reg 帧上移假定）——宁窄勿宽入册；
5. guard 递归预算：128B/层×32 层=4KB ≪ 1MB 栈——数字自洽。

## 5. 合入后基线
**main=`ae194d3`, 权威基线 63 样本 ×5 = 315/315**（x64 50 + x86 13）；x64 dump 底稿 `ffd47289` 不变（本单 x64 码体零动）；x86 真可跑面：跳表翻正 + REG-REG 位测试族入面 + guard 吃真实 prologue push——**"x86 生产可用"自此无 C2 星号**。
