# MIT-454 (X6 并单: push-imm 开面 + SSE 32 批迁) 裁定 — ACCEPT；两族三列读数全中（wvmpTest x86 stubs 9→11 / 残面 13→3 / SSE 0→32 全覆盖）；#33 再纠我派单锚（卡点 translator 非 lifter, 误导注释伏法）；D6 新规首执合规；二十二连

> 裁定人: 项目主 — 2026-09-02 23:5x | 处置: ff-merge main=`bf2a41d`, done
> 复验: agent worktree 自拆 + **未自行 merge main（453 事件后"禁自行 merge"显式句首次执行, D6 合规）**；项目主另建 `wvmp-x6`@bf2a41d 双 arch 独立重建全链亲跑

## 1. 独立复验（全部亲测, 双 CLI 对照）
| 项 | 实测 (@bf2a41d vs 修复前 main@4083b1f) |
|---|---|
| **B 族读数（push-imm）** | 旧 CLI: pushimm-note=**11** / stubs=9 → 新 CLI: **note=0 / stubs=11**——11 处全翻正, aa18/b678 转真虚拟化, 与报告分栏表逐位吻合 |
| **A 族读数（SSE 翻案铁证）** | `wvmp_x86_sse_sample` 双 CLI: **stubs 1→2 / gate-note 2→0 / 输出串 `sse=FBCF1C7E` 前后逐字节恒等**（D5 第一铁兑现）; 表 60→**92 唯一 op** 亲点（算术16+传送6+位运4+mem2+桥2+ucomis2=32 账闭合, ≤kVmOpMax=97<跳表 128 **零扩容**）|
| 新样本 pushimm | 亲手跑: stubs=1 / machine=0x14C / WOW64 byte-exact（`pi=12345678 FFFFFFFF 00000080 …` 含 imm8 sext/全 F/0 边界形）|
| wvmpTest x86 双跑 | **唯一 diff=程序自报路径行**（image 行, 406 以来惯例排除项）——剔除后**字节级恒等**亲验; 103/103 |
| wvmpTest x64 | 亲手: stubs=14 / en=17 / gate=0 / 双跑 diff 0——三批复验不变 |
| multiseed / ctest / 电池 / dump 门 | 亲跑 **325/325**（65 样本=50+15）/ 16/16 / **43/43**（WOW64 亲手）/ **PASS 92 项全覆盖** |
| **x64 恒等（第 8 次亲验）** | 双 CLI 同 seed asm_dump 均 `ffd47289…`/161,861B 逐字节——SSE 批迁+push-imm 双族全动 asmgen/translator, x64 码体分毫未扰 |
| 冻结契约 | kVmOpMax=97 / 跳表 128 / runtime.hpp / 判定链 / ExitNative 协议 / 载体域零触碰（15 文件全落 D3+披露清单）|

## 2. #33 判定：又推翻我的派单锚——这次错在"信了注释"
我 §A.1"卡点在 lifter :219 is_data_operand 拒 imm"**实测推翻**：`is_data_operand` 本就接受 Imm, push imm 一直被 lift; 11 处 gate note 全部出自 **translator skip**（真卡点=`dst.kind != Reg`）。我被 :1569 的**注释**"push imm：lifter 不产出"骗了——**注释本身是过时/错误的误导源**，agent 用逐 site grep 实证翻案并顺路修了注释。新教训入册：**锚点分级——行为实测 > 代码直读 > 注释（注释最不可信, 派单 §A 引注释必标注"待验"）**。运行时 Imm 形"存在性"亲核（446 预留兑现, X3b 电池已覆盖）同属 #33 合格动作。

## 3. D3 越解禁字面披露: **批准追认**（stub_gen.cpp x86 路径 xmm 同步）
证据链完整: ① 446 交接原文即预设条件句（"x86 运行时无 SSE handler, ctx.xmm 面未消费"——批迁后**前提翻转**, Win32 ABI xmm 全易失, 区域函数进入时刻 xmm 值必须有源, 否则 SSE 函数读到垃圾）; ② 改动全在 `build_stub_asm_x86` 体内 + 一处注释块（我 hunk 级亲核, :197 hunk 的 x64 函数签名只是上下文行）; ③ x64 路径逐字未动有 dump `ffd47289`+multiseed 250+wvmpTest x64 三面机器证明——这是 B.2 的**内在必需组成**而非范围扩张, 主动披露待追认的姿势正确。

## 4. 批迁缺陷实录（D4 归属标注纪律兑现）
X3d 族: `build_xmm_store_x86` 地址临时与 src 寻址临时同用 t_[1] → store 写野（x64 版 T1/T9 分工在 32 位镜像缺位——**X3a 池 6/临时 4 重构的衍生坑, 第 7 颗"每支持一族翻旧雷"实为自家新码挖的**, 电池当场炸当场修+分工修复+注释钉）; X5d 族仅测试断言 LIFO 方向写反（测试缺陷非产品缺陷）。编码面 #33: 26 mnemonics Keystone KS_MODE_32/64 **双模装配同字节+capstone 双解同 text 逐 op 断言**——没整体信 X0"编码双平台同"先验, 正确姿势。

## 5. 遗留与澄清核准
① 残面 13→**3** 闭合: 间接 jmp 1（aebb 挂账）+ 栈深 1（mul64hi 永久）+ Div 1（b59b G8 另单）——x86 真产物面已基本清空; ② **"32/32"口径澄清（披露 2）**: 32=SSE **VmOp 现存集**全覆盖; Cvt/Sqrt/Unpck/Shuf 指令族在冻结枚举域内**本无 VmOp**（x64 侧同样是 translator 折条/lifter gate 处理）——G7 行翻正按此口径入册即准确, 非漏迁; ③ push-imm x64 扩面挂 X6b（imm32 sext 64 位值域不同面, D2 分账纪律）; ④ wvmpTest x86 无 SSE 标记函数故 A 族该侧读数 0 增（不虚增, 池侧 +1 stub 如实）。

## 6. 合入后基线
**main=`bf2a41d`, 权威基线 65 样本 ×5 = 325/325**（x86 池 15）; x64 dump 底稿 `ffd47289` 不变。**x86 覆盖终读数: 103-kernel 真虚拟化 9/14→11/14（78.6%）+ SSE 面全开 + push-imm 清零——M2.5-X 收档后两波补丁（X5b 正确性/X5c 接线/X6 双族）使 x86 生产态完整度大幅抬升。** 下一战役: 410(M3 加密) / X6b(x64 push-imm 扩面+Div 族) / 客户态重扫。
