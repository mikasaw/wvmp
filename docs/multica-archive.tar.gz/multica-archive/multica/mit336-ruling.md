# 项目主裁定: 采纳 MIT-336 verifier 报告 + 接受 MIT-335 (xchg 指令支持) + 修 2 项 🟡 非阻断问题

## 总体评价

MIT-336 verifier 报告 (verifier 第 14 连实战) **接受** MIT-335 (commit `44052e9` xchg 指令支持): **13 项全部通过**, **2 项 🟡 非阻断问题** (commit message enum 数值注释错 + docs/contracts.md 冻结清单与实践不一致)。

verifier 独立 fresh verify 双重确认:
- ✅ build 296/296 clean
- ✅ tests 15/15 + lifter 59/59 PASS
- ✅ multiseed 5×8 REQUIRE_REAL=1: 40/40 + xchg 5/5 真虚拟化
- ✅ E2E xchg byte-exact match
- ✅ capstone 反汇编 MASM helper 真 codegen `xchg rax,rbx` / `xchg eax,ebx` 真字节 (派活单 §A 假设错 vs MASM helper 修复方向正确 — **pitfall #33 实战**)
- ✅ 4 个回归样本 (snake/bswap/imul/cl_shift) 全部 byte-exact + 真虚拟化

## 双重确认 (verifier + 项目主 fresh verify)

**verifier 实证**:
- 派活单 §A 假设 `__asm__("xchg %rax, %rbx")` 强制 codegen 错 (MSVC x64 不支持 inline asm)
- agent 改修复方向 MASM (.asm) helper 文件 emit 真 xchg 字节
- **verifier capstone 反汇编确认 MASM helper 真让 codegen 出 `xchg rax,rbx` / `xchg eax,ebx`** — 派活单 §A 假设错时 agent 改修复方向正确 (pitfall #33 实战)

**项目主 fresh verify** (本会话上一轮):
- HEAD `44052e9` ✅
- native xchg stdout = `xchg64=fedcba9876543210 xchg32=abcdef01 chain=ffffffffffffffff` ✅
- fresh protect: 3 个入口 stub 生成, .wvmp 节 17586 字节 @ RVA 0xB000 ✅
- **protected xchg stdout == native xchg stdout** → **XCHG BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

## 🟡 非阻断问题处理 (verifier 报 2 项, 不阻塞 MIT-335 done)

### 问题 1: `docs/contracts.md` 冻结清单与实践不一致

**verifier 建议**: 在 §4 加 "现有 enum 值与 Operand 字段不可改, **additive enum append-only**允许"

**项目主处理**: ✅ 沉淀到 pitfall #34 已包含此原则 (沿用 MIT-333 bswap 教训), docs/contracts.md §4 增补待办, 立新 sub-issue。

### 问题 2: commit message / 源码注释中 enum 数值写错

**verifier 实证**: 注释写 `Bswap=48, Xchg=49`, 实际是 `47/48` 或 `33/34`

**项目主处理**: ✅ commit message 数值不阻塞功能 (源码 `kVmOpMax` 是动态 `static_cast<u16>(VmOp::Xchg)`), 但 commit message 与源码同步性差, 立 sub-issue 修文档一致性。

**不修 commit** (沿用 pitfall #29 "派活单派活后 agent run failed 重新派遣纪律", 数值错是文档问题, 不影响运行)。

## 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-335** | ✅ **done** | xchg 指令支持 (Block C 阶段 2 第 2 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

## Block C 阶段 2 第 2 条 done ✅ (阶段 2 推进, 2 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **47** (MIT-300 ~ `44052e9`) |
| lifter 白名单 | **~42 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + **xchg**) |
| 真虚拟化样本 | **13 个** |
| ctest | **15/15** |
| E2E byte-exact | **17/17** |
| **E2E REQUIRE_REAL=1** | **17/17 真虚拟化** |
| multiseed 5×8 REQUIRE_REAL=1 | **40/40 真虚拟化** |
| verifier 实战 | **14 连** (含 MIT-336 反向二次确认 pitfall #33 实战) |

## 🟡 后续待办 (2 项非阻断, 立 sub-issue 跟踪)

1. **sub-issue A**: `docs/contracts.md` §4 增补 "现有 enum 值与 Operand 字段不可改, additive enum append-only 允许" (沿用 pitfall #34)
2. **sub-issue B**: commit message / 源码注释 enum 数值同步性差, 修文档一致性 (不修 commit, 修后续 commit 模板)

## 后续流水线 (Block C 阶段 2 第 3 条)

```
立 Block C 阶段 2 第 3 条派活单候选:
 - cmpxchg (原子, 复杂但有市场需求)
 - setcc / cmovcc (条件指令, 1 字节, 模板化, 1 天)
 - movzx 8→16/16→64 (cl_shift 已覆盖部分, 补全)
 - movsx (与 movzx 对偶)
  ↓
派活单直接复用本文档 6 层次派活单设计纪律 + 35 个 pitfall + MASM .asm helper 文件 (针对 MSVC x64 不支持 inline asm)
  ↓
阶段 2 完整规划 (5-7 天, ~7 条派活单)
```

## 沉淀 (verifier 第 14 连实战, 与 35 个 pitfall 联动)

### 关键沉淀 (本会话)

- ✅ verifier 第 14 连实战接受 MIT-335 (12 项 + 3 项重点核查全部 PASS)
- ✅ pitfall #33 派活单 §A 假设不一定是真根因 实战体现 (MIT-335 agent 派活单 §A 假设 "MSVC x64 支持 inline asm" 错, 改修复方向 MASM helper)
- ✅ pitfall #34 additive enum append-only 实战体现 (VmOp::Xchg 在 VmOp::Bswap 之后)
- ✅ **MASM (.asm) helper 文件** 强制 codegen 路径 (针对 MSVC x64 不支持 inline asm)

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单 (cmpxchg / setcc / cmovcc / movsx 等) 派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Xchg=49 之后 append-only)
- **MASM .asm helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35 候选)
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum
- 冻结契约核查
- enum 数值文档同步性 (避免 commit message enum 数值错)

---

## 引用链

- `m3-lifter-paihuo-9-issue-progression.md` (13 节点完整演进)
- `mit333-ruling.md` (bswap ruling)
- `mit335-ruling.md` (xchg ruling)
- `issue-34-xchg-instructions.md` (MIT-335 派活单)
- `issue-35-mit335-verifier-instructions.md` (MIT-336 verifier 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit335-xchg-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332 实证, **MIT-335 实战体现**)
- `pitfall #34` additive enum append-only (MIT-333 实证, MIT-335 实战体现)
- **pitfall #35 候选** (本会话新增): MSVC x64 不支持 inline asm, 测试 fixture 必须 MASM (.asm) helper 文件