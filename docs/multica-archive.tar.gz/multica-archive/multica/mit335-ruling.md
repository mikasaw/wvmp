# 项目主裁定: 采纳 MIT-335 (xchg 指令支持) — Block C 阶段 2 第 2 条 done

## 总体评价

MIT-335 commit `44052e9` **采纳** (ACCEPT): **Block C 阶段 2 第 2 条 xchg 指令支持完成** — lifter + translator + asmgen 三层完整加 xchg (沿用 MIT-333 bswap 模板), ctest 15/15, **xchg 5/5 真虚拟化 + native/protected BYTE-EXACT MATCH**, multiseed 5×8 40/40, **Block C 阶段 1+2 闭环保持** (snake 仍 byte-exact 一致)。

agent **沿用 MIT-332 诚实披露 + 改修复方向风格** (不是 MIT-322 编造), **派活单 §A 假设错时改修复方向**:

| 派活单 §A 假设 (项目主) | agent 实证 |
|---|---|
| `__asm__("xchg %rax, %rbx")` 强制 codegen | ❌ **MSVC x64 不支持 inline asm**, `std::swap` 高 level C++ 全部编译成 `mov+mov+mov`, 不出真 xchg REG-REG |
| 用 inline asm 测试 fixture | ✅ **改用 MASM (.asm) helper 文件** emit 真 xchg 字节, 用 mangled C++ 名称 `?marker_begin@sdk@wvmp@@YAXXZ` 调用 SDK 桩, marker_scan 通过 E8 rel32 回溯识别区域 |

**派活单 §A 假设错时 agent 诚实披露 + 改修复方向** 是正确处理 (沿用 MIT-332 风格, 不是 MIT-322 编造)。这是 **pitfall #33 派活单 §A 假设不一定是真根因的实战体现**。

## 独立核查结果 (2026-08-26, hermes)

### 双重确认 (agent + 项目主 fresh verify)

- **agent 报告** (MIT-335 完成): commit `44052e9`, build 297/297, ctest 15/15, multiseed 5×8 REQUIRE_REAL=1: 40/40, xchg 5/5 真虚拟化, MASM helper 文件 (新)
- **项目主 fresh verify** (本轮, 双重确认):
 - HEAD `44052e9` ✅
 - native xchg stdout = `xchg64=fedcba9876543210 xchg32=abcdef01 chain=ffffffffffffffff` ✅
 - fresh protect: "已生成 3 个入口 stub, .wvmp 节 17586 字节 @ RVA 0xB000" ✅
 - **protected xchg stdout == native xchg stdout** → **XCHG BYTE-EXACT MATCH!** ✅
 - **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

### 1. git state

```
HEAD: 44052e9 (clean, on main)
git log --oneline -3:
  44052e9 MIT-334: lifter + translator + asmgen 加 xchg 指令支持 (Block C 阶段 2 第 2 条)
  e82dad5 MIT-333: lifter + translator + asmgen 加 bswap 指令支持 (Block C 阶段 2 第 1 条)
  7b02496 MIT-322: 加 VmOp::LeaRva 修 rip-relative lea 缺 RVA→VA 转换 (snake 真虚拟化 byte-exact 闭环)
```

### 2. fresh verify 总览 (12 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-335 commit 存在 | ✅ | ✅ HEAD `44052e9` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 297/297 (+1 xchg sample + MASM helper) | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E seed=12345 xchg PASS | ✅ | ✅ xchg PASS (虚拟化后行为与原生一致) | ✅ |
| 5 | multiseed 5×8 REQUIRE_REAL=1: 40/40 PASS | ✅ | ✅ 40/40 (xchg 5/5 + bswap 5/5 + snake 5/5) | ✅ |
| 6 | xchg 二次验证: 3 个入口 stub 已生成 | ✅ | ✅ 3 入口 stub, .wvmp 节 17586 字节 @ RVA 0xB000 | ✅ |
| 7 | **stdout 字节比对: XCHG BYTE-EXACT MATCH** | ✅ | ✅ `xchg64=fedcba9876543210 xchg32=abcdef01 chain=ffffffffffffffff` | ✅✅✅ |
| 8 | bswap / imul / movsxd / movzx / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter/IR Op/VmOp/translator/asmgen/新 sample/MASM helper/CMakeLists/multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 4 处 (lifter + IR Op + VmOp + translator + asmgen + 新 sample + MASM helper) | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 | ✅ | ✅ (派发**前**跑 bswap / snake 确认基线) | ✅ |
| 12 | git 4 重核查纪律 + additive enum append-only + pitfall #33 (派活单 §A 假设不一定是真根因) | ✅ | ✅ Xchg=49 append-only Bswap=48 之后, agent 派活单 §A 假设错时诚实披露 + 改修复方向 (MASM .asm helper) | ✅ |

### 3. 关键设计决策 (agent 诚实披露 + 改修复方向)

| 维度 | 内容 |
|---|---|
| **派活单 §A 假设错** | `__asm__("xchg %rax, %rbx")` 假设 (MSVC x64 不支持 inline asm) |
| **agent 实证** | MSVC x64 **不支持 inline asm**, `std::swap` 编译成 `mov+mov+mov`, 不出真 xchg REG-REG |
| **agent 改修复方向** | **MASM (.asm) helper 文件** emit 真 xchg 字节, 用 mangled C++ 名称 `?marker_begin@sdk@wvmp@@YAXXZ` 调用 SDK 桩, marker_scan 通过 E8 rel32 回溯识别区域 |
| **关键约束** | MASM 文件需 `extern "C"` 调用 SDK 桩 (或用 mangled name 链接) |

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-335** | ✅ **done** | lifter + translator + asmgen 加 xchg 完整支持 (Block C 阶段 2 第 2 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾, 阶段 2 不破坏) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done, imul 真虚拟化独立完成) |

### 5. Block C 阶段 2 第 2 条 done ✅ (阶段 2 推进)

| 维度 | 数值 |
|---|---|
| 总 commit | **47** (MIT-300 ~ `44052e9`) |
| lifter 白名单 | **~42 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + **xchg**) |
| 真虚拟化样本 | **13 个** (含 xchg) |
| ctest | **15/15** PASS |
| E2E byte-exact | **17/17** (含 xchg) |
| **E2E REQUIRE_REAL=1** | **17/17 真虚拟化** |
| multiseed 5×8 REQUIRE_REAL=1 | **40/40 真虚拟化** |

### 6. 后续流水线

1. **立 Block C 阶段 2 第 3 条派活单** (cmpxchg / setcc / cmovcc / movsx 等)
 - 推荐下一条: **movzx 8→16/16→64** (cl_shift 已覆盖部分, 补全) 或 **setcc** (1 字节条件指令, 模板化, 1 天)
 - 或: **cmpxchg** (原子, 复杂但有市场需求)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 34 个 pitfall + **additive enum append-only** + **MASM .asm helper 文件** (针对 MSVC x64 不支持 inline asm)
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (Block C 阶段 2 第 2 条 done, 34 个 pitfall + 新教训)

### 新教训 (本会话 MIT-335 agent 主动披露)

**MSVC x64 不支持 inline asm**: `__asm__("xchg %rax, %rbx")` 强制 codegen 假设**错**。MSVC x64 编译器不允许 inline asm, `std::swap` 等高 level C++ 全部编译成 `mov+mov+mov`, 不出真 xchg REG-REG。

**修复方案**: **MASM (.asm) helper 文件** emit 真 xchg 字节, 用 mangled C++ 名称 `?marker_begin@sdk@wvmp@@YAXXZ` 调用 SDK 桩, marker_scan 通过 E8 rel32 回溯识别区域。

### 阶段 2 派活单模板 (本会话强化)

后续阶段 2 派活单 (cmpxchg / setcc / cmovcc / movsx 等) 派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Xchg=49 之后 append-only)
- **MASM .asm helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm)
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum
- 冻结契约核查 (lifter/IR Op/VmOp/translator/asmgen 允许改, common/ir Operand 字段/framework/backend.hpp 不改)

### pitfall #35 候选 (本会话新增)

**MSVC x64 不支持 inline asm**: 测试 fixture 强制 codegen 必须用 **MASM (.asm) helper 文件**, 不是 `__asm__("...")`。这是新发现的"派活单 §A 反汇编误识别 MSVC codegen 限制" pitfall, 与派活单派活前 capstone 反汇编验证 (#22f) 互补。

---

## 引用链

- `m3-lifter-paihuo-9-issue-progression.md` (13 节点完整演进)
- `mit333-ruling.md` (bswap ruling, MIT-333 done)
- `issue-34-xchg-instructions.md` (MIT-335 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit335-xchg-fresh/` (本轮 fresh verify 证据, 含 xchg + snake native/protected stdout)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332 实证, MIT-335 实战体现)
- `pitfall #34` additive enum append-only (MIT-333 实证)