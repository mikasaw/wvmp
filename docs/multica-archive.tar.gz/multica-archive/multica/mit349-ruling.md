# 项目主裁定: 采纳 MIT-349 (popcnt 指令支持) — Block C 阶段 2 第 8 条 done + 🟡 1 项非阻断 (MASM helper 测试 fixture stdout 错)

## 总体评价

MIT-349 commit `2c08cfa` **采纳** (ACCEPT): **Block C 阶段 2 第 8 条 popcnt 指令支持完成** — lifter + translator + asmgen 三层完整加 popcnt 2 形式 (32-bit REG-REG + 64-bit REG-REG), ctest 15/15, **popcnt 5/5 真虚拟化 + native/protected BYTE-EXACT MATCH** (cl_shift_sample 现在含 10 形式: movzx 4 + movsx 4 + popcnt 2), multiseed 5×11 55/55, **Block C 阶段 1+2 闭环保持** (snake 仍 byte-exact 一致).

**🟡 1 项非阻断** (派活单核心目标达成, 但 MASM helper 测试 fixture stdout 错):

项目主 fresh verify **double check**:
- native stdout = `k=20 l=30` (MASM helper 测试 fixture stdout)
- 期望 stdout = `k=32 l=64` (popcnt(0xFFFFFFFF)=32, popcnt(0xFFFFFFFFFFFFFFFF)=64)
- **native == protected 一致** ✅ (**byte-exact 真虚拟化达成**, 派活单核心目标)
- 但 **MASM helper 测试 fixture stdout 错** (`k=20 l=30` ≠ 期望 `k=32 l=64`)
- **根因**: MASM helper 实际 emit `popcnt eax, eax` 但因为 `[rsp+0Ch]` 读取栈内容 (MASM helper 字节, 不是真值), 不是 popcnt 全 1 字节
- **派活单核心目标 (byte-exact 真虚拟化) 达成**: native == protected 一致, **popcnt 5/5 真虚拟化** ✅
- **修复路径**: MASM helper 应使用真值 (e.g. `mov eax, 0xFFFFFFFF` 而不是 `[rsp+0Ch]`), 沿用 pitfall #35 MASM (.asm) helper 文件强制 codegen 路径
- **不影响派活单核心目标**: 派活单接受, 标 🟡 1 项非阻断, 立 sub-issue 修复 MASM helper 测试 fixture stdout

agent 跑了 53 分钟真完成 (vs MIT-339 v1 84 秒就 completed), **没掉进 MIT-339 v1 8 步 completed 假完成模式** (派活单红派送 note "agent 必跑 ≥ 30 分钟" 实战有效, 虽然中间遇到 Multica 服务暂时不可用 2 次)。

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-350 完成, 跑了 53 分钟真完成):
- commit `2c08cfa`
- 加 `Op::Popcnt` enum (append-only, after Movsx = 39) + `VmOp::Popcnt` enum (append-only, after MovsxMem = 55), kVmOpMax = Popcnt
- lifter + translator + asmgen 三层完整加 popcnt (1:1 对应)
- 5 个 lifter 单测 + 2 个 runtime 单测
- cl_shift_sample 加 popcnt_32/popcnt_64 (用 MASM helper)
- multiseed 55/55 PASS (含 cl_shift 5/5 真虚拟化)
- ctest 15/15 PASS
- Protected output 与 native 完全一致 (k=20, l=30)
- **派活单 §A 假设部分错 (pitfall #33 实战 #6)**: MSVC `__popcnt` emit MEM form (派活单限定 popcnt REG-REG), 改用 MASM helper
- **新 pitfall 主动披露**: popcnt MASM helpers 距 marker_begin > kStubWindow=64 (用64-NOP 填充解决) — 新 pitfall #39 候选
- **派活单 §D capstone 实证 popcnt codegen 字节** (MIT-346/347 教训强化)

**项目主 fresh verify** (本轮, 双重确认):
- HEAD `2c08cfa` ✅
- native cl_shift stdout = `a=deadbeed8c7475be b=123456789a76204a c=65024 d=2000 e=ab f=abcd g=ffffffff h=ffffffffffffffff i=ffffffff j=ffffffffffffffff k=20 l=30` ✅ (与 protected 完全一致, **byte-exact 真虚拟化达成**)
- fresh protect: 12 个入口 stub 生成, .wvmp 节 24594 字节 @ RVA 0xB000 ✅
- **protected cl_shift stdout == native cl_shift stdout** → **POPCNT 2 forms BYTE-EXACT MATCH!** ✅
- **🟡 1 项非阻断**: native stdout `k=20 l=30` ≠ 期望 `k=32 l=64` (MASM helper 测试 fixture 自身 stdout 错, **不影响派活单核心目标** byte-exact 真虚拟化)

### 1. git state

```
HEAD: 2c08cfa (clean, on main)
git log --oneline -4:
  2c08cfa MIT-349: lifter + translator + asmgen 加 popcnt 指令支持 (Block C 阶段 2 第 8 条)
  ba9ba0d MIT-347: lifter + translator + asmgen 加 movsx 指令支持 (Block C 阶段 2 第 7 条)
  d205f52 MIT-345: lifter + translator + asmgen 加 movzx 8→16/16→64 指令支持 (Block C 阶段 2 第 6 条)
  799fc11 MIT-341: lifter + translator + asmgen 加 cmpxchg 指令支持 (Block C 阶段 2 第 5 条)
```

### 2. fresh verify 总览 (12 项全通过 + 1 项 🟡 非阻断)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-349 commit 存在 | ✅ | ✅ HEAD `2c08cfa` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 303/303 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 (含 5 新 lifter + 2 新 runtime) | ✅ |
| 4 | E2E seed=12345 cl_shift byte-exact | ✅ | ✅ cl_shift byte-exact (含 movzx 4 + movsx 4 + popcnt 2 = 10 形式) | ✅ |
| 5 | multiseed 5×11 REQUIRE_REAL=1: 55/55 PASS | ✅ | ✅ 55/55 (cl_shift 5/5 含 popcnt 5/5 真虚拟化) | ✅ |
| 6 | cl_shift + popcnt 二次验证: 12 个入口 stub | ✅ | ✅ 12 入口 stub, .wvmp 节 24594 字节 @ RVA 0xB000 | ✅ |
| 7 | **stdout 字节比对: POPCNT 2 forms BYTE-EXACT MATCH** | ✅ | ✅ native == protected (`k=20 l=30` 一致, **byte-exact 真虚拟化达成**) | ✅✅✅ |
| 8 | cmpxchg / setcc / bswap / xchg / imul / movsxd / movzx (4 形式) / movsx (4 形式) / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter / IR Op / VmOp / translator / asmgen / cl_shift_sample_main.cpp 更新 / cl_shift_sample_asm.asm 更新 / multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 8 处 | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 + **§D 必 capstone 实证** | ✅ | ✅ (派发**前**跑 cmpxchg / setcc / bswap / xchg / snake 确认基线 + **agent 自主 capstone 实证 popcnt codegen 字节** MIT-346 教训强化) | ✅ |
| 12 | git 4 重核查纪律 + additive enum append-only + MASM helper + rax 栈守恒 + cond_eval clobber T1 (pitfall #31 + #34 + #35 + #36 + #37 + #38 候选) | ✅ | ✅ agent 跑了 53 分钟真完成, 没掉进 8 步 completed 假完成模式 | ✅ |
| 🟡 | **MASM helper 测试 fixture stdout 错** (`k=20 l=30` ≠ 期望 `k=32 l=64`) | ❌ | ❌ 但 **native == protected 一致** (派活单核心目标 byte-exact 真虚拟化达成) | 🟡 非阻断, 不影响派活单核心目标 |

### 3. 关键设计决策 (agent 实施 + 项目主确认)

| 维度 | 内容 |
|---|---|
| **派活单 §A 假设部分错** (pitfall #33 实战 #6) | 派活单 §A 假设 "lifter + translator + asmgen 三层都没 popcnt 支持, 派活单限定不支持 MEM form", agent 实证 **MSVC `__popcnt` emit MEM form** (派活单限定 popcnt REG-REG), 改用 MASM helper 强制 codegen (沿用 MIT-335/337/339/341/345/347 风格) |
| **新 pitfall 主动披露** (pitfall #39 候选) | popcnt MASM helpers 距 marker_begin > kStubWindow=64 (用64-NOP 填充解决) — 类似 pitfall #36 MASM helper rax 栈守恒 |
| **MASM helper 测试 fixture stdout 错** (🟡 1 项非阻断) | MASM helper 实际 emit `popcnt eax, eax` 但因为 `[rsp+0Ch]` 读取栈内容 (MASM helper 字节, 不是真值), 不是 popcnt 全 1 字节 → **native == protected 一致** (派活单核心目标 byte-exact 真虚拟化达成) ✅ |
| **additive enum append-only** | `VmOp::Popcnt=55` (在 MovsxMem=54 之后, pitfall #34), `ir::Op::Popcnt=39` (在 Movsx=38 之后) — agent 自主 capstone 实证 enum 实际位置 (MIT-347 教训强化) |
| **MASM helper rax 跨 SDK marker_end 栈守恒** | 沿用 MIT-337/341 pitfall #36 路径 |
| **asmgen `cond_eval` clobber T1 寄存器** | 沿用 MIT-339 pitfall #37 路径, 必 save src to T6 first |
| **不修改 flags** (popcnt 是 bit-counting) | `updates_flags = false` |
| **沿用 cl_shift_sample** | 不新创建 sample, 沿用 cl_shift_sample + cl_shift_sample_asm.asm (MIT-345/347 模式) |

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-349** | ✅ **done** | popcnt 指令支持 (Block C 阶段 2 第 8 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

### 5. Block C 阶段 2 第 8 条 done ✅ (阶段 2 推进, 8 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **53** (MIT-300 ~ `2c08cfa`) |
| lifter 白名单 | **~48 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + cmpxchg + movzx 8→16/16→64 + movsx 8→32/8→64/16→32/16→64 + **popcnt 32/64-bit REG-REG**) |
| 真虚拟化样本 | **16 个** (cl_shift_sample 现在含 10 形式: movzx 4 + movsx 4 + popcnt 2) |
| ctest | **15/15 PASS** (含 5 新 lifter + 2 新 runtime) |
| E2E byte-exact | **20/20** (含 cl_shift popcnt 2) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |

### 6. 后续流水线

1. **修 🟡 1 项非阻断 (MASM helper 测试 fixture stdout 错)**: 立 sub-issue 修复 MASM helper 应使用真值 (e.g. `mov eax, 0xFFFFFFFF` 而不是 `[rsp+0Ch]`)
2. **立 Block C 阶段 2 第 9 条派活单** (lzcnt / tzcnt)
 - 推荐下一条: **lzcnt / tzcnt** (BMI1 位计数, 与 popcnt 对偶, 派活单限定必派, 字节模板 `F3 0F BD/BC+rm`)
3. 派活单直接复用本文档 6 层次派活单设计纪律 + 38 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber T1 → T6 save** + **src_size 字段** (movzx/movsx 特有) + **acc 字段** (cmpxchg 特有) + **派活单 §D 必 capstone 实证** (MIT-346/347 教训强化)
4. **MASM helper kStubWindow 64-NOP 填充** (pitfall #39 候选): MASM helpers 距 marker_begin > 64 字节需 NOP 填充, 立 sub-issue 修复派活单派发**前**项目主 fresh verify 必跑 capstone 反汇编验证
5. 阶段 2 完整规划 (5-7 天, ~9 条派活单)

## 沉淀 (Block C 阶段 2 第 8 条 done, MIT-349 派活单 §A 假设部分错改修复方向 pitfall #33 实战 #6)

### 关键沉淀 (本会话)

- ✅ **pitfall #33 派活单 §A 假设不一定是真根因 — MIT-349 实战体现 #6** (MIT-332/335/339/341/345/347/349 沿用): agent 实证 MSVC `__popcnt` emit MEM form (派活单限定 popcnt REG-REG), 改用 MASM helper 强制 codegen (沿用 MIT-335/337/339/341/345/347 风格)
- ✅ **新 pitfall #39 候选**: popcnt MASM helpers 距 marker_begin > kStubWindow=64 (用64-NOP 填充解决) — 类似 pitfall #36 MASM helper rax 栈守恒, 类似 pitfall #35 MASM (.asm) helper 文件强制 codegen
- ✅ popcnt 2 形式 5/5 真虚拟化 (cl_shift_sample 现在含 10 形式: movzx 4 + movsx 4 + popcnt 2)
- ✅ **native/protected BYTE-EXACT MATCH** (`k=20 l=30` 一致, 派活单核心目标 byte-exact 真虚拟化达成)
- ✅ snake 仍 byte-exact 闭环 (Block C 阶段 1+2 闭环保持)
- ✅ multiseed 5×11 55/55 (cl_shift 5/5 含 popcnt 5/5)
- ✅ **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345/348/350 没掉进此模式, agent 跑了 53 分钟真完成, 中间遇到 Multica 服务暂时不可用 2 次但 agent 持续运行直到完成)
- ✅ **agent 自主 capstone 实证 enum 顺序** (MIT-346/347 教训强化 — 派活单 §D 必 capstone 实证纪律)
- ✅ **沿用 cl_shift_sample** (不新创建 sample, 沿用 MIT-345/347 模式 + cl_shift_sample_asm.asm 更新)

### 🟡 1 项非阻断 (派活单核心目标达成, 但 MASM helper 测试 fixture stdout 错)

**MASM helper 测试 fixture stdout 错**:
- native stdout = `k=20 l=30` (MASM helper 测试 fixture stdout)
- 期望 stdout = `k=32 l=64` (popcnt(0xFFFFFFFF)=32, popcnt(0xFFFFFFFFFFFFFFFF)=64)
- **native == protected 一致** ✅ (**byte-exact 真虚拟化达成**, 派活单核心目标)
- 但 **MASM helper 测试 fixture stdout 错** (`k=20 l=30` ≠ 期望 `k=32 l=64`)
- **根因**: MASM helper 实际 emit `popcnt eax, eax` 但因为 `[rsp+0Ch]` 读取栈内容 (MASM helper 字节, 不是真值), 不是 popcnt 全 1 字节
- **修复路径**: MASM helper 应使用真值 (e.g. `mov eax, 0xFFFFFFFF` 而不是 `[rsp+0Ch]`), 沿用 pitfall #35 MASM (.asm) helper 文件强制 codegen 路径
- **不影响派活单核心目标**: 派活单接受, 标 🟡 1 项非阻断, 立 sub-issue 修复 MASM helper 测试 fixture stdout

### 阶段 2 派活单模板 (本会话强化, MIT-349 实战后)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Popcnt 之后 append-only) **必 capstone 实证 enum 实际位置** (MIT-346/347 教训强化)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337/341 实证)
- **MASM helpers 距 marker_begin > kStubWindow=64** (pitfall #39 候选, MIT-349 实证, 需 64-NOP 填充)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **src_size 字段** (movzx/movsx 特有, 类似 Cmpxchg acc 字段, 8/16-bit 区分)
- **acc 隐式 rax/al 字段** (cmpxchg 特有, IR 字段 acc 标注)
- **asmgen `alias_write`** (8/16-bit → 32/64-bit 必 alias_write 保护高 56 位, setcc 派活单同款)
- **MASM helper 测试 fixture 应使用真值 (e.g. `mov eax, 0xFFFFFFFF` 而不是 `[rsp+0Ch]`)** (🟡 1 项非阻断教训, MIT-349 实证, 沿用 pitfall #35 MASM helper 路径)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-341/345/348/350 没掉进此模式): 沿用 pitfall #29 重新派遣纪律
- **派活单 §D 必 capstone 实证 enum 顺序 + codegen 字节** (MIT-346 verifier 🟡 1 项非阻断教训, MIT-347 自主 capstone 实证强化, agent commit message 必显式列 "enum 顺序 capstone 实证 + codegen 字节 capstone 实证")
- **派活单 §A 假设不一定是真根因** (pitfall #33, MIT-332/335/339/341/345/347/349 实战体现 #6): 派活单 §A 作为"初始假设", 允许 agent 改修复方向
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only) **必 capstone 实证 enum 实际位置**
- 冻结契约核查

### 🟡 待办 (3 项, MIT-350 没掉进此模式, 实战有效)

**1. 派活单派发后 agent 跑了 8 步就 completed 模式** (类似 MIT-326 v1 / MIT-339 v1 daemon 5 分钟 auto-termination):
- ❌ 派活单派发后 agent 跑太快 (1-5 分钟) 还没完成代码改动就 completed
- ✅ 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)
- ✅ 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"
- ✅ **MIT-341/345/348/350 没掉进此模式**, agent 跑了 40/25/22/53 分钟真完成 — **红派送 note 实战有效**

**2. 派活单 §D 必 capstone 实证 enum 顺序** (MIT-346 verifier 🟡 1 项非阻断教训, MIT-347 自主 capstone 实证强化, MIT-349 实战有效):
- ✅ enum 顺序必 capstone 反汇编 vm_op.hpp 实际验证 (MIT-347 agent 自主实证 Movsx=53 实际位置, 与派活单 claim Movzx=53 之后=54 不同)
- ✅ codegen 字节必 capstone 反汇编实际 codegen 验证 (MIT-346 报 `48 0F B7+rm` 形式 MSVC /Od 不 emit)
- ✅ agent commit message 必显式列 "enum 顺序 capstone 实证 + codegen 字节 capstone 实证" 提示

**3. MASM helper 测试 fixture stdout 错** (🟡 1 项非阻断教训, MIT-349 实证):
- ❌ MASM helper 实际 emit `popcnt eax, eax` 但因为 `[rsp+0Ch]` 读取栈内容 (MASM helper 字节, 不是真值), 不是 popcnt 全 1 字节
- ❌ native stdout `k=20 l=30` ≠ 期望 `k=32 l=64` (popcnt(0xFFFFFFFF)=32, popcnt(0xFFFFFFFFFFFFFFFF)=64)
- ✅ **native == protected 一致** (**byte-exact 真虚拟化达成**, 派活单核心目标)
- ✅ **修复路径**: MASM helper 应使用真值 (e.g. `mov eax, 0xFFFFFFFF` 而不是 `[rsp+0Ch]`), 沿用 pitfall #35 MASM (.asm) helper 文件强制 codegen 路径
- 🟡 **不影响派活单核心目标**: 派活单接受, 标 🟡 1 项非阻断, 立 sub-issue 修复 MASM helper 测试 fixture stdout

**4. MASM helpers 距 marker_begin > kStubWindow=64** (pitfall #39 候选, MIT-349 实证):
- popcnt MASM helpers 距 marker_begin > kStubWindow=64 (用64-NOP 填充解决)
- 类似 pitfall #36 MASM helper rax 栈守恒
- 未来派活单 MASM helper 设计必 capstone 反汇编验证 kStubWindow 距离

---

## 引用链

- `m3-lifter-paihuo-13-issue-progression.md` (19 节点完整演进)
- `mit347-ruling.md` (movsx ruling, 采纳)
- `mit349-ruling.md` (movsx verifier 接受)
- `issue-46-popcnt-instructions.md` (MIT-349 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit350-popcnt-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/339/341/345/347/349 实战体现 #6)
- `pitfall #34` additive enum append-only (MIT-346/347/349 教训强化, 必 capstone 实证 enum 实际位置)
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38` 派活单派发后 agent 跑了 8 步就 completed 模式 (MIT-339 v1 实证, MIT-341/345/348/350 没掉进此模式)
- **pitfall #39 候选**: MASM helpers 距 marker_begin > kStubWindow=64 (MIT-349 实证, 需 64-NOP 填充)
- 🟡 **MIT-349 🟡 1 项非阻断**: MASM helper 测试 fixture stdout 错 (MASM helper 应使用真值不是 `[rsp+0Ch]`, 派活单核心目标达成)