# MIT-G6r triage 报告 — AVX/VEX 支持侦察：真实产物频率实测 + 架构成本量化 + 路线裁决蓝图

- verifier: WVmpVerifier (裁定型 / 纯侦察, 零产品代码改动, 零 git 操作, 未采纳任何开发侧结论——本单无开发参与)
- 静态基线: main `92b21cb` (MIT-419, 2026-08-30 03:06); CLI = `build/cli/wvmp_cli.exe` (mtime 03:25 > HEAD, 项目主 fresh verify 产物)
- 实验环境: `%TEMP%\mit424_avx\` (5 探针源 × 9 编译档 = 45 exe + 45 /FA 列表 + 1 个 MASM VEX/EVEX E2E 样本 + 4 个扫描脚本 + 4354 个 System32 文件预扫/86 全扫) — **主仓零写入、零 git 操作**
- 采集时间: 2026-08-30 15:37–16:25 (+0800), 全部数字来自实测输出
- 结论置信度: **高** (编译器 /FA 列表 + capstone .pdata 函数域反汇编 + dumpbin 交叉 + capstone detail 语义探针 + E2E protect 行为链, 五路互证)
- ⚠️ **并发状态披露**: 本侦察全程主工作区有 MIT-423 (G4b) 并发在途 (工作树 6 个 tracked 文件 modified: lifter/translator/测试/CMake/multiseed 脚本——**非本 run 所改, 本 run 未触碰任何 tracked 文件**); 本 run 只新增本报告 drop (gitignored/untracked), 与 416 先例同构
- run 对账: 15:37 (首个命令) → 16:25 (成稿), 实测约 50 分钟 ≥ 30 分钟红线
- 留样: %TEMP% 会被系统清理 (416 教训) → **E2E 样本关键源码 + 复跑命令内嵌本报告 §3.4**, 扫描脚本要点内嵌 §2.1

## §0 结论 (裁定)

**B.1 四组频率实测完毕 (数字支撑 §2):**

| 编译档位/生态 | 样本 | VEX 密度 | 结论 |
|---|---|---|---|
| MSVC x64 `/arch:SSE2` (默认) TU 本体 | 5 探针 × {Od,O1,O2} | **0 VEX** (全部 legacy SSE, x87=0) | 不开 /arch:AVX* 编译器永不产 VEX |
| `/arch:AVX` TU 本体 | 5 探针 × {Od,O1,O2} | **100% VEX 化**: 标量浮点全升 VEX.128 (vaddss/vmulss/vmovss), legacy SSE=0 | **VEX.128 折叠档的真实价值锚点** |
| `/arch:AVX2` /O2 TU 本体 | 5 探针 | VEX.128+VEX.256 混合: 向量化循环出 vaddps/vmulps ymm (fp_loop 16 条 VEX256), FMA 不出现 (默认 /fp:precise) | /O2+/arch:AVX2 = 项目主先验①成立 |
| 手写 intrinsic | intrinsic_avx 探针 | **/Od 也产 ymm** (VEX256=16, intrinsic 绕过优化档位) | ymm 不依赖优化器胆量 |
| System32 真实二进制 (4354 预扫 → 86 全扫) | **49 个含 VEX** (13 exe + 36 dll) | 密度 0.001%–2.637%, ≥0.1% 的 10 个 (表见 §2.2) | **AVX 在真实世界真实存在且分层清晰** |
| v145 CRT (LIBCMT 静态链入) | 探针 exe + ucrtbase.dll | ucrtbase **1.781% 全 VEX**: VEX.128 标量 FP (vmulsd:372/vaddsd:249/vfmadd213sd:216) + VEX256 mem | CRT 自身已 VEX 化 (标记区域外执行, lift 面间接) |

**项目主 §A 先验逐条裁定 (修正 2 条, 含派单方 3 处):**
1. "/O2 /arch:AVX2 向量化循环自动出 vaddps/vmulps/ymm" — **✅ 成立** (fp_loop_O2_AVX2: VEX256=16, vaddps/vmulps 齐出; 默认 /fp:precise 下 **FMA 不出现** — vfmadd* 只在 intrinsic/CRT(/fp:fast) 出现, 蓝图单列)
2. "/O2 float 标量是否产 VEX 编码 vmovss/vaddss" — **✅ 成立且比预想更强**: /arch:AVX 下**全部** SSE (含标量) 升 VEX (scalar_fp_O2_AVX: 38 条全 VEX, legacy=0) — "VEX.128 折叠档"不是优化项, 是 /arch:AVX(2) 产物的**必要项**
3. "第三方运行时/.NET/游戏引擎 AVX 密度抽测" — **✅ 成立 + 分层**: 密度集中在安全/哈希 (smartscreen.dll 2.637%), ML 运行时 (onnxruntime 1.430% + **EVEX 16667 条**), 现代 CRT (ucrtbase 1.781%); **经典 OS API DLL 全零** (d3d11/d3d12/dxgi/dwrite/shell32/user32/kernel32 全 0 VEX); 本机无 .NET Framework CLR (clr.dll/coreclr.dll/clrjit.dll 不在 System32, 无法抽测 — 如实披露), 用 python314.dll (0.26%) 代第三方运行时
4. "capstone detail.prefix 对 VEX 报什么 / VEX 走 prefix 数组是我猜的" — **❌ 推翻派单方猜测 (实测)**: C4/C5/EVEX 全部 `prefix=[0,0,0,0]` — **VEX 不经 legacy prefix 数组**, lifter 入口前缀闸 (rep/F2/F3/66/67/F0 检查) 对 VEX **不触发**, VEX 指令直达 mnemonic switch 的 default → 未支持 → C1 gate (E2E 行为链实证, §3)
5. "vendored 头实测 719 个 X86_INS_V*" — **⚠️ 修正**: 实测 **723** (x86.h 全量正则去重); 真实二进制语料出现的 distinct VEX/EVEX mnemonic = **236** (<1/3, 档A 范围远小于 723)
6. ":1929 注释 'vpxor/vpor/vpand, VEX.NDS.128.0F.WIG 57/56/54'" — **⚠️ 措辞自相矛盾**: 57/56/54 是 **vxorps/vorps/vandps** (float 位运算) 的 VEX 编码; vpxor/vpor/vpand (整数) 是 VEX.128.66.0F WIG **EF/EB/DA**。注释名与编码错配 (行为无影响, 建议随 B.5 修正)

**当前行为链 (E2E 实测, §3):** VEX.128 (vaddps) / VEX.256 整数 (vpaddd) / VEX.256 mem rip (vmovaps [rip],ymm) / EVEX (vprold, AVX-512VL) 在标记区域内 → lifter 报 "未支持指令 'vXXX' 已跳过" → C1 gate 整函数保持原生 → **零 stub、stdout 逐字节一致、rc=0**; 白名单+VEX 混合区域整函数 gate (C1 保守拦截正确); addss 正例对照真虚拟化 (stub=1 钉死 gate 证据)。**现状已是"半 R3": VEX/EVEX 全谱零逃逸、不产坏壳, 缺的只是文档面** (与 x87 418 收口前完全同构)。

**路线裁决: R2 — 档A (VEX.128 折叠) 排波 + 档B (ymm) 不立即、不永久 gate, 挂"跳表扩容"前置评估 (数字支撑 §5)。R1 不排波, R3 只保留为档A 受阻时的回退。**

## §1 B.1 形态枚举 (真实出现频率 = 实测语料命中, 非理论全集)

| # | 家族 | 代表指令 (capstone id 例) | 真实世界频率/来源 | 对 lift 面 |
|---|---|---|---|---|
| 1 | VEX.128 packed FP | vaddps(760)/vsubps/vmulps/vdivps/vaddpd... | /arch:AVX2 向量化 FP 循环; onnxruntime/Hydrogen 为主源 | 档A 核心 |
| 2 | **VEX.128 标量 FP** | vaddss(762)/vmulss/vmovss/vcomiss | **/arch:AVX 下一切标量浮点** (探针 100%); ucrtbase vmulsd:372/vaddsd:249 | 档A 核心 (与既有 Op 1:1) |
| 3 | VEX.128 整数/packed int | vpaddd(1079)/vpxor/vpand/vpmovmskb/vpshufb | smartscreen/ThreatAssessment/WindowsCodecs (hash/codec); python314 | 档A+ (依赖 G1b 整数 VmOp) |
| 4 | VEX.256 (ymm) | vaddps ymm/vpaddd ymm/vinsertf128/vbroadcastss | /arch:AVX2 自动向量化 + intrinsic (/Od 也产); CRT memcpy/memset AVX2 变体 | 档B |
| 5 | VEX.256 mem 原语 | vmovdqu/vmovntdq ymm (CRT 指纹: vmovdqu:55+vmovntdq:30 组合在探针 exe 与多个系统 exe 逐条复现) | ucrtbase/vcruntime140 + 一切静态链 v145 CRT 的 exe | 档B (mem 原语或 gate) |
| 6 | **VEX-GP (BMI1/2)** | rorx/mulx/andn/shlx/pdep/bzhi | **真实且高频**: ClipUp rorx:288, wmp/BioIso mulx:898, smartscreen rorx:1088, ntdll shlx:28+pdep:14, ucrtbase shlx:30 | **派单未列** — 是 VEX id → 现 gate; 属"VEX 家族"但非 SIMD, 档A 需显式决策 (折叠 or 留 gate) |
| 7 | 加密 VEX | vpclmulqdq/vaesenc/vaesenclast (smartscreen 语料 20823/15853) | OS 安全组件 hash/CRC 路径 | gate (AES-NI 直执行可后议) |
| 8 | EVEX (AVX-512) | vpxorq/vmovdqu64/vfmadd231ps/zmm 系 | onnxruntime EVEX=16667, vcruntime140=67, **ntdll=47, mshtml/diagtrack=47** (OS 组件已含 AVX-512 路径) | zmm 不在面 (派单 §A.1) → gate; E2E 已实证 vprold gate (§3) |
| 9 | vzeroupper | vzeroupper(1477)/vzeroall | 探针 TU **0 条** (v145 不主动插); 真实 DLL 5–151 条; vcruntime140:20 | 档B 语义面 (upper-half dirty/ABI) |
| 10 | FMA (VEX) | vfmadd132/213/231 ps/pd/ss/sd | 探针 TU 0 (默认 /fp:precise 不收缩); ucrtbase vfmadd213sd:216, onnxruntime vfmadd231ps:5921 (intrinsic//fp:fast) | 档B+ 或独立档 (新 VmOp 群, 语义不可拆 mul+add——双舍入分叉) |

**反例逐条**: ① 经典 OS API 层 (d3d11/d3d12/dxgi/dwrite/d2d1/shell32/user32/kernel32/advapi32/ole32/win32u) **全零 VEX** — AVX 不是"新 exe 都有", 是特定负载 (向量数学/哈希/媒体) 才有; ② 老第三方 (D3DX9_*/mfc140d/Chakra) 仍是 x87/SSE 残余 + 零 VEX — 与 416 结论连续; ③ msvcp140_2.dll 预扫阳性但 .pdata 域扫描伪影过大 (SSEleg 56% 明显失真) — 已从引证样本剔除 (方法披露)。

## §2 B.1 频率实测 (样本集 + 方法 + 分母)

### §2.1 探针九宫格 (5 源 × {/Od,/O1,/O2} × {/arch:SSE2,AVX,AVX2} = 45, vcvars64 cl v19.51.36256)

方法: 源码 = fp_loop(浮点数组循环)/dot(点积+整点积)/bits_mix(整数位混合)/scalar_fp(标量浮点链)/intrinsic_avx(按 __AVX__ 宏分派的手写 intrinsic)。**主测量 = `/FAcs` 编译器列表** (TU 本体 ground truth, 排除 CRT 污染) + **capstone .pdata 函数域反汇编** (整 exe 口径) 双路; 预扫字节 (C4/C5/62 出现) 仅作必要条件过滤。代表行 (TU 本体, 指令计数):

| 探针/档位 | legacy SSE | VEX128 | VEX256 | 关键构成 |
|---|---|---|---|---|
| scalar_fp /O2/SSE2 | 46 | 0 | 0 | addss/movss/mulss legacy |
| scalar_fp /O2/AVX | 0 | **38** | 0 | vaddss:8/vmovaps:16/vmovss:5 — 标量全升 VEX |
| fp_loop /O2/SSE2 | 48 | 0 | 0 | mulps/addps/movups legacy |
| fp_loop /O2/AVX | 0 | 45 | 0 | vmulps/vaddps/vmovdqu |
| fp_loop /O2/AVX2 | 0 | 29 | **16** | + ymm 向量化 (vaddps ymm/vmulps ymm) |
| dot /O2/AVX2 | 0 | 66 | **35** | + vinsertf128/vpbroadcastd |
| bits_mix /O2/AVX2 | 0 | 19 | **28** | 整数 ymm (vpaddd/vpaddq/vextracti128) |
| intrinsic_avx /O2/AVX2 | 0 | 77 | **36** | 手写 _mm256_* 直出 |
| intrinsic_avx /Od/AVX2 | 0 | 13 | **16** | **/Od 也产 ymm** (intrinsic 绕优化档) |
| 全 45 列表 x87 | — | — | — | **0 条** (416 结论再证) |
| 全 45 列表 vzeroupper | — | — | — | **0 条** (v145 不主动插) |

### §2.2 真实二进制 (System32 4354 文件 → 预扫阳性 → .pdata 域 capstone 全扫 86 → **49 个 VEX>0**; 密度分母 = .text 域内 .pdata 函数总指令数)

| 二进制 | 总指令 | VEX128 | VEX256 | EVEX | 密度 | 构成判读 |
|---|---|---|---|---|---|---|
| smartscreen.dll | 773k | 9538 | 6217 | 4634 | **2.637%** | 哈希/CRC (vpxor/vpaddd/vpclmulqdq) — intrinsic 为主 |
| ThreatAssessment.dll | 696k | 8835 | 6041 | 808 | 2.255% | 同上指纹 |
| ucrtbase.dll | 237k | 3986 | 229 | 0 | **1.781%** | **VEX.128 标量 FP** (vmulsd/vaddsd/vfmadd213sd) + 数组/串 |
| onnxruntime.dll | 1925k | 1865 | 8990 | **16667** | 1.430% | ML kernel (vfmadd231ps:5921) — ymm/zmm 主场 |
| vcruntime140.dll | 30k | 28 | 260 | 67 | 1.189% | memcpy AVX2/AVX512 变体 + vzeroupper:20 |
| WindowsCodecs.dll | 397k | 201 | 364 | 78 | 0.162% | 图像 SIMD (vpaddw/vpshufb) |
| python314.dll (C:\Python314, MSVC 官建) | 820k | 1400 | 852 | 191 | 0.251% | 第三方运行时指纹 |
| amdhip64_6.dll | 2074k | 432 | 264 | 2 | 0.034% | GPU runtime (vendor) |
| ntdll.dll | 361k | 89 | 62 | **47** | 0.055% | BMI (shlx/pdep) + vpclmulqdq + EVEX 路径 |
| msvcrt.dll (SysWOW64 时代的 64 位版) | 129k | 10 | 62 | 0 | 0.056% | CRT AVX2 mem 变体 |
| d3d11.dll / d3d12.dll / dxgi.dll / dwrite.dll / shell32.dll / user32.dll / KernelBase.dll | — | **0** | **0** | **0** | **0.000%** | 经典 OS API 层无 AVX |

exe 侧 (前 150 个全扫): EEURestart 332 / OneDriveSetup 499 / AsusUpdateCheck 414 (VEX.128 标量 FP 指纹: vmulsd:45/vaddsd:37/vfmadd213sd:26) / ClipUp 338 (**rorx:288 = BMI**) / MRT 189 / GameBarPresenceWriter+GamePanel 110 (纯 CRT AVX2 mem 指纹) / CompMgmtLauncher 68 — 13 个 exe VEX>0。

**分类 (派单 §B.1 三分法)**: 编译器自然产物 = AsusUpdateCheck/EEURestart 类 (/O2+/arch:AVX2 或 CRT 混入); 手写/intrinsic = smartscreen/ThreatAssessment/onnxruntime (vpclmulqdq/vfmadd/vbroadcast 指纹); 运行时库密度 = ucrtbase/vcruntime140/msvcrt + 一切带 `vmovdqu:55+vmovntdq:30` 指纹的静态链 CRT exe。**≥10 个 AVX 产物要求: 实测 49 个, 超额**。

### §2.3 三操作数破坏性分布 (档A 折叠成本核心判决数, .pdata 域 REG-REG 3 地址形)

| 二进制 | 3reg 形态 | dst==src1 (零成本折叠) | dst==src2 (可交换零成本) | **dst 独立 (需前置 Mov)** | reg-mem 形态 |
|---|---|---|---|---|---|
| smartscreen.dll | 10526 | 60.1% | 1.9% | **38.0%** (vpclmulqdq:2553 主导) | 8721 |
| ucrtbase.dll | 1280 | 33.0% | 6.6% | **60.5%** (vmulsd:218/vaddsd:95 — CRT 标量 FP 全 3 地址) | 1686 |
| onnxruntime.dll | 5399 | 42.9% | 3.6% | **53.5%** (vfmadd 系 3 地址本性) | 2059 |
| python314.dll | 861 | 22.9% | 7.3% | **69.8%** (vpxor/vpaddd 清零惯用法) | 637 |
| EEURestart.exe (CRT 主导) | 31 | 71.0% | 3.2% | 25.8% | 42 |

**判读**: 真实 VEX 中 **dst 独立占 26–70%** — "VEX 只是 SSE 加个 v" 的直觉不成立; 但独立 dst 的标准折叠 = 前置一条既有 Op::Mov (dst←src1) 再走既有 2 地址 handler, **算术/位运算/比较族零新 VmOp** (非交换 d==s2 形态 = vsubss xmm2,xmm0,xmm2 类, 需 scratch 或拒绝, 频率未单列——蓝图内开项)。reg-mem 形态 (vaddps xmm1,xmm1,[mem]) 量级与 3reg 同档, 复用 MIT-408 MEM 通路。

### §2.4 id 命名空间 (capstone 语义探针, C4/C5/EVEX 三编码全测)

- **prefix=[0,0,0,0] 对 C4/C5/62 全部成立** → VEX 不走 prefix 数组, lifter 入口前缀闸不触发, 直达 mnemonic switch (派单猜测⑥推翻)
- **id 分裂完全**: addps=10 vs vaddps=760 vs vpaddd=1079 vs vzeroupper=1477 — 无同名复用, 无误配白名单风险 (vaddss=762 不会撞 addss)
- capstone 对 VEX 报 `rex=64` (0x40) 常量 — VEX.RXB 的再利用字段, lifter map_reg 不消费, 无影响 (披露)
- vendored capstone 5 (Python 5.0.7 同核) `x86.h`: X86_INS_* 1525 个, 其中 **X86_INS_V* = 723**; 真实语料 distinct VEX/EVEX mnemonic = 236
- **既有 26 个 SSE id 的 V-对全部存在** (VADDSS..VCOMISD 逐个核验 EXISTS) — 档A 白名单映射表可直接 1:1 生成

## §3 B.2 现状三态实测 (E2E, 全链真跑)

### §3.1 样本与结果

MASM 直写 6 个标记区域 (v145 ml64 AVX/AVX-512VL 助记符全通过), 链接 `build/sdk/wvmp_sdk.lib`, `build/cli/wvmp_cli.exe protect` (标准六 pass 管道, seed 12345) + 原生/保护 stdout+rc 逐字节比对:

| 区域 | 指令 (编码) | 分类预期 | 实测 |
|---|---|---|---|
| vex_vaddps | `vaddps xmm0,xmm0,xmm1` (C5 F0 58 C1, dst==src1) | gate | ✅ "未支持指令 'vaddps'，已跳过" → "触发 C1 gate" |
| vex_ymm | `vpaddd ymm0,ymm0,ymm1` (C4 E1 7D FE C1) | gate | ✅ "未支持指令 'vpaddd'" → C1 gate |
| vex_ymm_rip | `vmovaps ymmword ptr [g],ymm0` (C5 FC 29 05 rel32, VEX.256 rip store) | gate | ✅ "未支持指令 'vmovaps'" → C1 gate |
| vex_mixed | `addss xmm0,xmm1`(白名单) + `vaddps xmm2,xmm0,xmm1`(dst 独立) | 整区域 gate | ✅ C1 gate (白名单成员不救 VEX 邻居) |
| vex_evex | `vprold xmm0,xmm0,1` (EVEX.128.66.0F38 72, AVX-512VL) | gate | ✅ "未支持指令 'vprold'" → C1 gate |
| ctl_addss (正例对照) | `addss xmm0,xmm1` | 真虚拟化 | ✅ **stub=1** ("已生成 1 个入口 stub, .wvmp 节 27395 字节") |

**三态判定: 支持面 (addss) 真虚拟化 / VEX+EVEX 全谱 gate 保持原生 / 无逃逸**。保护后 stdout 逐字节一致、rc=0=0, e2e.sh PASS。stub 总数 1 = 仅正例, 钉死"VEX 区域零 stub" (416 x87 同构验证法)。

### §3.2 新发现 (P2 级): marker_scan kStubWindow 误归属 — printf 形态

本样本 protect 日志出现 `marker_scan: begin@0x506 没有配对的 end（区域被丢弃）`。根因 (源码级定位, marker_scan_pass.cpp:123-136 + scan_core.cpp:pair_regions): E8 调用归属规则 = "目标之后 ≤ kStubWindow(64B) 的第一个 magic"; 本样本 `printf` (RVA 0x1101) 的目标 0x1280 恰落在 begin-stub magic (0x12a8) 前 40B 窗口内 → 被误归属为 begin 调用 → 栈式配对中成为无 end 的幻影 begin (无害丢弃; 真实 5 对 begin/end 全部正确配对, 6 区域全按预期处理)。**已有同族先例**: cl_shift_sample_asm.asm:24 注释记录的 popcnt32_fn 符号贴近窗口形态。风险面: 幻影 begin 若落在某真实 begin/end 之间, 栈式配对会把真实 end 错配给幻影 → **区域错位** (本样本未发生, 幻影在全部真实 begin 之前故无害)。建议: 归属规则加"目标必须指向 stub 入口±少量字节"收紧 (P2, 独立小单, 不阻断本单)。

### §3.3 未覆盖面 (如实披露)

- EVEX zmm (非 VL) 区域未 E2E (vprold 已代表 EVEX 编码族; zmm 槽模型不在面)
- 多线程/异常路径下的 VEX 区域行为未测 (gate 后整函数原生, 与原生执行等价, 风险面=0)
- ymm 区域的 callgate 面: Win64 ABI __m256 按指针传参 (MIT-417 已覆盖 xmm0..3 值传) → callgate **无** ymm 值传需求 (源码+ABI 双证, 蓝图零项)

### §3.4 复现产物 (内嵌, %TEMP% 清理后仍可重建)

关键区域字节 (MASM, 区域内单指令 + NOP 填充, `call ?marker_begin@sdk@wvmp@@YAXXZ` / `?marker_end@...` 包裹, 链接 `build\sdk\wvmp_sdk.lib`):
```
vaddps xmm0,xmm0,xmm1      ; C5 F0 58 C1
vpaddd ymm0,ymm0,ymm1      ; C4 E1 7D FE C1
vmovaps ymmword ptr [g_ymm_dst], ymm0   ; C5 FC 29 05 <rel32> (g_ymm_dst: VEXDATA SEGMENT PAGE 'DATA' 段, PAGE=256B 对齐)
vprold xmm0,xmm0,1         ; EVEX 62 F1 7C 08 72 C0 01 (ml64 v145 直收助记符)
```
复跑命令: `ml64 /c /Fo vex_sample.obj vex_sample.asm && cl /c /Od /Ob0 vex_main.cpp && cl vex_main.obj vex_sample.obj <repo>\build\sdk\wvmp_sdk.lib /Fe:vex_sample.exe` → `scripts/e2e.sh vex_sample.exe` → 预期: 5×"未支持指令 'v*' 已跳过" + stub=1 + PASS。

## §4 B.3 拆单蓝图 (两档分级, 412 标准: 依赖/前置/锚点逐项)

### 档A — VEX.128 折叠进既有 SSE 通路 (M, ≈3–4 天)

| 项 | 内容 | 锚点 (禁拍脑袋依据) |
|---|---|---|
| A-1 lifter 白名单 | 26 个既有 SSE id 的 V-对 case (VADDSS..VCOMISD, 实测全存在) → 复用既有 Op, **零新 VmOp** | MIT-411 (G1-c) andpd/orpd/xorpd 零新 VmOp 折叠先例; 26=既有白名单行数 (GAPS §支持面) |
| A-2 3 地址折叠器 | dst==src1 直走; dst==src2 且可交换 → 交换; dst 独立 → 前置 Op::Mov(dst,src1) (既有 op); 非交换 d==s2 → 决策点 (scratch 槽 v18..v23 双槽临时先例 or 拒) | 折叠成本实测 §2.3 (38–70% dst 独立, 但每条只多 1 个既有 Mov); GAPS C4b 双槽临时 v18..v23 先例 |
| A-3 mem 形态 | vaddss/vaddps xmm,[mem] 等 → 既有 Load+Op 折叠通路 | MIT-408 (C4b) MEM 形态先例 |
| A-4 验收门 | A.1 静态扫描 + A.2 multiseed 影子样本 (vaddss/vaddps/vmovaps 3 函数 MASM 直写, §3.4 同法) + A.3 handler dump 校验 (SSE_HANDLERS 集合不变——零新 handler, A.3 校验对象=既有 handler 不回归) | Agent 身份 §SSE/VMX/AVX 验收门; 415/419 样本登记法 |
| 范围外 (显式) | VEX 整数族 (vpaddd/vpxor/vpand…→ 需 G1b 的 legacy 整数 VmOp 先落, **建议 G1b 与档A 同波或 G1b 先行**); vmul*/vpand V-对同依赖; BMI-GP (rorx/mulx) 不入档A (GP 域, 留 gate, 文档化); FMA 族不入档A (双舍入语义, 新 VmOp 群) | GAPS:153 不支持面 (mul 族/SSE2 整数族/andnps 未支持=档A V-对白名单的镜像); §1 #6/#10 |
| 第一张前置单草案 | `MIT-G6r-A: VEX.128 白名单折叠 (26 V-对 + 3 地址折叠器 + multiseed 影子样本), M` — 无硬前置 (A-2 决策点单内裁), 与 G1b 解耦 (整数族不在内) | — |

### 档B — ymm 256 (L/XL, 不建议立即立项)

| 项 | 内容 | 锚点 |
|---|---|---|
| B-1 kCtxSize | xmm[8]@0x140 (16B/槽) → ymm: 8×32B=0x100 → sizeof 0x1C0→0x240, kCtxSize 0x1C8→0x248; 若 ymm0..15 全槽 (ABI xmm8..15 现本就不跟踪) 16×32B→0x2C8 | runtime.hpp:83-104 (单一来源派生式 MIT-B2 已铺路); E1/380 冻结面评估通道 |
| B-2 新 VmOp | ymm 宽度语义: 选项 (i) aux 宽度复用 (handler movups×2 拆) 零新 op 但 handler 改造面大; (ii) 新 VmOp 群 (~20–30) → **跳表 128→256 扩容为硬前置** (现 91 项用, 余量 37, kVmOpMax=90@vm_op.hpp:528; 与 x87 L0 ~80 op/G7 共享同一扩容单) | GAPS x87 节已预埋扩容议题; vm_op.hpp:528 |
| B-3 CPU 特性检测 | AVX 需 CPUID.1:ECX.AVX[bit28]+OSXSAVE+XGETBV 检测; 不支持机器上保护产物可用性决策 (拒绝保护/降级 ymm gate) — SSE 线无此面 | 新基建, 档B 特有 |
| B-4 vzeroupper 语义 | upper-half 置零 + AVX-SSE transition penalty (性能披露面); 真实频率低 (DLL 5–151 条) | §1 #9 |
| B-5 验收门 | 同 A.1–A.3 + ctx ymm 读回 (影子样本 [ctx_ymm] 行) | 身份 §A.2 |
| 第一张前置单草案 (若立项) | `MIT-G6r-B0: 跳表 128→256 扩容 (kTableEntries + build_dispatch 掩码回归), S~M` — **同时是 x87 L0/G7 的共享前置, 建议独立先落** | GAPS x87 节路线 |

## §5 B.4 路线建议 (数字支撑 + G 线排程对齐)

**核心裁决数**: ① /O2+/arch:AVX2 的 VEX 产出是**全谱性**的 (标量也升 VEX, 先验②) — 客户 "Release 习惯 /arch:AVX2" 时, 其标记算法函数**必含 VEX.128**; ② VEX.128-only 真实产物真实存在 (AsusUpdateCheck 414/414, ClipUp 337/338, ucrtbase 3986/4215 = 95% VEX.128), ymm 集中在向量化热循环与 CRT mem; ③ 现状零逃逸不产坏壳 (§3) — 任何路线的底线安全。

- **(R2) 档A 排波 + 档B 挂评估 — 推荐**: 档A M 级、零新 VmOp、直接覆盖 "/arch:AVX 标量 + /arch:AVX2 VEX.128 部分 + VEX.128-only 客户产物"; 档B 的硬前置 (跳表扩容) 与 x87 L0/G7 共享, 先落扩容单 (`G6r-B0`) 再按 416 R2 模式随 G7 立项评估, **不建议"永久 gate"措辞** (频率数据不支持永久放弃: 真实 ymm 密度 0.01–0.9% 且集中于 memcpy——真需求存在但非当前波)。
- **(R1) 档A+档B 全排波 — 不推荐现在投**: 档B 的 CPU 检测/kCtxSize 冻结面/新 VmOp 群 XL 成本, 对标的 ymm 收益集中在 CRT mem 函数 (不在标记区域) 与向量化热循环; 无独立的"先扩跳表"决策前 R1 与 x87 L0 在扩容单上串行冲突。
- **(R3) 全 gate 文档化 — 回退保留**: 现状已是半 R3, 若档A 被否, 补一单 x87 格式的 "AVX/VEX 全谱 (含 EVEX/BMI-GP) 永久 gate" 文档收口 (S 级, GAPS B.5 文本已备)。
- **G 线排程一句话**: 建议次序 = **G1b (SSE 残余: mul/整数/andnps VmOp) → 档A (V-对白名单, 其中 mul/整数 V-对直接复用 G1b 产物) ∥ MIT-410 (BytecodeCodec, 零文件冲突可并行) → G6r-B0 (跳表扩容, x87/G7/档B 共享) → G7P1 立项时统一裁 ymm+x87 L0**; MIT-423 (G4b 收尾) 不涉本面。
- **每条路线的第一张前置单**: R2→`MIT-G6r-A` (§4); R1→`G6r-B0` 先行 (§4); R3→`AVX gate 文档收口单` (§B.5 文本即其正文)。

## §6 新发现耦合点 (派单 §A 未列)

1. **marker_scan kStubWindow 幻影 begin (P2)**: §3.2 — printf 调用目标落 begin magic 前 64B 窗口即误归属; 潜在区域错位形态未复现但结构上可达; cl_shift 注释已有同族披露。
2. **BMI1/2 是 VEX id (中)**: rorx/mulx/andn/shlx/pdep 在真实二进制高频 (ClipUp 288 条 rorx, smartscreen 1088+90) — 现状 gate 正确, 但它是 **GP 整数** VEX, 档A 文档须显式声明"VEX-GP 不在 SIMD 档A 内", 避免后续误当 SIMD 漏项。
3. **CRT 自身 VEX.128 标量 FP (信息项)**: ucrtbase/LIBCMT 已含 vmulsd/vaddsd/vfmadd213sd — 真实客户 exe 的 CRT 部分执行 VEX; 标记区域通常不含 CRT 函数, 但若客户用 /LTO/内联 CRT helper (如 math) 可能引入; 档A 落地后自动覆盖 vmulsd/vaddsd (V-对在内)。
4. **EVEX 已进 OS 基础组件 (信息项)**: ntdll/mshtml/diagtrack 各 47 条 EVEX (vpclmulqdq/vpxord) — AVX-512 不再是"ML 专属", gate 声明应含 EVEX 全谱 (vprold E2E 已证)。
5. **FMA 双舍入红线 (设计约束)**: vfmadd* 不可拆 mul+add (单舍入语义), 档A/B 均不得用分解实现保真 — 需独立 VmOp 群且只在 /fp:fast 或 intrinsic 产物出现, 优先级可后置但不可"顺手拆"。
6. **派单方数字修正**: X86_INS_V* 723 (非 719); 跳表余量 **37** (kVmOpMax=90 → 91 项已用, 派单 "~38" 近似偏差 1); GAPS.md:194 "kVmOpMax=86 即 87 项" 已 stale (MIT-419 后 90) — B.5 一并修正。

## §7 B.5 GAPS/文档联动 (现状声明精确化草案)

1. **GAPS.md:153 "不支持面" 行追加**: "AVX/VEX 全谱 (C4/C5 前缀, VEX.128/256 + EVEX/AVX-512 + VEX-GP BMI1/2): capstone 报独立 INS id 且不经 legacy prefix 数组 (MIT-G6r 实测), 现状整函数 C1 gate 保持原生、零逃逸、byte-identical (E2E 六区域实证); 路线裁决 = 档A (VEX.128 折叠) 排波 / ymm 挂跳表扩容评估, 详见 .multica/mit-G6r-triage.md"
2. **x86_translate.cpp:1929 注释措辞修正**: "vpxor/vpor/vpand, VEX.NDS.128.0F.WIG 57/56/54" → "vxorps/vorps/vandps, VEX.NDS.128.0F.WIG 57/56/54" (名实对齐; vpxor 系为 VEX.128.66.0F WIG EF/EB/DA)
3. **GAPS.md:194 跳表数字刷新**: kVmOpMax 86→**90** (MIT-419 Btc, vm_op.hpp:528), 91/128 项已用, 余量 37
4. **观察清单转录** (未来触发重评的信号): 客户产物抽样出现 ymm 标记区域 → 提档B; /arch:AVX512 编译习惯出现 → EVEX 档评估; BMI-GP 在客户哈希/乘法热点出现 → 评估 GP-VEX 档 (rorx/mulx 单 VmOp native 直执行与 lock 族同构)
5. **STATUS.md** M3 技术债段 "lifter 持续补指令" 行同步 AVX 现状声明

## §8 结论

✅ **推荐 R2: 档A (VEX.128 折叠, M, 零新 VmOp) 排波, 前置 G1b 更优; 档B (ymm) 不立即、不永久 gate, 以 `G6r-B0` (跳表 128→256, 与 x87/G7 共享) 为 hinge 随 G7 评估; R3 文档收口文本已备作回退。** 全部数字 = 本机实测 (45 列表 + 86 个 .pdata 域全扫 + 49 个 AVX 产物 + 六区域 E2E), 方法/样本/反例逐条披露, 主工作区零写入 (MIT-423 并发在途未扰动), run 对账 50 分钟。

== MIT-G6r triage 完 ==
