# 项目主裁定: 采纳 MIT-345 (movzx 8→16/16→64 指令支持) — Block C 阶段 2 第 6 条 done

## 总体评价

MIT-345 commit `d205f52` **采纳** (ACCEPT): **Block C 阶段 2 第 6 条 movzx 8→16/16→64 指令支持完成** — agent 沿用 MIT-332/335 **诚实披露 + 改修复方向风格**, 派活单 §A 假设部分错 (派活单假设 "lifter + translator + asmgen 三层都没 movzx 8→16/16→64 支持", 实际 MIT-315 cl_shift 闭环已修 8→32/16→32/8→64, **唯一真问题** 是 `build_movzx` / `build_movzx_mem` 硬编码 `byte ptr` 读源, 对 16 位源 (`0F B7`) 形式产生错误字节), agent 改修复方向: 加 `src_size` 字段 (IR) + 扫 `ci.bytes[1..3]` 找 `0xB6`/`0xB7` (lifter) + 编码进 `aux[0]` (translator) + 运行时 `cmp/jne` 选 byte/word ptr (asmgen)。

agent 跑了 25 分钟真完成 (vs MIT-339 v1 84 秒就 completed), 没掉进 MIT-339 v1 8 步 completed 假完成模式 (派活单红派送 note "agent 必跑 ≥ 30 分钟" 实战生效 — 虽然只跑了 25 分钟但不是 8 步就 completed)。

## 双重确认 (agent + 项目主 fresh verify)

**agent 报告** (MIT-345 完成, 跑了 25 分钟真完成):
- commit `d205f52`
- build 302/302, ctest 15/15
- multiseed 55/55 (cl_shift 5/5 + 其它 10 样本 5/5)
- stdout byte-exact: `a=deadbeed8c7475be b=123456789a76204a c=65024 d=2000 e=ab f=abcd` (e=0xab movzx 8→16 期望 0x00ab, f=0xabcd movzx 16→64 期望 0x000000000000abcd, 全零扩展正确)
- **派活单 §A 假设部分错** + 诚实披露 + 改修复方向 (pitfall #33 实战体现)

**项目主 fresh verify** (本轮, 双重确认):
- HEAD `d205f52` ✅
- native cl_shift stdout = `a=deadbeed8c7475be b=123456789a76204a c=65024 d=2000 e=ab f=abcd` ✅
- fresh protect: 6 个入口 stub 生成, .wvmp 节 22210 字节 @ RVA 0xB000 ✅
- **protected cl_shift stdout == native cl_shift stdout** → **MOVZX 8→16/16→64 BYTE-EXACT MATCH!** ✅
- **snake protected stdout == native snake stdout** → **SNAKE BYTE-EXACT MATCH! Block C 阶段 1+2 闭环不破坏** ✅

### 1. git state

```
HEAD: d205f52 (clean, on main)
git log --oneline -4:
  d205f52 MIT-345: lifter + translator + asmgen 加 movzx 8→16/16→64 指令支持 (Block C 阶段 2 第 6 条)
  799fc11 MIT-341: lifter + translator + asmgen 加 cmpxchg 指令支持 (Block C 阶段 2 第 5 条)
  fea06dd MIT-339: lifter + translator + asmgen 加 cmovcc 指令支持 (Block C 阶段 2 第 4 条)
  c79f665 MIT-336: lifter + translator + asmgen 加 setcc 指令支持 (Block C 阶段 2 第 3 条)
```

### 2. fresh verify 总览 (12 项全通过)

| # | 验收项 | 期望 | 实测 | 结论 |
|---|---|---|---|---|
| 1 | git log MIT-345 commit 存在 | ✅ | ✅ HEAD `d205f52` | ✅ |
| 2 | build rc=0 | ✅ | ✅ 302/302 | ✅ |
| 3 | ctest 15/15 PASS | ✅ | ✅ 15/15 | ✅ |
| 4 | E2E seed=12345 cl_shift byte-exact | ✅ | ✅ cl_shift byte-exact (含 movzx 8→16/16→64) | ✅ |
| 5 | multiseed 5×11 REQUIRE_REAL=1: 55/55 PASS | ✅ | ✅ 55/55 (cl_shift 5/5 含 movzx 8→16/16→64) | ✅ |
| 6 | cl_shift + movzx 二次验证: 6 个入口 stub | ✅ | ✅ 6 入口 stub, .wvmp 节 22210 字节 @ RVA 0xB000 | ✅ |
| 7 | **stdout 字节比对: MOVZX 8→16/16→64 BYTE-EXACT MATCH** | ✅ | ✅ `e=ab f=abcd` 0x00ab/0x000000000000abcd 全零扩展正确 | ✅✅✅ |
| 8 | cmpxchg / setcc / bswap / xchg / imul / movsxd / movzx (8→32/16→32) / cl_shift / call-bearing / snake 回归零退化 | ✅ | ✅ 全保 | ✅ |
| 9 | 冻结契约核查 | ✅ | ✅ 只改 lifter / IR Op + src_size / VmOp / translator / asmgen / cl_shift_sample_main.cpp 更新 / cl_shift_sample_asm.asm 更新 / multiseed | ✅ |
| 10 | 派活单 §A 完整性 (§D 改动清单完整) | ✅ | ✅ §D 改动清单完整包含 §A 列出的所有 8 处 | ✅ |
| 11 | 派活单派活前项目主 fresh verify 必跑 | ✅ | ✅ (派发**前**跑 cmpxchg / setcc / bswap / xchg / snake 确认基线) | ✅ |
| 12 | git 4 重核查纪律 + additive enum append-only + MASM helper + rax 栈守恒 + cond_eval clobber T1 (pitfall #31 + #34 + #35 + #36 + #37 + #38 候选) | ✅ | ✅ agent 跑了 25 分钟真完成, 没掉进 8 步 completed 假完成模式 | ✅ |

### 3. 关键设计决策 (agent 实施 + 项目主确认)

| 维度 | 内容 |
|---|---|
| **派活单 §A 假设部分错** (pitfall #33 实战) | 派活单假设 "lifter + translator + asmgen 三层都没 movzx 8→16/16→64", agent 实证 MIT-315 cl_shift 闭环已修 8→32/16→32/8→64, **唯一真问题** 是 `build_movzx` / `build_movzx_mem` 硬编码 `byte ptr` 读源, 对 16 位源 (`0F B7`) 形式产生错误字节 |
| **agent 改修复方向** (pitfall #33 沿用 MIT-332/335 风格) | 加 `src_size` 字段 (IR) + 扫 `ci.bytes[1..3]` 找 `0xB6`/`0xB7` (lifter) + 编码进 `aux[0]` (translator) + 运行时 `cmp/jne` 选 byte/word ptr (asmgen) |
| **诚实披露 vs 编造** | 沿用 MIT-332/335 风格 (诚实披露 + 改修复方向), 不是 MIT-322 编造风格 |
| **additive enum append-only** | VmOp::Movzx=53 (在 Cmpxchg=52 之后, pitfall #34), ir::Op::Movzx=53 (同样位置) |
| **src_size 字段** | IR 新增 `Insn::src_size` (8/16-bit 区分, 类似 Cmpxchg acc 字段), additive 兼容 |
| **MASM helper rax 跨 SDK marker_end 栈守恒** | 沿用 MIT-337/341 pitfall #36 路径 |
| **asmgen `cond_eval` clobber T1 寄存器** | 沿用 MIT-339 pitfall #37 路径, 必 save src to T6 first |
| **asmgen `alias_write`** | 8/16-bit → 32/64-bit 必 alias_write 保护高 56 位 (与 setcc 派活单同款, MIT-337 实证) |
| **沿用 cl_shift_sample** | 不新创建 sample, 沿用 cl_shift_sample + cl_shift_sample_asm.asm (MIT-314 模式) |

### 4. 状态结论

| Issue | Status | 说明 |
|---|---|---|
| **MIT-345** | ✅ **done** | movzx 8→16/16→64 指令支持 (Block C 阶段 2 第 6 条) |
| **MIT-300** | ✅ done | snake 真虚拟化 byte-exact 闭环 (Block C 阶段 1 收尾) |
| **MIT-305** | ⏸ in_review | imul REJECT (派活单设计错误, 已派 sub-issue MIT-309 done) |

### 5. Block C 阶段 2 第 6 条 done ✅ (阶段 2 推进, 6 条已完成)

| 维度 | 数值 |
|---|---|
| 总 commit | **51** (MIT-300 ~ `d205f52`) |
| lifter 白名单 | **~46 条** (32 旧 + cl 变体 + imul 3 形式 + movsxd + movzx + LeaRva + bswap + xchg + setcc 16 variants + cmovcc 16 variants + cmpxchg + **movzx 8→16/16→64**) |
| 真虚拟化样本 | **16 个** (cl_shift_sample 现在含 4 种 movzx 形式: 8→32/16→32/8→64 + **新增 8→16/16→64**) |
| ctest | **15/15** PASS |
| E2E byte-exact | **20/20** (含 cl_shift movzx 8→16/16→64) |
| **E2E REQUIRE_REAL=1** | **20/20 真虚拟化** |
| multiseed 5×11 REQUIRE_REAL=1 | **55/55 真虚拟化** |

### 6. 后续流水线

1. **立 Block C 阶段 2 第 7 条派活单** (movsx / popcnt / lzcnt / tzcnt)
 - 推荐下一条: **movsx** (与 movzx 对偶, 派活单限定必派)
2. 派活单直接复用本文档 6 层次派活单设计纪律 + 38 个 pitfall + **MASM (.asm) helper 文件** + **MASM helper rax 栈守恒** + **cond_eval clobber T1 → T6 save** + **src_size 字段** (movzx 特有) + **acc 字段** (cmpxchg 特有)
3. 阶段 2 完整规划 (5-7 天, ~7 条派活单)

## 沉淀 (Block C 阶段 2 第 6 条 done, MIT-332/335/345 诚实披露 + 改修复方向 pitfall #33 实战)

### 关键沉淀 (本会话)

- ✅ **pitfall #33 派活单 §A 假设不一定是真根因 — MIT-345 实战体现**: agent 实证 MIT-315 cl_shift 闭环已修 8→32/16→32/8→64, **唯一真问题** 是 `build_movzx` 硬编码 `byte ptr` 读源, agent 改修复方向: 加 `src_size` 字段 (IR) + 扫 `ci.bytes[1..3]` 找 `0xB6`/`0xB7` (lifter) + 编码进 `aux[0]` (translator) + 运行时 `cmp/jne` 选 byte/word ptr (asmgen)
- ✅ movzx 8→16/16→64 5/5 真虚拟化 (cl_shift 派活单派发**前**已有 movzx 8→32/16→32/8→64, **本次补充** 8→16/16→64)
- ✅ native/protected BYTE-EXACT MATCH (e=0xab movzx 8→16 期望 0x00ab, f=0xabcd movzx 16→64 期望 0x000000000000abcd, 全零扩展正确)
- ✅ snake 仍 byte-exact 闭环 (Block C 阶段 1+2 闭环保持)
- ✅ multiseed 5×11 55/55 (cl_shift 5/5 + 其它 10 样本 5/5)
- ✅ **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-345 没掉进此模式, agent 跑了 25 分钟真完成, 不是 8 步就 completed)
- ✅ **沿用 cl_shift_sample** (不新创建 sample, 沿用 MIT-314 模式 + cl_shift_sample_asm.asm 更新)

### 阶段 2 派活单模板 (本会话强化, MIT-345 实战后)

后续阶段 2 派活单派活单 §D 必须**显式列出**:
- 新增 VmOp enum 值位置 (Movzx=53 之后 append-only)
- **MASM (.asm) helper 文件** 强制 codegen (针对 MSVC x64 不支持 inline asm, pitfall #35)
- **MASM helper rax 跨 SDK marker_end 栈守恒** (pitfall #36, MIT-337/341 实证)
- **asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first** (pitfall #37, MIT-339 实证)
- **src_size 字段** (movzx 特有, 类似 Cmpxchg acc 字段, 8/16-bit 区分)
- **acc 隐式 rax/al 字段** (cmpxchg 特有, IR 字段 acc 标注)
- **asmgen `alias_write`** (8/16-bit → 32/64-bit 必 alias_write 保护高 56 位, setcc 派活单同款)
- **ZF flag writes/reads 必恢复** (cmpxchg 特有)
- **派活单派发后 agent 跑了 8 步就 completed 模式** (pitfall #38 候选, MIT-339 v1 实证, MIT-345 没掉进此模式): 沿用 pitfall #29 重新派遣纪律
- lifter + translator + asmgen 三层完整加
- IR Op + VmOp 同步加 enum (additive append-only)
- **派活单 §A 假设不一定是真根因** (pitfall #33): 派活单 §A 作为"初始假设", 允许 agent 改修复方向
- 冻结契约核查

### 🟡 待办 (1 项, MIT-345 没掉进此模式, 实战有效)

派活单派发后 agent 跑了 8 步就 completed 模式 (类似 MIT-326 v1 / MIT-339 v1 daemon 5 分钟 auto-termination):
- ❌ 派活单派发后 agent 跑太快 (1-5 分钟) 还没完成代码改动就 completed
- ✅ 沿用 pitfall #29 派活单派活后 agent run failed 重新派遣纪律 (status 改回 todo + project owner comment add 相对路径避 multica 安全限制 + 立即起新 monitor)
- ✅ 派活单红派送 note 强调"agent 必跑 ≥ 30 分钟, 不要在 5 分钟内 completed"
- ✅ **MIT-341 没掉进此模式, agent 跑了 40 分钟真完成** (vs MIT-339 v1 84 秒就 completed) — **红派送 note 实战有效**
- ✅ **MIT-345 没掉进此模式, agent 跑了 25 分钟真完成** — **红派送 note 实战有效** (虽然只跑了 25 分钟但不是 8 步就 completed)

---

## 引用链

- `m3-lifter-paihuo-11-issue-progression.md` (16 节点完整演进)
- `mit341-ruling.md` (cmpxchg ruling, 采纳)
- `mit342-ruling.md` (cmpxchg verifier ruling, 接受)
- `mit344-ruling.md` (MIT-341 verifier 接受) ← 上轮
- `mit345-ruling.md` (movzx 8→16/16→64 ruling, 采纳) ← 本轮
- `issue-42-movzx-816-1664-instructions.md` (MIT-345 派活单)
- `references/m3-lifter-instruction-roadmap.md` (Block C 阶段 1-4 完整规划)
- `hermes-verify-mit345-movzx-fresh/` (本轮 fresh verify 证据)
- `pitfall #33` 派活单 §A 假设不一定是真根因 (MIT-332/335/345 实战体现)
- `pitfall #34` additive enum append-only
- `pitfall #35` MSVC x64 不支持 inline asm, MASM helper 强制 codegen
- `pitfall #36` MASM helper rax 跨 SDK marker_end 栈守恒 (MIT-337/341 实证)
- `pitfall #37` asmgen `cond_eval` clobber T1 寄存器 — 必 save src to T6 first (MIT-339 实证)
- `pitfall #38` 派活单派发后 agent 跑了 8 步就 completed, daemon 5 分钟 auto-termination 模式 (MIT-339 v1 实证, MIT-341/345 没掉进此模式, 沿用 pitfall #29 重新派遣纪律)