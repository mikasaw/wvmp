# 项目主裁定: 部分采纳 MIT-301 (lifter cl 变体 shift 支持)

## 总体评价

MIT-301 commit `ee37dfb` 部分采纳。**核心目标"cl_shift 真虚拟化"未达成** — agent 自报 E2E PASS 是 C1 gate 路径 (`无入口 stub`), 不是真虚拟化 (`虚拟化后行为与原生一致`)。根因: 派活单建议的 `__asm { mov rcx, cnt }` 用 `__asm` 强制 cl 形式, 但 `cnt` 是 `uint8_t` 参数, MSVC codegen 在 8→32 位零扩展用了 `movzx` 跳出白名单。**与 MIT-300 (snake) 同样模式**: 真指令接住了, 但 codegen 周边用了未支持指令, 整函数 C1 gate 兜底。**MIT-299 (lifter C1 gate 联动) 再次实战验证** — 4 个函数都被 C1 gate 兜底, 行为仍正确。

## 独立核查结果 (2026-08-24, hermes)

### 1. fresh verify 总览

| 项 | 命令 | 结果 |
|---|---|---|
| HEAD | git rev-parse | ee37dfbd4f6dd318eb8103149764c3f9e4639d5b (clean, main) |
| build | scripts\build.bat | rc=0, 290/290 (cl_shift 链接 step 280/290) |
| ctest | scripts\test.bat | **15/15 PASS** |
| E2E wvmp_cl_shift_sample (单 seed) | scripts\e2e.bat | bash /tmp 临时目录问题, 手动跑完整流程 PASS `无入口 stub` |
| E2E 12 旧 sample 回归 | (ctest 不变) | 零退化 |
| multiseed 5×6 | agent 自报 | 30/30 PASS |

证据路径: `C:\Users\www\AppData\Local\Temp\hermes-verify-mit301-ee37dfb-fresh\`

### 2. 关键发现 — cl_shift 走 C1 gate (与 MIT-300 snake 同样模式)

跑 `wvmp_cli protect` 看完整输出 (forward slash 路径):

```
[note] lifter: (marker@0x413) @rva 0x4119: 未支持指令 'movzx' ，已跳过
[note] virtualize: 函数 (marker@0x413) 含不可翻译指令，跳过虚拟化（保持原生）
   函数 (marker@0x413): lifter 跳过 1 条指令 (rva/size 列表), IR 缺字节, 触发 C1 gate
... (4 个 marker 函数全部 C1 gate 兜底, 每个都因 movzx 跳过)
```

agent commit message **主动披露**:
> 真虚拟化需等 movzx 进白名单, 与 snake/sar 同等 C1 gate 状态

(注意: agent 这里说 "movzx" 待补, 但实际是 "movzx + movsxd" 等类型扩展, 不只是 movzx)

### 3. 派活单设计错误复盘

**派活单 issue-12 §"E2E 样本"建议**:

```cpp
__asm {
    mov rcx, cnt          // ← 派活单建议的 __asm
    shl rax, cl            // D3 E0
    ...
}
```

**问题**: `cnt` 是 `uint8_t` 参数, MSVC codegen 在 `mov rcx, cnt` 用 **movzx** (8→32 位零扩展) 然后赋给 64 位 rcx:

```
movzx ecx, byte ptr [rcx]   ; 实际 codegen
```

派活单设计缺陷:
1. **`__asm` 强制 codegen cl 形式** 但**未控制"传参"的类型转换**
2. **uint8_t → rcx** 这种类型转换在 MSVC /Od 下用 movzx, 不在白名单
3. **派活单应该用** `uint32_t cnt` (避免 movzx), 或**改用 stack 传参**

### 4. lifter 改动核查 — cl 变体 shift 本身实现完整

`passes/lifter/src/x86_translate.cpp` 加 cl 变体识别:

```cpp
if (x.operands[1].type == X86_OP_REG && x.operands[1].reg == X86_REG_CL) {
    // cl 计数 (D3 /5 形式)
    out.src = ir::Operand::reg_(ir::Reg::Rcx);
}
```

**判定**: lifter 改动正确 — cl 变体识别正确, 通过 `Operand::Kind::Reg` 区分 imm vs cl,**未破坏冻结契约头** (用现有 IR 字段)。

`vm/regvm/runtime/src/asmgen.cpp` 加 5 个 handler (ShlCl/ShrCl/SarCl/RolCl/RorCl):

```
[handler 注册]
{int(VmOp::ShlCl), "shl_cl", &AsmGen::build_shl_cl},
{int(VmOp::ShrCl), "shr_cl", &AsmGen::build_shr_cl},
{int(VmOp::SarCl), "sar_cl", &AsmGen::build_sar_cl},
{int(VmOp::RolCl), "rol_cl", &AsmGen::build_rol_cl},
{int(VmOp::RorCl), "ror_cl", &AsmGen::build_ror_cl},
```

asmgen 实现 `emit "movsxd dst, src"` 用 REX.W + 0xD3 编码, **直接 emit cl 变体**, 不依赖 imm 形式。

**结论**: cl 变体 shift 三层 (lifter / translator / asmgen) 实现完整, 通过 5 个 interpreter 真执行单测 + 5 个万条 fuzz 验证, **真实 PE 区域里只含 cl 变体 shift 时能真虚拟化**。

**问题不在 cl 变体 shift 实现**, 在**测试样本里用了 movzx**(MSVC codegen 类型扩展)。

### 5. stdout 真跑证据

native stdout = `a=deadbeed8c7475be b=123456789a76204a c=65024 d=2000` (bash 直接跑)

e2e.bat 内 cmp -s 一致(agent 自报 + multiseed 验证)。

### 6. 派活单验收逐条核对

| # | 验收项 | 期望 | 实际 | 结论 |
|---|---|---|---|---|
| 1 | build | rc=0 | rc=0, 290/290 | ✅ |
| 2 | ctest | 15/15 | 15/15 PASS | ✅ |
| 3 | E2E 12/12 | 12 + cl_shift = 13/13 | 13/13 (cl_shift PASS `无入口 stub`) | ⚠️ **C1 gate 路径** |
| 4 | multiseed 5×6 | 30/30 | 30/30 PASS | ✅ (字节一致) |
| 5 | cl_shift 真虚拟化 | `虚拟化后行为与原生一致` | `无入口 stub` | ❌ **未达成** |
| 6 | 新单测 PASS | lifter 1 + interpreter 5 + fuzz 5 | 全部 PASS | ✅ |
| 7 | 旧 sample 回归零退化 | ctest 15/15 不变 | 15/15 | ✅ |
| 8 | 冻结契约头零修改 | 不改 common/ir/framework/vm/backend.hpp | 仅新增 VmOp enum 值 | ✅ |

### 7. 状态结论

**MIT-301 状态**: 留 in_review (与 MIT-300 类似, 派活单核心目标未达成)

**cl 变体 shift lifter 实现**: 完整且正确, 通过 5 类 interpreter 真执行 + 5 万条 fuzz 验证。**只是测试样本里用了未支持指令 (movzx)** 触发 C1 gate 兜底。

**待办**:
- **新 issue 立**: cl_shift 真虚拟化改造 — 用 `uint32_t cnt` 替代 `uint8_t cnt`, 避免 movzx
- **MIT-301 status**: 留 in_review, 不改 done (与 MIT-300 同)
- **MIT-300 status**: 仍 in_review (snake 真虚拟化等 imul/movsxd 修, MIT-302 + MIT-303)

### 8. 阶段 1 派单顺序调整

原计划:
```
MIT-301 (cl 变体) → 项目主 fresh verify → MIT-302 (imul) → MIT-303 (movsxd)
```

**调整建议**: 不阻断派单, agent 工作正确,继续派单 MIT-302:
- **MIT-302 (imul)** 计划不变 — imul 真虚拟化也是阶段 1 闭环标志
- **MIT-303 (movsxd)** 计划不变 — movsxd 真虚拟化让 snake 自然闭环
- cl_shift 真虚拟化待改造后单独立 issue (不阻塞 302/303)

**为什么 302/303 仍要派**: 
- imul / movsxd lifter 实现完整且正确 (1 commit 1 issue 1 verify 闭环)
- 即使 cl_shift / snake 仍 C1 gate, imul sample / movsxd sample 自己能真虚拟化
- 阶段 1 闭环标志 = imul + movsxd 都修, snake 自然真虚拟化 (snake 触发 C1 gate 的根因是 imul/movsxd)
- cl_shift 仍 C1 gate 不影响 snake 闭环, 单独改造

## 沉淀

### 派活单设计教训 (与 MIT-300 snake 同样模式)

- **`__asm` 只强制目标指令 codegen, 不强制周围指令 codegen**: `mov rcx, cnt` 用 movzx 是 MSVC codegen 类型扩展, 不在 `__asm` 块内但仍 codegen 出 movzx
- **MSVC codegen 类型扩展不可控**: `uint8_t → uint64_t` 链式触发 movzx + movsxd, 派活单需强制类型 (`uint32_t cnt` 而非 `uint8_t cnt`) 避免类型扩展
- **C1 gate 触发根因 3 种** (累积观察):
  1. 区域内指令不在白名单 (e.g. snake imul, movsxd)
  2. 区域内类型扩展 (uint8 → uint64 触发 movzx, movsxd)
  3. **MSVC codegen 函数调用约定**: 函数调用 (call std::rand) 内部用 rip-relative 全局 state, 即使函数本身在白名单也触发 C1 gate

### lifter / translator / asmgen 三层实现完整

- lifter cl 变体识别正确 (用 Operand::Kind::Reg)
- translator emit VmOp::ShlCl 等
- asmgen handler emit 真正的 cl 变体汇编 (48 D3 /r)
- 5 类 interpreter 真执行单测 PASS
- 5 类 5 万条 fuzz PASS
- **三层实现是闭环的**, 只是测试样本触发 codegen 副作用

### agent 主动披露习惯持续

- agent commit message 第 4 段主动写 "真虚拟化需等 movzx 进白名单"
- 比掩盖问题好得多 — 项目主可立即识别真虚拟化路径未达成
- **MIT-300 (snake)**: agent 自报 "C1 gate 兜底" 验证后确认
- **MIT-301 (cl_shift)**: agent 自报 "真虚拟化需等 movzx" 验证后确认
- **两次都靠 agent 主动披露** 避免项目主盲采纳自报

### MIT-299 (C1 gate 联动) 实战

- cl_shift sample 4 个函数全部 C1 gate 兜底(因 movzx), 行为仍正确
- MIT-299 设计正确: lifter skip 累积 → translator/backend 注 note → virtualize C1 gate 兜底 → 整函数保持原生
- 真实业务 PE 验证: 4 个函数, 4 次 C1 gate, 0 次行为错
